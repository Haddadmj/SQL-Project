import options

type
  CmdInput* = object
    env*: string
    operation*: string
    product*: Option[string]
    catalog*: Option[string]
    app*: Option[string]
    global*: Option[string]
    consumer_org*: Option[string]

type 
  Product* = object
    name*: string
    url*: string

type 
    Catalog* = object
      name*: string
      path*: string

type
    UserData* = object
      name*: string
      pass*: string

type
    Context* = object
        env*: string
        server*: string
        org*: string
        realm*: string
        catalogs*: seq[Catalog]

type
    Props* = object
        userdata*: UserData
        environments*: seq[Context]

type
  App* = object
    name*: string
    consumer*: string

type 
  GPAssign* = enum
    PREHOOK, POSTHOOK, ERROR

type
  LStatus* = enum
    LOGOUT, LOGIN, DONOTHING, DOBOTH