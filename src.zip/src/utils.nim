import types, parseopt, options, strformat, strutils

proc getCmdInput*(): CmdInput = 
    var opt = initOptParser()
    var env, operation = ""
    var product, catalog, app, global, consumer_org = none(string)
    for kind, key, value in opt.getOpt():
      case kind
      of cmdArgument:
        operation = key
      of cmdLongOption, cmdShortOption:
        case key
        of "env", "e": env = value
        of "product", "p": product = some(value)
        of "catalog", "c": catalog = some(value)
        of "app", "a": app = some(value)
        of "global", "g": global = some(value)
        of "corg", "m": consumer_org = some(value)
      else: continue
    
    doAssert env != ""
    return CmdInput( env: env, product: product, catalog: catalog, app: app, global: global, consumer_org: consumer_org, operation: operation )

proc productPath*(context: Context, catalog: Catalog): string =
    return fmt"{catalog.path}/{context.env}/{catalog.name}/Products/"

proc globalPolicyPath*(context: Context, catalog: Catalog): string =
    return fmt"{catalog.path}/{context.env}/{catalog.name}/Global Policies/"

proc selectContext*(cmd_input: CmdInput, props: Props): Context =
  var context = none(Context)
  for e in props.environments:
    if e.env == cmd_input.env:
      context = some(e)
  doAssert context.isSome
  return context.get()

proc colonForm*(product: string): string =
  let product_name = product.split('_')[0]
  var product_qualified_name = product_name & ':' & product.split('_')[1]
  product_qualified_name.removeSuffix(".yaml")
  result = product_qualified_name