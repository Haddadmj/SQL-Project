import strformat, os, strutils, options, types, utils, osproc, apic_helpers, tables

proc subscribeToAllProducts*(useropts: UserData, context: Context, props: Props, cmd_input: CmdInput) =
  doAssert cmd_input.catalog.isSome
  doAssert cmd_input.app.isSome
  var catalog = none(Catalog)
  for c in context.catalogs:
    if c.name == cmd_input.catalog.get():
      catalog = some(c)
    
  doAssert catalog.isSome
  doAssert cmd_input.consumer_org.isSome

  login(context, useropts)
  
  let published_products = listPublishedProductsIterable(context, catalog.get())

  for product in published_products:
    createSubscription(context, product.url, "default-plan", catalog.get(), cmd_input.app.get(), cmd_input.consumer_org.get())
    
  logout(context)

proc subscribeFromAllApps*(useropts: UserData, context: Context, props: Props, cmd_input: CmdInput) =
  doAssert cmd_input.catalog.isSome
  doAssert cmd_input.product.isSome
  var catalog = none(Catalog)
  for c in context.catalogs:
    if c.name == cmd_input.catalog.get():
      catalog = some(c)
    
  doAssert catalog.isSome
  
  login(context, useropts)

  let consumer_orgs = listConsumerOrgs(context, catalog.get())
  let apps = listApps(context, catalog.get(), consumer_orgs)
  let product = findProduct(context, catalog.get(), cmd_input.product.get())

  doAssert product.isSome

  createSubscriptionFromAllApps(context, product.get().url, "default-plan", catalog.get(), apps)
  logout(context)

proc deployGlobalPolicy*(useropts: UserData, context: Context, props: Props, cmd_input: CmdInput, assign: GPAssign, lstatus: LStatus = LStatus.DOBOTH) = 
  doAssert cmd_input.catalog.isSome
  doAssert cmd_input.global.isSome
  var catalog = none(Catalog)
  for c in context.catalogs:
    if c.name == cmd_input.catalog.get():
      catalog = some(c)
  
  doAssert catalog.isSome
  
  if lstatus == LStatus.LOGIN or lstatus == LStatus.DOBOTH:
    login(context, useropts)

  let gateways = listConfiguredGateways(context, catalog.get())

  var selection = 0
  if gateways.len > 1:
    echo fmt"Target gateway:"
    for i, gw in gateways:
      echo fmt"[{i}]: {gw}"
    selection = parseInt(readLine(stdin))

  let global_policy_path = globalPolicyPath(context, catalog.get())
  echo &"apic global-policies:create --catalog {catalog.get().name} --configured-gateway-service {gateways[selection]} --org {context.org} --server {context.server} --scope catalog \"{global_policy_path & cmd_input.global.get()}\""
  doAssert 0 == execShellCmd(&"apic global-policies:create --catalog {catalog.get().name} --configured-gateway-service {gateways[selection]} --org {context.org} --server {context.server} --scope catalog \"{global_policy_path & cmd_input.global.get()}\"")
  doAssert 0 == execShellCmd(&"apic global-policies:get --catalog {catalog.get().name} --configured-gateway-service {gateways[selection]} --org {context.org} --server {context.server} --scope catalog {colonForm(cmd_input.global.get())} --fields url")
  let global_policy = readFile("GlobalPolicy.yaml").replace("url", "global_policy_url")
  writeFile("GlobalPolicy.yaml", global_policy)
  case assign
  of GPAssign.PREHOOK:
    doAssert 0 == execShellCmd(&"apic global-policy-prehooks:create --catalog {catalog.get().name} --configured-gateway-service {gateways[selection]} --org {context.org} --server {context.server} --scope catalog GlobalPolicy.yaml")
  of GPAssign.POSTHOOK:
    doAssert 0 == execShellCmd(&"apic global-policy-posthooks:create --catalog {catalog.get().name} --configured-gateway-service {gateways[selection]} --org {context.org} --server {context.server} --scope catalog GlobalPolicy.yaml")
  of GPAssign.ERROR:
    doAssert 0 == execShellCmd(&"apic global-policy-errors:create --catalog {catalog.get().name} --configured-gateway-service {gateways[selection]} --org {context.org} --server {context.server} --scope catalog GlobalPolicy.yaml")
  
  removeFile("GlobalPolicy.yaml")

  if lstatus == LStatus.LOGOUT or lstatus == LStatus.DOBOTH:
    logout(context)

proc deployPrehookGlobalPolicy*(useropts: UserData, context: Context, props: Props, cmd_input: CmdInput) =
  deployGlobalPolicy(useropts,context,props,cmd_input, GPAssign.PREHOOK)

proc deployPosthookGlobalPolicy*(useropts: UserData, context: Context, props: Props, cmd_input: CmdInput) =
  deployGlobalPolicy(useropts,context,props,cmd_input, GPAssign.POSTHOOK)

proc deployErrorGlobalPolicy*(useropts: UserData, context: Context, props: Props, cmd_input: CmdInput) =
  deployGlobalPolicy(useropts,context,props,cmd_input, GPAssign.ERROR)

proc deploy*(useropts: UserData, context: Context, props: Props, cmd_input: CmdInput) =
  doAssert cmd_input.catalog.isSome
  doAssert cmd_input.product.isSome
  var catalog = none(Catalog)
  for c in context.catalogs:
    if c.name == cmd_input.catalog.get():
      catalog = some(c)
    
  doAssert catalog.isSome

  login(context, useropts)

  let consumer_orgs = listConsumerOrgs(context, catalog.get())
  let apps = listApps(context, catalog.get(), consumer_orgs)
  let product = findProduct(context, catalog.get(), cmd_input.product.get())

  if product.isSome:
    discard execShellCmd(fmt"apic products:delete --id --scope catalog --org {context.org} --server {context.server} --catalog {catalog.get().name} {product.get().url.rsplit('/', maxsplit=1)[1]}")

  let product_path = productPath(context, catalog.get())
  echo &"apic products:publish --catalog {catalog.get().name} --server {context.server} --org {context.org} \"{product_path & cmd_input.product.get()}\""
  let publish_stdout = execProcess(&"apic products:publish --catalog {catalog.get().name} --server {context.server} --org {context.org} \"{product_path & cmd_input.product.get()}\"")
  echo publish_stdout
  let published_prod_url = publish_stdout.split(']', maxsplit=1)[1].strip()
  createSubscriptionFromAllApps(context, published_prod_url, "default-plan", catalog.get(), apps)

  logout(context)

proc deployAllLocal*(useropts: UserData, context: Context, props: Props, cmd_input: CmdInput, lstatus: LStatus = LStatus.DOBOTH) =
  doAssert cmd_input.catalog.isSome
  var catalog = none(Catalog)
  for c in context.catalogs:
    if c.name == cmd_input.catalog.get():
      catalog = some(c)
    
  doAssert catalog.isSome
  
  let product_path = productPath(context, catalog.get())
  
  var products: seq[tuple[path: string, name: string]] = @[]
  for kind, path in walkDir(product_path, relative=true):
    products.add (fmt"{product_path & path}", path )
  
  if lstatus == LStatus.LOGIN or lstatus == LStatus.DOBOTH:
    login(context, useropts)

  let published_products = listPublishedProductsQueryable(context, catalog.get())
  let consumer_orgs = listConsumerOrgs(context, catalog.get())
  let apps = listApps(context, catalog.get(), consumer_orgs)

  for product in products:
    if published_products.hasKey(colonForm(product.name)):
      discard execShellCmd(fmt"apic products:delete --scope catalog --org {context.org} --server {context.server} --catalog {catalog.get().name} --id {published_products[colonForm(product.name)].url.rsplit('/', maxsplit=1)[1]}")
    
    let publish_stdout = execProcess(&"apic products:publish --catalog {catalog.get().name} --server {context.server} --org {context.org} \"{product.path}\"")
    echo publish_stdout
    let published_prod_url = publish_stdout.split(']', maxsplit=1)[1].strip()
    createSubscriptionFromAllApps(context, published_prod_url, "default-plan", catalog.get(), apps)
    
  if lstatus == LStatus.LOGOUT or lstatus == LStatus.DOBOTH:
    logout(context)

proc doEverything*(useropts: UserData, context: Context, props: Props, cmd_input: CmdInput) =
  login(context, useropts)
  for c in context.catalogs:
      deployAllLocal(useropts, context, props, cmd_input, LStatus.DONOTHING)
      let global_policy_path = globalPolicyPath(context, c)
      for kind, path in walkDir(global_policy_path, relative=true):
        if path.contains("input-gp"):
          deployGlobalPolicy(useropts, context, props, cmd_input, GPAssign.PREHOOK, LStatus.DONOTHING)
        if path.contains("output-gp"): 
          deployGlobalPolicy(useropts, context, props, cmd_input, GPAssign.POSTHOOK, LStatus.DONOTHING)
        if path.contains("error-gp"): 
          deployGlobalPolicy(useropts, context, props, cmd_input, GPAssign.ERROR, LStatus.DONOTHING)
  logout(context)