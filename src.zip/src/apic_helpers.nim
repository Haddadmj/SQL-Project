# everything here assumes it'll be called after login

import strformat, strutils, types, os, options, utils, tables

proc login*(context: Context, useropts: UserData): void =
    echo (&"apic login --server {context.server} --username {useropts.name} --password \"{useropts.pass}\" --realm {context.realm}")
    doAssert 0 == execShellCmd(&"apic login --server {context.server} --username {useropts.name} --password \"{useropts.pass}\" --realm {context.realm}")

proc logout*(context: Context): void =
  doAssert 0 == execShellCmd(fmt"apic logout --server {context.server}")

proc listPublishedProductsIterable*(context: Context, catalog: Catalog): seq[Product] =
  discard execShellCmd(fmt"apic products:list-all --org {context.org} --scope catalog --server {context.server} --catalog {catalog.name} | findstr published > published.txt")
  var published_products: seq[Product] = @[]
  for line in lines "published.txt":
    let name = line.split(' ')[0]
    let url = line.split(']')[1].strip()
    doAssert name.contains(':')
    doAssert url.startsWith("https://")
    published_products.add Product( name: name, url: url )
  
  removeFile("published.txt")
  result = published_products

proc listPublishedProductsQueryable*(context: Context, catalog: Catalog): Table[string, Product] =
  discard execShellCmd(fmt"apic products:list-all --org {context.org} --scope catalog --server {context.server} --catalog {catalog.name} | findstr published > published.txt")
  var published_products = initTable[string, Product]()
  for line in lines "published.txt":
    let name = line.split(' ')[0]
    let url = line.split(']')[1].strip()
    doAssert name.contains(':')
    doAssert url.startsWith("https://")
    published_products[name] = Product( name: name, url: url )
  
  removeFile("published.txt")
  result = published_products

proc createSubscription*(context: Context, url: string, plan: string = "default-plan", catalog: Catalog, app: string, consumer_org: string): void =
    let subscribe = fmt"""product_url: {url}
plan: {plan}"""
    writeFile("subscribe.txt", subscribe)
    echo fmt"apic subscriptions:create --server {context.server} --org {context.org} --catalog {catalog.name} --consumer-org {consumer_org} --app {app} subscribe.txt"
    discard execShellCmd(fmt"apic subscriptions:create --server {context.server} --org {context.org} --catalog {catalog.name} --consumer-org {consumer_org} --app {app} subscribe.txt")          
    removefile("subscribe.txt")

proc createSubscriptionFromAllApps*(context: Context, url: string, plan: string = "default-plan", catalog: Catalog, apps: seq[App]): void =
    let subscribe = fmt"""product_url: {url}
plan: {plan}"""
    writeFile("subscribe.txt", subscribe)
    for app in apps:
      discard execShellCmd(fmt"apic subscriptions:create --server {context.server} --org {context.org} --catalog {catalog.name} --consumer-org {app.consumer} --app {app.name} subscribe.txt")          
    removefile("subscribe.txt")

proc listApps*(context: Context, catalog: Catalog, consumer_orgs: seq[string]): seq[App] =
  var apps: seq[App] = @[]
  for co in consumer_orgs:
    doAssert 0 == execShellCmd(fmt"apic apps:list --org {context.org} --server {context.server} --catalog {catalog.name} --consumer-org {co} > apps.txt")
    for line in lines "apps.txt":
      if line.contains("enabled"):
        let app = line.split(' ')[0]
        apps.add App(name: app, consumer: co)
    removeFile("apps.txt")
  
  result = apps

proc listConsumerOrgs*(context: Context, catalog: Catalog): seq[string] =
  echo (&"apic consumer-orgs:list --org {context.org} --server {context.server} --catalog {catalog.name}")
  doAssert 0 == execShellCmd(fmt"apic consumer-orgs:list --org {context.org} --server {context.server} --catalog {catalog.name} > consumerorgs.txt")

  var consumer_orgs: seq[string] = @[]
  
  for line in lines "consumerorgs.txt":
    if line.contains("enabled"):
      let consumer_org = line.split(' ')[0]
      consumer_orgs.add consumer_org

  removeFile("consumerorgs.txt")
  result = consumer_orgs

proc findProduct*(context: Context, catalog: Catalog, product: string): Option[Product] =
  var product_qualified_name = colonForm(product)
  var cmd = execShellCmd(fmt"apic products:list-all --scope catalog --org {context.org} --server {context.server} --catalog {catalog.name} | findstr published | findstr {product_qualified_name} > product.txt")
  if cmd == 0:
    let product_find = readFile("product.txt")
    removeFile("product.txt")
    var product = none(Product)
    if product_find.contains(product_qualified_name):
      let url = product_find.split(']')[1].strip()
      product = some(Product(name: product_qualified_name, url:url))
      result = product
    else:
      result = none(Product)
  else: 
    removeFile("product.txt")

proc listConfiguredGateways*(context: Context, catalog: Catalog): seq[string] =
  doAssert 0 == execShellCmd(fmt"apic configured-gateway-services:list --scope catalog -c {catalog.name} -o {context.org} -s {context.server} > gateways.txt")
  var gateways: seq[string] = @[]
  for line in lines "gateways.txt":
    let gateway = line.split(' ')[0]
    gateways.add gateway
  
  removeFile("gateways.txt")

  result = gateways
