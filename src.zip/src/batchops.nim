import types,utils,json,apic_procs,strutils

let props = parseJson(readFile("props.json")).to(Props)
let cmd_input = getCmdInput()

doAssert cmd_input.env != ""
doAssert cmd_input.operation != ""

let context = selectContext(cmd_input, props)

case normalize(cmd_input.operation)
of normalize("deploy"):
    deploy(props.userdata, context, props, cmd_input)
of normalize("deployAll"):
    deployAllLocal(props.userdata, context, props, cmd_input)
of normalize("subFromAllApps"):
    subscribeFromAllApps(props.userdata, context, props, cmd_input)
of normalize("subToAllProducts"):
    subscribeToAllProducts(props.userdata, context, props, cmd_input)
of normalize("prehookGPDeploy"):
    deployPrehookGlobalPolicy(props.userdata, context, props, cmd_input)
of normalize("posthookGPDeploy"):
    deployPosthookGlobalPolicy(props.userdata, context, props, cmd_input)
of normalize("errorGPDeploy"):
    deployErrorGlobalPolicy(props.userdata, context, props, cmd_input)
of normalize("doEverything"): 
    doEverything(props.userdata, context, props, cmd_input)