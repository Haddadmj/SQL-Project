# Seeds 12 months of POS / ECommerce / LocalBankTransfer transactions
# for account ACC-A7ED03BE via POST /api/dev-portal/admin/ob/transactions.
#
# Business rules enforced:
#   - 12 months: 2025-08 .. 2026-07
#   - Each month: POS, ECommerce, LocalBankTransfer, each as one Debit + one Credit
#   - POS Debit in the last 3 months (May/Jun/Jul 2026) is capped < 3000 SAR
#   - POS Debit in older months may exceed 3000 SAR
#   - MONTHLY SALES < 5000 SAR: the sum of ALL Credit amounts in a calendar month
#     (POS + ECommerce + LocalBankTransfer credits combined) stays under 5000 SAR.
#     A single per-month budget is split across the three channel credits.
#
# Usage (pass the admin JWT at runtime - do NOT hardcode it here):
#   .\seed-transactions.ps1 -Token "<admin-jwt>"
#   .\seed-transactions.ps1 -Token $env:OB_ADMIN_TOKEN -AccountId "ACC-XXXX"

param(
    [string]$BaseUrl   = "https://developer-portal.neotek.sa",
    [string]$Path      = "/api/dev-portal/admin/ob/transactions",
    [string]$AccountId = "ACC-A7ED03BE",
    [Parameter(Mandatory = $true)]
    [string]$Token                                         # Bearer admin JWT
)

$headers = @{ "Content-Type" = "application/json" }
if ($Token) { $headers["Authorization"] = "Bearer $Token" }

# 12 months ending at the current month (2026-07). Use first-of-month anchors;
# each transaction gets a randomized day within its month below.
$months = 0..11 | ForEach-Object { (Get-Date "2026-07-01T00:00:00+03:00").AddMonths(-$_) } | Sort-Object
$today  = Get-Date "2026-07-20T00:00:00+03:00"

# Cutoff for the "last 3 months" POS < 3K rule (>= 2026-05-01)
$last3Cutoff = Get-Date "2026-05-01T00:00:00+03:00"

$rand = [System.Random]::new()

function New-Amount([double]$min, [double]$max) {
    [math]::Round($min + $rand.NextDouble() * ($max - $min), 2)
}

# Split a total into $parts positive random shares that sum to (about) the total.
# Used to spread a month's credit budget across the channel credits.
function Split-Amount([double]$total, [int]$parts) {
    $weights = 1..$parts | ForEach-Object { $rand.NextDouble() + 0.15 }
    $sum = ($weights | Measure-Object -Sum).Sum
    $out = @()
    $running = 0
    for ($i = 0; $i -lt $parts; $i++) {
        if ($i -eq $parts - 1) {
            $out += [math]::Round($total - $running, 2)   # last part absorbs rounding
        } else {
            $v = [math]::Round($total * ($weights[$i] / $sum), 2)
            $out += $v
            $running += $v
        }
    }
    $out
}

# Maximum allowed monthly credit (sales) total. Kept strictly under 5000.
$MonthlySalesCap = 4900.0

$specs = @(
    @{ Type="KSAOB.POS";               Merchant="Panda Hypermarket"; Mcc="5411"; DebitSub="KSAOB.Purchase";     CreditSub="KSAOB.Refund" },
    @{ Type="KSAOB.ECommerce";         Merchant="Amazon.sa";         Mcc="5262"; DebitSub="KSAOB.Purchase";     CreditSub="KSAOB.Refund" },
    @{ Type="KSAOB.LocalBankTransfer"; Merchant=$null;               Mcc=$null;  DebitSub="KSAOB.MoneyTransfer"; CreditSub="KSAOB.MoneyTransfer" }
)

$created = 0
foreach ($m in $months) {
    $isLast3 = $m -ge $last3Cutoff

    # One credit budget for this month (< 5000 SAR), split across the 3 channel
    # credits. This is what enforces "monthly sales < 5K".
    $monthlyCreditTotal = New-Amount 2500 $MonthlySalesCap
    $creditParts = Split-Amount $monthlyCreditTotal $specs.Count
    $creditAlloc = @{}
    for ($i = 0; $i -lt $specs.Count; $i++) { $creditAlloc[$specs[$i].Type] = $creditParts[$i] }
    $monthCreditSum = 0

    foreach ($s in $specs) {
        foreach ($ind in @("KSAOB.Debit", "KSAOB.Credit")) {

            # Randomized day within the month: 3..25 (keeps dates off month edges).
            # For the current month, stay a few days before today so nothing hits
            # 2026-07-20 or the future (@PastOrPresent).
            $maxDay = if ($m.Year -eq $today.Year -and $m.Month -eq $today.Month) { 17 } else { 25 }
            $day    = $rand.Next(3, $maxDay + 1)
            $hour   = $rand.Next(8, 21)
            $min    = $rand.Next(0, 60)
            $txDate = Get-Date -Year $m.Year -Month $m.Month -Day $day -Hour $hour -Minute $min -Second 0
            $dt     = $txDate.ToString("yyyy-MM-ddTHH:mm:sszzz")

            # Amount rules.
            # CREDITS (sales, money in): drawn from the capped monthly budget so the
            # month's credit total stays < 5000 SAR.
            # DEBITS (money out): independent, with the POS-under-3K last-3-months rule.
            if ($ind -eq "KSAOB.Credit") {
                $amount = $creditAlloc[$s.Type]
                $monthCreditSum += $amount
            } elseif ($s.Type -eq "KSAOB.POS") {
                $amount = if ($isLast3) { New-Amount 50 2900 } else { New-Amount 100 6000 }
            } elseif ($s.Type -eq "KSAOB.ECommerce") {
                $amount = New-Amount 80 3500
            } else {
                $amount = New-Amount 500 12000
            }

            $sub = if ($ind -eq "KSAOB.Debit") { $s.DebitSub } else { $s.CreditSub }

            $body = @{
                accountId              = $AccountId
                transactionDateTime    = $dt
                bookingDateTime        = $dt
                creditDebitIndicator   = $ind
                status                 = "Booked"
                amount                 = $amount
                currency               = "SAR"
                transactionInformation = "$($s.Type) $ind $($m.ToString('yyyy-MM'))"
                transactionType        = $s.Type
                subTransactionType     = $sub
            }
            if ($s.Merchant) { $body.merchantName = $s.Merchant; $body.merchantCategoryCode = $s.Mcc }
            if ($s.Type -eq "KSAOB.LocalBankTransfer") {
                $body.counterpartyName = if ($ind -eq "KSAOB.Credit") { "Neotek Payroll" } else { "Utility Co" }
                $body.counterpartyIban = "SA0380000000608010167519"
            }

            $json = $body | ConvertTo-Json -Depth 5
            try {
                Invoke-RestMethod -Method Post -Uri "$BaseUrl$Path" -Headers $headers -Body $json | Out-Null
                $created++
                Write-Host ("OK  {0}  {1,-26} {2,-12} {3,10:N2} SAR" -f $m.ToString('yyyy-MM'), $s.Type, $ind, $amount)
            } catch {
                Write-Host ("FAIL {0} {1} {2}: {3}" -f $m.ToString('yyyy-MM'), $s.Type, $ind, $_.Exception.Message) -ForegroundColor Red
            }
        }
    }

    $flag = if ($monthCreditSum -lt 5000) { "OK" } else { "OVER!" }
    Write-Host ("   -> {0} monthly sales (credits) = {1,8:N2} SAR  [{2}]" -f $m.ToString('yyyy-MM'), $monthCreditSum, $flag) -ForegroundColor Cyan
}
Write-Host "`nCreated $created transactions." -ForegroundColor Green
