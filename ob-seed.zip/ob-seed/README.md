# Open Banking – Transaction Seed Data

Seed script and business-case context for populating Open Banking transactions
against a target account via the admin API.

## Endpoint

`POST {BaseUrl}/api/dev-portal/admin/ob/transactions`

- Controller: `OBAdminController#createTransaction`
- Request body: `OBTransactionCreateRequest` (one record per call — no bulk endpoint)
- Requires an **admin** Bearer JWT (`isAdmin: true`)

## Files

| File | Purpose |
|------|---------|
| `seed-transactions.ps1` | Generates and POSTs 12 months of transactions for one account |
| `README.md` | This context document |

## Running

The admin JWT is **mandatory** and passed at runtime — it is intentionally **not**
stored in the script (it is a short-lived secret).

```powershell
.\seed-transactions.ps1 -Token "<admin-jwt>"

# override defaults if needed:
.\seed-transactions.ps1 -Token $env:OB_ADMIN_TOKEN `
    -AccountId "ACC-A7ED03BE" `
    -BaseUrl   "https://developer-portal.neotek.sa" `
    -Path      "/api/dev-portal/admin/ob/transactions"
```

## Business cases modeled

Target account: **`ACC-A7ED03BE`** (associated with userId 10).

1. **12 months of activity** — 2025-08 → 2026-07, across three channels, each
   as one **Credit** and one **Debit** per month:
   - `POS`               → business term "POS"
   - `ECommerce`         → business term "ECOM"
   - `LocalBankTransfer` → business term "Account Transfer"
   (12 months × 3 channels × 2 indicators = **72 transactions**.)

2. **POS Debit < 3,000 SAR in the last 3 months** (May/Jun/Jul 2026).
   Older months' POS debits may exceed 3,000 SAR.

3. **Monthly sales < 5,000 SAR** — the sum of *all* Credit amounts in any
   calendar month (POS + ECommerce + LocalBankTransfer credits combined) stays
   under 5,000 SAR. A single per-month credit budget (2,500–4,900 SAR) is split
   across the three channels.

### Rule interaction (Case 2 coupling)

The "monthly sales < 5K" cap applies **only to the credit (money-in) side**.
Debits (money-out) are unconstrained by it, so debit transfers can still be
large (e.g. > 10,000 SAR). This models a low-revenue merchant with normal
spending. If large **incoming** transfers are later required for a test, this
account cannot represent that without breaking the 5K sales cap — use a separate
account instead.

## Field / type reference

From `OBTransactionCreateRequest`:

- `creditDebitIndicator`: `KSAOB.Credit`, `KSAOB.Debit`
- `status`: `Booked`, `Pending`
- `transactionType`: `KSAOB.POS`, `KSAOB.ATM`, `KSAOB.ECommerce`,
  `KSAOB.LocalBankTransfer`, `KSAOB.InternationalBankTransfer`,
  `KSAOB.BillPayments`, `KSAOB.CardTransaction`, `KSAOB.CashTransaction`,
  `KSAOB.Other`
- `subTransactionType`: `KSAOB.Purchase`, `KSAOB.Withdrawal`, `KSAOB.Deposit`,
  `KSAOB.MoneyTransfer`, `KSAOB.Refund`, `KSAOB.Payment`, `KSAOB.Charge`,
  `KSAOB.Interest`, `KSAOB.Dividend`, `KSAOB.Other`
- `currency`: `SAR` only
- `transactionDateTime` / `bookingDateTime`: `@PastOrPresent` — must not be in
  the future.

From `OBAccountCreateRequest` (for reference when creating the account):

- `accountType`: `KSAOB.Corporate`, `KSAOB.Retail`
- `accountSubType`: `CurrentAccount`, `Savings`, `CreditCard`, `ChargeCard`,
  `PrePaidCard`, `EMoney`
- `currency`: `SAR`

## Notes / caveats

- **Not idempotent.** Re-running adds another 72 records (duplicate months).
  Clear existing data first, or add a guard, before re-seeding.
- The target account must already exist and be linked to its user before seeding.
- Dates use Riyadh offset `+03:00`; days are randomized within each month
  (3–25, current month capped at day 17 to stay before "today").
