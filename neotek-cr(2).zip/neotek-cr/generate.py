#!/usr/bin/env python3
"""Fill the Neotek CR templates from a JSON input.

Usage: python3 generate.py <input.json> <output_dir> [--env UAT|PROD]

Writes:
  <output_dir>/email.docx                              (always)
  <output_dir>/Change_Impact_Assessment.xlsx           (PROD only)
  <output_dir>/Implementation_and_Rollback_Plan.xlsx   (PROD only)

For UAT deployments the two xlsx outputs are skipped. The environment is
read from --env if supplied, otherwise from the "environment" key of
input.json, defaulting to PROD when neither is set.

The cell mapping mirrors the layout of the templates in `templates/`. If
Neotek changes the templates (rows shift, cells move), the assertions in
verify_layout() catch it before silently writing to wrong cells.
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

import openpyxl

SKILL_DIR = Path(__file__).resolve().parent
TEMPLATE_DIR = SKILL_DIR / "templates"
CHANGE_IMPACT_TEMPLATE = TEMPLATE_DIR / "Change Impact Assesments template.xlsx"
IMPL_ROLLBACK_TEMPLATE = TEMPLATE_DIR / "Implemntation and rollpack plan template.xlsx"
CR_EMAIL_TEMPLATE = TEMPLATE_DIR / "cr_email_template.docx"


def assert_label(ws, coord, expected, doc):
    actual = ws[coord].value
    if actual is None or expected.strip().lower() not in str(actual).strip().lower():
        raise SystemExit(
            f"Layout drift in {doc}: expected cell {coord} to contain {expected!r}, "
            f"got {actual!r}. Update generate.py to match the new template."
        )


def fill_change_impact(values: dict, out_path: Path) -> None:
    shutil.copy(CHANGE_IMPACT_TEMPLATE, out_path)
    wb = openpyxl.load_workbook(out_path)
    ws = wb["Sheet2"]

    # Layout sanity check
    assert_label(ws, "B4", "Change Request Number", "change-impact")
    assert_label(ws, "B14", "Direct related Services", "change-impact")
    assert_label(ws, "B21", "SUMMARY OF IMPACT", "change-impact")

    # Header
    ws["C4"] = values.get("cr_number", "")
    ws["F4"] = values.get("date_created", "")
    ws["C5"] = values.get("service_name", "")
    ws["F5"] = values.get("module_sub_service", "")
    ws["C6"] = values.get("preprod_completed", "")
    ws["F6"] = values.get("preprod_cr_number", "")

    # State
    ws["C8"] = values.get("business_benefit", "")
    ws["C9"] = values.get("financial_impact", "")

    # Key risks (list rendered as bullet lines in the merged B11:F11 cell)
    risks = values.get("key_risks", [])
    if risks:
        ws["B11"] = "\n".join(f"- {r}" for r in risks)

    # Impact rows
    impact_rows = {
        "direct":       14,
        "indirect":     15,
        "customer":     16,
        "utilization":  17,
        "availability": 18,
        "continuity":   19,
        "infosec":      20,
    }
    for key, row in impact_rows.items():
        i = values.get("impacts", {}).get(key, {})
        ws[f"C{row}"] = i.get("yesno", "")
        # For "No" rows we leave detail/level/remarks blank per the no-negative-content rule
        if i.get("yesno", "").strip().lower() == "yes":
            ws[f"D{row}"] = i.get("detail", "")
            ws[f"E{row}"] = i.get("level", "")
            ws[f"F{row}"] = i.get("remarks", "")

    # Summary of impact
    ws["B22"] = values.get("summary_of_impact", "")

    wb.save(out_path)


def fill_impl_rollback(values: dict, out_path: Path) -> None:
    shutil.copy(IMPL_ROLLBACK_TEMPLATE, out_path)
    wb = openpyxl.load_workbook(out_path)
    ws = wb["Sheet1"]

    # Layout sanity
    assert_label(ws, "B2",  "Change Number",        "impl-rollback")
    assert_label(ws, "B6",  "Deployment Plan",       "impl-rollback")
    assert_label(ws, "B12", "Pre-Implementation",   "impl-rollback")
    assert_label(ws, "B15", "Implementation Tasks", "impl-rollback")
    assert_label(ws, "B34", "Roll Back Steps",      "impl-rollback")

    # Header
    ws["C2"] = values.get("change_number", "")
    ws["C3"] = values.get("technical_kt", "")
    ws["C4"] = values.get("implementation_complexity", "")
    ws["H4"] = values.get("implementor_team", "")

    # Deployment plan — row 9 is the template's example (kept as-is).
    # Real tasks are inserted starting at row 10. Each task fills:
    #   B = task, C = duration, J = outage, K = notes
    # Start/End dates/times and Doer/Checker are intentionally left blank.
    tasks = values.get("deployment_tasks", [])
    inserted = 0
    if tasks:
        ws.insert_rows(10, amount=len(tasks))
        inserted = len(tasks)
        for i, t in enumerate(tasks):
            row = 10 + i
            ws.cell(row=row, column=2).value = t.get("task", "")
            ws.cell(row=row, column=3).value = t.get("duration", "")
            ws.cell(row=row, column=10).value = t.get("outage", "")  # J
            ws.cell(row=row, column=11).value = t.get("notes", "")   # K

    def _task_duration(item):
        """List items can be a plain string (task only) or {task, duration}."""
        if isinstance(item, dict):
            return item.get("task", ""), item.get("duration", "")
        return item, ""

    # Variable-length list sections. Process in template order; if a section
    # needs more rows than the template provides, insert extras at the end
    # of its slot and shift subsequent sections down.
    sections = [
        # (json_key,                   template_start, template_max)
        ("coordination_with_business", 11, 1),
        ("pre_implementation",         13, 2),
        ("implementation_tasks",       16, 12),
        ("verification_steps",         29, 3),
        ("post_implementation",        33, 1),
        ("business_health_check",      46, 1),
    ]
    for key, template_start, template_max in sections:
        items = values.get(key) or []
        if not items:
            continue
        start_row = template_start + inserted
        if len(items) > template_max:
            extra = len(items) - template_max
            ws.insert_rows(start_row + template_max, amount=extra)
            inserted += extra
        # Clear defaults the template ships with, then fill all items
        for offset in range(max(template_max, len(items))):
            ws.cell(row=start_row + offset, column=2).value = None
            ws.cell(row=start_row + offset, column=3).value = None
        for offset, item in enumerate(items):
            task, duration = _task_duration(item)
            ws.cell(row=start_row + offset, column=2).value = task
            ws.cell(row=start_row + offset, column=3).value = duration

    # Rollback steps — template provides 2 merged 4-row groups (rows 35-37
    # and 39-41). Supporting >2 rollback steps means cloning merged-group
    # structure, which is fragile in openpyxl; warn and truncate instead.
    rollback_rows = [35 + inserted, 39 + inserted]
    rollback_steps = values.get("rollback_steps") or []
    for offset, step in enumerate(rollback_steps[: len(rollback_rows)]):
        task, duration = _task_duration(step)
        row = rollback_rows[offset]
        ws.cell(row=row, column=2).value = task
        ws.cell(row=row, column=3).value = duration
    if len(rollback_steps) > len(rollback_rows):
        print(f"  WARN: {len(rollback_steps)} rollback steps supplied but "
              f"template has {len(rollback_rows)} merged groups; extras "
              f"truncated. Combine steps or extend the template.",
              file=sys.stderr)

    wb.save(out_path)


def fill_cr_email(values: dict, out_path: Path) -> None:
    """Fill cr_email_template.docx — CR description section (paragraphs + env/type + links tables)
    plus the deployment notification email (subject + Change Overview + Service Approval Matrix).
    """
    import docx
    from copy import deepcopy
    from docx.text.paragraph import Paragraph

    shutil.copy(CR_EMAIL_TEMPLATE, out_path)
    doc = docx.Document(out_path)

    environment = values.get("environment", "")
    cr_number = values.get("cr_number", "")
    scope = values.get("scope", "")
    version = (values.get("version") or "").strip()
    email_service = values.get("module_sub_service") or values.get("service_name", "")
    cr_title = " ".join(p for p in [scope, version, environment, "Deployment"] if p)
    email_subject_line = f"{cr_number} - {environment} - {scope} Deployment/Change Request"

    # Capture direct references to every paragraph we will modify, BEFORE the component
    # expansion below shifts later paragraphs' positions in doc.paragraphs.
    title_p           = doc.paragraphs[2]
    components_p      = doc.paragraphs[7]
    summary_p         = doc.paragraphs[9]
    deploy_steps_p    = doc.paragraphs[11]
    email_subject_p   = doc.paragraphs[18]
    cab_link_p        = doc.paragraphs[-1]

    # --- CR description section ---

    _replace_paragraph_text(title_p, cr_title)
    _replace_label_and_body(
        summary_p,
        "Summary of Changes: ",
        values.get("summary_of_changes", "SUMMARY_OF_CHANGES"),
    )
    _replace_label_and_body(
        deploy_steps_p,
        "Deployment Steps: ",
        values.get("deployment_steps", "DEPLOYMENT_STEPS"),
    )

    # Table 0 (2x2): Environment + Type
    env_type_table = doc.tables[0]
    _set_cell(env_type_table.rows[0].cells[1], environment)
    _set_cell(env_type_table.rows[1].cells[1], values.get("deployment_type", ""))

    # Table 1 (4x2): Links
    links_table = doc.tables[1]
    _set_cell(links_table.rows[0].cells[1], values.get("pr_links") or "PR_LINKS")
    _set_cell(links_table.rows[1].cells[1], values.get("jira_links") or "JIRA_TICKET_LINKS")
    _set_cell(links_table.rows[2].cells[1], values.get("sonarqube_link") or "SONARQUBE_REPORT_LINK")
    _set_cell(links_table.rows[3].cells[1], values.get("changelog_link") or "CHANGELOG_LINK")

    # Components Affected: the template ships with one bullet paragraph. Replace its text
    # with the first component, then clone the element to append additional bullets.
    components = values.get("components") or ["COMPONENT_AFFECTED"]
    _replace_paragraph_text(components_p, f"- {components[0]}")
    current_elem = components_p._element
    for comp in components[1:]:
        new_elem = deepcopy(components_p._element)
        current_elem.addnext(new_elem)
        new_p = Paragraph(new_elem, components_p._parent)
        _replace_paragraph_text(new_p, f"- {comp}")
        current_elem = new_elem

    # --- Email section ---

    _replace_paragraph_text(email_subject_p, f"Subject: {email_subject_line}")

    cab_link = values.get("cab_meeting_link") or "CAB_MEETING_LINK"
    _replace_label_and_body(cab_link_p, "CAB Teams Meeting Link: ", cab_link)

    # Table 2: Change Overview — right column of rows 1..6
    overview = doc.tables[2]
    pairs = [
        environment,
        _email_type(values.get("deployment_type", "")),
        scope,
        email_service,
        cr_number,
        values.get("cr_link") or "CR_LINK",
    ]
    for i, value in enumerate(pairs, start=1):
        _set_cell(overview.rows[i].cells[1], value)

    # Table 3: Service Approval Matrix — fill row 1, append rows for additional services.
    matrix = doc.tables[3]
    services = values.get("approval_matrix") or [{
        "service":         email_service,
        "description":     values.get("approval_description", ""),
        "release_status":  values.get("release_status", "Pending Review"),
        "product_owner":   values.get("product_owner") or "PRODUCT_OWNER",
        "cyber_security":  values.get("cyber_security") or "CYBER_SECURITY",
        "tech_manager":    values.get("tech_manager") or "TECH_MANAGER",
    }]
    for idx, svc in enumerate(services):
        if idx == 0:
            row = matrix.rows[1]
        else:
            row = matrix.add_row()
        cells = [
            svc.get("service", ""),
            svc.get("description", ""),
            svc.get("release_status", "Pending Review"),
            svc.get("product_owner") or "PRODUCT_OWNER",
            svc.get("cyber_security") or "CYBER_SECURITY",
            svc.get("tech_manager") or "TECH_MANAGER",
        ]
        for ci, val in enumerate(cells):
            _set_cell(row.cells[ci], val)

    doc.save(out_path)


def _email_type(deployment_type: str) -> str:
    """Strip leading 'new ' and Title-Case the deployment type. 'new feature' -> 'Feature'."""
    t = (deployment_type or "").strip()
    if t.lower().startswith("new "):
        t = t[4:]
    return t.title()


def _replace_paragraph_text(paragraph, new_text: str) -> None:
    """Replace a paragraph's text without losing the paragraph's style."""
    # Clear existing runs, write a single new run with the replacement text
    for run in list(paragraph.runs):
        run.text = ""
    if paragraph.runs:
        paragraph.runs[0].text = new_text
    else:
        paragraph.add_run(new_text)


def _replace_label_and_body(paragraph, label: str, body: str) -> None:
    """Replace a 'Label: body' paragraph, keeping the label and body in separate runs
    so the template's per-run formatting (bold label, non-bold body) is preserved.
    """
    runs = list(paragraph.runs)
    if len(runs) >= 2:
        runs[0].text = label
        runs[1].text = body
        for r in runs[2:]:
            r.text = ""
    elif runs:
        runs[0].text = label
        body_run = paragraph.add_run(body)
        body_run.bold = False
    else:
        label_run = paragraph.add_run(label)
        label_run.bold = True
        paragraph.add_run(body)


def _set_cell(cell, value: str) -> None:
    """Write `value` into the first paragraph of `cell`, preserving cell style."""
    if cell.paragraphs:
        _replace_paragraph_text(cell.paragraphs[0], str(value))
        for extra in cell.paragraphs[1:]:
            _replace_paragraph_text(extra, "")
    else:
        cell.text = str(value)


def main() -> int:
    parser = argparse.ArgumentParser(description="Fill Neotek CR deliverables from a JSON input.")
    parser.add_argument("input", help="path to input.json")
    parser.add_argument("output_dir", help="directory to write outputs into")
    parser.add_argument(
        "--env",
        choices=["UAT", "PROD"],
        default=None,
        help="environment override; defaults to input.json's 'environment' value, then PROD. UAT skips xlsx outputs.",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    values = json.loads(input_path.read_text())

    env = (args.env or values.get("environment") or "PROD").upper()
    is_uat = env == "UAT"

    cr_email_out = out_dir / "cr_email.docx"
    fill_cr_email(values, cr_email_out)
    print(f"Wrote {cr_email_out}")

    if is_uat:
        print("UAT deployment: skipping xlsx outputs (Change_Impact_Assessment, Implementation_and_Rollback_Plan).")
        return 0

    impact_out = out_dir / "Change_Impact_Assessment.xlsx"
    impl_out = out_dir / "Implementation_and_Rollback_Plan.xlsx"
    fill_change_impact(values, impact_out)
    fill_impl_rollback(values, impl_out)
    print(f"Wrote {impact_out}")
    print(f"Wrote {impl_out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
