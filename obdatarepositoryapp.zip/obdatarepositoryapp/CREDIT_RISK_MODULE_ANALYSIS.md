# Credit Risk Module — Architecture & Analysis

**Package:** `com.ejada.obdatarepositoryapp.creditrisk`
**Project:** OBDataRepository (Spring Boot, Open Banking data repository)
**Scope:** 35 Java files (~10k LOC), credit-risk package only
**Date:** 2026-06-08
**Method:** Multi-agent static analysis across four slices — API/contract, data/persistence, scoring engine, and PDF reporting.

---

## 1. Executive Summary

The `creditrisk` package is a self-contained credit-scoring sub-application bolted onto the OB data repository. It exposes four REST endpoints that take Open Banking account identifiers, pull the customer's transaction history, run a weighted multi-factor scoring model, and return either a JSON credit report or a rendered PDF.

It is structured cleanly into layers (controller → service → repository → domain) with dedicated DTOs, enums, validation, and its own exception handler. The data layer is sound (parameterized queries, DB-level PGP decryption, consent gating on account access). **The risk concentrates in the scoring engine and PDF layer** — both are large, math-heavy, and contain edge-case bugs that can change a credit decision. This module is under active bug-fixing, and several findings below corroborate that.

**Top risks (act first):**
1. **AGE range boundary overlap** — age 61 scores 0 instead of 100 pts (`CreditRiskScoringService` ~line 512–518).
2. **Default interest rate 3.0%** is below Saudi market (5–8%), inflating affordability (`CreditRiskScoringService` ~line 392).
3. **Inconsistent affordability thresholds** — 30% of cash flow for max payment vs 40% DBR for "affordable" vs 30%/50% for risk level.
4. **V1/V2 PDF percentage-formatting divergence** — same field formatted differently (one multiplies ×100, the other doesn't), producing wrong percentages.
5. **Revenue-trend division-by-zero / -100% with 1 month of data** (`FinancialMetricsCalculator` ~line 965).

---

## 2. Module Map

```
creditrisk/
├── controller/   CreditRiskController          → 4 REST endpoints
├── config/       CreditRiskConfig              → externalized thresholds, severity logic
├── dto/
│   ├── TransactionData                         → transaction model + 200+ lines of classification keywords
│   ├── request/  CreditRiskRequest, RangeConfig, RiskFactorConfig
│   └── response/ CreditRiskReportResponse, FinancialMetrics, FactorScore,
│                 CustomerProfile, CreditRecommendation, PurposeAssessment, PDFResponse
├── enums/        CreditRatingClass, CustomerType, LoanPurpose, RiskFactorType
├── exception/    CreditRiskException, GlobalExceptionHandler
├── domain/       DrahimTransaction, ObTransaction, ObAccount, UserConsent
│                 + DecryptedTransactionProjection, DecryptedDrahimTransactionProjection
├── repository/   DrahimTransactionRepository, ObTransactionRepository,
│                 ObAccountRepository, UserConsentRepository
├── validation/   TransactionDataValidator
└── service/
    ├── OpenBankingDataFetcher                  → data access orchestrator
    ├── FinancialMetricsCalculator (1225 LOC)   → all financial metrics
    ├── CreditRiskScoringService (691 LOC)      → scoring + report assembly
    ├── PdfReportGenerator (1627 LOC)           → V1 PDF (5 pages)
    └── PdfReportGeneratorV2 (2609 LOC)         → V2 PDF (8 pages)
```

---

## 3. API / Contract Layer

### Endpoints (`CreditRiskController`)

| Method | Path | Response | Purpose |
|--------|------|----------|---------|
| POST | `/api/v1/credit-risk/getCreditRiskReport` | `CreditRiskReportResponse` | JSON credit assessment |
| POST | `/api/v1/credit-risk/getCreditRiskReport/pdf` | `PDFResponse` (base64) | V1 PDF (5-page) |
| POST | `/api/v1/credit-risk/getCreditRiskReport/v2/pdf` | `PDFResponse` (base64) | V2 PDF (8-page) |
| GET | `/api/v1/credit-risk/health` | `String` | Health check |

### Request (`CreditRiskRequest`)
- **Required (`@NotBlank`):** `psuId`, `accountLinkId`, `accountId`, `sponsoredTppId`
- **Optional:** `customerType` (default `RETAIL`), `riskFactors` (custom config), `purpose`, `requestedAmount`, `loanTermMonths`, `annualInterestRate`, `age`
- Supports **runtime factor customization** via `RiskFactorConfig` (weight, ranges, enabled) and `RangeConfig` (min/max/points/label).

### Response (`CreditRiskReportResponse`)
Root: `totalScore` (0–1000), `maxPossibleScore`, `ratingClass`, `approvalRecommendation`, plus nested `factorScores[]`, `financialMetrics` (40+ fields), `customerProfile`, `recommendation`, optional `purposeAssessment`, and `metadata` (factors evaluated/skipped, weight-redistribution flag, data-quality note).

### Enums
- **CreditRatingClass:** AAA (900–1000) → D (0–99), 10 bands with name/description/approval guidance.
- **CustomerType:** RETAIL, CORPORATE.
- **LoanPurpose:** 11 values (PERSONAL_FINANCE, CAR_LOAN, HOME_MORTGAGE, …).
- **RiskFactorType:** 7 retail + 8 corporate factors, each with weight, description, and `isApplicableTo(CustomerType)`.

### Exception Handling (`GlobalExceptionHandler`, `@RestControllerAdvice`)
`CreditRiskException`/`IllegalArgumentException` → 400; `ArithmeticException` (CALCULATION_ERROR) and `NullPointerException` (MISSING_DATA) → 500; generic fallback → 500 (details hidden outside dev). **No handler for `MethodArgumentNotValidException`** (bean-validation errors fall to Spring defaults) and **no 404 handling**.

### Contract-layer findings
- **`System.out.println` debug statements** leak `psuId` into stdout (`CreditRiskController` ~line 50, 54, 56) — should use `@Slf4j`.
- **PDF returned as base64 inside JSON** — memory-heavy; native-download headers exist but are commented out.
- **Weak/absent validation:** no bounds on `age`, `requestedAmount`, `loanTermMonths`, `annualInterestRate` (negatives/absurd values accepted); no `min ≤ max` check on `RangeConfig`; no check that supplied `riskFactors` match `customerType`.
- **`TransactionData` carries ~200 lines of classification keyword logic** — business logic living in a DTO; belongs in the service layer.
- **`TransactionDataValidator` is shallow** — allows zero-amount and future-dated transactions, doesn't validate the credit/debit indicator enum.

---

## 4. Data / Persistence Layer

### Entities (all `@Immutable`)
| Entity | Table | Represents |
|--------|-------|-----------|
| `DrahimTransaction` | `drahim_transactions` | Enriched/categorized transaction (active source) |
| `ObTransaction` | `raw_transactions` | Raw Open Banking transaction (legacy/fallback) |
| `ObAccount` | `accounts` | Bank account linked via Open Banking |
| `UserConsent` | `users_consents` | PSU grant of access (consent + tokens) |

### Two data sources — Drahim vs Ob
- **Drahim** (`drahim_transactions`): post-categorization pipeline output; filtered by `is_ignored_in_budget = false` to drop duplicates/failed/same-account transfers. This is the intended **active** source.
- **Ob/raw** (`raw_transactions`): direct API pull; filtered by `status IN ('processed','merchant_extraction_failed')`.
- ⚠️ **Discrepancy worth verifying:** `DrahimTransactionRepository` is fully implemented but the provided `OpenBankingDataFetcher.getTransactionsForAccount()` still calls **`ObTransactionRepository`**. Either the Drahim path is wired elsewhere, or the "switch to Drahim" is incomplete / the Ob path is stale. (Memory notes record a Drahim source switch landing — confirm the fetcher actually uses it.)

### Encryption & projections
- Transaction/account payloads are **encrypted at rest** (`encrypted_data byte[]`), decrypted **at the database** via PostgreSQL `pgp_sym_decrypt(..., :encryptionKey)`. Key injected from `${openbanking.encryption.pgp-key}` (single key, all tables; rotation needs redeploy).
- `Decrypted*Projection` interfaces map the decrypted JSON string back to the app, parsed by `OpenBankingDataFetcher`.

### Consent gating
- `getAccount()` enforces: consent exists (E100001) → status connected (E100002) → ownership `consent.userId == psuId` (E100003).
- ⚠️ **Gaps:** `getTransactionsForAccount()` does **not** re-validate consent (relies on caller ordering); **no `expiresAt` / token-expiry check** anywhere.

### Other data-layer findings
- **Queries are SQL-injection-safe** — consistently parameterized (`@Param`, named params in native SQL).
- **No date filtering** on transaction fetches — full history is loaded even if scoring only needs the last 6 months (performance + memory).
- **Implied missing indexes** on the multi-column filter combinations (e.g. `drahim_transactions(user_id, account_id, sponsored_tpp_id, is_ignored_in_budget)`, `users_consents(neotek_accounts_link_id, sponsored_tpp_id)`).
- **Hardcoded status strings** in native queries (no enum) — a typo silently returns zero rows.
- Parsing is defensively null-safe (amounts default to ZERO, balances to null, multiple date formats tried).

---

## 5. Scoring Engine (the core risk area)

### Flow (`CreditRiskScoringService.generateReport`)
fetch account → fetch transactions → build profile → `FinancialMetricsCalculator.calculate()` → build factor configs (defaults + request overrides + applicability/age gating) → score each factor against its ranges → **sum + weight-redistribution** → map to `CreditRatingClass` → recommendation → optional purpose/affordability → assemble report.

### Factors & weights (1000-pt scale, normalized)
- **Retail (7, nominal 1050 pts):** AGE 150, INCOME 150, LOAN_PAYMENT 150, SURPLUS_RATIO 150, SALARY_CATEGORY 150, CASH_FLOW 150, DEBT_BURDEN_RATIO 100.
- **Corporate (8, nominal 1150 pts):** BUSINESS_AGE 150, REVENUE_STABILITY 150, REVENUE_TREND 150, OPERATING_EXPENSE_RATIO 150, SUPPLIER_PAYMENT_CONSISTENCY 150, CASH_BUFFER 150, CORPORATE_CASH_FLOW 150, PAYMENT_BEHAVIOR 100.
- Both nominal totals **exceed 1000**, so weight redistribution (`totalScore × 1000 / availableMaxPoints` when factors are skipped) is always doing real work.

### Metrics (`FinancialMetricsCalculator`)
Income (avg/median/last-month, **spike-excluded median** of last 3 months, split into salary/rental/other), expenses (retail excludes debt; corporate uses **all debits**), debt (loan/mortgage/credit-card, recurring detection), ratios (surplus, DBR, savings rate, cash flow), balance/liquidity (**time-weighted average balance**, negative-balance days, emergency-fund months), salary regularity, volatility (CV), behavior-change detection, and 9 corporate-specific metrics.

### Transaction classification
Keyword matching (English + Arabic) over `description + reference + merchantName + category` for salary, loan, mortgage, credit-card, utilities, rent, living expenses, rental income; transfers matched on exact `transactionType` enum. Salary detection excludes returns/refunds/reversals and corporate payroll.

### Retail vs corporate
Corporate **includes all debits** as operating expenses (vs retail excluding debt service); salary/age metrics are nullified for corporate; surplus ratio nullified for corporate (downstream NPE risk if ever read).

### Scoring-engine findings
| # | Severity | Finding | Location (approx) |
|---|----------|---------|-------------------|
| 1 | **HIGH** | AGE range overlap: age 61 matches `[61-120]=0pts` before/instead of `[51-60]=100pts` | `CreditRiskScoringService` 512–518 |
| 2 | **HIGH** | Default `annualInterestRate = 3.0%` is below Saudi market (5–8%); inflates affordability | `CreditRiskScoringService` ~392 |
| 3 | MED | Affordability thresholds inconsistent: maxPayment = 30% cash flow, "affordable" ≤40% DBR, risk Low ≤30%/High >50% | `CreditRiskScoringService` 361, 409, 420 |
| 4 | MED | Revenue-trend half-split: with n=1 month, `olderAvg` divides into empty `recentAvg` → −100% / div-by-zero | `FinancialMetricsCalculator` 951–970 |
| 5 | MED | Spike-exclusion threshold = `median × factor`; fails when all 3 months are spikes (median itself inflated) | `FinancialMetricsCalculator` 573–596 |
| 6 | MED | `negativeBalanceDays` skips txns where `balanceAfter == null` → undercounts on sparse balance data | `FinancialMetricsCalculator` ~729 |
| 7 | MED | Supplier-consistency returns `null` for no suppliers but `50` for zero *recurring* suppliers — inconsistent, can inflate score | `FinancialMetricsCalculator` 980, 1003 |
| 8 | MED | LOAN_PAYMENT range labels (comments say "/month avg") don't match the cumulative range values used | `CreditRiskScoringService` 529–536 |
| 9 | LOW | "Credit Card Payment" category not seeded in initial `categoryTotals` map (5 vs 6 categories) | `FinancialMetricsCalculator` ~1180 |
| 10 | LOW | Volatility std-dev via `Math.sqrt(double)` loses BigDecimal precision (<0.01%) | `FinancialMetricsCalculator` ~621 |
| 11 | LOW | Default loan term 60 mo (non-mortgage) / 240 mo (mortgage) hardcoded, not config-driven | `CreditRiskScoringService` 384–386 |
| 12 | LOW | Display rounding (1 dp) vs internal scale (4 dp) can disagree at band boundaries | various |

*Default for missing ranges returns `maxScore / 2` (50%) — a missing/misconfigured factor silently awards half marks.*

---

## 6. PDF Reporting Layer

- **Library:** Apache PDFBox 2.x; A4 pages, Standard-14 Helvetica fonts, logo from classpath (`neotek-logo.png`, orange "neotek" text fallback).
- **V1 (`PdfReportGenerator`, 5 pages):** executive summary, factor breakdown, financial health, transaction analysis, loan exposure + recommendation. Served by `/pdf`.
- **V2 (`PdfReportGeneratorV2`, 8 pages):** all of V1 plus unavailable-factor rendering, weight-redistribution footnotes, a Behavior Analysis page, multi-page Monthly Breakdown, Purpose Assessment, and a metadata footer. Served by `/v2/pdf`. **Both are live** — V1 is *not* dead code.

### PDF findings
- **~95% duplication** between V1 and V2 (pages 1–4, all helpers, color palette) — extract a shared base class.
- ⚠️ **Formatting divergence (correctness):** `formatPercentageShort`/`formatPercentage`/`formatCoefficientOfVariation` multiply by 100 in V1 but assume already-percent in V2 (and vice-versa on some fields) → the **same metric renders with different (wrong) values** depending on endpoint. Reconcile the decimal-vs-percent convention end-to-end.
- **V2 strips non-ASCII** (`replaceAll("[^\\x00-\\x7F]","")`) — Arabic customer names are mangled in the PDF.
- Income-breakdown count basis differs (V1 `totalTransactions` vs V2 `creditTransactionCount`).
- Heavy hardcoding (colors, fonts, credit-class table, recommendation strings, "SAR", date format) and no i18n.
- Minimal error handling beyond logo loading; `IOException` propagates to the controller.

---

## 7. Cross-Cutting Themes

1. **Decimal vs percentage convention is not unified** — surfaces as the band-boundary rounding issue (scoring) and the V1/V2 formatting divergence (PDF). A single documented convention (store decimals, format once) would kill a class of bugs.
2. **Magic numbers / thresholds scattered** — some externalized in `CreditRiskConfig`, many hardcoded in the scoring service (0.3, 0.4, 3.0%, term lengths, age bands). Centralize.
3. **Missing input bounds** — request validation, range sanity (`min ≤ max`), factor/customer-type consistency.
4. **Drahim vs Ob source ambiguity** — verify the fetcher uses the intended active table; retire the unused path.
5. **Duplication & misplaced logic** — PDF V1/V2 duplication; classification keywords inside a DTO.
6. **Observability hygiene** — replace `System.out.println` (which leaks identifiers) with structured logging.

---

## 8. Recommended Priorities

**P0 — correctness (can change a credit decision):**
- Fix AGE band overlap (#1) and verify all band boundaries are contiguous and ordered.
- Reconcile the V1/V2 PDF percentage convention (#3 PDF).
- Raise/parameterize default interest rate; align affordability thresholds.
- Guard revenue-trend for <2 months; fix supplier-consistency null/50 inconsistency.

**P1 — robustness:**
- Add request validation bounds; enforce `min ≤ max` on ranges; validate factor/customer-type match.
- Add date filtering to transaction queries; add the implied indexes.
- Re-validate consent (and expiry) in `getTransactionsForAccount()`.

**P2 — maintainability:**
- Extract a shared PDF base class; move classification keywords out of the DTO into a service; centralize thresholds in `CreditRiskConfig`; replace `System.out.println` with `@Slf4j`; resolve the Drahim/Ob source path.

---

*Generated from a four-agent parallel analysis. Line numbers are approximate (from agent reads) — confirm against current source before editing, as this module is under active change.*