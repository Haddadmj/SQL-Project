# Credit Risk Module — Code Analysis Report

_Analysis only. No code was changed. Branch: `feat/credit-risk-fix`._
_Scope: `src/main/java/com/ejada/obdatarepositoryapp/creditrisk/` — produced by three parallel analysis passes (scoring, data-fetch/parse, API/validation/config), then cross-verified against source._

---

## 0. Which table is actually used

The **active** code path reads from **`raw_transactions`** (entity `ObTransaction`), NOT `drahim_transactions`:

- `CreditRiskScoringService:54` → `dataFetcher.getTransactionsForAccount(...)`
- `OpenBankingDataFetcher:113-115` → `obTransactionRepository.findDecryptedByUserIdAndAccountId(...)`
- `ObTransactionRepository:72` → `FROM raw_transactions` + `pgp_sym_decrypt(...)`, filtered `status IN ('processed','merchant_extraction_failed')`

**Stale/misleading drahim artifacts still in the tree (dead in the active path):**
- `getTransactionsForAccount` Javadoc (`OpenBankingDataFetcher:108`) claims `drahim_transactions` — false.
- `parseDecryptedDrahimTransaction()`, `DrahimTransactionRepository`, `ObTransactionRepository.findDecryptedByAccountId()` — never called.
- `parseDecryptedTransaction()` catch-block log (`:195`) says "drahim transaction" (copy-paste).

> Note: memory note "drahim source switch landed" is **stale** w.r.t. current code — the engine reads `raw_transactions`. (May be an intentional revert per the compare/revert workflow.)

---

## 🔴 Critical

### C1 — Corporate scores computed on a 1150 scale but rated against 1000
- **Where:** `CreditRiskScoringService:77-82`; weights in `enums/RiskFactorType.java:25-32`
- **Verified:** Corporate has **8** factors: BUSINESS_AGE 150, REVENUE_STABILITY 150, REVENUE_TREND 150, OPERATING_EXPENSE_RATIO 150, SUPPLIER_PAYMENT_CONSISTENCY 150, CASH_BUFFER 150, **CORPORATE_CASH_FLOW 150**, PAYMENT_BEHAVIOR 100 = **1150**. Retail = 1000.
- **Why wrong:** `availableMaxPoints = 1000 - skippedMaxScore` and `maxPossibleScore = 1000` are hardcoded. Normalization only runs `if (skippedMaxScore > 0 && availableMaxPoints > 0)`. For a corporate customer with no skipped factors, the raw total (up to 1150) is fed straight into `CreditRatingClass.fromScore` with no scaling → **corporate ratings are systematically inflated**. When BUSINESS_AGE is skipped (no age), it normalizes by `1000-150=850` instead of the true `1150-150=1000` → wrong denominator.
- **Two valid fixes (decision deferred per your instruction):**
  1. Compute `availableMaxPoints` as the sum of `maxScore` over non-skipped factors and **always** normalize to 1000.
  2. Rebalance corporate weights in `RiskFactorType` to sum to 1000 (product/tuning decision on which factor loses points).

### C2 — Continuous values fall into band gaps and silently score 0
- **Where:** band defs `CreditRiskScoringService:513-646`; fall-through `:292` returns `ScoreResult(0, null)`
- **Why wrong:** Many bands use integer boundaries (`…10000` then `10001…`) or `.99/.01` seams, but the scored value is a continuous `BigDecimal`:
  - INCOME (`:522-525`): median `10000.50` matches neither `…10000` nor `10001…`.
  - DEBT_BURDEN_RATIO (`:530-535`): value is `ratio×100` (decimal) vs integer bands.
  - SURPLUS_RATIO (`:541-545`): gap between `0` and `1`, and at `10/11`, `20/21`, `30/31`.
  - CASH_FLOW (`:558-561`): `1000.50` falls between `…1000` and `1001…`.
  - Corporate (`:589-646`): `.99` seams (e.g. `79.99/80`); partially mitigated by 2-dp rounding upstream but real.
  - AGE top band closed at `120` (`:513-517`) → age 121+ or <18 → silent 0.
- **Impact:** a legitimate value scores 0, then C1's renormalization amplifies it.
- **Suggested fix:** make adjacent bands contiguous (next `minValue` == previous `maxValue`, rely on first-match `>=`/`<=`), or fall back to the nearest band instead of 0; open-end the AGE top band.

---

## 🟠 High

### H1 — `hasData` treats a legitimate 0 as "missing"
- **Where:** `CreditRiskScoringService:205` — `hasData = rawValue != null && rawValue.compareTo(ZERO) != 0`
- **Why wrong:** 0 is a valid, scoreable value for CASH_FLOW (band `0..1000`=50pts), SURPLUS_RATIO (0%), REVENUE_TREND (0% flat = "Stable", 100pts), CORPORATE_CASH_FLOW (Fair, 80pts), OPERATING_EXPENSE_RATIO. These get `dataAvailable=false`, are dropped from the total, and their `maxScore` is subtracted from the base — distorting the normalized score. Only LOAN_PAYMENT and DEBT_BURDEN_RATIO are rescued (`:208-211`).
- **Suggested fix:** drive availability off `rawValue == null` only (distinguish null vs zero in the metrics layer).

### H2 — Caller-supplied weights/ranges trusted without validation
- **Where:** `CreditRiskScoringService:156-161`, `:225-226`; `RiskFactorConfig.java:22`
- **Why wrong:** custom `weight` is applied verbatim and never re-validated to sum to the expected total; custom `ranges` aren't checked for contiguity/overlap or that points ≤ weight. A range awarding more points than `maxScore` makes `percentage > 100` and inflates `totalScore`; negative/garbage weights can drive `availableMaxPoints ≤ 0` (then the `>0` guard silently skips renormalization).
- **Suggested fix:** validate caller weights and ranges (sorted, contiguous, `points ∈ [0, weight]`), reject configs whose enabled weights don't sum to expected.

### H3 — Missing request input validation → uncaught 500s
- **Where:** `CreditRiskRequest.java:44-62`; `CreditRiskController`/`OpenBankingDataFetcher`
- **Why wrong:** no `@Positive/@Min/@Max` on `requestedAmount`, `loanTermMonths`, `annualInterestRate`, `age`. Zero term/rate → divide-by-zero `ArithmeticException`; `Long.parseLong(accountLinkId)` (`OpenBankingDataFetcher:63,95`) → `NumberFormatException` unmapped by `GlobalExceptionHandler` → generic 500. Negative `requestedAmount` flows into affordability/amortization.
- **Suggested fix:** add bean-validation constraints; catch/validate ID parsing → 400.

### H4 — Misleading drahim Javadoc + missing dedup filter on the active path
- **Where:** `OpenBankingDataFetcher:107-111` (Javadoc), `:195` (log), `:174` (comment)
- **Why wrong:** Javadoc says it reads `drahim_transactions` and "Filters out ignored transactions (duplicates, failed, same-account transfers)." The active query reads `raw_transactions` filtered only by `status`. There is **no `is_ignored_in_budget` filtering** — the documented dedup/same-account-transfer exclusion does not happen. If scoring assumes ignored/duplicate transactions are removed, this is a correctness gap, not just a doc bug.
- **Suggested fix:** correct the docs/log; decide whether budget-ignore filtering is actually required on this path (if so, it is currently missing entirely).

---

## 🟡 Medium

### M1 — `@Valid` errors bypass the custom error envelope
- **Where:** `GlobalExceptionHandler` (no handler) + `CreditRiskController:48`
- **Why:** `MethodArgumentNotValidException` (e.g. blank `psuId`) hits Spring's default handler, not the custom timestamp/errorCode/message envelope — inconsistent with all other errors. Add an `@ExceptionHandler`.

### M2 — NPE globally mapped to 500 "MISSING_DATA"
- **Where:** `GlobalExceptionHandler:85-97`
- **Why:** an NPE is almost always an internal bug, but it's labeled as a client "required data is missing" error, masking real defects. Remove this handler or scope it narrowly.

### M3 — Transaction fetch performs no consent/TPP isolation
- **Where:** `OpenBankingDataFetcher:112-123`; `ObTransactionRepository:55-75`
- **Why:** `getTransactionsForAccount(psuId, accountId, sponsoredTppId)` ignores `sponsoredTppId` and queries on `user_id`+`account_id` only — no consent existence/status/ownership check (unlike `getAccount`). Relies entirely on `getAccount` being called first; the query has no `sponsored_tpp_id` predicate. Document the precondition or enforce isolation at this layer.

### M4 — Time-weighted average balance ignores the most-recent balance
- **Where:** `FinancialMetricsCalculator:1031` (loop `i < size-1`)
- **Why:** the last (most recent) `balanceAfter` gets zero weight (no "next" interval), skewing the average toward older balances. Same-timestamp txns produce `seconds = 0` and are silently dropped (`:1037`). Extend the last balance to the analysis end; handle zero-duration intervals.

### M5 — Inconsistent time windows within the same formula
- **Where:** `FinancialMetricsCalculator:152-153` vs `:172`, `:191`
- **Why:** `avgExpenses` is over the **last 3 months**, but `avgDebtPayment` and `cashFlow` use **all** months. `avgSurplus`/`surplusRatio` therefore mix a 3-month expense average with an all-month debt average. Also `cashFlow` (`:191`) subtracts total expenses from **salary-only** income — a definition mismatch vs the band comment "Avg Income − Avg Expenses" (`:556`). Pick one window/definition and apply consistently.

### M6 — Spike-exclusion median discards genuine raises
- **Where:** `FinancialMetricsCalculator:573-596` (`calculateMedianExcludingSpikes`)
- **Why:** drops every value above `roughMedian × 1.3`. With 3 months (e.g. 8k, 8k, 12k → threshold 10.4k), a legitimate raise to 12k is discarded as a "spike," understating income for upward-trending earners. Use true-outlier/MAD detection or a higher multiplier.

---

## 🟢 Low / Cleanup

- **L1 — Dead drahim/parse code:** `DrahimTransactionRepository`, `parseDecryptedDrahimTransaction` (`OpenBankingDataFetcher:129-163`, uses lowercase `creditDebitIndicator`/`currency` that don't match SAMA JSON), `ObTransactionRepository.findDecryptedByAccountId`, `extractCategory` (`:307-317`), and the `MerchantDetails`/`CreditorAgent` branches of `extractMerchantName` (never fire). Delete to reduce confusion.
- **L2 — `buildErrorReport` hardcodes `factorsSkipped(7)`** (`CreditRiskScoringService:500`) — wrong for corporate's 8 factors.
- **L3 — `System.out.println` debug lines** leaking `psuId` to stdout: `CreditRiskController:50,54,56`. Remove.
- **L4 — `parseCurrency` dead try/catch + broken fallback** (`OpenBankingDataFetcher:247-266`): returning a String can't throw; `amountNode.asText(null)` on an object yields `""` not `null`.
- **L5 — Timezone offset silently dropped** (`OpenBankingDataFetcher:201-224`): `ISO_DATE_TIME` parses `…+03:00` into a naive `LocalDateTime`, discarding the offset. Harmless for KSA-only `+03:00` data (internally consistent) but would corrupt ordering if mixed offsets appear. The `Instant.parse` fallback is dead for this data.
- **L6 — `reference` always null** (`OpenBankingDataFetcher:191`): reads `TransactionReference`, which doesn't exist in the fixture. Confirm against the live SAMA contract.
- **L7 — `parseBalanceAfter` sign negation inert/odd** (`:294-298`): only negates on `KSAOB.Debit`, which never occurs in the fixture; account-balance CDI is not a per-transaction sign. Verify intent.
- **L8 — Enum lookup inconsistency:** `CustomerType.fromString` throws `IllegalArgumentException` (caught → 400); `LoanPurpose`/`RiskFactorType` have no `@JsonCreator` → Jackson `InvalidFormatException` (unmapped → 500). Inconsistent.
- **L9 — Substring guards:** `report.getReportId().substring(0,8)` (`CreditRiskController:84,116`) — safe for UUIDs but would throw if `reportId` is null/short (e.g. from `buildErrorReport`).

---

## Cross-agent verification notes

- **Conflict resolved:** the corporate weight total is **1150** (verified directly in `RiskFactorType.java`). The pass that reported "1000" omitted `CORPORATE_CASH_FLOW`.
- **Confirmed correct (not bugs):** amortization formula + zero guards (`:441-470`); BigDecimal divides all pass scale + RoundingMode; comparisons use `compareTo` not `equals`; retail weights sum to 1000; `DEFAULT_RANGES` reference is swapped per-request, not mutated in place; active `parseDecryptedTransaction` field names (`CreditDebitIndicator`, `TransactionType`, `Amount.Amount`, `Balance.Amount.Amount`) all match `data_transactions.json` exactly.
- **Test gap:** `BakeryFixtureIntegrationTest` reimplements parsing instead of calling production `parseDecryptedTransaction`, so it cannot catch regressions in the production parser (or the H4 log bug).
