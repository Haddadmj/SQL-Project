package com.ejada.obrepositoryabstractmodel.errors;

import lombok.Getter;

@Getter
public enum ErrorCodes {
    REQUEST_ID_IS_MANDATORY("E200001", Constants.REQUEST_ID_IS_MANDATORY),
    ACCOUNTS_LINK_ID_IS_MANDATORY("E200002", Constants.ACCOUNTS_LINK_ID_IS_MANDATORY),
    FINANCIAL_INSTITUTION_ID_IS_MANDATORY("E200003", Constants.FINANCIAL_INSTITUTION_ID_IS_MANDATORY),
    APPLICATION_ID_IS_MANDATORY("E200004", Constants.APPLICATION_ID_IS_MANDATORY),
    PSU_ID_IS_MANDATORY("E200005", Constants.PSU_ID_IS_MANDATORY),
    ACCOUNT_ID_IS_MANDATORY("E200006", Constants.ACCOUNT_ID_IS_MANDATORY),
    RESOURCE_TYPE_IS_MANDATORY("E200007", Constants.RESOURCE_TYPE_IS_MANDATORY),
    INVALID_RESOURCE_TYPE("E200008", Constants.INVALID_RESOURCE_TYPE),
    INVALID_ACCOUNT_TYPE("E200009", Constants.INVALID_ACCOUNT_TYPE),
    INVALID_ACCOUNT_SUB_TYPE("E200010", Constants.INVALID_ACCOUNT_SUB_TYPE),
    INVALID_STATUS("E200011", Constants.INVALID_STATUS),
    INVALID_ORDER("E200012", Constants.INVALID_ORDER),
    INVALID_TRANSACTION_TYPE("E200013", Constants.INVALID_TRANSACTION_TYPE),
    INVALID_TRANSACTION_SUB_TYPE("E200014", Constants.INVALID_TRANSACTION_SUB_TYPE),
    INVALID_TRANSACTION_FLAGS("E200015", Constants.INVALID_TRANSACTION_FLAGS),
    INVALID_PAYMENT_MODE("E200016", Constants.INVALID_PAYMENT_MODE),
    INVALID_TRANSACTION_AMOUNT_TYPE("E200017", Constants.INVALID_TRANSACTION_AMOUNT_TYPE),
    INVALID_TRANSACTION_MUTABILITY("E200018", Constants.INVALID_TRANSACTION_MUTABILITY),
    INVALID_CARD_SCHEME_NAME("E200019", Constants.INVALID_CARD_SCHEME_NAME),
    INVALID_INSTRUMENT_TYPE("E200020", Constants.INVALID_INSTRUMENT_TYPE),
    INVALID_SCHEDULE_TYPE("E200021", Constants.INVALID_SCHEDULE_TYPE),
    ACCOUNTS_LINK_FETCHER_ID_IS_MANDATORY("E200022", Constants.ACCOUNTS_LINK_FETCHER_ID_IS_MANDATORY),
    TOTAL_PAGES_IS_MANDATORY("E200023", Constants.TOTAL_PAGES_IS_MANDATORY),
    FAILED_PAGES_IS_MANDATORY("E200024", Constants.FAILED_PAGES_IS_MANDATORY),
    SUCCESS_PAGES_IS_MANDATORY("E200025", Constants.SUCCESS_PAGES_IS_MANDATORY),
    APPLICATION_DOES_NOT_EXIST("E200026", Constants.APPLICATION_DOES_NOT_EXIST),

    INVALID_BENEFICIARY_TYPE("E200027", Constants.INVALID_BENEFICIARY_TYPE);
    private final String code;
    private final String desc;

    ErrorCodes(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static class Constants {
        public static final String REQUEST_ID_IS_MANDATORY = "Request ID is mandatory";
        public static final String ACCOUNTS_LINK_ID_IS_MANDATORY = "Account Links ID is mandatory";
        public static final String FINANCIAL_INSTITUTION_ID_IS_MANDATORY = "Financial Institution ID is mandatory";
        public static final String APPLICATION_ID_IS_MANDATORY = "Application ID is mandatory";
        public static final String PSU_ID_IS_MANDATORY = "PSU ID is mandatory";
        public static final String ACCOUNT_ID_IS_MANDATORY = "Account ID is mandatory";
        public static final String RESOURCE_TYPE_IS_MANDATORY = "Resource Type is mandatory";
        public static final String INVALID_RESOURCE_TYPE = "Invalid Resource Type";
        public static final String INVALID_BALANCE_TYPE = "Invalid Balance Type";
        public static final String INVALID_BALANCE_AMOUNT_TYPE = "Invalid Balance Amount Type";
        public static final String INVALID_ACCOUNT_TYPE = "Invalid AccountType";
        public static final String INVALID_ACCOUNT_SUB_TYPE = "Invalid AccountSubType";
        public static final String INVALID_STATUS = "Invalid Status";
        public static final String INVALID_ACCOUNT_STATUS = "Invalid Account Status";
        public static final String INVALID_TRANSACTION_STATUS = "Invalid Transaction Status";
        public static final String INVALID_ORDER = "Invalid Order";
        public static final String INVALID_TRANSACTION_TYPE = "Invalid TransactionType";
        public static final String INVALID_TRANSACTION_SUB_TYPE = "Invalid TransactionSubType";
        public static final String INVALID_TRANSACTION_FLAGS = "Invalid TransactionFlags";
        public static final String INVALID_PAYMENT_MODE = "Invalid PaymentMode";
        public static final String INVALID_TRANSACTION_AMOUNT_TYPE = "Invalid TransactionAmountType";
        public static final String INVALID_TRANSACTION_MUTABILITY = "Invalid TransactionMutability";
        public static final String INVALID_CARD_SCHEME_NAME = "Invalid CardSchemeName";
        public static final String INVALID_INSTRUMENT_TYPE = "Invalid InstrumentType";
        public static final String INVALID_SCHEDULE_TYPE = "Invalid Schedule Type";
        public static final String ACCOUNTS_LINK_FETCHER_ID_IS_MANDATORY = "AccountsLinkFetcherId is Mandatory";
        public static final String TOTAL_PAGES_IS_MANDATORY = "TotalPages is Mandatory";
        public static final String FAILED_PAGES_IS_MANDATORY = "FailedPages is Mandatory";
        public static final String SUCCESS_PAGES_IS_MANDATORY = "SuccessPages is Mandatory";
        public static final String INVALID_INCLUDE_BALANCES_FLAG = "IncludeBalancesFlag value is invalid";
        public static final String APPLICATION_DOES_NOT_EXIST = "Application doesn't exist";
        public static final String INVALID_BENEFICIARY_TYPE = "Invalid Beneficiary Type";
    }
}
