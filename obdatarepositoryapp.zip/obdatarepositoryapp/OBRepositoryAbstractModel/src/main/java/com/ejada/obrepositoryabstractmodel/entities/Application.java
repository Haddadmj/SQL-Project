package com.ejada.obrepositoryabstractmodel.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "application")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Application {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_id_seq")
    @SequenceGenerator(name = "application_id_seq", sequenceName = "application_id_seq", allocationSize = 1)
    private Long id;

    @Column(name = "application_id")
    private String applicationId;

    @Column(name = "sponsored_tpp_id")
    private String sponsoredTPPId;

}
