package com.ejada.obrepositoryabstractmodel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObRepositoryAbstractModelApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObRepositoryAbstractModelApplication.class, args);
	}

}
