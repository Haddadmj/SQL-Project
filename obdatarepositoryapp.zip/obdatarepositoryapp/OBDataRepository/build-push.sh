image="me-jeddah-1.ocir.io/axfao7pkdawf/neotek-repo-dev:darahim-ob-data-repository2.0.5"

current_dir="$(pwd)"
echo "docker build --no-cache -t $image ."
echo "docker push $image"

if docker build --no-cache -t $image .; then
    if ! docker push $image; then
        echo "❌ Push failed: $current_dir"
    fi
else
    echo "❌ Build failed: $current_dir"
fi