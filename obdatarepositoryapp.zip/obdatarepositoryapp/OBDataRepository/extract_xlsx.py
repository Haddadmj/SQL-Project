"""Dump non-empty cells of one or more sheets, showing the FORMULA when a cell
has one, otherwise the literal value. Usage:

    python extract_xlsx.py "<file.xlsx>" "<Sheet Name>" ["<Sheet Name 2>" ...]
    python extract_xlsx.py "<file.xlsx>" --list      # list sheet names
    python extract_xlsx.py "<file.xlsx>" --formulas "<Sheet>"  # only formula cells
"""
import sys
import openpyxl


def main():
    path = sys.argv[1]
    wb = openpyxl.load_workbook(path, data_only=False, read_only=False)

    if len(sys.argv) >= 3 and sys.argv[2] == "--list":
        for ws in wb.worksheets:
            print(f"{ws.title}\tdims={ws.dimensions}\tstate={ws.sheet_state}")
        return

    formulas_only = False
    args = sys.argv[2:]
    if args and args[0] == "--formulas":
        formulas_only = True
        args = args[1:]

    for name in args:
        ws = wb[name]
        print(f"\n===== SHEET: {name} (dims={ws.dimensions}, state={ws.sheet_state}) =====")
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if v is None or (isinstance(v, str) and v.strip() == ""):
                    continue
                is_formula = isinstance(v, str) and v.startswith("=")
                if formulas_only and not is_formula:
                    continue
                tag = "FORMULA" if is_formula else "value"
                text = str(v).replace("\n", "\\n")
                print(f"{cell.coordinate}\t[{tag}]\t{text}")


if __name__ == "__main__":
    main()
