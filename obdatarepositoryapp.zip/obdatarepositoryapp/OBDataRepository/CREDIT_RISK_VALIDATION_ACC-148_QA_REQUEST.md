# Credit Risk Validation — ACC-148 (QA Request, age = 17)

**Endpoint:** `POST /api/v1/credit-risk/getCreditRiskReport`
**Validated:** 2026-06-14
**Request (QA replica):**
```json
{
  "psuId": "AbrarCRA2",
  "accountLinkId": "1442",
  "accountId": "ACC-148",
  "sponsoredTppId": "01K920FBZBT9NE8WRP8BQSHSBQ",
  "customerType": "RETAIL",
  "age": 17
}
```
**Result:** `totalScore = 270` · `ratingClass = CC` ("Very Weak") · approval **Very Low**

> **QA-replica note.** With `age = 17` supplied, AGE is evaluated (scores 0, `dataAvailable = true`), so there is no ×1000/850 redistribution and the total is the flat sum: 270 → CC. The prior age-omitted run returned 318/CCC purely from the redistribution artifact (D6).

---

## 1. Executive Summary

- **Internally consistent:** ✅ Yes — every metric and score reproduces exactly (one harmless IEEE-754 float artifact on `surplusRatio`, band unaffected).
- **Follows DF-4018 to the dot:** ❌ **No — this is the clearest failure of the three.** The spec-correct formulas yield **320/CCC** (= the QA workbook expectation); the live code returns **270/CC** — **one rating class too low**. The gap is fully explained by two formula divergences: **D1 (+100)** and **D2 (−50)**, net **+50**, which crosses the CC→CCC boundary.
- **One thing to fix:** D1 (Surplus Ratio) and D2 (Cash Flow) — together they misclassify this stressed-but-borderline applicant a full notch worse than the spec intends.

---

## 2. Input Data Profile

| Property | Value |
|---|---|
| Transactions | 53 (6 credit, 47 debit) |
| Months of data | 7 (2025-09 → 2026-03, consecutive) |
| Salary pattern | 6 monthly credits `"Salary - Retail Chain (Hourly) / راتب"` |
| Debt | 1,000/mo loan = 6,000 total; **no mortgage** |
| ⚠️ Notable | **2026-03 is a zero-income month** (a single 428 debit, income = 0); it is present and counted (`monthsOfData = 7`) |
| Current balance | 18,873.00 SAR · IBAN SA90…0749 · SAIB |

**Expense categories** (debits, total 22,577):

| Category | Amount | % |
|---|---|---|
| Others | 7,918.00 | 35.07 % |
| Loan Repayments | 6,000.00 | 26.58 % |
| Living Expenses | 5,218.00 | 23.11 % |
| Utilities | 3,441.00 | 15.24 % |

---

## 3. Financial Metrics Validation

All metrics **PASS** (±0.01). One cosmetic float artifact: `surplusRatio` raw −11.21999… vs report −11.22 (IEEE-754 noise; band unaffected).

| Metric | Value | Metric | Value |
|---|---|---|---|
| medianMonthlyIncome | 2,900.00 | surplusRatio | −0.1122 |
| medianSalaryIncome | 2,900.00 | debtBurdenRatio | 0.2956 |
| averageMonthlyExpenses | ~2,650 | cashFlow | 217.57 |
| lastMonthIncome | **0** | lastMonthIncomeChange | **−100 %** (CRITICAL income-drop) |
| incomeVolatility | **41.21 %** (HIGH) | salaryOccurrences | 6 |

**L3M median window** = `[2026-03, 2026-02, 2026-01]` incomes `[0, 2900, 3200]`; spike threshold = 2900 × 1.3 = 3,770 (nothing dropped — spike exclusion is high-side only); median = **2,900**. The zero-income month sits at the head of the window and pulls the median down, tipping INCOME and SALARY_CATEGORY into their lowest bands.

---

## 4. Factor Scoring (age = 17, flat sum)

| Factor | Raw value | Band | Score / Max | Label |
|---|---|---|---|---|
| AGE | 17 | *no band* | **0** / 150 | Very Poor |
| INCOME | 2,900 | ≤ 5,000 | **0** / 150 | Below minimum threshold |
| LOAN_PAYMENT | 0 (fallback) | ≤ 1,500 | **150** / 150 | Very low debt |
| SURPLUS_RATIO | −11.22 | −100–0 | **0** / 150 | Spending more than earning |
| SALARY_CATEGORY | 2,900 | ≤ 5,000 | **30** / 150 | High Risk |
| CASH_FLOW | 217.57 | 0–1,000 | **50** / 150 | Minimal positive |
| DEBT_BURDEN_RATIO | 29.56 | 26–40 | **40** / 100 | Moderate |

**Total:** `0 + 0 + 150 + 0 + 30 + 50 + 40 = 270`. `factorsSkipped = 0`, `weightsRedistributed = false` → **270 → CC**. ✅ (arithmetically exact for this data)

**Recommendation:** strengths = [Loan Payment]; weaknesses = [Age: Very Poor, Income: Below minimum threshold, Surplus Ratio: Spending more than earning, Salary Category: High Risk, Cash Flow: Minimal positive]; recommendations = ["Consider reducing monthly expenses to improve surplus ratio"]; `maxAffordablePayment = floor(217.57 × 0.3) = 65`.

---

## 5. DF-4018 Conformance — Does it follow the spec to the dot?

**No. This account exposes the two band-changing factor divergences.**

| Div | Spec rule | Code → band → pts | Spec → band → pts | Δ pts | Class effect |
|---|---|---|---|---|---|
| **D1 Surplus Ratio** | `(income − exp)/income` (no debt) | −11.22 % → 0 | **18.34 % → 100** | **+100** | CC → B |
| **D2 Cash Flow** | `(Σsalary − Σ all debits)/n` | 217.57 → 50 | **−639.57 → 0** | **−50** | CC → CC↓ |
| D3 Salary Category | last-month salary | med 2,900 → 30 | last = 0 → 30 | 0 | inert |
| D4 DBR | ÷ median income | 29.56 % → 40 | 29.56 % → 40 | 0 | inert (income = salary) |
| D5 Loan Payment | loans only | 0 → 150 | 0 → 150 | 0 | inert (no mortgage) |
| D6 Redistribution | "equally" | inactive (age supplied) | — | — | ✅ off |
| D7 monthsOfData | inject zero-activity months | 7 (all present) | 7 | 0 | inert (no gap — 2026-03 is debit-bearing) |
| D8 Avg Balance 6M | "Not Available" | **0.0** | — | — | ❌ fails |

**Combined D1 + D2:** `270 + 100 − 50 = 320 → CCC`. **This is exactly the QA workbook expectation.** The two divergences are opposite-sign and net to +50, which is enough to cross CC → CCC. The live code's **270/CC understates the spec-correct 320/CCC by one rating class.**

---

## 6. Comparison to QA Workbook

| | QA workbook | Code (age = 17) | Spec-correct (D1 + D2) |
|---|---|---|---|
| Total | **320** | **270** | **320** ✅ |
| Class | **CCC** | **CC** ❌ | CCC |

The QA workbook's 320/CCC equals the **spec-correct** result. The live engine produces 270/CC — a genuine **one-class conformance failure**, caused by D1 and D2. (The 2026-03 zero-income month is handled correctly and is *not* the cause; D7 is inert because that month carries a transaction.)

---

## 7. Findings & Recommendations

1. **❌ Code fails the spec by one rating class (CC vs CCC).** Priority fix: **D1 (Surplus Ratio)** — stop subtracting debt and stop using median; use `(income − expenses)/income`. This alone is +100 raw (→ B).
2. **❌ Fix D2 (Cash Flow)** — the spec is `(Σsalary − Σ all debits)/n`; the code excludes debt from the debits. This is −50 raw and partially offsets D1.
3. **ℹ️ Net effect** — with both D1 and D2 corrected the engine lands on **320/CCC**, matching the QA workbook exactly.
4. **⚠️ D8** — `averageBalance6M` 0.0 should be "Not Available".
5. **ℹ️ Zero-income month handled correctly** — 2026-03 is counted; spike exclusion correctly does not drop it; the resulting −100 % income-drop and 41.21 % volatility flags are accurate signals.
