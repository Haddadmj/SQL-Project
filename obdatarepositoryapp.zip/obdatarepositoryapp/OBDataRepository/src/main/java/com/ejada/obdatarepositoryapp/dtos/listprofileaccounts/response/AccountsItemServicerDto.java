package com.ejada.obdatarepositoryapp.dtos.listprofileaccounts.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class AccountsItemServicerDto {
    @JsonProperty("IdentificationType")
    private String identificationType;

    @JsonProperty("Identification")
    private String identification;
}
