package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Getter;

@Getter
public enum OrderEnums {
    ASC("ASC"),
    DESC("DESC");


    private final String value;

    OrderEnums(String value) {
        this.value = value;
    }

    @Override
//    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static OrderEnums fromValue(String text) {
        for (OrderEnums b : OrderEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
