package com.ejada.obdatarepositoryapp.clients.models.ListAccounts;

import com.ejada.obdatarepositoryapp.dtos.listprofileaccounts.response.ListProfileAccountsDataDto;
import com.ejada.obdatarepositoryapp.dtos.listprofileaccounts.response.ListProfileAccountsItemDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ClientListAccountsResponse {
    @JsonProperty("total_count")
    private Integer totalCount;

    @JsonProperty("result_list")
    private List<ListProfileAccountsItemDto> accounts = new ArrayList<>();
}
