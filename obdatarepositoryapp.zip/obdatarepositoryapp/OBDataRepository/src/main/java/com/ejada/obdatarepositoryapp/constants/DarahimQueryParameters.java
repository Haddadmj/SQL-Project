package com.ejada.obdatarepositoryapp.constants;

public class DarahimQueryParameters {
    public static final String DARAHIM_PSU_ID = "psu_id";
    public static final String PROFILE_ID = "profile_id";
    public static final String FINANCIAL_INSTITUTION_ID = "financial_institution_id";
    public static final String ACCOUNTS_LINK_ID = "accounts_link_id";
    public static final String ACCOUNT_ID = "account_id";
    public static final String STATUS = "status";
    public static final String CURRENCY = "currency";
    public static final String ACCOUNT_TYPE = "account_type";
    public static final String ACCOUNT_SUB_TYPE = "account_sub_type";
    public static final String FROM_OPENING_DATE = "from_opening_date";
    public static final String TO_OPENING_DATE = "to_opening_date";
    public static final String ORDER = "order";
    public static final String BALANCE_TYPE = "balance_type";
    public static final String TRANSACTION_TYPE = "transaction_type";
    public static final String TRANSACTION_SUB_TYPE = "transaction_sub_type";
    public static final String TRANSACTION_FLAGS = "transaction_flags";
    public static final String PAYMENT_MODE = "payment_mode";
    public static final String TRANSACTION_AMOUNT_TYPE = "transaction_amount_type";
    public static final String TRANSACTION_MUTABILITY = "transaction_mutability";
    public static final String FROM_BOOKING_DATE = "from_booking_date";
    public static final String TO_BOOKING_DATE = "to_booking_date";
    public static final String FROM_AMOUNT = "from_amount";
    public static final String TO_AMOUNT = "to_amount";
    public static final String MERCHANT_NAME = "merchant_name";
    public static final String CARD_SCHEME_NAME = "card_scheme_name";

    public static final String FINANCIAL_INSTITUTION_NAME = "financial_institution_name";
    public static final String INCLUDE_BALANCES_FLAG = "include_balances_flag";

    public static final String SPONSORED_TPP_ID = "sponsored_tpp_id";
    public static final String TRANSACTION_STATUS = "transaction_status";

    public static final String LIMIT = "limit";
    public static final String OFFSET = "offset";
    public static final String INSTRUMENT_TYPE = "instrument-type";
    public static final String BALANCE_AMOUNT_TYPE = "balance-amount-type";
    public static final String BENEFICIARY_TYPE = "beneficiary_type";
    public static final String BENEFICIARY_NAME = "beneficiary_name" ;
    public static final String BENEFICIARY_SHORT_NAME = "beneficiary_short_name";
    public static final String BENEFICIARY_BANK_NAME = "beneficiary_bank_name";

}
