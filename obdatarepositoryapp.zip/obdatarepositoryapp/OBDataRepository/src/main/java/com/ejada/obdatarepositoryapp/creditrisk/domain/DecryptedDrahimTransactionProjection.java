package com.ejada.obdatarepositoryapp.creditrisk.domain;

import java.time.Instant;

/**
 * Projection interface for database-level decrypted drahim transaction data.
 * Used with native queries that utilize pgp_sym_decrypt().
 */
public interface DecryptedDrahimTransactionProjection {
    
    String getId();
    
    String getUserId();
    
    String getAccountId();
    
    String getSponsoredTppId();
    
    String getKind();
    
    String getEffectiveCategoryId();
    
    Instant getTimestamp();
    
    String getDecryptedData();
}
