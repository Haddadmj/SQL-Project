package com.ejada.obdatarepositoryapp.clients.models.ListProfileBeneficiaries;

import com.ejada.obdatarepositoryapp.dtos.listprofilebeneficiariesresponse.ListProfileBeneficiariesItemDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ClientListBeneficiariesResponse {
    @JsonProperty("total_count")
    private Integer totalCount;

    @JsonProperty("result_list")
    private List<ListProfileBeneficiariesItemDto> beneficiaries = new ArrayList<>();
}
