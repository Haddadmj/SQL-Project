package com.ejada.obdatarepositoryapp.repositories;

import com.ejada.obrepositoryabstractmodel.entities.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ApplicationRepo extends JpaRepository<Application, Long> {

    Optional<Application> findByApplicationId(String applicationId);

}
