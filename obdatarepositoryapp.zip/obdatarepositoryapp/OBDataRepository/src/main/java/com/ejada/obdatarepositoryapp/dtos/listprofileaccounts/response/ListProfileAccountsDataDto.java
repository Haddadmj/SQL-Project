package com.ejada.obdatarepositoryapp.dtos.listprofileaccounts.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class ListProfileAccountsDataDto {
    @JsonProperty("Accounts")
    private List<ListProfileAccountsItemDto> accounts;
}
