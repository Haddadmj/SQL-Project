package com.ejada.obdatarepositoryapp.creditrisk.dto.response;

import com.ejada.obdatarepositoryapp.creditrisk.domain.DecryptedDrahimTransactionProjection;
import com.ejada.obdatarepositoryapp.creditrisk.domain.DecryptedTransactionProjection;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Debug-only response exposing the raw rows returned from the
 * raw_transactions table (via {@code ObTransactionRepository}) and the
 * drahim_transactions table (via {@code DrahimTransactionRepository}),
 * with PGP decryption already applied at the database level.
 *
 * <p>Intended for troubleshooting data availability and decryption issues.
 * Not part of the production scoring flow.</p>
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DebugTransactionsResponse {

    /** The identifiers used to run the queries. */
    private String psuId;
    private String accountLinkId;
    private String requestedAccountId;
    private String sponsoredTppId;

    /** The internal account id (account.getId()) the queries actually ran against. */
    private String resolvedInternalAccountId;

    /** True when the account/consent was resolved successfully. */
    private boolean accountResolved;

    /** Optional message describing resolution outcome or errors. */
    private String message;

    /** raw_transactions (ObTransactionRepository) results. */
    private int rawTransactionsCount;
    private List<DecryptedTransactionProjection> rawTransactions;

    /** drahim_transactions (DrahimTransactionRepository) results. */
    private int drahimTransactionsCount;
    private List<DecryptedDrahimTransactionProjection> drahimTransactions;
}
