package com.ejada.obdatarepositoryapp.dtos.listprofileaccounts.response;

import com.ejada.obdatarepositoryapp.dtos.commondtos.response.FinancialInstitutionDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListProfileAccountsItemDto {
    @JsonProperty("ProfileId")
    private String profileId;

    @JsonProperty("AccountsLinkId")
    private String accountsLinkId;

    @JsonProperty("FinancialInstitution")
    private FinancialInstitutionDto financialInstitution;

    @JsonProperty("AccountId")
    private String accountId;

    @JsonProperty("AccountHolderName")
    private String accountHolderName;

    @JsonProperty("AccountHolderShortName")
    private String accountHolderShortName;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("StatusUpdateDateTime")
    private OffsetDateTime statusUpdateDateTime;

    @JsonProperty("Currency")
    private String currency;

    @JsonProperty("AccountType")
    private String accountType;

    @JsonProperty("AccountSubType")
    private String accountSubType;

    @JsonProperty("Description")
    private String description;

    @JsonProperty("Nickname")
    private String nickname;

    @JsonProperty("OpeningDate")
    private OffsetDateTime openingDate;

    @JsonProperty("MaturityDate")
    private OffsetDateTime maturityDate;

    @JsonProperty("AccountIdentifiers")
    @Builder.Default
    private List<AccountsItemAccountIdentifiersDto> accountIdentifiers = new ArrayList<>();

    @JsonProperty("Servicer")
    private AccountsItemServicerDto servicer;

    @JsonProperty("Balances")
//    @Builder.Default
    private List<AccountBalanceDTO> balancesList;
}
