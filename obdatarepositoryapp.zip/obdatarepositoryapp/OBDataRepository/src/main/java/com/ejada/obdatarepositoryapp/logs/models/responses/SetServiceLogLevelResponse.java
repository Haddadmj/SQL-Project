package com.ejada.obdatarepositoryapp.logs.models.responses;

import com.ejada.commons.logs.LogLevel;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SetServiceLogLevelResponse {

    @JsonProperty("LogLevel")
    @NotNull
    private LogLevel logLevel;
}
