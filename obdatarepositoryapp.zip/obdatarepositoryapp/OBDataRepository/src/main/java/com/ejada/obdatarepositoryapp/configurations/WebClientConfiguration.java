package com.ejada.obdatarepositoryapp.configurations;

import feign.okhttp.OkHttpClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfiguration {

    @Bean
    WebClient createWebClient() {
        return WebClient.create();
    }
    @Bean
    public OkHttpClient client() {
        return new OkHttpClient();
    }

}
