package com.ejada.obdatarepositoryapp.constants;

public class ControllerQueryParameters {
    public static final String APPLICATION_ID = "ApplicationId";
    public static final String PSU_ID = "PSUId";
    public static final String PROFILE_ID = "ProfileId";
    public static final String FINANCIAL_INSTITUTION_ID = "FinancialInstitutionId";
    public static final String ACCOUNTS_LINK_ID = "AccountsLinkId";
    public static final String ACCOUNT_ID = "AccountId";
    public static final String STATUS = "Status";
    public static final String CURRENCY = "Currency";
    public static final String ACCOUNT_TYPE = "AccountType";
    public static final String ACCOUNT_SUB_TYPE = "AccountSubType";
    public static final String FROM_OPENING_DATE = "FromOpeningDate";
    public static final String TO_OPENING_DATE = "ToOpeningDate";
    public static final String PAGE = "Page";
    public static final String ORDER = "Order";
    public static final String BALANCE_TYPE = "BalanceType";
    public static final String BALANCE_AMOUNT_TYPE = "BalanceAmountType";
    public static final String TRANSACTION_TYPE = "TransactionType";
    public static final String TRANSACTION_SUB_TYPE = "TransactionSubType";
    public static final String TRANSACTION_FLAGS = "TransactionFlags";
    public static final String PAYMENT_MODE = "PaymentMode";
    public static final String TRANSACTION_AMOUNT_TYPE = "TransactionAmountType";
    public static final String TRANSACTION_MUTABILITY = "TransactionMutability";
    public static final String FROM_BOOKING_DATE = "FromBookingDate";
    public static final String TO_BOOKING_DATE = "ToBookingDate";
    public static final String FROM_AMOUNT = "FromAmount";
    public static final String TO_AMOUNT = "ToAmount";
    public static final String MERCHANT_NAME = "MerchantName";
    public static final String CARD_SCHEME_NAME = "CardSchemeName";
    public static final String INSTRUMENT_TYPE = "InstrumentType";
    public static final String FINANCIAL_INSTITUTION_NAME = "FinancialInstitutionName";
    public static final String INCLUDE_BALANCES_FLAG = "IncludeBalancesFlag";
    public static final String BENEFICIARY_TYPE = "BeneficiaryType";
    public static final String BENEFICIARY_NAME = "BeneficiaryName" ;
    public static final String BENEFICIARY_SHORT_NAME = "BeneficiaryShortName";
    public static final String BENEFICIARY_BANK_NAME = "BeneficiaryBankName";

}
