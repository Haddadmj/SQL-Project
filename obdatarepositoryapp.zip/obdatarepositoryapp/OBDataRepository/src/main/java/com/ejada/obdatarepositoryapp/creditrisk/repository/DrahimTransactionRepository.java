package com.ejada.obdatarepositoryapp.creditrisk.repository;

import com.ejada.obdatarepositoryapp.creditrisk.domain.DecryptedDrahimTransactionProjection;
import com.ejada.obdatarepositoryapp.creditrisk.domain.DrahimTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for accessing drahim_transactions table.
 * Provides processed transactions with categorization and budget filtering.
 */
@Repository
public interface DrahimTransactionRepository extends JpaRepository<DrahimTransaction, String> {

    /**
     * Find all valid transactions for a user and account, filtering out ignored transactions.
     * Uses is_ignored_in_budget = false to exclude duplicates, failed, or same-account transfers.
     */
    @Query("SELECT t FROM DrahimTransaction t WHERE t.userId = :userId AND t.accountId = :accountId " +
           "AND t.sponsoredTppId = :sponsoredTppId AND t.isIgnoredInBudget = false ORDER BY t.timestamp DESC")
    List<DrahimTransaction> findValidTransactionsByUserAndAccount(
            @Param("userId") String userId,
            @Param("accountId") String accountId,
            @Param("sponsoredTppId") String sponsoredTppId);

    /**
     * Find all valid transactions for a user across all their accounts under a sponsored TPP.
     */
    @Query("SELECT t FROM DrahimTransaction t WHERE t.userId = :userId " +
           "AND t.sponsoredTppId = :sponsoredTppId AND t.isIgnoredInBudget = false ORDER BY t.timestamp DESC")
    List<DrahimTransaction> findValidTransactionsByUser(
            @Param("userId") String userId,
            @Param("sponsoredTppId") String sponsoredTppId);

    /**
     * Find all valid transactions for multiple account IDs under a sponsored TPP.
     */
    @Query("SELECT t FROM DrahimTransaction t WHERE t.userId = :userId AND t.accountId IN :accountIds " +
           "AND t.sponsoredTppId = :sponsoredTppId AND t.isIgnoredInBudget = false ORDER BY t.timestamp DESC")
    List<DrahimTransaction> findValidTransactionsByUserAndAccounts(
            @Param("userId") String userId,
            @Param("accountIds") List<String> accountIds,
            @Param("sponsoredTppId") String sponsoredTppId);

    /**
     * Find all valid transactions for a user and account with database-level PGP decryption.
     * Uses pgp_sym_decrypt() to decrypt encrypted_data at database level.
     */
    @Query(value = """
        SELECT 
            t.id as id,
            t.user_id as userId,
            t.account_id as accountId,
            t.sponsored_tpp_id as sponsoredTppId,
            t.kind as kind,
            t.effective_category_id as effectiveCategoryId,
            t.timestamp as timestamp,
            CAST(pgp_sym_decrypt(t.encrypted_data, :encryptionKey) AS text) as decryptedData
        FROM drahim_transactions t
        WHERE t.user_id = :userId 
          AND t.account_id = :accountId
          AND t.sponsored_tpp_id = :sponsoredTppId
          AND t.is_ignored_in_budget = false
          AND t.encrypted_data IS NOT NULL
        ORDER BY t.timestamp DESC
        """, nativeQuery = true)
    List<DecryptedDrahimTransactionProjection> findDecryptedByUserAndAccount(
            @Param("userId") String userId,
            @Param("accountId") String accountId,
            @Param("sponsoredTppId") String sponsoredTppId,
            @Param("encryptionKey") String encryptionKey);
}
