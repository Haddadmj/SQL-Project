package com.ejada.obdatarepositoryapp.dtos.listprofilebeneficiariesresponse;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PostalAddressDto {
    @JsonProperty("AddressType")
    private String addressType;

    @JsonProperty("ShortAddress")
    private String shortAddress;

    @JsonProperty("BuildingNumber")
    private String buildingNumber;

    @JsonProperty("UnitNumber")
    private Integer unitNumber;

    @JsonProperty("StreetName")
    private String streetName;

    @JsonProperty("SecondaryNumber")
    private String secondaryNumber;

    @JsonProperty("District")
    private String district;

    @JsonProperty("PostalCode")
    private String postalCode;

    @JsonProperty("City")
    private String city;

    @JsonProperty("Country")
    private String country;
}
