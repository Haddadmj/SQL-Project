package com.ejada.obdatarepositoryapp.creditrisk.dto.response;

import com.ejada.obdatarepositoryapp.creditrisk.enums.RiskFactorType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Score breakdown for a single risk factor.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FactorScore {
    
    private RiskFactorType factorType;
    private String factorName;
    private BigDecimal rawValue;
    private String formattedValue;
    private Integer score;
    private Integer maxScore;
    private Double percentage;
    private String scoreLabel;
    private BigDecimal industryStandard;
    private String industryStandardLabel;
    private Boolean dataAvailable;
    private String dataUnavailableReason;
}
