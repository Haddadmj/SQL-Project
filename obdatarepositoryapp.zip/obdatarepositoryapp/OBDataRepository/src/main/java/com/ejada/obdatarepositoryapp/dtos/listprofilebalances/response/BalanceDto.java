package com.ejada.obdatarepositoryapp.dtos.listprofilebalances.response;

import com.ejada.obdatarepositoryapp.dtos.commondtos.response.FinancialInstitutionDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class BalanceDto {
    @JsonProperty("ProfileId")
    private String profileId;

    @JsonProperty("AccountsLinkId")
    private String accountsLinkId;

    @JsonProperty("FinancialInstitution")
    private FinancialInstitutionDto financialInstitution;

    @JsonProperty("AccountId")
    private String accountId;

    @JsonProperty("CreditDebitIndicator")
    private String creditDebitIndicator;

    @JsonProperty("Type")
    private String type;

    @JsonProperty("DateTime")
    private OffsetDateTime dateTime;

    @JsonProperty("Amount")
    private AmountDto amount;

    @JsonProperty("CreditLine")
    @Builder.Default
    private List<CreditLineDto> creditLine = new ArrayList<>();
}
