package com.ejada.obdatarepositoryapp.utils;

import com.ejada.obdatarepositoryapp.models.EnumValidatorByClassConstants;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EnumValidatorByClassConstantsImpl implements ConstraintValidator<EnumValidatorByClassConstants, CharSequence> {
    private Set<String> acceptedValues;

    @Override
    public void initialize(EnumValidatorByClassConstants annotation) {
        acceptedValues = Stream.of(annotation.enumClass().getEnumConstants())
                               .map(Enum::toString)
                               .collect(Collectors.toSet());
    }

    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        return acceptedValues.contains(value.toString());
    }

}
