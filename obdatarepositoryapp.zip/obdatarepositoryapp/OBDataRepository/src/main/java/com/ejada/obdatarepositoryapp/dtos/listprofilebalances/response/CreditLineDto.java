package com.ejada.obdatarepositoryapp.dtos.listprofilebalances.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class CreditLineDto {
    @JsonProperty("Included")
    private boolean included;
    @JsonProperty("Type")
    private String type;
    @JsonProperty("Amount")
    private AmountDto amount;
}
