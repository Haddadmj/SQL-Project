package com.ejada.obdatarepositoryapp.clients.models.ListProfileTransactions;

import com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response.ListProfileTransactionsItemCategorizedDto;
import com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response.ListProfileTransactionsItemDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ClientListTransactionsCategorizedResponse {
    @JsonProperty("total_count")
    private Integer totalCount;

    @JsonProperty("result_list")
    private List<ListProfileTransactionsItemCategorizedDto> transactions = new ArrayList<>();
}
