package com.ejada.obdatarepositoryapp.creditrisk.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;

/**
 * Centralized configuration for Credit Risk Engine.
 * All thresholds and magic numbers are configurable via application.yml.
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "credit-risk")
public class CreditRiskConfig {

    // Spike detection
    private BigDecimal spikeThreshold = new BigDecimal("1.3");  // 30% above median
    
    // Minimum data requirements
    private int minimumMonthsForMedian = 3;
    private int minimumMonthsForRecurring = 3;
    private int recurringDetectionPeriod = 6;  // Look back 6 months
    
    // Salary regularity
    private int salaryMinOccurrences = 3;
    private int salaryDayTolerance = 5;
    
    // Recurring payment tolerance
    private BigDecimal recurringAmountTolerance = new BigDecimal("0.05");  // 5% tolerance
    
    // Behavior change thresholds (percentages)
    private BigDecimal incomeChangeThreshold = new BigDecimal("30");
    private BigDecimal expenseChangeThreshold = new BigDecimal("30");
    private BigDecimal transactionFrequencyChangeThreshold = new BigDecimal("40");
    private BigDecimal highVolatilityThreshold = new BigDecimal("25");
    
    // Severity thresholds (percentages)
    private BigDecimal severityLowMax = new BigDecimal("30");
    private BigDecimal severityMediumMax = new BigDecimal("50");
    private BigDecimal severityHighMax = new BigDecimal("75");
    
    // Industry standards
    private BigDecimal industryStandardIncomeVolatility = new BigDecimal("15");
    private BigDecimal industryStandardSavingsRate = new BigDecimal("15");
    private BigDecimal industryStandardEmergencyFundMonths = new BigDecimal("3");
    private BigDecimal industryStandardDebtBurdenRatio = new BigDecimal("35");
    
    // Supplier consistency
    private BigDecimal supplierConsistencyCVThreshold = new BigDecimal("30");
    
    // Default values for empty/missing data
    private BigDecimal defaultSupplierConsistencyScore = new BigDecimal("50");
    private BigDecimal defaultPaymentBehaviorScore = new BigDecimal("50");
    
    /**
     * Determine severity level based on percentage change.
     */
    public String determineSeverity(BigDecimal changePercent) {
        BigDecimal absChange = changePercent.abs();
        if (absChange.compareTo(severityHighMax) > 0) {
            return "CRITICAL";
        } else if (absChange.compareTo(severityMediumMax) > 0) {
            return "HIGH";
        } else if (absChange.compareTo(severityLowMax) > 0) {
            return "MEDIUM";
        } else {
            return "LOW";
        }
    }
}
