package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum TransactionTypeEnums {
    POS("KSAOB.POS"),
    E_COMMERCE("KSAOB.ECommerce"),
    ATM("KSAOB.ATM"),
    BILL_PAYMENTS("KSAOB.BillPayments"),
    LOCAL_BANK_TRANSFER("KSAOB.LocalBankTransfer"),
    SAME_BANK_TRANSFER("KSAOB.SameBankTransfer"),
    INTERNATIONAL_TRANSFER("KSAOB.InternationalTransfer"),
    TELLER("KSAOB.Teller"),
    CHEQUE("KSAOB.Cheque"),
    OTHER("KSAOB.Other");

    private final String value;

    TransactionTypeEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static TransactionTypeEnums fromValue(String text) {
        for (TransactionTypeEnums b : TransactionTypeEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
