package com.ejada.obdatarepositoryapp.creditrisk.repository;

import com.ejada.obdatarepositoryapp.creditrisk.domain.UserConsent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for accessing users_consents table.
 * Used to cross-reference account link ID with bank consents.
 */
@Repository
public interface UserConsentRepository extends JpaRepository<UserConsent, String> {

    /**
     * Find consent by user ID, consent ID (account link ID), and sponsored TPP ID.
     * Ensures data isolation per client.
     */
    @Query("SELECT c FROM UserConsent c WHERE c.userId = :userId AND c.consentId = :consentId AND c.sponsoredTppId = :sponsoredTppId")
    Optional<UserConsent> findByUserIdAndConsentIdAndSponsoredTppId(
            @Param("userId") String userId,
            @Param("consentId") String consentId,
            @Param("sponsoredTppId") String sponsoredTppId);

    /**
     * Find all consents for a user under a specific sponsored TPP.
     */
    @Query("SELECT c FROM UserConsent c WHERE c.userId = :userId AND c.sponsoredTppId = :sponsoredTppId")
    List<UserConsent> findByUserIdAndSponsoredTppId(
            @Param("userId") String userId,
            @Param("sponsoredTppId") String sponsoredTppId);

    /**
     * Find consent by neotek accounts link ID and sponsored TPP ID.
     */
    @Query("SELECT c FROM UserConsent c WHERE c.neotekAccountsLinkId = :accountLinkId AND c.sponsoredTppId = :sponsoredTppId")
    Optional<UserConsent> findByNeotekAccountsLinkIdAndSponsoredTppId(
            @Param("accountLinkId") Long accountLinkId,
            @Param("sponsoredTppId") String sponsoredTppId);
}
