package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum BalanceAmountTypeEnum {

    KSAOB_CREDIT("KSAOB.Credit"),
    KSAOB_DEBIT("KSAOB.Debit");

    private final String value;

    BalanceAmountTypeEnum(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static BalanceAmountTypeEnum fromValue(String text) {
        for (BalanceAmountTypeEnum b : BalanceAmountTypeEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
