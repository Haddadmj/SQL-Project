package com.ejada.obdatarepositoryapp.creditrisk.repository;

import com.ejada.obdatarepositoryapp.creditrisk.domain.DecryptedTransactionProjection;
import com.ejada.obdatarepositoryapp.creditrisk.domain.ObTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Read-only repository for Open Banking transactions.
 * Supports database-level PGP decryption for sensitive transaction data.
 */
@Repository
public interface ObTransactionRepository extends JpaRepository<ObTransaction, String> {

    /**
     * Find all valid transactions for a specific account with database-level decryption.
     * Uses pgp_sym_decrypt() to decrypt encrypted_data at database level.
     *
     * @param accountId the Open Banking account ID
     * @param encryptionKey the PGP symmetric encryption key
     * @return list of transactions with decrypted data
     */
    @Query(value = """
        SELECT 
            t.id as id,
            t.user_id as userId,
            t.account_id as accountId,
            t.status as status,
            t.type as type,
            t.extracted_merchant_name as extractedMerchantName,
            t.created_at as createdAt,
            CAST(pgp_sym_decrypt(t.encrypted_data, :encryptionKey) AS text) as decryptedData
        FROM raw_transactions t
        WHERE t.account_id = :accountId 
          AND t.status IN ('processed', 'merchant_extraction_failed')
          AND t.encrypted_data IS NOT NULL
        ORDER BY t.created_at DESC
        """, nativeQuery = true)
    List<DecryptedTransactionProjection> findDecryptedByAccountId(
            @Param("accountId") String accountId,
            @Param("encryptionKey") String encryptionKey);

    /**
     * Find all valid transactions for a specific user and account with database-level decryption.
     *
     * @param userId the PSU ID
     * @param accountId the Open Banking account ID
     * @param encryptionKey the PGP symmetric encryption key
     * @return list of transactions with decrypted data
     */
    @Query(value = """
        SELECT 
            t.id as id,
            t.user_id as userId,
            t.account_id as accountId,
            t.status as status,
            t.type as type,
            t.extracted_merchant_name as extractedMerchantName,
            t.created_at as createdAt,
            CAST(pgp_sym_decrypt(t.encrypted_data, :encryptionKey) AS text) as decryptedData
        FROM raw_transactions t
        WHERE t.user_id = :userId
          AND t.account_id = :accountId 
          AND t.status IN ('processed', 'merchant_extraction_failed')
          AND t.encrypted_data IS NOT NULL
        ORDER BY t.created_at DESC
        """, nativeQuery = true)
    List<DecryptedTransactionProjection> findDecryptedByUserIdAndAccountId(
            @Param("userId") String userId,
            @Param("accountId") String accountId,
            @Param("encryptionKey") String encryptionKey);

    /**
     * Count valid transactions for a specific account.
     */
    @Query("SELECT COUNT(t) FROM ObTransaction t WHERE t.accountId = :accountId AND t.status IN ('processed', 'merchant_extraction_failed')")
    long countByAccountId(@Param("accountId") String accountId);
}
