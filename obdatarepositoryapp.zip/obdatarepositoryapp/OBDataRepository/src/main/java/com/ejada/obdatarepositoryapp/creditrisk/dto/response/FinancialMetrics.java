package com.ejada.obdatarepositoryapp.creditrisk.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Financial metrics calculated from Open Banking transaction data.
 * Uses JsonInclude.NON_NULL to exclude null fields (customer-type specific fields).
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FinancialMetrics {
    
    // Customer demographics (from request)
    private Integer age;
    
    private BigDecimal averageMonthlyIncome;      // Total income (all credits)
    private BigDecimal medianMonthlyIncome;
    private BigDecimal lastMonthIncome;
    
    // Income breakdown (median, spike-excluded)
    private BigDecimal medianSalaryIncome;        // Salary-related income only (spike-excluded)
    private BigDecimal medianRentalIncome;        // Rental/Ejar income only (spike-excluded)
    private BigDecimal medianOtherIncome;         // Other credits (not salary or rental, spike-excluded)
    
    private BigDecimal averageMonthlyExpenses;
    private BigDecimal lastMonthExpenses;
    private List<ExpenseCategory> expenseCategories;  // Breakdown by transaction type
    
    private BigDecimal averageMonthlySurplus;
    private BigDecimal lastMonthSurplus;
    private BigDecimal surplusRatio;
    
    private BigDecimal totalLoanPayments;
    private BigDecimal lastMonthLoanPayment;
    private BigDecimal totalMortgagePayments;
    private BigDecimal lastMonthMortgagePayment;
    private BigDecimal totalDebtPayments;        // Loan + Mortgage combined (across all months)
    private BigDecimal lastMonthDebtPayment;     // Last month's total debt payment (loans + mortgages)
    private BigDecimal debtBurdenRatio;          // Last Month Debt Payment / Monthly Income (<35%)
    
    private BigDecimal cashFlow;
    
    // Salary regularity metrics
    private BigDecimal salaryRegularity;
    private Integer salaryOccurrences;
    private BigDecimal averageSalaryAmount;
    private Integer salaryDayVariance;
    
    // Other metrics from Excel (industry standards)
    private BigDecimal savingsRate;              // Total Monthly Savings / Total Monthly Income (>15%)
    private BigDecimal emergencyFundMonths;      // Total Savings Balance / Average Monthly Expenses (>3 Months)
    private BigDecimal averageBalance6M;         // Sum of Daily Account Balances / Days (Stable)
    private Integer negativeBalanceDays;         // Count of Days with Balance < 0 (0 Days)
    
    // Velocity metrics - detect sudden behavior changes
    private BigDecimal incomeVolatility;         // Coefficient of variation (std dev / mean) for monthly income
    private BigDecimal expenseVolatility;        // Coefficient of variation for monthly expenses
    private BigDecimal lastMonthIncomeChange;    // % change: (last month - avg) / avg
    private BigDecimal lastMonthExpenseChange;   // % change: (last month - avg) / avg
    private Integer lastMonthTransactionCount;   // Transaction count for last month
    private BigDecimal transactionFrequencyChange; // % change in transaction frequency vs average
    private Boolean behaviorChangeDetected;      // True if significant deviation detected
    private List<BehaviorChange> detectedChanges; // Detailed list of detected behavior changes
    
    private Integer transactionCount;
    private LocalDate dataStartDate;
    private LocalDate dataEndDate;
    private Integer monthsOfData;
    
    private List<MonthlyBreakdown> monthlyBreakdowns;
    
    // Corporate-specific metrics
    private BigDecimal revenueStabilityCoefficient;
    private BigDecimal revenueTrendPercentage;
    private BigDecimal operatingExpenseRatio;
    private BigDecimal supplierPaymentConsistencyScore;
    private BigDecimal cashBufferMonths;
    private BigDecimal corporateCashFlow;
    private BigDecimal paymentBehaviorScore;
    private Integer uniqueSupplierCount;
    private BigDecimal averagePaymentDelay;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MonthlyBreakdown {
        private String month;
        private BigDecimal income;
        private BigDecimal expenses;
        private BigDecimal loanPayment;
        private BigDecimal surplus;
        // Corporate additions
        private BigDecimal revenue;
        private BigDecimal operatingExpenses;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BehaviorChange {
        private String changeType;           // INCOME_SPIKE, INCOME_DROP, EXPENSE_SPIKE, EXPENSE_DROP, TRANSACTION_SPIKE, TRANSACTION_DROP
        private String metric;               // e.g., "lastMonthIncomeChange", "expenseVolatility"
        private BigDecimal currentValue;     // Current value of the metric
        private BigDecimal expectedValue;    // Expected/average value
        private BigDecimal changePercent;    // Percentage change
        private String severity;             // LOW, MEDIUM, HIGH, CRITICAL
        private String industryStandard;     // Industry standard description
        private String description;          // Human-readable description
        private String recommendation;       // What the client should know/do
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ExpenseCategory {
        private String category;             // Category name (e.g., "Loan Repayments", "Utilities")
        private BigDecimal amount;           // Total amount for this category
        private BigDecimal percentage;       // Percentage of total expenses
    }
}
