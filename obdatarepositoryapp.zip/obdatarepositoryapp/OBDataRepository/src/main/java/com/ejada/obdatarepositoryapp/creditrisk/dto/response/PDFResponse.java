package com.ejada.obdatarepositoryapp.creditrisk.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PDFResponse {
    @JsonProperty("PDF_File")
    private String pdfFile;
}
