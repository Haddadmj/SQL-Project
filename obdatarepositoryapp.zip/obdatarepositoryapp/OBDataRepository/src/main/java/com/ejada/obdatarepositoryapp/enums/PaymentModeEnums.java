package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum PaymentModeEnums {
    ONLINE("KSAOB.Online"),
    OFFLINE("KSAOB.Offline"),
    BATCH("KSAOB.Batch");

    private final String value;

    PaymentModeEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static PaymentModeEnums fromValue(String text) {
        for (PaymentModeEnums b : PaymentModeEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
