package com.ejada.obdatarepositoryapp.creditrisk.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Risk factor types for credit scoring.
 * Each factor has a default weight out of 1000 total points.
 * Factors are categorized as RETAIL, CORPORATE, or BOTH.
 */
@Getter
@RequiredArgsConstructor
public enum RiskFactorType {
    
    // Retail factors
    AGE("Age", 150, "Lookup based on age ranges", CustomerType.RETAIL),
    INCOME("Income", 150, "Median of last 3 months (spike-excluded)", CustomerType.RETAIL),
    LOAN_PAYMENT("Loan Payment", 150, "Last month loan payment amount", CustomerType.RETAIL),
    SURPLUS_RATIO("Surplus Ratio", 150, "(Income - Expenses) / Income", CustomerType.RETAIL),
    SALARY_CATEGORY("Salary Category", 150, "Risk categorization by income level", CustomerType.RETAIL),
    CASH_FLOW("Cash Flow", 150, "Absolute: Income - Expenses", CustomerType.RETAIL),
    DEBT_BURDEN_RATIO("Debt Burden Ratio", 100, "Total Monthly Debt Payments / Total Monthly Income", CustomerType.RETAIL),
    
    // Corporate factors
    BUSINESS_AGE("Business Age", 150, "Years in operation - 3 years baseline, +2 year tiers increase trust", CustomerType.CORPORATE),
    REVENUE_STABILITY("Revenue Stability", 150, "Coefficient of variation of monthly revenue (lower = more stable)", CustomerType.CORPORATE),
    REVENUE_TREND("Revenue Trend", 150, "Revenue growth trend over analysis period", CustomerType.CORPORATE),
    OPERATING_EXPENSE_RATIO("Operating Expense Ratio", 150, "Operating expenses / Revenue", CustomerType.CORPORATE),
    SUPPLIER_PAYMENT_CONSISTENCY("Supplier Payment Consistency", 150, "Consistency of payments to suppliers/vendors", CustomerType.CORPORATE),
    CASH_BUFFER("Cash Buffer", 150, "Average cash balance relative to monthly expenses", CustomerType.CORPORATE),
    CORPORATE_CASH_FLOW("Corporate Cash Flow", 150, "Net operating cash flow", CustomerType.CORPORATE),
    PAYMENT_BEHAVIOR("Payment Behavior", 100, "Timeliness and regularity of outgoing payments", CustomerType.CORPORATE);

    private final String displayName;
    private final int defaultWeight;
    private final String description;
    private final CustomerType applicableTo;
    
    public boolean isApplicableTo(CustomerType customerType) {
        return this.applicableTo == customerType;
    }
}
