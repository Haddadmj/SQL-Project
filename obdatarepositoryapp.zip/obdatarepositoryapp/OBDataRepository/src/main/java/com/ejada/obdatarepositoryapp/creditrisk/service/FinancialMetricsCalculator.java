package com.ejada.obdatarepositoryapp.creditrisk.service;

import com.ejada.obdatarepositoryapp.creditrisk.config.CreditRiskConfig;
import com.ejada.obdatarepositoryapp.creditrisk.dto.TransactionData;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.FinancialMetrics;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType;
import com.ejada.obdatarepositoryapp.creditrisk.exception.CreditRiskException;
import com.ejada.obdatarepositoryapp.creditrisk.validation.TransactionDataValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service for calculating financial metrics from transaction data.
 * Computes income, expenses, surplus, loan payments, and ratios.
 * Supports both retail and corporate-specific metrics.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FinancialMetricsCalculator {

    private final CreditRiskConfig config;
    private final TransactionDataValidator validator;

    private static final int SCALE = 2;

    public FinancialMetrics calculate(List<TransactionData> transactions, CustomerType customerType, Integer age) {
        log.debug("Starting financial metrics calculation for customerType={}, age={}, transactionCount={}", 
                customerType, age, transactions != null ? transactions.size() : 0);
        
        try {
            // Validate and sanitize input
            List<TransactionData> validTransactions = validator.validateAndFilter(transactions);
            
            // Calculate base metrics
            FinancialMetrics metrics = calculateBase(validTransactions, age);
            
            // Enrich with corporate metrics if needed
            if (customerType == CustomerType.CORPORATE && !validTransactions.isEmpty()) {
                metrics = enrichWithCorporateMetrics(metrics, validTransactions);
            }
            
            // Nullify fields not applicable to customer type
            metrics = filterMetricsByCustomerType(metrics, customerType);
            
            log.debug("Financial metrics calculation completed successfully");
            return metrics;
            
        } catch (CreditRiskException e) {
            throw e;  // Re-throw our custom exceptions
        } catch (ArithmeticException e) {
            log.error("Arithmetic error during calculation: {}", e.getMessage(), e);
            throw new CreditRiskException("CALCULATION_ERROR", 
                    "Error during financial calculations", e);
        } catch (Exception e) {
            log.error("Unexpected error during metrics calculation: {}", e.getMessage(), e);
            throw new CreditRiskException("METRICS_CALCULATION_ERROR", 
                    "Failed to calculate financial metrics", e);
        }
    }

    public FinancialMetrics calculate(List<TransactionData> transactions, CustomerType customerType) {
        return calculate(transactions, customerType, null);
    }

    public FinancialMetrics calculate(List<TransactionData> transactions) {
        return calculate(transactions, CustomerType.RETAIL, null);
    }

    private FinancialMetrics calculateBase(List<TransactionData> transactions, Integer age) {
        if (transactions == null || transactions.isEmpty()) {
            return buildEmptyMetrics(age);
        }

        Map<YearMonth, List<TransactionData>> byMonth = groupByMonth(transactions);
        List<YearMonth> sortedMonths = byMonth.keySet().stream()
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());

        if (sortedMonths.isEmpty()) {
            return buildEmptyMetrics(age);
        }

        List<FinancialMetrics.MonthlyBreakdown> breakdowns = new ArrayList<>();
        List<BigDecimal> monthlyIncomes = new ArrayList<>();
        List<BigDecimal> monthlySalaryIncomes = new ArrayList<>();
        List<BigDecimal> monthlyRentalIncomes = new ArrayList<>();
        List<BigDecimal> monthlyOtherIncomes = new ArrayList<>();
        List<BigDecimal> monthlyExpenses = new ArrayList<>();
        List<BigDecimal> monthlyLoanPayments = new ArrayList<>();
        List<BigDecimal> monthlyMortgagePayments = new ArrayList<>();

        for (YearMonth month : sortedMonths) {
            List<TransactionData> monthTxns = byMonth.get(month);
            
            BigDecimal income = calculateMonthlyIncome(monthTxns);
            BigDecimal salaryIncome = calculateMonthlySalaryIncome(monthTxns);
            BigDecimal rentalIncome = calculateMonthlyRentalIncome(monthTxns);
            BigDecimal otherIncome = calculateMonthlyOtherIncome(monthTxns);
            BigDecimal expenses = calculateMonthlyExpenses(monthTxns);
            BigDecimal loanPayment = calculateMonthlyLoanPayments(monthTxns);
            BigDecimal mortgagePayment = calculateMonthlyMortgagePayments(monthTxns);
            monthlyIncomes.add(income);
            monthlySalaryIncomes.add(salaryIncome);
            monthlyRentalIncomes.add(rentalIncome);
            monthlyOtherIncomes.add(otherIncome);
            monthlyExpenses.add(expenses);
            monthlyLoanPayments.add(loanPayment);
            monthlyMortgagePayments.add(mortgagePayment);

            // Debt payment = loans + mortgages for the month
            BigDecimal debtPayment = loanPayment.add(mortgagePayment);
            
            // Surplus = Income - Expenses - Debt Payments
            BigDecimal surplus = income.subtract(expenses).subtract(debtPayment);
            
            breakdowns.add(FinancialMetrics.MonthlyBreakdown.builder()
                    .month(month.toString())
                    .income(income)
                    .expenses(expenses)
                    .loanPayment(debtPayment)  // Include both loans and mortgages
                    .surplus(surplus)
                    .build());
        }

        // Use last 3 months for median calculations (as per factor specification)
        int monthsForMedian = Math.min(3, monthlyIncomes.size());
        List<BigDecimal> last3MonthsIncomes = monthlyIncomes.subList(0, monthsForMedian);
        List<BigDecimal> last3MonthsSalaryIncomes = monthlySalaryIncomes.subList(0, monthsForMedian);
        List<BigDecimal> last3MonthsRentalIncomes = monthlyRentalIncomes.subList(0, monthsForMedian);
        List<BigDecimal> last3MonthsOtherIncomes = monthlyOtherIncomes.subList(0, monthsForMedian);
        
        BigDecimal medianIncome = calculateMedianExcludingSpikes(last3MonthsIncomes);
        BigDecimal avgIncome = calculateAverage(monthlyIncomes);
        BigDecimal lastMonthIncome = monthlyIncomes.isEmpty() ? BigDecimal.ZERO : monthlyIncomes.get(0);

        // Income breakdown medians (spike-excluded, last 3 months)
        BigDecimal medianSalaryIncome = calculateMedianExcludingSpikes(last3MonthsSalaryIncomes);
        BigDecimal medianRentalIncome = calculateMedianExcludingSpikes(last3MonthsRentalIncomes);
        BigDecimal medianOtherIncome = calculateMedianExcludingSpikes(last3MonthsOtherIncomes);

        // Use last 3 months for expense average (consistent with income median)
        List<BigDecimal> last3MonthsExpenses = monthlyExpenses.subList(0, monthsForMedian);
        BigDecimal avgExpenses = calculateAverage(last3MonthsExpenses);
        BigDecimal lastMonthExpenses = monthlyExpenses.isEmpty() ? BigDecimal.ZERO : monthlyExpenses.get(0);

        // Detect recurring loan payments (must appear in at least 3 of last 6 months)
        BigDecimal recurringLoanPayment = calculateRecurringLoanPayment(byMonth, sortedMonths);
        BigDecimal lastMonthLoanPayment = recurringLoanPayment;  // Use recurring amount, not just any loan payment
        BigDecimal totalLoanPayments = monthlyLoanPayments.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // Detect recurring mortgage payments (must appear in at least 3 of last 6 months)
        BigDecimal recurringMortgagePayment = calculateRecurringMortgagePayment(byMonth, sortedMonths);
        BigDecimal lastMonthMortgagePayment = recurringMortgagePayment;  // Use recurring amount
        BigDecimal totalMortgagePayments = monthlyMortgagePayments.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // Monthly debt payments (last month) = loans + mortgages for current month
        BigDecimal lastMonthDebtPayment = lastMonthLoanPayment.add(lastMonthMortgagePayment);
        // Total debt payments across all observed months
        BigDecimal totalDebtPayments = totalLoanPayments.add(totalMortgagePayments);

        // Surplus = Income - Expenses - Debt Payments
        BigDecimal avgDebtPayment = calculateAverage(monthlyLoanPayments).add(calculateAverage(monthlyMortgagePayments));
        BigDecimal avgSurplus = avgIncome.subtract(avgExpenses).subtract(avgDebtPayment);
        BigDecimal lastMonthSurplus = lastMonthIncome.subtract(lastMonthExpenses).subtract(lastMonthDebtPayment);

        BigDecimal surplusRatio = BigDecimal.ZERO;
        if (medianIncome.compareTo(BigDecimal.ZERO) > 0) {
            // Surplus ratio = (Income - Expenses - Debt) / Income
            BigDecimal avgSurplusForRatio = medianIncome.subtract(avgExpenses).subtract(avgDebtPayment);
            surplusRatio = avgSurplusForRatio.divide(medianIncome, 4, RoundingMode.HALF_UP);
        }

        // Debt Burden Ratio = Total Monthly Debt Payments / Monthly Income
        // Industry standard: <35% is healthy
        BigDecimal debtBurdenRatio = BigDecimal.ZERO;
        if (medianIncome.compareTo(BigDecimal.ZERO) > 0) {
            debtBurdenRatio = lastMonthDebtPayment.divide(medianIncome, 4, RoundingMode.HALF_UP);
        }

        BigDecimal cashFlow = medianIncome.subtract(avgExpenses);

        LocalDate startDate = transactions.stream()
                .map(t -> t.getTransactionDateTime().toLocalDate())
                .min(Comparator.naturalOrder())
                .orElse(null);
        LocalDate endDate = transactions.stream()
                .map(t -> t.getTransactionDateTime().toLocalDate())
                .max(Comparator.naturalOrder())
                .orElse(null);

        // Calculate salary regularity
        SalaryRegularityResult salaryResult = calculateSalaryRegularity(transactions);

        // Calculate Other Metrics from Excel
        // Savings Rate = Total Monthly Savings / Total Monthly Income (industry standard >15%)
        // Stored as decimal (0.15 = 15%) for consistency with other ratios
        BigDecimal savingsRate = BigDecimal.ZERO;
        BigDecimal totalSavings = avgSurplus.max(BigDecimal.ZERO); // Positive surplus is savings
        if (avgIncome.compareTo(BigDecimal.ZERO) > 0) {
            savingsRate = totalSavings.divide(avgIncome, 4, RoundingMode.HALF_UP);
        }

        // Emergency Fund = Total Savings Balance / Average Monthly Expenses (industry standard >3 Months)
        BigDecimal emergencyFundMonths = BigDecimal.ZERO;
        if (avgExpenses.compareTo(BigDecimal.ZERO) > 0) {
            // Estimate savings balance as cumulative surplus over observed months
            BigDecimal estimatedSavingsBalance = avgSurplus.max(BigDecimal.ZERO)
                    .multiply(BigDecimal.valueOf(sortedMonths.size()));
            emergencyFundMonths = estimatedSavingsBalance.divide(avgExpenses, 2, RoundingMode.HALF_UP);
        }

        // Average Balance (6M) - approximate from net cash flow
        BigDecimal averageBalance6M = calculateAverageBalanceFromTransactions(transactions);

        // Negative Balance Days - count days with cumulative balance < 0
        int negativeBalanceDays = calculateNegativeBalanceDays(transactions);

        // Velocity metrics - detect sudden behavior changes
        BigDecimal incomeVolatility = calculateVolatility(monthlyIncomes);
        BigDecimal expenseVolatility = calculateVolatility(monthlyExpenses);
        
        BigDecimal lastMonthIncomeChange = BigDecimal.ZERO;
        if (avgIncome.compareTo(BigDecimal.ZERO) > 0) {
            lastMonthIncomeChange = lastMonthIncome.subtract(avgIncome)
                    .divide(avgIncome, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100));
        }
        
        BigDecimal lastMonthExpenseChange = BigDecimal.ZERO;
        if (avgExpenses.compareTo(BigDecimal.ZERO) > 0) {
            lastMonthExpenseChange = lastMonthExpenses.subtract(avgExpenses)
                    .divide(avgExpenses, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100));
        }
        
        // Transaction frequency analysis
        Map<YearMonth, Integer> monthlyTxnCounts = new HashMap<>();
        for (YearMonth month : sortedMonths) {
            monthlyTxnCounts.put(month, byMonth.get(month).size());
        }
        int lastMonthTxnCount = sortedMonths.isEmpty() ? 0 : monthlyTxnCounts.get(sortedMonths.get(0));
        double avgTxnCount = monthlyTxnCounts.values().stream().mapToInt(Integer::intValue).average().orElse(0);
        BigDecimal txnFrequencyChange = BigDecimal.ZERO;
        if (avgTxnCount > 0) {
            txnFrequencyChange = BigDecimal.valueOf((lastMonthTxnCount - avgTxnCount) / avgTxnCount * 100);
        }
        
        // Behavior change detection with detailed reporting
        List<FinancialMetrics.BehaviorChange> detectedChanges = new ArrayList<>();
        
        // Check income change
        if (lastMonthIncomeChange.abs().compareTo(config.getIncomeChangeThreshold()) > 0) {
            boolean isSpike = lastMonthIncomeChange.compareTo(BigDecimal.ZERO) > 0;
            String severity = config.determineSeverity(lastMonthIncomeChange.abs());
            detectedChanges.add(FinancialMetrics.BehaviorChange.builder()
                    .changeType(isSpike ? "INCOME_SPIKE" : "INCOME_DROP")
                    .metric("lastMonthIncomeChange")
                    .currentValue(lastMonthIncome)
                    .expectedValue(avgIncome)
                    .changePercent(lastMonthIncomeChange)
                    .severity(severity)
                    .industryStandard("Monthly income should remain within ±20% of average for stability")
                    .description(isSpike 
                            ? "Last month's income was " + lastMonthIncomeChange.abs().setScale(1, RoundingMode.HALF_UP) + "% above average"
                            : "Last month's income was " + lastMonthIncomeChange.abs().setScale(1, RoundingMode.HALF_UP) + "% below average")
                    .recommendation(isSpike 
                            ? "Verify source of additional income. May indicate bonus, asset sale, or irregular payment."
                            : "Investigate income reduction. May indicate job change, reduced hours, or payment delays.")
                    .build());
        }
        
        // Check expense change
        if (lastMonthExpenseChange.abs().compareTo(config.getExpenseChangeThreshold()) > 0) {
            boolean isSpike = lastMonthExpenseChange.compareTo(BigDecimal.ZERO) > 0;
            String severity = config.determineSeverity(lastMonthExpenseChange.abs());
            detectedChanges.add(FinancialMetrics.BehaviorChange.builder()
                    .changeType(isSpike ? "EXPENSE_SPIKE" : "EXPENSE_DROP")
                    .metric("lastMonthExpenseChange")
                    .currentValue(lastMonthExpenses)
                    .expectedValue(avgExpenses)
                    .changePercent(lastMonthExpenseChange)
                    .severity(severity)
                    .industryStandard("Monthly expenses should remain within ±25% of average for financial health")
                    .description(isSpike 
                            ? "Last month's expenses were " + lastMonthExpenseChange.abs().setScale(1, RoundingMode.HALF_UP) + "% above average"
                            : "Last month's expenses were " + lastMonthExpenseChange.abs().setScale(1, RoundingMode.HALF_UP) + "% below average")
                    .recommendation(isSpike 
                            ? "Review large purchases or new recurring payments. May impact debt servicing capacity."
                            : "Positive indicator if sustainable. Verify not due to missed payments.")
                    .build());
        }
        
        // Check transaction frequency change
        if (txnFrequencyChange.abs().compareTo(config.getTransactionFrequencyChangeThreshold()) > 0) {
            boolean isSpike = txnFrequencyChange.compareTo(BigDecimal.ZERO) > 0;
            String severity = config.determineSeverity(txnFrequencyChange.abs());
            detectedChanges.add(FinancialMetrics.BehaviorChange.builder()
                    .changeType(isSpike ? "TRANSACTION_SPIKE" : "TRANSACTION_DROP")
                    .metric("transactionFrequencyChange")
                    .currentValue(BigDecimal.valueOf(lastMonthTxnCount))
                    .expectedValue(BigDecimal.valueOf(avgTxnCount))
                    .changePercent(txnFrequencyChange)
                    .severity(severity)
                    .industryStandard("Transaction frequency should remain within ±30% of average pattern")
                    .description(isSpike 
                            ? "Transaction count increased by " + txnFrequencyChange.abs().setScale(1, RoundingMode.HALF_UP) + "% vs average"
                            : "Transaction count decreased by " + txnFrequencyChange.abs().setScale(1, RoundingMode.HALF_UP) + "% vs average")
                    .recommendation(isSpike 
                            ? "May indicate lifestyle change, new financial obligations, or unusual activity."
                            : "May indicate reduced financial activity, account dormancy, or consolidation of payments.")
                    .build());
        }
        
        // Check high volatility
        if (incomeVolatility.compareTo(config.getHighVolatilityThreshold()) > 0) {
            detectedChanges.add(FinancialMetrics.BehaviorChange.builder()
                    .changeType("HIGH_INCOME_VOLATILITY")
                    .metric("incomeVolatility")
                    .currentValue(incomeVolatility)
                    .expectedValue(config.getIndustryStandardIncomeVolatility())
                    .changePercent(incomeVolatility)
                    .severity(config.determineSeverity(incomeVolatility))
                    .industryStandard("Income volatility (CV) should be below 15% for stable employment")
                    .description("Income varies by " + incomeVolatility.setScale(1, RoundingMode.HALF_UP) + "% month-to-month")
                    .recommendation("High income variability suggests irregular income sources. Consider income verification.")
                    .build());
        }
        
        boolean behaviorChangeDetected = !detectedChanges.isEmpty();

        // Calculate expense categories breakdown
        List<FinancialMetrics.ExpenseCategory> expenseCategories = calculateExpenseCategories(transactions);

        return FinancialMetrics.builder()
                .age(age)
                .averageMonthlyIncome(avgIncome.setScale(SCALE, RoundingMode.HALF_UP))
                .medianMonthlyIncome(medianIncome.setScale(SCALE, RoundingMode.HALF_UP))
                .lastMonthIncome(lastMonthIncome.setScale(SCALE, RoundingMode.HALF_UP))
                .medianSalaryIncome(medianSalaryIncome.setScale(SCALE, RoundingMode.HALF_UP))
                .medianRentalIncome(medianRentalIncome.setScale(SCALE, RoundingMode.HALF_UP))
                .medianOtherIncome(medianOtherIncome.setScale(SCALE, RoundingMode.HALF_UP))
                .averageMonthlyExpenses(avgExpenses.setScale(SCALE, RoundingMode.HALF_UP))
                .lastMonthExpenses(lastMonthExpenses.setScale(SCALE, RoundingMode.HALF_UP))
                .expenseCategories(expenseCategories)
                .averageMonthlySurplus(avgSurplus.setScale(SCALE, RoundingMode.HALF_UP))
                .lastMonthSurplus(lastMonthSurplus.setScale(SCALE, RoundingMode.HALF_UP))
                .surplusRatio(surplusRatio.setScale(4, RoundingMode.HALF_UP))
                .totalLoanPayments(totalLoanPayments.setScale(SCALE, RoundingMode.HALF_UP))
                .lastMonthLoanPayment(lastMonthLoanPayment.setScale(SCALE, RoundingMode.HALF_UP))
                .totalMortgagePayments(totalMortgagePayments.setScale(SCALE, RoundingMode.HALF_UP))
                .lastMonthMortgagePayment(lastMonthMortgagePayment.setScale(SCALE, RoundingMode.HALF_UP))
                .totalDebtPayments(totalDebtPayments.setScale(SCALE, RoundingMode.HALF_UP))
                .lastMonthDebtPayment(lastMonthDebtPayment.setScale(SCALE, RoundingMode.HALF_UP))
                .debtBurdenRatio(debtBurdenRatio.setScale(4, RoundingMode.HALF_UP))
                .cashFlow(cashFlow.setScale(SCALE, RoundingMode.HALF_UP))
                .salaryRegularity(salaryResult.regularity.setScale(SCALE, RoundingMode.HALF_UP))
                .salaryOccurrences(salaryResult.occurrences)
                .averageSalaryAmount(salaryResult.averageAmount.setScale(SCALE, RoundingMode.HALF_UP))
                .salaryDayVariance(salaryResult.dayVariance)
                .savingsRate(savingsRate.setScale(SCALE, RoundingMode.HALF_UP))
                .emergencyFundMonths(emergencyFundMonths.setScale(SCALE, RoundingMode.HALF_UP))
                .averageBalance6M(averageBalance6M.setScale(SCALE, RoundingMode.HALF_UP))
                .negativeBalanceDays(negativeBalanceDays)
                .incomeVolatility(incomeVolatility.setScale(SCALE, RoundingMode.HALF_UP))
                .expenseVolatility(expenseVolatility.setScale(SCALE, RoundingMode.HALF_UP))
                .lastMonthIncomeChange(lastMonthIncomeChange.setScale(SCALE, RoundingMode.HALF_UP))
                .lastMonthExpenseChange(lastMonthExpenseChange.setScale(SCALE, RoundingMode.HALF_UP))
                .lastMonthTransactionCount(lastMonthTxnCount)
                .transactionFrequencyChange(txnFrequencyChange.setScale(SCALE, RoundingMode.HALF_UP))
                .behaviorChangeDetected(behaviorChangeDetected)
                .detectedChanges(detectedChanges)
                .transactionCount(transactions.size())
                .dataStartDate(startDate)
                .dataEndDate(endDate)
                .monthsOfData(sortedMonths.size())
                .monthlyBreakdowns(breakdowns)
                .build();
    }

    private Map<YearMonth, List<TransactionData>> groupByMonth(List<TransactionData> transactions) {
        return transactions.stream()
                .filter(t -> t.getTransactionDateTime() != null)
                .collect(Collectors.groupingBy(t -> YearMonth.from(t.getTransactionDateTime())));
    }

    private BigDecimal calculateMonthlyIncome(List<TransactionData> transactions) {
        return transactions.stream()
                .filter(TransactionData::isCredit)
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal calculateMonthlyExpenses(List<TransactionData> transactions) {
        // Exclude debt payments (loans + mortgages) as they're tracked separately
        return transactions.stream()
                .filter(TransactionData::isDebit)
                .filter(t -> !t.isDebtPayment())  // Exclude loans and mortgages
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .map(BigDecimal::abs)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal calculateMonthlyLoanPayments(List<TransactionData> transactions) {
        return transactions.stream()
                .filter(TransactionData::isDebit)
                .filter(TransactionData::isLoanPayment)
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .map(BigDecimal::abs)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal calculateMonthlyMortgagePayments(List<TransactionData> transactions) {
        return transactions.stream()
                .filter(TransactionData::isDebit)
                .filter(TransactionData::isMortgage)
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .map(BigDecimal::abs)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal calculateMonthlySalaryIncome(List<TransactionData> transactions) {
        return transactions.stream()
                .filter(TransactionData::isCredit)
                .filter(TransactionData::isSalary)
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal calculateMonthlyRentalIncome(List<TransactionData> transactions) {
        return transactions.stream()
                .filter(TransactionData::isCredit)
                .filter(TransactionData::isRentalIncome)
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal calculateMonthlyOtherIncome(List<TransactionData> transactions) {
        return transactions.stream()
                .filter(TransactionData::isCredit)
                .filter(t -> !t.isSalary() && !t.isRentalIncome() && !t.isTransfer())
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Calculate recurring loan payment amount.
     * A loan payment is considered recurring if similar amounts appear in at least 3 of the last 6 months.
     * Returns the average of recurring loan payment amounts.
     */
    private BigDecimal calculateRecurringLoanPayment(Map<YearMonth, List<TransactionData>> byMonth, List<YearMonth> sortedMonths) {
        return calculateRecurringPayment(byMonth, sortedMonths, TransactionData::isLoanPayment);
    }

    /**
     * Calculate recurring mortgage payment amount.
     * A mortgage payment is considered recurring if similar amounts appear in at least 3 of the last 6 months.
     */
    private BigDecimal calculateRecurringMortgagePayment(Map<YearMonth, List<TransactionData>> byMonth, List<YearMonth> sortedMonths) {
        return calculateRecurringPayment(byMonth, sortedMonths, TransactionData::isMortgage);
    }

    /**
     * Generic recurring payment detection.
     * Looks for payment amounts that appear consistently across multiple months.
     * Requires at least 3 occurrences in the last 6 months to be considered recurring.
     */
    private BigDecimal calculateRecurringPayment(Map<YearMonth, List<TransactionData>> byMonth, 
                                                   List<YearMonth> sortedMonths,
                                                   java.util.function.Predicate<TransactionData> paymentFilter) {
        // Limit to last 6 months
        int monthsToCheck = Math.min(6, sortedMonths.size());
        if (monthsToCheck < 3) {
            // Not enough data for recurring pattern detection, fall back to last month
            if (!sortedMonths.isEmpty()) {
                List<TransactionData> lastMonthTxns = byMonth.get(sortedMonths.get(0));
                return lastMonthTxns.stream()
                        .filter(TransactionData::isDebit)
                        .filter(paymentFilter)
                        .map(TransactionData::getAmount)
                        .filter(Objects::nonNull)
                        .map(BigDecimal::abs)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
            }
            return BigDecimal.ZERO;
        }

        // Collect all payment amounts from last 6 months with their month count
        Map<BigDecimal, Integer> amountOccurrences = new HashMap<>();
        BigDecimal tolerance = new BigDecimal("0.05"); // 5% tolerance for amount matching

        for (int i = 0; i < monthsToCheck; i++) {
            YearMonth month = sortedMonths.get(i);
            List<TransactionData> monthTxns = byMonth.get(month);
            
            List<BigDecimal> monthPayments = monthTxns.stream()
                    .filter(TransactionData::isDebit)
                    .filter(paymentFilter)
                    .map(TransactionData::getAmount)
                    .filter(Objects::nonNull)
                    .map(BigDecimal::abs)
                    .collect(Collectors.toList());

            for (BigDecimal payment : monthPayments) {
                // Find if this amount (within tolerance) already exists
                boolean found = false;
                for (BigDecimal existing : amountOccurrences.keySet()) {
                    if (isWithinTolerance(payment, existing, tolerance)) {
                        amountOccurrences.merge(existing, 1, Integer::sum);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    amountOccurrences.put(payment, 1);
                }
            }
        }

        // Sum amounts that appear in at least 3 months (recurring)
        BigDecimal recurringTotal = BigDecimal.ZERO;
        for (Map.Entry<BigDecimal, Integer> entry : amountOccurrences.entrySet()) {
            if (entry.getValue() >= 3) {
                recurringTotal = recurringTotal.add(entry.getKey());
            }
        }

        return recurringTotal;
    }

    /**
     * Check if two amounts are within tolerance of each other.
     */
    private boolean isWithinTolerance(BigDecimal a, BigDecimal b, BigDecimal tolerancePercent) {
        if (a.compareTo(BigDecimal.ZERO) == 0 || b.compareTo(BigDecimal.ZERO) == 0) {
            return a.compareTo(b) == 0;
        }
        BigDecimal diff = a.subtract(b).abs();
        BigDecimal maxVal = a.max(b);
        BigDecimal tolerance = maxVal.multiply(tolerancePercent);
        return diff.compareTo(tolerance) <= 0;
    }

    private BigDecimal calculateMedianExcludingSpikes(List<BigDecimal> values) {
        if (values.isEmpty()) {
            return BigDecimal.ZERO;
        }

        List<BigDecimal> filtered = new ArrayList<>(values);
        
        if (filtered.size() >= config.getMinimumMonthsForMedian()) {
            // Use median-based threshold (more robust than average-based)
            BigDecimal roughMedian = calculateRoughMedian(filtered);
            if (roughMedian.compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal threshold = roughMedian.multiply(config.getSpikeThreshold());
                filtered = filtered.stream()
                        .filter(v -> v.compareTo(threshold) <= 0)
                        .collect(Collectors.toList());
            }
        }

        if (filtered.isEmpty()) {
            filtered = values;
        }

        return calculateRoughMedian(filtered);
    }

    /**
     * Calculate volatility (coefficient of variation = std dev / mean).
     * Higher values indicate more variability in the data.
     * Returns percentage (0-100+).
     */
    private BigDecimal calculateVolatility(List<BigDecimal> values) {
        if (values == null || values.size() < 2) {
            return BigDecimal.ZERO;
        }
        
        BigDecimal mean = calculateAverage(values);
        if (mean.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        
        // Calculate standard deviation
        BigDecimal sumSquaredDiff = BigDecimal.ZERO;
        for (BigDecimal value : values) {
            BigDecimal diff = value.subtract(mean);
            sumSquaredDiff = sumSquaredDiff.add(diff.multiply(diff));
        }
        
        BigDecimal variance = sumSquaredDiff.divide(BigDecimal.valueOf(values.size()), 10, RoundingMode.HALF_UP);
        BigDecimal stdDev = BigDecimal.valueOf(Math.sqrt(variance.doubleValue()));
        
        // Coefficient of variation as percentage
        return stdDev.divide(mean, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100));
    }

    /**
     * Calculate median without spike exclusion.
     * Used as base for threshold calculation to avoid outlier influence.
     */
    private BigDecimal calculateRoughMedian(List<BigDecimal> values) {
        if (values.isEmpty()) {
            return BigDecimal.ZERO;
        }
        
        List<BigDecimal> sorted = values.stream()
                .sorted()
                .collect(Collectors.toList());
        
        int size = sorted.size();
        if (size % 2 == 0) {
            return sorted.get(size / 2 - 1).add(sorted.get(size / 2))
                    .divide(BigDecimal.valueOf(2), SCALE, RoundingMode.HALF_UP);
        } else {
            return sorted.get(size / 2);
        }
    }

    private BigDecimal calculateAverage(List<BigDecimal> values) {
        if (values.isEmpty()) {
            return BigDecimal.ZERO;
        }
        BigDecimal sum = values.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
        return sum.divide(BigDecimal.valueOf(values.size()), SCALE, RoundingMode.HALF_UP);
    }

    /**
     * Calculate average balance from transactions over observed period.
     * Uses balanceAfter field from transactions for accurate balance tracking.
     * Sum of Daily Account Balances / Number of Days
     */
    private BigDecimal calculateAverageBalanceFromTransactions(List<TransactionData> transactions) {
        if (transactions == null || transactions.isEmpty()) {
            return BigDecimal.ZERO;
        }

        // Sort transactions by date and use balanceAfter for accurate balance
        List<TransactionData> sorted = transactions.stream()
                .filter(t -> t.getTransactionDateTime() != null)
                .sorted(Comparator.comparing(TransactionData::getTransactionDateTime))
                .collect(Collectors.toList());

        if (sorted.isEmpty()) {
            return BigDecimal.ZERO;
        }

        // Track daily balances using balanceAfter field
        Map<LocalDate, BigDecimal> dailyBalances = new TreeMap<>();

        for (TransactionData txn : sorted) {
            LocalDate date = txn.getTransactionDateTime().toLocalDate();
            
            // Use balanceAfter if available, otherwise fall back to running calculation
            if (txn.getBalanceAfter() != null) {
                dailyBalances.put(date, txn.getBalanceAfter());
            }
        }

        if (dailyBalances.isEmpty()) {
            return BigDecimal.ZERO;
        }

        // Calculate average of daily balances
        BigDecimal sumBalances = dailyBalances.values().stream()
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return sumBalances.divide(BigDecimal.valueOf(dailyBalances.size()), SCALE, RoundingMode.HALF_UP);
    }

    /**
     * Count days with negative balance.
     * Uses balanceAfter field from transactions for accurate balance tracking.
     * Industry standard: 0 Days
     */
    private int calculateNegativeBalanceDays(List<TransactionData> transactions) {
        if (transactions == null || transactions.isEmpty()) {
            return 0;
        }

        // Sort transactions by date and use balanceAfter for accurate balance
        List<TransactionData> sorted = transactions.stream()
                .filter(t -> t.getTransactionDateTime() != null)
                .sorted(Comparator.comparing(TransactionData::getTransactionDateTime))
                .collect(Collectors.toList());

        if (sorted.isEmpty()) {
            return 0;
        }

        // Track daily balances using balanceAfter field
        Map<LocalDate, BigDecimal> dailyBalances = new TreeMap<>();

        for (TransactionData txn : sorted) {
            LocalDate date = txn.getTransactionDateTime().toLocalDate();
            
            // Use balanceAfter if available
            if (txn.getBalanceAfter() != null) {
                dailyBalances.put(date, txn.getBalanceAfter());
            }
        }

        // Count days with negative balance
        return (int) dailyBalances.values().stream()
                .filter(balance -> balance.compareTo(BigDecimal.ZERO) < 0)
                .count();
    }

    /**
     * Calculate salary regularity metrics.
     * Based on configuration: Min Occurrences=3, Day Tolerance=5, Expected Frequency=30 days.
     * Salary Regularity = (Number of Months with Salary Received on Time / Total Months Observed) × 100
     */
    private SalaryRegularityResult calculateSalaryRegularity(List<TransactionData> transactions) {
        if (transactions == null || transactions.isEmpty()) {
            return new SalaryRegularityResult(BigDecimal.ZERO, 0, BigDecimal.ZERO, 0);
        }

        // Find all salary transactions
        List<TransactionData> salaryTransactions = transactions.stream()
                .filter(TransactionData::isCredit)
                .filter(TransactionData::isSalary)
                .sorted(Comparator.comparing(TransactionData::getTransactionDateTime))
                .collect(Collectors.toList());

        int occurrences = salaryTransactions.size();
        if (occurrences < config.getSalaryMinOccurrences()) {
            return new SalaryRegularityResult(BigDecimal.ZERO, occurrences, BigDecimal.ZERO, 0);
        }

        // Calculate average salary amount
        BigDecimal totalSalary = salaryTransactions.stream()
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal avgSalary = totalSalary.divide(BigDecimal.valueOf(occurrences), SCALE, RoundingMode.HALF_UP);

        // Calculate day-of-month variance and regularity
        List<Integer> salaryDays = salaryTransactions.stream()
                .map(t -> t.getTransactionDateTime().getDayOfMonth())
                .collect(Collectors.toList());
        
        // Calculate average day of month for salary
        double avgDay = salaryDays.stream().mapToInt(Integer::intValue).average().orElse(15);
        
        // Count how many salaries arrived within tolerance of expected day
        int onTimeCount = 0;
        for (Integer day : salaryDays) {
            if (Math.abs(day - avgDay) <= config.getSalaryDayTolerance()) {
                onTimeCount++;
            }
        }

        // Calculate day variance (standard deviation)
        double variance = salaryDays.stream()
                .mapToDouble(d -> Math.pow(d - avgDay, 2))
                .average().orElse(0);
        int dayVariance = (int) Math.round(Math.sqrt(variance));

        // Calculate regularity as percentage
        // Stored as decimal (0.90 = 90%) for consistency with other ratios
        BigDecimal regularity = BigDecimal.valueOf(onTimeCount)
                .divide(BigDecimal.valueOf(occurrences), 4, RoundingMode.HALF_UP);

        return new SalaryRegularityResult(regularity, occurrences, avgSalary, dayVariance);
    }

    private static class SalaryRegularityResult {
        final BigDecimal regularity;
        final int occurrences;
        final BigDecimal averageAmount;
        final int dayVariance;

        SalaryRegularityResult(BigDecimal regularity, int occurrences, BigDecimal averageAmount, int dayVariance) {
            this.regularity = regularity;
            this.occurrences = occurrences;
            this.averageAmount = averageAmount;
            this.dayVariance = dayVariance;
        }
    }

    private FinancialMetrics enrichWithCorporateMetrics(FinancialMetrics base, List<TransactionData> transactions) {
        Map<YearMonth, List<TransactionData>> byMonth = groupByMonth(transactions);
        List<YearMonth> sortedMonths = byMonth.keySet().stream()
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());

        // Calculate monthly revenues (credits)
        List<BigDecimal> monthlyRevenues = new ArrayList<>();
        for (YearMonth month : sortedMonths) {
            BigDecimal revenue = calculateMonthlyIncome(byMonth.get(month));
            monthlyRevenues.add(revenue);
        }

        // Revenue Stability (Coefficient of Variation) - lower is better
        BigDecimal revenueStability = calculateCoefficientOfVariation(monthlyRevenues);

        // Revenue Trend (growth percentage)
        BigDecimal revenueTrend = calculateTrendPercentage(monthlyRevenues);

        // Operating Expense Ratio
        BigDecimal avgRevenue = calculateAverage(monthlyRevenues);
        BigDecimal operatingExpenseRatio = BigDecimal.ZERO;
        if (avgRevenue.compareTo(BigDecimal.ZERO) > 0) {
            operatingExpenseRatio = base.getAverageMonthlyExpenses()
                    .divide(avgRevenue, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100));
        }

        // Supplier Payment Consistency
        Map<String, List<TransactionData>> supplierPayments = groupBySupplier(transactions);
        BigDecimal supplierConsistency = calculateSupplierPaymentConsistency(supplierPayments);
        int uniqueSuppliers = supplierPayments.size();

        // Cash Buffer (months of expenses covered by average balance)
        BigDecimal cashBuffer = BigDecimal.ZERO;
        if (base.getAverageMonthlyExpenses().compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal avgBalance = calculateAverageBalance(transactions);
            cashBuffer = avgBalance.divide(base.getAverageMonthlyExpenses(), 2, RoundingMode.HALF_UP);
        }

        // Corporate Cash Flow
        BigDecimal corporateCashFlow = avgRevenue.subtract(base.getAverageMonthlyExpenses());

        // Payment Behavior Score (0-100)
        BigDecimal paymentBehavior = calculatePaymentBehaviorScore(transactions);

        // Average Payment Delay
        BigDecimal avgPaymentDelay = calculateAveragePaymentDelay(supplierPayments);

        return FinancialMetrics.builder()
                // Copy base metrics
                .age(base.getAge())
                .averageMonthlyIncome(base.getAverageMonthlyIncome())
                .medianMonthlyIncome(base.getMedianMonthlyIncome())
                .lastMonthIncome(base.getLastMonthIncome())
                .medianSalaryIncome(base.getMedianSalaryIncome())
                .medianRentalIncome(base.getMedianRentalIncome())
                .medianOtherIncome(base.getMedianOtherIncome())
                .averageMonthlyExpenses(base.getAverageMonthlyExpenses())
                .lastMonthExpenses(base.getLastMonthExpenses())
                .averageMonthlySurplus(base.getAverageMonthlySurplus())
                .lastMonthSurplus(base.getLastMonthSurplus())
                .surplusRatio(base.getSurplusRatio())
                .totalLoanPayments(base.getTotalLoanPayments())
                .lastMonthLoanPayment(base.getLastMonthLoanPayment())
                .totalMortgagePayments(base.getTotalMortgagePayments())
                .lastMonthMortgagePayment(base.getLastMonthMortgagePayment())
                .totalDebtPayments(base.getTotalDebtPayments())
                .lastMonthDebtPayment(base.getLastMonthDebtPayment())
                .debtBurdenRatio(base.getDebtBurdenRatio())
                .cashFlow(base.getCashFlow())
                .salaryRegularity(base.getSalaryRegularity())
                .salaryOccurrences(base.getSalaryOccurrences())
                .averageSalaryAmount(base.getAverageSalaryAmount())
                .salaryDayVariance(base.getSalaryDayVariance())
                .savingsRate(base.getSavingsRate())
                .emergencyFundMonths(base.getEmergencyFundMonths())
                .averageBalance6M(base.getAverageBalance6M())
                .negativeBalanceDays(base.getNegativeBalanceDays())
                .incomeVolatility(base.getIncomeVolatility())
                .expenseVolatility(base.getExpenseVolatility())
                .lastMonthIncomeChange(base.getLastMonthIncomeChange())
                .lastMonthExpenseChange(base.getLastMonthExpenseChange())
                .lastMonthTransactionCount(base.getLastMonthTransactionCount())
                .transactionFrequencyChange(base.getTransactionFrequencyChange())
                .behaviorChangeDetected(base.getBehaviorChangeDetected())
                .detectedChanges(base.getDetectedChanges())
                .transactionCount(base.getTransactionCount())
                .dataStartDate(base.getDataStartDate())
                .dataEndDate(base.getDataEndDate())
                .monthsOfData(base.getMonthsOfData())
                .monthlyBreakdowns(base.getMonthlyBreakdowns())
                // Corporate-specific metrics
                .revenueStabilityCoefficient(revenueStability.setScale(2, RoundingMode.HALF_UP))
                .revenueTrendPercentage(revenueTrend.setScale(2, RoundingMode.HALF_UP))
                .operatingExpenseRatio(operatingExpenseRatio.setScale(2, RoundingMode.HALF_UP))
                .supplierPaymentConsistencyScore(supplierConsistency.setScale(2, RoundingMode.HALF_UP))
                .cashBufferMonths(cashBuffer.setScale(2, RoundingMode.HALF_UP))
                .corporateCashFlow(corporateCashFlow.setScale(2, RoundingMode.HALF_UP))
                .paymentBehaviorScore(paymentBehavior.setScale(2, RoundingMode.HALF_UP))
                .uniqueSupplierCount(uniqueSuppliers)
                .averagePaymentDelay(avgPaymentDelay.setScale(1, RoundingMode.HALF_UP))
                .build();
    }

    private BigDecimal calculateCoefficientOfVariation(List<BigDecimal> values) {
        if (values.size() < 2) return BigDecimal.ZERO;
        
        BigDecimal mean = calculateAverage(values);
        if (mean.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ZERO;

        BigDecimal sumSquaredDiff = BigDecimal.ZERO;
        for (BigDecimal value : values) {
            BigDecimal diff = value.subtract(mean);
            sumSquaredDiff = sumSquaredDiff.add(diff.multiply(diff));
        }
        
        BigDecimal variance = sumSquaredDiff.divide(BigDecimal.valueOf(values.size()), 10, RoundingMode.HALF_UP);
        BigDecimal stdDev = BigDecimal.valueOf(Math.sqrt(variance.doubleValue()));
        
        return stdDev.divide(mean, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100));
    }

    private BigDecimal calculateTrendPercentage(List<BigDecimal> monthlyValues) {
        if (monthlyValues.size() < 2) return BigDecimal.ZERO;
        
        // Compare recent period vs older period
        int midPoint = monthlyValues.size() / 2;
        List<BigDecimal> recent = monthlyValues.subList(0, midPoint);
        List<BigDecimal> older = monthlyValues.subList(midPoint, monthlyValues.size());
        
        BigDecimal recentAvg = calculateAverage(recent);
        BigDecimal olderAvg = calculateAverage(older);
        
        if (olderAvg.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ZERO;
        
        return recentAvg.subtract(olderAvg)
                .divide(olderAvg, 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100));
    }

    private Map<String, List<TransactionData>> groupBySupplier(List<TransactionData> transactions) {
        return transactions.stream()
                .filter(TransactionData::isDebit)
                .filter(t -> t.getMerchantName() != null && !t.getMerchantName().isBlank())
                .collect(Collectors.groupingBy(t -> t.getMerchantName().toLowerCase().trim()));
    }

    private BigDecimal calculateSupplierPaymentConsistency(Map<String, List<TransactionData>> supplierPayments) {
        if (supplierPayments.isEmpty()) return BigDecimal.valueOf(50);
        
        int consistentSuppliers = 0;
        int totalRecurringSuppliers = 0;
        
        for (Map.Entry<String, List<TransactionData>> entry : supplierPayments.entrySet()) {
            List<TransactionData> payments = entry.getValue();
            if (payments.size() >= 2) {
                totalRecurringSuppliers++;
                // Check if payments are regular (similar amounts)
                List<BigDecimal> amounts = payments.stream()
                        .map(TransactionData::getAmount)
                        .filter(Objects::nonNull)
                        .map(BigDecimal::abs)
                        .collect(Collectors.toList());
                
                BigDecimal cv = calculateCoefficientOfVariation(amounts);
                if (cv.compareTo(BigDecimal.valueOf(30)) <= 0) {
                    consistentSuppliers++;
                }
            }
        }
        
        if (totalRecurringSuppliers == 0) return BigDecimal.valueOf(50);
        
        return BigDecimal.valueOf(consistentSuppliers)
                .divide(BigDecimal.valueOf(totalRecurringSuppliers), 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100));
    }

    private BigDecimal calculateAverageBalance(List<TransactionData> transactions) {
        // Simplified: estimate average balance from net flow
        BigDecimal totalCredits = transactions.stream()
                .filter(TransactionData::isCredit)
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal totalDebits = transactions.stream()
                .filter(TransactionData::isDebit)
                .map(TransactionData::getAmount)
                .filter(Objects::nonNull)
                .map(BigDecimal::abs)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        return totalCredits.subtract(totalDebits).abs().divide(BigDecimal.valueOf(2), SCALE, RoundingMode.HALF_UP);
    }

    private BigDecimal calculatePaymentBehaviorScore(List<TransactionData> transactions) {
        // Score based on regularity of outgoing payments
        Map<YearMonth, Long> monthlyPaymentCounts = transactions.stream()
                .filter(TransactionData::isDebit)
                .filter(t -> t.getTransactionDateTime() != null)
                .collect(Collectors.groupingBy(
                        t -> YearMonth.from(t.getTransactionDateTime()),
                        Collectors.counting()));
        
        if (monthlyPaymentCounts.isEmpty()) return BigDecimal.valueOf(50);
        
        List<BigDecimal> counts = monthlyPaymentCounts.values().stream()
                .map(BigDecimal::valueOf)
                .collect(Collectors.toList());
        
        BigDecimal cv = calculateCoefficientOfVariation(counts);
        
        // Lower variation = higher score (max 100)
        BigDecimal score = BigDecimal.valueOf(100).subtract(cv);
        return score.max(BigDecimal.ZERO).min(BigDecimal.valueOf(100));
    }

    private BigDecimal calculateAveragePaymentDelay(Map<String, List<TransactionData>> supplierPayments) {
        // Calculate average days between payments to same supplier
        List<Long> allDelays = new ArrayList<>();
        
        for (List<TransactionData> payments : supplierPayments.values()) {
            if (payments.size() < 2) continue;
            
            List<TransactionData> sorted = payments.stream()
                    .filter(t -> t.getTransactionDateTime() != null)
                    .sorted(Comparator.comparing(TransactionData::getTransactionDateTime))
                    .collect(Collectors.toList());
            
            for (int i = 1; i < sorted.size(); i++) {
                long days = java.time.temporal.ChronoUnit.DAYS.between(
                        sorted.get(i - 1).getTransactionDateTime().toLocalDate(),
                        sorted.get(i).getTransactionDateTime().toLocalDate());
                allDelays.add(days);
            }
        }
        
        if (allDelays.isEmpty()) return BigDecimal.ZERO;
        
        double avgDelay = allDelays.stream().mapToLong(Long::longValue).average().orElse(0);
        return BigDecimal.valueOf(avgDelay);
    }

    private FinancialMetrics buildEmptyMetrics(Integer age) {
        return FinancialMetrics.builder()
                .age(age)
                .averageMonthlyIncome(BigDecimal.ZERO)
                .medianMonthlyIncome(BigDecimal.ZERO)
                .lastMonthIncome(BigDecimal.ZERO)
                .medianSalaryIncome(BigDecimal.ZERO)
                .medianRentalIncome(BigDecimal.ZERO)
                .medianOtherIncome(BigDecimal.ZERO)
                .averageMonthlyExpenses(BigDecimal.ZERO)
                .lastMonthExpenses(BigDecimal.ZERO)
                .averageMonthlySurplus(BigDecimal.ZERO)
                .lastMonthSurplus(BigDecimal.ZERO)
                .surplusRatio(BigDecimal.ZERO)
                .totalLoanPayments(BigDecimal.ZERO)
                .lastMonthLoanPayment(BigDecimal.ZERO)
                .debtBurdenRatio(BigDecimal.ZERO)
                .cashFlow(BigDecimal.ZERO)
                .incomeVolatility(BigDecimal.ZERO)
                .expenseVolatility(BigDecimal.ZERO)
                .lastMonthIncomeChange(BigDecimal.ZERO)
                .lastMonthExpenseChange(BigDecimal.ZERO)
                .lastMonthTransactionCount(0)
                .transactionFrequencyChange(BigDecimal.ZERO)
                .behaviorChangeDetected(false)
                .detectedChanges(Collections.emptyList())
                .transactionCount(0)
                .monthsOfData(0)
                .monthlyBreakdowns(Collections.emptyList())
                .build();
    }

    /**
     * Filter metrics by customer type - nullify fields not applicable to the customer type.
     * For RETAIL: nullify corporate-specific fields
     * For CORPORATE: nullify retail-specific fields (age, salary metrics)
     */
    private FinancialMetrics filterMetricsByCustomerType(FinancialMetrics metrics, CustomerType customerType) {
        if (metrics == null) {
            return metrics;
        }
        
        if (customerType == CustomerType.RETAIL) {
            // Nullify corporate-specific fields for retail customers
            metrics.setRevenueStabilityCoefficient(null);
            metrics.setRevenueTrendPercentage(null);
            metrics.setOperatingExpenseRatio(null);
            metrics.setSupplierPaymentConsistencyScore(null);
            metrics.setCashBufferMonths(null);
            metrics.setCorporateCashFlow(null);
            metrics.setPaymentBehaviorScore(null);
            metrics.setUniqueSupplierCount(null);
            metrics.setAveragePaymentDelay(null);
        } else if (customerType == CustomerType.CORPORATE) {
            // Nullify retail-specific fields for corporate customers
            metrics.setAge(null);
            metrics.setSalaryRegularity(null);
            metrics.setSalaryOccurrences(null);
            metrics.setAverageSalaryAmount(null);
            metrics.setSalaryDayVariance(null);
            metrics.setMedianSalaryIncome(null);
            metrics.setMedianRentalIncome(null);
        }
        
        return metrics;
    }

    /**
     * Calculate expense categories breakdown from transactions.
     * Categories: Loan Repayments, Utilities, Rent / Housing, Living Expenses, Others
     */
    private List<FinancialMetrics.ExpenseCategory> calculateExpenseCategories(List<TransactionData> transactions) {
        // Group expenses by category
        Map<String, BigDecimal> categoryTotals = new LinkedHashMap<>();
        categoryTotals.put("Loan Repayments", BigDecimal.ZERO);
        categoryTotals.put("Living Expenses", BigDecimal.ZERO);
        categoryTotals.put("Utilities", BigDecimal.ZERO);
        categoryTotals.put("Rent / Housing", BigDecimal.ZERO);
        categoryTotals.put("Others", BigDecimal.ZERO);

        BigDecimal totalExpenses = BigDecimal.ZERO;

        for (TransactionData tx : transactions) {
            if (!tx.isDebit()) {
                continue;
            }
            BigDecimal amount = tx.getAmount() != null ? tx.getAmount().abs() : BigDecimal.ZERO;
            String category = tx.getExpenseCategory();
            if (category != null) {
                categoryTotals.merge(category, amount, BigDecimal::add);
                totalExpenses = totalExpenses.add(amount);
            }
        }

        // Build expense categories list with percentages
        List<FinancialMetrics.ExpenseCategory> categories = new ArrayList<>();
        for (Map.Entry<String, BigDecimal> entry : categoryTotals.entrySet()) {
            BigDecimal amount = entry.getValue();
            if (amount.compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal percentage = totalExpenses.compareTo(BigDecimal.ZERO) > 0
                        ? amount.divide(totalExpenses, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100))
                        : BigDecimal.ZERO;
                categories.add(FinancialMetrics.ExpenseCategory.builder()
                        .category(entry.getKey())
                        .amount(amount.setScale(SCALE, RoundingMode.HALF_UP))
                        .percentage(percentage.setScale(2, RoundingMode.HALF_UP))
                        .build());
            }
        }

        // Sort by amount descending, but keep "Others" last
        categories.sort((a, b) -> {
            if ("Others".equals(a.getCategory())) return 1;
            if ("Others".equals(b.getCategory())) return -1;
            return b.getAmount().compareTo(a.getAmount());
        });

        return categories;
    }
}
