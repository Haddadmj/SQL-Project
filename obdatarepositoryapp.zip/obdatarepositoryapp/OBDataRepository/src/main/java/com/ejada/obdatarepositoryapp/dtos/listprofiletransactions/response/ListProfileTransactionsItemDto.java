package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.ejada.obdatarepositoryapp.dtos.commondtos.response.FinancialInstitutionDto;
import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigInteger;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ListProfileTransactionsItemDto {
    @JsonProperty("ProfileId")
    private String profileId;

    @JsonProperty("AccountsLinkId")
    private String accountsLinkId;

    @JsonProperty("FinancialInstitution")
    private FinancialInstitutionDto financialInstitution;

    @JsonProperty("AccountId")
    private String accountId;

    @JsonProperty("TransactionId")
    private String transactionId;

    @JsonProperty("TransactionDateTime")
    private OffsetDateTime transactionDateTime;

    @JsonProperty("LocalTimeZone")
    private String localTimeZone;

    @JsonProperty("StatementReference")
    private String statementReference;

    @JsonProperty("TransactionReference")
    private String transactionReference;

    @JsonProperty("TransactionType")
    private String transactionType;

    @JsonProperty("SubTransactionType")
    private String subTransactionType;

    @JsonProperty("TerminalId")
    private String terminalId;

    @JsonProperty("Flags")
    private List<String> flags = new ArrayList<>();

    @JsonProperty("PaymentModes")
    private String paymentModes;

    @JsonProperty("CreditDebitIndicator")
    private String creditDebitIndicator;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("TransactionMutability")
    private String transactionMutability;

    @JsonProperty("BookingDateTime")
    private OffsetDateTime bookingDateTime;

    @JsonProperty("ValueDateTime")
    private OffsetDateTime valueDateTime;

    @JsonProperty("TransactionInformation")
    private String transactionInformation;

    @JsonProperty("Amount")
    private AmountDto amount;

    @JsonProperty("ChargeAmount")
    private ChargeAmountDto chargeAmount;

    @JsonProperty("ChargeAmountVat")
    private AmountDto chargeAmountVat;

    @JsonProperty("CurrencyExchange")
    private CurrencyExchangeDto currencyExchange;

    @JsonProperty("BankTransactionCode")
    private BankTransactionCodeDto bankTransactionCode;

    @JsonProperty("ProprietaryBankTransactionCode")
    private ProprietaryBankTransactionCodeDto proprietaryBankTransactionCode;

    @JsonProperty("Balance")
    private TransactionCashBalanceDto balance;

    @JsonProperty("MerchantDetails")
    private MerchantDetailsDto merchantDetails;

    @JsonProperty("CreditorAgent")
    private AgentDto creditorAgent;

    @JsonProperty("CreditorAccount")
    @Builder.Default
    private List<IdentifiersWithNameDto> creditorAccount = new ArrayList<>();

    @JsonProperty("DebtorAgent")
    private AgentDto debtorAgent;

    @JsonProperty("DebtorAccount")
    private IdentifiersWithNameDto debtorAccount;

    @JsonProperty("CardInstrument")
    private TransactionCardInstrumentDto cardInstrument;

    @JsonProperty("SupplementaryData")
    private Object supplementaryData;

    @JsonProperty("BillDetails")
    private BillDetailsDto billDetails;

    @JsonProperty("IsCategorized")
    private Integer isCategorized;

    @JsonProperty("CategorizationLevels")
    private List<CategorizationLevelsDto> categorizationLevels;
}
