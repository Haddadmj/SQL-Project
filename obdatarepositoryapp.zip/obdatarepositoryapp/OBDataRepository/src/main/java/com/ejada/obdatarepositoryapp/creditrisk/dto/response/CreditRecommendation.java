package com.ejada.obdatarepositoryapp.creditrisk.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * Credit recommendation based on scoring results.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditRecommendation {
    
    private String decision;
    private String decisionReason;
    private BigDecimal recommendedLimit;
    private BigDecimal maxAffordablePayment;
    private List<String> strengths;
    private List<String> weaknesses;
    private List<String> recommendations;
}
