package com.ejada.obdatarepositoryapp.creditrisk.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.time.Instant;

/**
 * Read-only entity mapping to raw_transactions table in Open Banking database.
 * Contains encrypted transaction data that requires PGP decryption.
 */
@Entity
@Table(name = "raw_transactions")
@Immutable
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ObTransaction {

    @Id
    @Column(name = "id", nullable = false, length = 26)
    private String id;

    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "account_id")
    private String accountId;

    @Column(name = "status")
    private String status;

    @Column(name = "type")
    private String type;

    @Column(name = "purpose")
    private String purpose;

    @Column(name = "extracted_merchant_name")
    private String extractedMerchantName;

    @Column(name = "encrypted_data")
    private byte[] encryptedData;

    @Column(name = "created_at")
    private Instant createdAt;

    @Column(name = "updated_at")
    private Instant updatedAt;
}
