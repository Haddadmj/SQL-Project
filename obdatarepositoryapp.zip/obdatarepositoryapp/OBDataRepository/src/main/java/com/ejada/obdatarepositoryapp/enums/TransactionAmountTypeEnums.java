package com.ejada.obdatarepositoryapp.enums;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum TransactionAmountTypeEnums {
    CREDIT("KSAOB.Credit"),
    DEBIT("KSAOB.Debit");

    private final String value;

    TransactionAmountTypeEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static TransactionAmountTypeEnums fromValue(String text) {
        for (TransactionAmountTypeEnums b : TransactionAmountTypeEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
