package com.ejada.obdatarepositoryapp.creditrisk.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Credit rating classification based on score (0-1000 scale).
 * From AAA (excellent) to D (very poor).
 */
@Getter
@RequiredArgsConstructor
public enum CreditRatingClass {
    
    AAA("Excellent", "Outstanding creditworthiness with minimal risk", 900, 1000, "Very High"),
    AA("Very Good", "Very strong creditworthiness with very low risk", 800, 899, "High"),
    A("Good", "Strong creditworthiness with low risk", 700, 799, "High"),
    BBB("Satisfactory", "Adequate creditworthiness with moderate risk", 600, 699, "Moderate"),
    BB("Fair", "Speculative creditworthiness with elevated risk", 500, 599, "Moderate"),
    B("Marginal", "Highly speculative with high risk", 400, 499, "Low"),
    CCC("Weak", "Substantial risk, vulnerable to default", 300, 399, "Low"),
    CC("Very Weak", "Highly vulnerable to default", 200, 299, "Very Low"),
    C("Extremely Weak", "Near default with minimal recovery expected", 100, 199, "Very Low"),
    D("Default/Reject", "In default or imminent default", 0, 99, "Reject");

    private final String className;
    private final String description;
    private final int minScore;
    private final int maxScore;
    private final String approvalRecommendation;

    /**
     * Get credit rating class based on score.
     */
    public static CreditRatingClass fromScore(int score) {
        for (CreditRatingClass rating : values()) {
            if (score >= rating.minScore && score <= rating.maxScore) {
                return rating;
            }
        }
        return D;
    }
}
