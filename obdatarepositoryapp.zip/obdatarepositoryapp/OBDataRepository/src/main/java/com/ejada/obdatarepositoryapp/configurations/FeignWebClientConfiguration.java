package com.ejada.obdatarepositoryapp.configurations;

import com.ejada.obdatarepositoryapp.ObDataRepositoryApplication;
import feign.Client;
import feign.Logger;
import feign.okhttp.OkHttpClient;
import io.netty.handler.ssl.SslContextBuilder;
import okhttp3.internal.tls.OkHostnameVerifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

@Configuration
public class FeignWebClientConfiguration {


    private static final String SSL_PROTOCOL = "TLS";
    @Value("${app.config.integration.backend.keystore.name}")
    private String keystoreName;
    @Value("${app.config.integration.backend.keystore.password}")
    private String keystorePassword;
    @Value("${spring.env}")
    private String env;

    @Bean
    public Client feignClient() throws IOException, CertificateException, NoSuchAlgorithmException,
            KeyStoreException, KeyManagementException, UnrecoverableKeyException {
        okhttp3.OkHttpClient okHttpClient = createOkHttpClient();
        return new OkHttpClient(okHttpClient);
    }

    @Bean
    @Lazy
    public WebClient webClient() throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException{
        TrustManagerFactory tmf = createTrustManagerFactory();
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(
                        HttpClient.create().secure(spec -> spec.sslContext(SslContextBuilder.forClient().trustManager(tmf)))))
                .build();
    }

    private okhttp3.OkHttpClient createOkHttpClient() throws IOException, CertificateException, NoSuchAlgorithmException,
            KeyStoreException, KeyManagementException, UnrecoverableKeyException {
        SSLContext sslContext = createSslContext();
        X509TrustManager trustManager = (X509TrustManager) createTrustManagerFactory().getTrustManagers()[0];

        return new okhttp3.OkHttpClient.Builder()
                .sslSocketFactory(sslContext.getSocketFactory(), trustManager)
                .hostnameVerifier((OkHostnameVerifier.INSTANCE))
                .connectionPool(new okhttp3.ConnectionPool(5, 5, TimeUnit.MINUTES))
                .build();
    }

    private SSLContext createSslContext() throws IOException, CertificateException, NoSuchAlgorithmException,
            KeyStoreException, KeyManagementException, UnrecoverableKeyException {
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        if(Objects.equals(env, "development")) {
            try (InputStream certInputStream = ObDataRepositoryApplication.class.getClassLoader().getResourceAsStream(keystoreName)) {
                if (certInputStream == null) {
                    throw new IOException("Keystore resource not found: " + keystoreName);
                }
                ks.load(certInputStream, keystorePassword.toCharArray());
            }
        } else {
            try (FileInputStream fis = new FileInputStream(keystoreName)) {
                ks.load(fis, keystorePassword.toCharArray());
            }
        }
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(ks, keystorePassword.toCharArray());
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(ks);
        SSLContext sc = SSLContext.getInstance(SSL_PROTOCOL);
        sc.init(keyManagerFactory.getKeyManagers(), tmf.getTrustManagers(), new SecureRandom());
        return sc;
    }

    private TrustManagerFactory createTrustManagerFactory() throws IOException, CertificateException, NoSuchAlgorithmException,
            KeyStoreException {
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        if(Objects.equals(env, "development")) {
            try (InputStream certInputStream = ObDataRepositoryApplication.class.getClassLoader().getResourceAsStream(keystoreName)) {
                if (certInputStream == null) {
                    throw new IOException("Keystore resource not found: " + keystoreName);
                }
                ks.load(certInputStream, keystorePassword.toCharArray());
            }
        } else {
            try (FileInputStream fis = new FileInputStream(keystoreName)) {
                ks.load(fis, keystorePassword.toCharArray());
            }
        }
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(ks);
        return tmf;
    }

    @Bean
    Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL;
    }
}