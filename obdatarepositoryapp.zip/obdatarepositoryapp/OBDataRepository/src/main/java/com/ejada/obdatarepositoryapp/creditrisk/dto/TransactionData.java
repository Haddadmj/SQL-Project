package com.ejada.obdatarepositoryapp.creditrisk.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Parsed transaction data from decrypted Open Banking transaction.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionData {
    
    private String transactionId;
    private String accountId;
    private LocalDateTime transactionDateTime;
    private BigDecimal amount;
    private String currency;
    private String creditDebitIndicator;
    private String status;
    private String transactionType;
    private String category;
    private String merchantName;
    private String description;
    private String reference;
    private BigDecimal balanceAfter;  // Account balance after this transaction
    
    public boolean isCredit() {
        return "KSAOB.Credit".equals(creditDebitIndicator);
    }
    
    public boolean isDebit() {
        return "KSAOB.Debit".equals(creditDebitIndicator);
    }
    
    /**
     * Loan payment detection keywords (PF and other types).
     * Priority: 90, Min Occurrences: 3, Day Tolerance: 3, Expected Frequency: 30 days
     */
    private static final String[] LOAN_KEYWORDS = {
            // English keywords
            "MURABAHA", "Finance Payment", "Loan Deduction", "Finance Deduction", "Auto Loan",
            "Direct Debit", "Loan Repayment", "Loan Payment", "Monthly Installment", "Payment Installment",
            "Consumer Loan", "Installment Payment", "Loan Installment", "Personal Loan", "Finance Installment",
            "INSTALLMENT", "LOAN", "TAWARRUQ",
            // Arabic keywords
            "تمويل", "تمويل شخصي", "تمويل استهلاكي", "استقطاع قرض", "استقطاع تمويل", "سداد قرض",
            "خصم تمويل", "قرض", "سداد تمويل", "قسط قرض", "حسم مباشر", "قسط تمويل", "خصم قرض"
    };

    /**
     * Mortgage/Housing loan detection keywords.
     * Priority: 85, Min Occurrences: 3, Day Tolerance: 3, Expected Frequency: 30 days
     */
    private static final String[] MORTGAGE_KEYWORDS = {
            // English keywords
            "Home Finance", "HOUSING LOAN", "Real Estate Payment", "HOME LOAN", "SAB Home Finance",
            "REAL ESTATE LOAN", "Al Rajhi Home Finance", "Housing Finance", "MORTGAGE",
            "Riyad Bank Home Finance", "BBank AlJazira Home Finance", "Alinma Home Finance",
            "SNB Home Finance", "Property Loan", "Mortgage Payment", "Property Payment",
            "Developer Payment", "Mortgage Installment",
            // Arabic keywords
            "تمويل عقاري", "تمويل سكني", "قسط رهن", "قرض عقاري", "قرض سكني", "رهن عقاري",
            "دفعة رهن", "دفعة عقار"
    };

    /**
     * Utilities detection keywords (electricity, water, telecom, internet).
     */
    private static final String[] UTILITIES_KEYWORDS = {
            // English keywords
            "Electricity", "Electric Bill", "SEC", "Saudi Electricity", "Water Bill", "NWC",
            "National Water", "STC", "Mobily", "Zain", "Internet", "Telecom", "Phone Bill",
            "Mobile Bill", "Fiber", "Gas Bill", "SADAD", "Utility", "GOSI",
            // Arabic keywords
            "كهرباء", "فاتورة كهرباء", "ماء", "فاتورة ماء", "اتصالات", "جوال", "انترنت",
            "هاتف", "موبايلي", "زين", "سداد", "خدمات"
    };

    /**
     * Rent/Housing expense detection keywords.
     */
    private static final String[] RENT_KEYWORDS = {
            // English keywords
            "Rent", "Rental Payment", "Apartment Rent", "House Rent", "Lease", "Ejar",
            "Housing Rent", "Property Rent", "Monthly Rent", "Landlord",
            // Arabic keywords
            "إيجار", "ايجار", "دفعة إيجار", "إيجار شقة", "إيجار منزل", "إيجار سكن",
            "مالك العقار", "إيجار شهري"
    };

    /**
     * Living expenses detection keywords (groceries, food, supermarket).
     */
    private static final String[] LIVING_EXPENSES_KEYWORDS = {
            // English keywords
            "Grocery", "Supermarket", "Food", "Restaurant", "Cafe", "Coffee", "Dining",
            "Panda", "Carrefour", "Tamimi", "Danube", "Lulu", "HyperPanda", "Extra",
            "Market", "Bakery", "Pharmacy", "Medical", "Healthcare", "Hospital", "Clinic",
            "Education", "School", "University", "Tuition", "Transport", "Fuel", "Petrol",
            "Gas Station", "Aramco", "Naft",
            // Arabic keywords
            "بقالة", "سوبرماركت", "مطعم", "مقهى", "طعام", "صيدلية", "مستشفى", "عيادة",
            "تعليم", "مدرسة", "جامعة", "وقود", "بنزين", "محطة"
    };

    public boolean isLoanPayment() {
        String searchText = buildSearchText();
        if (searchText == null || searchText.isEmpty()) {
            return false;
        }
        
        String lowerText = searchText.toLowerCase();
        for (String keyword : LOAN_KEYWORDS) {
            if (lowerText.contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    public boolean isMortgage() {
        String searchText = buildSearchText();
        if (searchText == null || searchText.isEmpty()) {
            return false;
        }
        
        String lowerText = searchText.toLowerCase();
        for (String keyword : MORTGAGE_KEYWORDS) {
            if (lowerText.contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if transaction is any type of debt payment (loan or mortgage).
     */
    public boolean isDebtPayment() {
        return isLoanPayment() || isMortgage();
    }
    
    /**
     * Internal/Regular transfer detection using transactionType field.
     * These should be EXCLUDED from "other income" calculation.
     * Based on SAMA OB TransactionType enum values.
     */
    private static final String[] TRANSFER_TYPE_INDICATORS = {
            // SAMA OB Transfer Transaction Types (exact enum values)
            "KSAOB.LocalBankTransfer",      // Local bank transfers
            "KSAOB.SameBankTransfer",       // Same bank transfers (internal/own account)
            "KSAOB.InternationalTransfer"   // International transfers
    };

    /**
     * Rental/Ejar income detection keywords.
     * Includes Ejar platform transfers and general rental income.
     */
    private static final String[] RENTAL_INCOME_KEYWORDS = {
            // English keywords
            "EJAR", "Ejar Transfer", "Ejar Payment", "Rent Income", "Rental Income",
            "Rent Payment Received", "Lease Income", "Property Income", "Tenant Payment",
            "Rental Deposit", "Lease Payment", "Property Rental", "Real Estate Income",
            // Arabic keywords
            "إيجار", "ايجار", "دخل إيجار", "إيجار عقار", "تحويل إيجار", "دفعة إيجار",
            "إيراد عقاري", "دخل عقاري", "إيجار شهري", "مستأجر"
    };

    /**
     * Salary detection keywords from configuration.
     * Includes English and Arabic terms for salary-related transactions.
     */
    private static final String[] SALARY_KEYWORDS = {
            // English keywords
            "payroll", "wages", "payroll deposit", "monthly salary", "salary deposit",
            "payroll transfer", "wage", "sal transfer", "salary credit", "salary",
            "employee salary", "salary transfer",
            // Arabic keywords
            "الرواتب", "راتب شهري", "صرف راتب", "أجر", "رواتب موظفين", "ايداع راتب",
            "إيداع راتب", "راتب", "تحويل راتب", "أجور", "حوالة راتب"
    };

    public boolean isSalary() {
        String searchText = buildSearchText();
        if (searchText == null || searchText.isEmpty()) {
            return false;
        }
        
        String lowerText = searchText.toLowerCase();
        for (String keyword : SALARY_KEYWORDS) {
            if (lowerText.contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if transaction is a transfer type (local, same bank, or international).
     * Uses transactionType field with exact SAMA OB enum matching.
     */
    public boolean isTransfer() {
        if (transactionType == null) {
            return false;
        }
        
        for (String indicator : TRANSFER_TYPE_INDICATORS) {
            if (transactionType.equals(indicator)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if transaction is rental/Ejar income.
     */
    public boolean isRentalIncome() {
        String searchText = buildSearchText();
        if (searchText == null || searchText.isEmpty()) {
            return false;
        }
        
        String lowerText = searchText.toLowerCase();
        for (String keyword : RENTAL_INCOME_KEYWORDS) {
            if (lowerText.contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if transaction is any identified income type (salary or rental).
     */
    public boolean isIdentifiedIncome() {
        return isSalary() || isRentalIncome();
    }

    private String buildSearchText() {
        StringBuilder sb = new StringBuilder();
        if (description != null) sb.append(description).append(" ");
        if (reference != null) sb.append(reference).append(" ");
        if (merchantName != null) sb.append(merchantName);
        return sb.toString().trim();
    }

    /**
     * Returns true if transaction is a utility payment.
     */
    public boolean isUtility() {
        String searchText = buildSearchText();
        if (searchText == null || searchText.isEmpty()) {
            return false;
        }
        String lowerText = searchText.toLowerCase();
        for (String keyword : UTILITIES_KEYWORDS) {
            if (lowerText.contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if transaction is a rent payment.
     */
    public boolean isRentPayment() {
        String searchText = buildSearchText();
        if (searchText == null || searchText.isEmpty()) {
            return false;
        }
        String lowerText = searchText.toLowerCase();
        for (String keyword : RENT_KEYWORDS) {
            if (lowerText.contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if transaction is a living expense.
     */
    public boolean isLivingExpense() {
        String searchText = buildSearchText();
        if (searchText == null || searchText.isEmpty()) {
            return false;
        }
        String lowerText = searchText.toLowerCase();
        for (String keyword : LIVING_EXPENSES_KEYWORDS) {
            if (lowerText.contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the expense category for this transaction.
     * Categories: "Loan Repayments", "Utilities", "Rent / Housing", "Living Expenses", "Others"
     */
    public String getExpenseCategory() {
        if (!isDebit()) {
            return null;
        }
        if (isDebtPayment()) {
            return "Loan Repayments";
        }
        if (isUtility()) {
            return "Utilities";
        }
        if (isRentPayment()) {
            return "Rent / Housing";
        }
        if (isLivingExpense()) {
            return "Living Expenses";
        }
        return "Others";
    }
}
