package com.ejada.obdatarepositoryapp.dtos.commondtos.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FinancialInstitutionDto {
    @JsonProperty("FinancialInstitutionId")
    private String financialInstitutionId;

    @JsonProperty("NameEn")
    private String nameEn;

    @JsonProperty("NameAr")
    private String nameAr;

    @JsonProperty("Logo")
    private String logo;
}
