package com.ejada.obdatarepositoryapp.creditrisk.dto.request;

import com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType;
import com.ejada.obdatarepositoryapp.creditrisk.enums.LoanPurpose;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * Request DTO for credit risk assessment.
 * Contains account identifiers, customer type, and optional purpose/amount.
 * Currency is SAR by default.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditRiskRequest {

    @NotBlank(message = "PSU ID is required")
    private String psuId;

    @NotBlank(message = "Account Link ID (consent) is required")
    private String accountLinkId;

    @NotBlank(message = "Account ID is required")
    private String accountId;

    @NotBlank(message = "Sponsored TPP ID (client identifier) is required")
    private String sponsoredTppId;

    @Builder.Default
    private CustomerType customerType = CustomerType.RETAIL;

    private List<RiskFactorConfig> riskFactors;

    private LoanPurpose purpose;

    private BigDecimal requestedAmount;

    /**
     * Loan term in months. Optional.
     * Defaults: 60 months (5 years) for regular loans, 240 months (20 years) for HOME_MORTGAGE.
     */
    private Integer loanTermMonths;

    /**
     * Annual interest rate as percentage (e.g., 3.0 for 3%).
     * Default: 3.0% for all loan types.
     */
    private BigDecimal annualInterestRate;

    /**
     * Customer age in years. Optional - if provided, enables AGE factor scoring.
     * Typical ranges: 18-25 (young), 26-35 (establishing), 36-50 (peak), 51-60 (near retirement), 61+ (retired)
     */
    private Integer age;
}
