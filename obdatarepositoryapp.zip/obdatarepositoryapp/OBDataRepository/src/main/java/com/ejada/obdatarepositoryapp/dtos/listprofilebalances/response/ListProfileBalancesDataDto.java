package com.ejada.obdatarepositoryapp.dtos.listprofilebalances.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.RequiredArgsConstructor;

import java.util.List;

@lombok.Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class ListProfileBalancesDataDto {
    @JsonProperty("Balances")
    private List<BalanceDto> balances;
}
