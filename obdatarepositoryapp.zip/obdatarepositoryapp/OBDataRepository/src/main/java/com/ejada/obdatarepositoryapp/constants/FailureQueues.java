package com.ejada.obdatarepositoryapp.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * Constants representing the failure queue names used throughout the project.
 */
@NoArgsConstructor(access = AccessLevel.NONE)
public class FailureQueues {
    public static final String OB_DATA_REPOSITORY_FAILURE_QUEUE = "JMS.DRM.OBDataRepository.Fail";
}
