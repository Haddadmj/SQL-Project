package com.ejada.obdatarepositoryapp.creditrisk.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Configuration for a score range within a risk factor.
 * Defines the value range and points awarded for that range.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RangeConfig {
    
    private BigDecimal minValue;
    private BigDecimal maxValue;
    private Integer points;
    private String label;
}
