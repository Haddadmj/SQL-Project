package com.ejada.obdatarepositoryapp.configurations;

import com.ejada.commons.errors.handlers.JmsExceptionHandler;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import lombok.Setter;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.RedeliveryPolicy;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.util.ErrorHandler;

import java.util.UUID;

@Configuration
@ConfigurationProperties(prefix = "spring.mq")
@EnableJms
@Setter
public class JmsListenerConfig {
    private String brokerUrl;

    private String username;

    private String password;

    private Integer maximumRedeliveries;

    @Value("${jms.listener.concurrency}")
    private String concurrencyLevel;
    @Bean
    public DefaultJmsListenerContainerFactory jmsListenerContainerFactory(
            DefaultJmsListenerContainerFactoryConfigurer configurer,
            @Qualifier("mqConnectionFactory") ConnectionFactory connectionFactory,
            JmsExceptionHandler myErrorHandler) {

        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, connectionFactory);
        factory.setErrorHandler(myErrorHandler);
        return factory;
    }

    @ConditionalOnProperty(value = "spring.mq.type", havingValue = "activemq", matchIfMissing = false)
    private ActiveMQConnectionFactory getApacheActiveMqConnectionFactory() throws JMSException {
        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
        connectionFactory.setBrokerURL(brokerUrl);
        connectionFactory.setPassword(password);
        connectionFactory.setUserName(username);
        return connectionFactory;
    }

    @Bean
    public DefaultJmsListenerContainerFactory coreJmsListenerContainerFactory(
            DefaultJmsListenerContainerFactoryConfigurer configurer,
            JmsExceptionHandler myErrorHandler) throws JMSException {
        ActiveMQConnectionFactory connectionFactory = getApacheActiveMqConnectionFactory();
        RedeliveryPolicy redeliveryPolicy = new RedeliveryPolicy();
        redeliveryPolicy.setMaximumRedeliveries(0);
        connectionFactory.setRedeliveryPolicy(redeliveryPolicy);
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, connectionFactory);
        factory.setErrorHandler(myErrorHandler);
        factory.setConcurrency(concurrencyLevel.concat("-").concat(concurrencyLevel));
        return factory;
    }

    @Bean
    public DefaultJmsListenerContainerFactory coreJmsListenerContainerFactoryWithRetrial(
            DefaultJmsListenerContainerFactoryConfigurer configurer,
            JmsExceptionHandler myErrorHandler) throws JMSException {
        ActiveMQConnectionFactory connectionFactory = getApacheActiveMqConnectionFactory();
        RedeliveryPolicy redeliveryPolicy = new RedeliveryPolicy();
        redeliveryPolicy.setMaximumRedeliveries(maximumRedeliveries);
        connectionFactory.setRedeliveryPolicy(redeliveryPolicy);
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, connectionFactory);
        factory.setErrorHandler(myErrorHandler);
        return factory;
    }

    @Bean(name = "jmsTemplate")
    @Primary
    public JmsTemplate jmsTemplate() throws JMSException {
        JmsTemplate jmsTemplate = new JmsTemplate();
        jmsTemplate.setConnectionFactory(getApacheActiveMqConnectionFactory());
        jmsTemplate.setSessionTransacted(true); // Enable transacted sessions
        return jmsTemplate;
    }

    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public DefaultJmsListenerContainerFactory jmsListenerContainerFactoryTopicsWithRetrial(DefaultJmsListenerContainerFactoryConfigurer configurer,
                                                                                           JmsExceptionHandler myErrorHandler) throws JMSException {
        ActiveMQConnectionFactory connectionFactory = getApacheActiveMqConnectionFactory();
        RedeliveryPolicy redeliveryPolicy = new RedeliveryPolicy();
        redeliveryPolicy.setMaximumRedeliveries(maximumRedeliveries);
        connectionFactory.setRedeliveryPolicy(redeliveryPolicy);
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, connectionFactory);
        factory.setErrorHandler(myErrorHandler);
        factory.setPubSubDomain(true);
        factory.setClientId("OBDataRepositoryConsumer"+ UUID.randomUUID());
        factory.setSubscriptionDurable(true);
        return factory;
    }

    @Bean
    public ErrorHandler exceptionHandler() {
        // Define your error handling logic for listener 1
        return new JmsExceptionHandler();
    }
}