package com.ejada.obdatarepositoryapp.controllers;

import com.ejada.commons.errors.exceptions.ErrorCodeException;
import com.ejada.commons.logs.FlowContext;
import com.ejada.commons.logs.annotations.FailureQueueDescriptor;
import com.ejada.commons.logs.annotations.ServiceDescriptor;
import com.ejada.commons.logs.annotations.Variable;
import com.ejada.obdatarepositoryapp.constants.Headers;
import com.ejada.obdatarepositoryapp.constants.ControllerQueryParameters;
import com.ejada.obdatarepositoryapp.dtos.listprofileaccounts.response.ListProfileAccountsResponseDto;
import com.ejada.obdatarepositoryapp.dtos.listprofilebalances.response.ListProfileBalancesResponseDto;
import com.ejada.obdatarepositoryapp.dtos.listprofilebeneficiariesresponse.ListProfileBeneficiariesResponseDto;
import com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response.ListProfileTransactionsResponseCategorizedDto;
import com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response.ListProfileTransactionsResponseDto;
import com.ejada.obdatarepositoryapp.enums.*;
import com.ejada.obdatarepositoryapp.models.EnumValidatorByClassConstants;
import com.ejada.obdatarepositoryapp.services.OBDataRepositoryService;
import com.ejada.obrepositoryabstractmodel.errors.ErrorCodes;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.OffsetDateTime;

import static com.ejada.commons.errors.enums.ErrorCodes.INVALID_REQUEST_BODY;
import static com.ejada.obdatarepositoryapp.constants.FailureQueues.OB_DATA_REPOSITORY_FAILURE_QUEUE;

@RestController
@RequestMapping("/single-api-aggregator/v1")
@Slf4j
@RequiredArgsConstructor
@Validated
@FailureQueueDescriptor(destination = OB_DATA_REPOSITORY_FAILURE_QUEUE)
public class OBDataRepositoryController {
    private static final String LIST_PROFILE_ACCOUNTS_SERVICE_NAME = "ListProfileAccounts";
    private static final String LIST_PROFILE_ACCOUNTS_SERVICE_EXCEPTION = "ListProfileAccountsEXCP";
    private static final String LIST_PROFILE_TRANSACTIONS_SERVICE_NAME = "ListProfileTransactions";
    private static final String LIST_PROFILE_TRANSACTIONS_SERVICE_EXCEPTION = "ListProfileTransactionsEXCP";
    private static final String LIST_PROFILE_BALANCES_SERVICE_NAME = "ListProfileBalances";
    private static final String LIST_PROFILE_BALANCES_SERVICE_EXCEPTION = "ListProfileBalancesEXCP";
    private static final String LIST_PROFILE_BENEFICIARIES_SERVICE_NAME = "ListProfileBeneficiaries";
    private static final String LIST_PROFILE_BENEFICIARIES_SERVICE_EXCEPTION = "ListProfileBeneficiariesEXCP";
    private final OBDataRepositoryService obDataRepositoryService;

    @Autowired
    @Qualifier("requestHttpFlowContext")
    private FlowContext flowContext;

    @GetMapping(value = "/profiles/accounts", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ServiceDescriptor(name = LIST_PROFILE_ACCOUNTS_SERVICE_NAME, exception = LIST_PROFILE_ACCOUNTS_SERVICE_EXCEPTION)
    public ResponseEntity<ListProfileAccountsResponseDto> listProfileAccounts(
            @Variable(name = Headers.X_REQUEST_ID)
            @RequestHeader(name = Headers.X_REQUEST_ID, required = false) String xRequestId,
            @Variable(name = ControllerQueryParameters.APPLICATION_ID, index = 3)
            @Valid @NotBlank(message = ErrorCodes.Constants.APPLICATION_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.APPLICATION_ID) String applicationId,
            @Variable(name = ControllerQueryParameters.PSU_ID, index = 5)
            @Valid @NotBlank(message = ErrorCodes.Constants.PSU_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.PSU_ID) String psuId,
            @Variable(name = ControllerQueryParameters.PROFILE_ID, index = 2)
            @RequestParam(name = ControllerQueryParameters.PROFILE_ID, required = false) String profileId,
            @Variable(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, index = 4)
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, required = false) String financialInstitutionId,
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_NAME, required = false) String financialInstitutionName,
            @Variable(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, index = 6)
            @RequestParam(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, required = false) String accountsLinkId,
            @Variable(name = ControllerQueryParameters.ACCOUNT_ID, index = 7)
            @RequestParam(name = ControllerQueryParameters.ACCOUNT_ID, required = false) String accountId,
            @EnumValidatorByClassConstants(enumClass = AccountStatusEnums.class, message = ErrorCodes.Constants.INVALID_ACCOUNT_STATUS)
            @RequestParam(name = ControllerQueryParameters.STATUS, required = false) String status,
            @RequestParam(name = ControllerQueryParameters.CURRENCY, required = false) String currency,
            @EnumValidatorByClassConstants(enumClass = AccountTypesEnums.class, message = ErrorCodes.Constants.INVALID_ACCOUNT_TYPE)
            @RequestParam(name = ControllerQueryParameters.ACCOUNT_TYPE, required = false) String accountType,
            @EnumValidatorByClassConstants(enumClass = AccountSubTypesEnums.class, message = ErrorCodes.Constants.INVALID_ACCOUNT_SUB_TYPE)
            @RequestParam(name = ControllerQueryParameters.ACCOUNT_SUB_TYPE, required = false) String accountSubType,
            @RequestParam(name = ControllerQueryParameters.FROM_OPENING_DATE, required = false) OffsetDateTime fromOpeningDate,
            @RequestParam(name = ControllerQueryParameters.TO_OPENING_DATE, required = false) OffsetDateTime toOpeningDate,
            @RequestParam(name = ControllerQueryParameters.PAGE, defaultValue = "1", required = false) Integer page,
            @EnumValidatorByClassConstants(enumClass = OrderEnums.class, message = ErrorCodes.Constants.INVALID_ORDER)
            @RequestParam(name = ControllerQueryParameters.ORDER, defaultValue = "DESC", required = false) String order,
            @RequestParam(name = ControllerQueryParameters.INCLUDE_BALANCES_FLAG,required = false,defaultValue = "false") String includeBalancesFlag,
            @EnumValidatorByClassConstants(enumClass = BalanceTypeEnum.class, message = ErrorCodes.Constants.INVALID_BALANCE_TYPE)
            @RequestParam(name = ControllerQueryParameters.BALANCE_TYPE, required = false) String balanceType
            ) {
        log.trace("Operation {} called", LIST_PROFILE_ACCOUNTS_SERVICE_NAME);

        if (includeBalancesFlag == null || !includeBalancesFlag.matches("(?i)true|false|0|1")) {
            throw new ErrorCodeException(INVALID_REQUEST_BODY.getCode(),
                    ErrorCodes.Constants.INVALID_INCLUDE_BALANCES_FLAG);
        }

        // Normalize the includeBalancesFlag to "true" if it is either "true" or "1"
        if (includeBalancesFlag.equalsIgnoreCase("true") || includeBalancesFlag.equals("1")) {
            includeBalancesFlag = "true";
        }

        ListProfileAccountsResponseDto response = obDataRepositoryService.listProfileAccounts(
                applicationId, psuId, profileId, financialInstitutionId, financialInstitutionName,
                accountsLinkId, accountId, status, currency, accountType,
                accountSubType, fromOpeningDate, toOpeningDate, page, order,
                flowContext.getFoundation().getTraceId(),includeBalancesFlag,balanceType);
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.APPLICATION_JSON)
                .header(Headers.X_REQUEST_ID, flowContext.getFoundation().getTraceId())
                .body(response);
    }

    @GetMapping(value = "/profiles/balances", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ServiceDescriptor(name = LIST_PROFILE_BALANCES_SERVICE_NAME, exception = LIST_PROFILE_BALANCES_SERVICE_EXCEPTION)
    public ResponseEntity<ListProfileBalancesResponseDto> listProfileBalances(
            @Variable(name = Headers.X_REQUEST_ID)
            @RequestHeader(name = Headers.X_REQUEST_ID, required = false) String xRequestId,
            @Variable(name = ControllerQueryParameters.APPLICATION_ID, index = 3)
            @Valid @NotBlank(message = ErrorCodes.Constants.APPLICATION_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.APPLICATION_ID) String applicationId,
            @Variable(name = ControllerQueryParameters.PSU_ID, index = 5)
            @Valid @NotBlank(message = ErrorCodes.Constants.PSU_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.PSU_ID) String psuId,
            @Variable(name = ControllerQueryParameters.PROFILE_ID, index = 2)
            @RequestParam(name = ControllerQueryParameters.PROFILE_ID, required = false) BigInteger profileId,
            @Variable(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, index = 4)
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, required = false) String financialInstitutionId,
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_NAME, required = false) String financialInstitutionName,
            @Variable(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, index = 6)
            @RequestParam(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, required = false) String accountsLinkId,
            @Variable(name = ControllerQueryParameters.ACCOUNT_ID, index = 7)
            @RequestParam(name = ControllerQueryParameters.ACCOUNT_ID, required = false) String accountId,
            @RequestParam(name = ControllerQueryParameters.CURRENCY, required = false) String currency,
            @RequestParam(name = ControllerQueryParameters.PAGE, defaultValue = "1", required = false) Integer page,
            @EnumValidatorByClassConstants(enumClass = BalanceTypeEnum.class, message = ErrorCodes.Constants.INVALID_BALANCE_TYPE)
            @RequestParam(name = ControllerQueryParameters.BALANCE_TYPE, required = false) String balanceType,
            @EnumValidatorByClassConstants(enumClass = BalanceAmountTypeEnum.class, message = ErrorCodes.Constants.INVALID_BALANCE_AMOUNT_TYPE)
            @RequestParam(name = ControllerQueryParameters.BALANCE_AMOUNT_TYPE, required = false) String balanceAmountType,
            @RequestParam(name = ControllerQueryParameters.FROM_AMOUNT, required = false) BigDecimal fromAmount,
            @RequestParam(name = ControllerQueryParameters.TO_AMOUNT, required = false) BigDecimal toAmount
    ){
        log.trace("Operation {} called", LIST_PROFILE_BALANCES_SERVICE_NAME);
        ListProfileBalancesResponseDto response = obDataRepositoryService.listProfileBalances(
                applicationId,
                psuId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountsLinkId,
                accountId,
                currency,
                page,
                balanceType,
                balanceAmountType,
                fromAmount,
                toAmount,
                flowContext.getFoundation().getTraceId()
        );
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.APPLICATION_JSON)
                .header(Headers.X_REQUEST_ID, flowContext.getFoundation().getTraceId())
                .body(response);
    }

    @GetMapping(value = "/profiles/transactions", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ServiceDescriptor(name = LIST_PROFILE_TRANSACTIONS_SERVICE_NAME, exception = LIST_PROFILE_TRANSACTIONS_SERVICE_EXCEPTION)
    public ResponseEntity<ListProfileTransactionsResponseDto> listProfileTransactions(
            @Variable(name = Headers.X_REQUEST_ID)
            @RequestHeader(name = Headers.X_REQUEST_ID, required = false) String xRequestId,
            @Variable(name = ControllerQueryParameters.APPLICATION_ID, index = 3)
            @Valid @NotBlank(message = ErrorCodes.Constants.APPLICATION_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.APPLICATION_ID) String applicationId,
            @Variable(name = ControllerQueryParameters.PSU_ID, index = 5)
            @Valid @NotBlank(message = ErrorCodes.Constants.PSU_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.PSU_ID) String psuId,
            @Variable(name = ControllerQueryParameters.PROFILE_ID, index = 2)
            @RequestParam(name = ControllerQueryParameters.PROFILE_ID, required = false) BigInteger profileId,
            @Variable(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, index = 4)
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, required = false) String financialInstitutionId,
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_NAME, required = false) String financialInstitutionName,
            @Variable(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, index = 6)
            @RequestParam(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, required = false) String accountsLinkId,
            @Variable(name = ControllerQueryParameters.ACCOUNT_ID, index = 7)
            @RequestParam(name = ControllerQueryParameters.ACCOUNT_ID, required = false) String accountId,
            @EnumValidatorByClassConstants(enumClass = TransactionTypeEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_TYPE)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_TYPE, required = false) String transactionType,
            @EnumValidatorByClassConstants(enumClass = TransactionSubTypeEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_SUB_TYPE)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_SUB_TYPE, required = false) String transactionSubType,
            @EnumValidatorByClassConstants(enumClass = TransactionFlagsEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_FLAGS)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_FLAGS, required = false) String transactionFlags,
            @EnumValidatorByClassConstants(enumClass = PaymentModeEnums.class, message = ErrorCodes.Constants.INVALID_PAYMENT_MODE)
            @RequestParam(name = ControllerQueryParameters.PAYMENT_MODE, required = false) String paymentMode,
            @EnumValidatorByClassConstants(enumClass = TransactionAmountTypeEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_AMOUNT_TYPE)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_AMOUNT_TYPE, required = false) String transactionAmountType,
            @EnumValidatorByClassConstants(enumClass = TransactionStatusEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_STATUS)
            @RequestParam(name = ControllerQueryParameters.STATUS, required = false) String status,
            @EnumValidatorByClassConstants(enumClass = TransactionMutabilityEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_MUTABILITY)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_MUTABILITY, required = false) String transactionMutability,
            @RequestParam(name = ControllerQueryParameters.FROM_BOOKING_DATE, required = false) OffsetDateTime fromBookingDate,
            @RequestParam(name = ControllerQueryParameters.TO_BOOKING_DATE, required = false) OffsetDateTime toBookingDate,
            @RequestParam(name = ControllerQueryParameters.FROM_AMOUNT, required = false) BigDecimal fromAmount,
            @RequestParam(name = ControllerQueryParameters.TO_AMOUNT, required = false) BigDecimal toAmount,
            @RequestParam(name = ControllerQueryParameters.CURRENCY, required = false) String currency,
            @RequestParam(name = ControllerQueryParameters.MERCHANT_NAME, required = false) String merchantName,
            @EnumValidatorByClassConstants(enumClass = CardSchemeNameEnums.class, message = ErrorCodes.Constants.INVALID_CARD_SCHEME_NAME)
            @RequestParam(name = ControllerQueryParameters.CARD_SCHEME_NAME, required = false) String cardSchemeName,
            @EnumValidatorByClassConstants(enumClass = InstrumentTypeEnums.class, message = ErrorCodes.Constants.INVALID_INSTRUMENT_TYPE)
            @RequestParam(name = ControllerQueryParameters.INSTRUMENT_TYPE, required = false) String instrumentType,
            @RequestParam(name = ControllerQueryParameters.PAGE, defaultValue = "1", required = false) Integer page,
            @EnumValidatorByClassConstants(enumClass = OrderEnums.class, message = ErrorCodes.Constants.INVALID_ORDER)
            @RequestParam(name = ControllerQueryParameters.ORDER, defaultValue = "DESC", required = false) String order
    ) {

        log.trace("Operation {} called", LIST_PROFILE_TRANSACTIONS_SERVICE_NAME);
        ListProfileTransactionsResponseDto response = obDataRepositoryService.listProfileTransactions(
                applicationId, psuId, profileId, financialInstitutionId, financialInstitutionName,
                accountsLinkId, accountId, transactionType, transactionSubType, transactionFlags, paymentMode,
                transactionAmountType, status, transactionMutability, fromBookingDate,
                toBookingDate, fromAmount, toAmount, currency, merchantName,
                cardSchemeName, instrumentType, page, order, flowContext.getFoundation().getTraceId());
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.APPLICATION_JSON)
                .header(Headers.X_REQUEST_ID, flowContext.getFoundation().getTraceId())
                .body(response);
    }

    @GetMapping(value = "/profiles/transactions-categorized", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ServiceDescriptor(name = LIST_PROFILE_TRANSACTIONS_SERVICE_NAME, exception = LIST_PROFILE_TRANSACTIONS_SERVICE_EXCEPTION)
    public ResponseEntity<ListProfileTransactionsResponseCategorizedDto> listProfileTransactionsCategorized(
            @Variable(name = Headers.X_REQUEST_ID)
            @RequestHeader(name = Headers.X_REQUEST_ID, required = false) String xRequestId,
            @Variable(name = ControllerQueryParameters.APPLICATION_ID, index = 3)
            @Valid @NotBlank(message = ErrorCodes.Constants.APPLICATION_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.APPLICATION_ID) String applicationId,
            @Variable(name = ControllerQueryParameters.PSU_ID, index = 5)
            @Valid @NotBlank(message = ErrorCodes.Constants.PSU_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.PSU_ID) String psuId,
            @Variable(name = ControllerQueryParameters.PROFILE_ID, index = 2)
            @RequestParam(name = ControllerQueryParameters.PROFILE_ID, required = false) BigInteger profileId,
            @Variable(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, index = 4)
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, required = false) String financialInstitutionId,
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_NAME, required = false) String financialInstitutionName,
            @Variable(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, index = 6)
            @RequestParam(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, required = false) String accountsLinkId,
            @Variable(name = ControllerQueryParameters.ACCOUNT_ID, index = 7)
            @RequestParam(name = ControllerQueryParameters.ACCOUNT_ID, required = false) String accountId,
            @EnumValidatorByClassConstants(enumClass = TransactionTypeEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_TYPE)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_TYPE, required = false) String transactionType,
            @EnumValidatorByClassConstants(enumClass = TransactionSubTypeEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_SUB_TYPE)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_SUB_TYPE, required = false) String transactionSubType,
            @EnumValidatorByClassConstants(enumClass = TransactionFlagsEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_FLAGS)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_FLAGS, required = false) String transactionFlags,
            @EnumValidatorByClassConstants(enumClass = PaymentModeEnums.class, message = ErrorCodes.Constants.INVALID_PAYMENT_MODE)
            @RequestParam(name = ControllerQueryParameters.PAYMENT_MODE, required = false) String paymentMode,
            @EnumValidatorByClassConstants(enumClass = TransactionAmountTypeEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_AMOUNT_TYPE)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_AMOUNT_TYPE, required = false) String transactionAmountType,
            @EnumValidatorByClassConstants(enumClass = TransactionStatusEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_STATUS)
            @RequestParam(name = ControllerQueryParameters.STATUS, required = false) String status,
            @EnumValidatorByClassConstants(enumClass = TransactionMutabilityEnums.class, message = ErrorCodes.Constants.INVALID_TRANSACTION_MUTABILITY)
            @RequestParam(name = ControllerQueryParameters.TRANSACTION_MUTABILITY, required = false) String transactionMutability,
            @RequestParam(name = ControllerQueryParameters.FROM_BOOKING_DATE, required = false) OffsetDateTime fromBookingDate,
            @RequestParam(name = ControllerQueryParameters.TO_BOOKING_DATE, required = false) OffsetDateTime toBookingDate,
            @RequestParam(name = ControllerQueryParameters.FROM_AMOUNT, required = false) BigDecimal fromAmount,
            @RequestParam(name = ControllerQueryParameters.TO_AMOUNT, required = false) BigDecimal toAmount,
            @RequestParam(name = ControllerQueryParameters.CURRENCY, required = false) String currency,
            @RequestParam(name = ControllerQueryParameters.MERCHANT_NAME, required = false) String merchantName,
            @EnumValidatorByClassConstants(enumClass = CardSchemeNameEnums.class, message = ErrorCodes.Constants.INVALID_CARD_SCHEME_NAME)
            @RequestParam(name = ControllerQueryParameters.CARD_SCHEME_NAME, required = false) String cardSchemeName,
            @EnumValidatorByClassConstants(enumClass = InstrumentTypeEnums.class, message = ErrorCodes.Constants.INVALID_INSTRUMENT_TYPE)
            @RequestParam(name = ControllerQueryParameters.INSTRUMENT_TYPE, required = false) String instrumentType,
            @RequestParam(name = ControllerQueryParameters.PAGE, defaultValue = "1", required = false) Integer page,
            @EnumValidatorByClassConstants(enumClass = OrderEnums.class, message = ErrorCodes.Constants.INVALID_ORDER)
            @RequestParam(name = ControllerQueryParameters.ORDER, defaultValue = "DESC", required = false) String order
    ) {

        log.trace("Operation {} called", LIST_PROFILE_TRANSACTIONS_SERVICE_NAME);
        ListProfileTransactionsResponseCategorizedDto response = obDataRepositoryService.listProfileTransactionsCategorized(
                applicationId, psuId, profileId, financialInstitutionId, financialInstitutionName,
                accountsLinkId, accountId, transactionType, transactionSubType, transactionFlags, paymentMode,
                transactionAmountType, status, transactionMutability, fromBookingDate,
                toBookingDate, fromAmount, toAmount, currency, merchantName,
                cardSchemeName, instrumentType, page, order, flowContext.getFoundation().getTraceId());
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.APPLICATION_JSON)
                .header(Headers.X_REQUEST_ID, flowContext.getFoundation().getTraceId())
                .body(response);
    }


    @GetMapping(value = "/profiles/beneficiaries", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ServiceDescriptor(name = LIST_PROFILE_BENEFICIARIES_SERVICE_NAME, exception = LIST_PROFILE_BENEFICIARIES_SERVICE_EXCEPTION)
    public ResponseEntity<ListProfileBeneficiariesResponseDto> listProfileBeneficiaries(
            @Variable(name = Headers.X_REQUEST_ID)
            @RequestHeader(name = Headers.X_REQUEST_ID, required = false) String xRequestId,
            @Variable(name = ControllerQueryParameters.APPLICATION_ID, index = 3)
            @Valid @NotBlank(message = ErrorCodes.Constants.APPLICATION_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.APPLICATION_ID) String applicationId,
            @Variable(name = ControllerQueryParameters.PSU_ID, index = 5)
            @Valid @NotBlank(message = ErrorCodes.Constants.PSU_ID_IS_MANDATORY)
            @RequestParam(name = ControllerQueryParameters.PSU_ID) String psuId,
            @Variable(name = ControllerQueryParameters.PROFILE_ID, index = 2)
            @RequestParam(name = ControllerQueryParameters.PROFILE_ID, required = false) BigInteger profileId,
            @Variable(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, index = 4)
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_ID, required = false) String financialInstitutionId,
            @RequestParam(name = ControllerQueryParameters.FINANCIAL_INSTITUTION_NAME, required = false) String financialInstitutionName,
            @Variable(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, index = 6)
            @RequestParam(name = ControllerQueryParameters.ACCOUNTS_LINK_ID, required = false) String accountsLinkId,
            @Variable(name = ControllerQueryParameters.ACCOUNT_ID, index = 7)
            @RequestParam(name = ControllerQueryParameters.ACCOUNT_ID, required = false) String accountId,
            @EnumValidatorByClassConstants(enumClass = BeneficiaryTypeEnums.class, message = ErrorCodes.Constants.INVALID_BENEFICIARY_TYPE)
            @RequestParam(name = ControllerQueryParameters.BENEFICIARY_TYPE, required = false) String beneficiaryType,
            @RequestParam(name = ControllerQueryParameters.BENEFICIARY_NAME, required = false) String beneficiaryName,
            @RequestParam(name = ControllerQueryParameters.BENEFICIARY_SHORT_NAME, required = false) String beneficiaryShortName,
            @RequestParam(name = ControllerQueryParameters.BENEFICIARY_BANK_NAME, required = false) String beneficiaryBankName,
            @RequestParam(name = ControllerQueryParameters.PAGE, defaultValue = "1", required = false) Integer page
    ) {

        log.trace("Operation {} called", LIST_PROFILE_BENEFICIARIES_SERVICE_NAME);
        ListProfileBeneficiariesResponseDto response = obDataRepositoryService.listProfileBeneficiaries(
                applicationId, psuId, profileId, financialInstitutionId, financialInstitutionName,
                accountsLinkId, accountId, beneficiaryType, beneficiaryName,
                beneficiaryShortName, beneficiaryBankName, page, flowContext.getFoundation().getTraceId());
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.APPLICATION_JSON)
                .header(Headers.X_REQUEST_ID, flowContext.getFoundation().getTraceId())
                .body(response);
    }
}
