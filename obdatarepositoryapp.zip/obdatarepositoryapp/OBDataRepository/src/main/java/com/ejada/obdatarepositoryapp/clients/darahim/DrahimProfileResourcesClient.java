package com.ejada.obdatarepositoryapp.clients.darahim;

import com.ejada.commons.errors.handlers.FeignClientErrorDecoder;
import com.ejada.commons.logs.annotations.FailureQueueDescriptor;
import com.ejada.obdatarepositoryapp.clients.models.ListAccounts.ClientListAccountsResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListAccountsBalances.ClientListAccountsBalancesResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListProfileBeneficiaries.ClientListBeneficiariesResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListProfileTransactions.ClientListTransactionsCategorizedResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListProfileTransactions.ClientListTransactionsResponse;
import com.ejada.obdatarepositoryapp.configurations.FeignWebClientConfiguration;
import com.ejada.obdatarepositoryapp.constants.DarahimQueryParameters;
import com.ejada.obdatarepositoryapp.constants.FailureQueues;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.OffsetDateTime;

import static com.ejada.obdatarepositoryapp.constants.Headers.*;

@FailureQueueDescriptor(destination = FailureQueues.OB_DATA_REPOSITORY_FAILURE_QUEUE)
@FeignClient(name = "ProfileResources", url = "${app.config.integration.backend.host}",   configuration = { FeignWebClientConfiguration.class, FeignClientErrorDecoder.class }
)
public interface DrahimProfileResourcesClient {
    @GetMapping(value = "${app.config.integration.backend.api.list-balances}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ClientListAccountsBalancesResponse drahimListProfileBalances(
            @RequestHeader(value = X_REQUEST_ID, required = false) String requestId,
            @RequestHeader(value = CLIENT_ID, required = true) String clientId,
            @RequestHeader(value = CLIENT_SECRET, required = true) String clientSecret,
            @RequestHeader(value = DRAHIM_CLIENT_ID, required = true) String drahimClientId,
            @RequestHeader(value = DRAHIM_CLIENT_SECRET, required = true) String drahimClientSecret,
            @RequestParam(value = DarahimQueryParameters.SPONSORED_TPP_ID, required = true) String sponsoredTPPId,
            @RequestParam(value = DarahimQueryParameters.PROFILE_ID) BigInteger profileId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_ID) String financialInstitutionId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_NAME) String financialInstitutionName,
            @RequestParam(value = DarahimQueryParameters.ACCOUNT_ID) String accountId,
            @RequestParam(value = DarahimQueryParameters.ACCOUNTS_LINK_ID) String accountsLinkId,
            @RequestParam(value = DarahimQueryParameters.BALANCE_TYPE) String balanceType,
            @RequestParam(value = DarahimQueryParameters.CURRENCY) String currency,
            @RequestParam(value = DarahimQueryParameters.FROM_AMOUNT) BigDecimal fromAmount,
            @RequestParam(value = DarahimQueryParameters.TO_AMOUNT) BigDecimal toAmount,
            @RequestParam(value = DarahimQueryParameters.DARAHIM_PSU_ID) String psuId,
            @RequestParam(value = DarahimQueryParameters.BALANCE_AMOUNT_TYPE) String balanceAmountType,
            @RequestParam(value = DarahimQueryParameters.LIMIT, required = false) Integer limit,
            @RequestParam(value = DarahimQueryParameters.OFFSET, required = false) Integer offset
    );

    @GetMapping(value = "${app.config.integration.backend.api.list-accounts}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ClientListAccountsResponse drahimListProfileAccounts(
            @RequestHeader(value = X_REQUEST_ID, required = false) String requestId,
            @RequestHeader(value = CLIENT_ID, required = true) String clientId,
            @RequestHeader(value = CLIENT_SECRET, required = true) String clientSecret,
            @RequestHeader(value = DRAHIM_CLIENT_ID, required = true) String drahimClientId,
            @RequestHeader(value = DRAHIM_CLIENT_SECRET, required = true) String drahimClientSecret,
            @RequestParam(value = DarahimQueryParameters.SPONSORED_TPP_ID, required = true) String sponsoredTPPId,
//            @RequestParam(value = QueryParameters.CONSENT_ID, required = false) String consentId,
            @RequestParam(value = DarahimQueryParameters.PROFILE_ID, required = false) String profileId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_ID, required = false) String financialInstitutionId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_NAME, required = false) String financialInstitutionName,
            @RequestParam(value = DarahimQueryParameters.ACCOUNTS_LINK_ID, required = false) String accountsLinkId,
            @RequestParam(value = DarahimQueryParameters.ACCOUNT_ID, required = false) String accountId,
            @RequestParam(value = DarahimQueryParameters.STATUS, required = false) String status,
            @RequestParam(value = DarahimQueryParameters.CURRENCY, required = false) String currency,
            @RequestParam(value = DarahimQueryParameters.ACCOUNT_TYPE, required = false) String accountType,
            @RequestParam(value = DarahimQueryParameters.ACCOUNT_SUB_TYPE, required = false) String accountSubType,
            @RequestParam(value = DarahimQueryParameters.FROM_OPENING_DATE, required = false) OffsetDateTime fromOpeningDate,
            @RequestParam(value = DarahimQueryParameters.TO_OPENING_DATE, required = false) OffsetDateTime toOpeningDate,
            @RequestParam(value = DarahimQueryParameters.INCLUDE_BALANCES_FLAG, required = false) boolean includeBalanceFlag,
            @RequestParam(value = DarahimQueryParameters.BALANCE_TYPE, required = false) String balanceType,
            @RequestParam(value = DarahimQueryParameters.ORDER, required = false) String order,
            @RequestParam(value = DarahimQueryParameters.DARAHIM_PSU_ID, required = false) String psuId,
            @RequestParam(value = DarahimQueryParameters.OFFSET, required = false) Integer offset,
            @RequestParam(value = DarahimQueryParameters.LIMIT, required = false) Integer limit
    );

    @GetMapping(value = "${app.config.integration.backend.api.list-transactions}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ClientListTransactionsResponse drahimListProfileTransactions(
            @RequestHeader(value = X_REQUEST_ID, required = false) String requestId,
            @RequestHeader(value = CLIENT_ID, required = true) String clientId,
            @RequestHeader(value = CLIENT_SECRET, required = true) String clientSecret,
            @RequestHeader(value = DRAHIM_CLIENT_ID, required = true) String drahimClientId,
            @RequestHeader(value = DRAHIM_CLIENT_SECRET, required = true) String drahimClientSecret,
            @RequestParam(value = DarahimQueryParameters.SPONSORED_TPP_ID, required = true) String sponsoredTPPId,
//            @RequestParam(value = QueryParameters.CONSENT_ID, required = false) String consentId,
            @RequestParam(value = DarahimQueryParameters.PROFILE_ID, required = false) BigInteger profileId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_ID, required = false) String financialInstitutionId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_NAME, required = false) String financialInstitutionName,
            @RequestParam(value = DarahimQueryParameters.ACCOUNTS_LINK_ID, required = false) String accountsLinkId,
            @RequestParam(value = DarahimQueryParameters.ACCOUNT_ID, required = false) String accountId,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_TYPE, required = false) String transactionType,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_SUB_TYPE, required = false) String transactionSubType,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_FLAGS, required = false) String transactionFlags,
            @RequestParam(value = DarahimQueryParameters.PAYMENT_MODE, required = false) String paymentMode,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_AMOUNT_TYPE, required = false) String transactionAmountType,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_STATUS, required = false) String transactionStatus,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_MUTABILITY, required = false) String transactionMutability,
            @RequestParam(value = DarahimQueryParameters.FROM_BOOKING_DATE, required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime fromBookingDate,
            @RequestParam(value = DarahimQueryParameters.TO_BOOKING_DATE, required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime toBookingDate,
            @RequestParam(value = DarahimQueryParameters.FROM_AMOUNT, required = false) BigDecimal fromAmount,
            @RequestParam(value = DarahimQueryParameters.TO_AMOUNT, required = false) BigDecimal toAmount,
            @RequestParam(value = DarahimQueryParameters.CURRENCY, required = false) String currency,
            @RequestParam(value = DarahimQueryParameters.MERCHANT_NAME, required = false) String merchantName,
            @RequestParam(value = DarahimQueryParameters.CARD_SCHEME_NAME, required = false) String cardSchemeName,
            @RequestParam(value = DarahimQueryParameters.ORDER, required = false) String order,
            @RequestParam(value = DarahimQueryParameters.DARAHIM_PSU_ID, required = false) String psuId,
            @RequestParam(value = DarahimQueryParameters.INSTRUMENT_TYPE, required = false) String instrumentType,
            @RequestParam(value = DarahimQueryParameters.OFFSET, required = false) Integer offset,
            @RequestParam(value = DarahimQueryParameters.LIMIT, required = false) Integer limit
    );

    @GetMapping(value = "${app.config.integration.backend.api.list-transactions}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ClientListTransactionsCategorizedResponse drahimListProfileTransactionsCategorized(
            @RequestHeader(value = X_REQUEST_ID, required = false) String requestId,
            @RequestHeader(value = CLIENT_ID, required = true) String clientId,
            @RequestHeader(value = CLIENT_SECRET, required = true) String clientSecret,
            @RequestHeader(value = DRAHIM_CLIENT_ID, required = true) String drahimClientId,
            @RequestHeader(value = DRAHIM_CLIENT_SECRET, required = true) String drahimClientSecret,
            @RequestParam(value = DarahimQueryParameters.SPONSORED_TPP_ID, required = true) String sponsoredTPPId,
//            @RequestParam(value = QueryParameters.CONSENT_ID, required = false) String consentId,
            @RequestParam(value = DarahimQueryParameters.PROFILE_ID, required = false) BigInteger profileId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_ID, required = false) String financialInstitutionId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_NAME, required = false) String financialInstitutionName,
            @RequestParam(value = DarahimQueryParameters.ACCOUNTS_LINK_ID, required = false) String accountsLinkId,
            @RequestParam(value = DarahimQueryParameters.ACCOUNT_ID, required = false) String accountId,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_TYPE, required = false) String transactionType,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_SUB_TYPE, required = false) String transactionSubType,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_FLAGS, required = false) String transactionFlags,
            @RequestParam(value = DarahimQueryParameters.PAYMENT_MODE, required = false) String paymentMode,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_AMOUNT_TYPE, required = false) String transactionAmountType,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_STATUS, required = false) String transactionStatus,
            @RequestParam(value = DarahimQueryParameters.TRANSACTION_MUTABILITY, required = false) String transactionMutability,
            @RequestParam(value = DarahimQueryParameters.FROM_BOOKING_DATE, required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime fromBookingDate,
            @RequestParam(value = DarahimQueryParameters.TO_BOOKING_DATE, required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime toBookingDate,
            @RequestParam(value = DarahimQueryParameters.FROM_AMOUNT, required = false) BigDecimal fromAmount,
            @RequestParam(value = DarahimQueryParameters.TO_AMOUNT, required = false) BigDecimal toAmount,
            @RequestParam(value = DarahimQueryParameters.CURRENCY, required = false) String currency,
            @RequestParam(value = DarahimQueryParameters.MERCHANT_NAME, required = false) String merchantName,
            @RequestParam(value = DarahimQueryParameters.CARD_SCHEME_NAME, required = false) String cardSchemeName,
            @RequestParam(value = DarahimQueryParameters.ORDER, required = false) String order,
            @RequestParam(value = DarahimQueryParameters.DARAHIM_PSU_ID, required = false) String psuId,
            @RequestParam(value = DarahimQueryParameters.INSTRUMENT_TYPE, required = false) String instrumentType,
            @RequestParam(value = DarahimQueryParameters.OFFSET, required = false) Integer offset,
            @RequestParam(value = DarahimQueryParameters.LIMIT, required = false) Integer limit
    );

    @GetMapping(value = "${app.config.integration.backend.api.list-beneficiaries}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ClientListBeneficiariesResponse drahimListProfileBeneficiaries(
            @RequestHeader(value = X_REQUEST_ID, required = false) String requestId,
            @RequestHeader(value = CLIENT_ID, required = true) String clientId,
            @RequestHeader(value = CLIENT_SECRET, required = true) String clientSecret,
            @RequestHeader(value = DRAHIM_CLIENT_ID, required = true) String drahimClientId,
            @RequestHeader(value = DRAHIM_CLIENT_SECRET, required = true) String drahimClientSecret,
            @RequestParam(value = DarahimQueryParameters.SPONSORED_TPP_ID, required = true) String sponsoredTPPId,
            @RequestParam(value = DarahimQueryParameters.DARAHIM_PSU_ID, required = false) String psuId,
            @RequestParam(value = DarahimQueryParameters.PROFILE_ID, required = false) BigInteger profileId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_ID, required = false) String financialInstitutionId,
            @RequestParam(value = DarahimQueryParameters.FINANCIAL_INSTITUTION_NAME, required = false) String financialInstitutionName,
            @RequestParam(value = DarahimQueryParameters.ACCOUNTS_LINK_ID, required = false) String accountsLinkId,
            @RequestParam(value = DarahimQueryParameters.ACCOUNT_ID, required = false) String accountId,
            @RequestParam(value = DarahimQueryParameters.BENEFICIARY_TYPE, required = false) String beneficiaryType,
            @RequestParam(value = DarahimQueryParameters.BENEFICIARY_NAME, required = false) String beneficiaryName,
            @RequestParam(value = DarahimQueryParameters.BENEFICIARY_SHORT_NAME, required = false) String beneficiaryShortName,
            @RequestParam(value = DarahimQueryParameters.BENEFICIARY_BANK_NAME, required = false) String beneficiaryBankName,
            @RequestParam(value = DarahimQueryParameters.OFFSET, required = false) Integer offset,
            @RequestParam(value = DarahimQueryParameters.LIMIT, required = false) Integer limit
    );
}
