package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum TransactionFlagsEnums {
    CASHBACK("KSAOB.Cashback"),
    PAYROLL("KSAOB.Payroll"),
    DIRECT_DEBIT("KSAOB.DirectDebit"),
    STANDING_ORDER("KSAOB.StandingOrder"),
    LOAN("KSAOB.Loan"),
    DIVIDEND("KSAOB.Dividend");

    private final String value;

    TransactionFlagsEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static TransactionFlagsEnums fromValue(String text) {
        for (TransactionFlagsEnums b : TransactionFlagsEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
