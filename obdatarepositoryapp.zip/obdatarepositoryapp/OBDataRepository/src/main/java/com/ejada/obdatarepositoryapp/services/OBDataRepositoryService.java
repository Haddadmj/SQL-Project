package com.ejada.obdatarepositoryapp.services;

import com.ejada.obdatarepositoryapp.clients.darahim.DrahimProfilesResourcesClientFacade;
import com.ejada.obdatarepositoryapp.clients.models.ListAccounts.ClientListAccountsResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListAccountsBalances.ClientListAccountsBalancesResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListProfileBeneficiaries.ClientListBeneficiariesResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListProfileTransactions.ClientListTransactionsCategorizedResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListProfileTransactions.ClientListTransactionsResponse;
import com.ejada.obdatarepositoryapp.dtos.commondtos.response.MetaDto;
import com.ejada.obdatarepositoryapp.dtos.listprofileaccounts.response.ListProfileAccountsDataDto;
import com.ejada.obdatarepositoryapp.dtos.listprofileaccounts.response.ListProfileAccountsResponseDto;
import com.ejada.obdatarepositoryapp.dtos.listprofilebalances.response.ListProfileBalancesDataDto;
import com.ejada.obdatarepositoryapp.dtos.listprofilebalances.response.ListProfileBalancesResponseDto;
import com.ejada.obdatarepositoryapp.dtos.listprofilebeneficiariesresponse.ListProfileBeneficiariesDataDto;
import com.ejada.obdatarepositoryapp.dtos.listprofilebeneficiariesresponse.ListProfileBeneficiariesResponseDto;
import com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response.ListProfileTransactionsDataCategorizedDto;
import com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response.ListProfileTransactionsDataDto;
import com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response.ListProfileTransactionsResponseCategorizedDto;
import com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response.ListProfileTransactionsResponseDto;
import com.ejada.obdatarepositoryapp.repositories.*;
import com.ejada.obrepositoryabstractmodel.entities.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.OffsetDateTime;

import static com.ejada.obdatarepositoryapp.utils.CommonUtilities.calculatePageOffset;

@Service
@Slf4j
@RequiredArgsConstructor
public class OBDataRepositoryService {
    private final ApplicationRepoFacade applicationRepoFacade;
    private final DrahimProfilesResourcesClientFacade drahimProfilesResourcesClientFacade;


    @Value("${page_size}")
    private Integer pageSize;

    public ListProfileAccountsResponseDto listProfileAccounts(String applicationId, String psuId, String profileId,
                                                              String financialInstitutionId, String financialInstitutionName,
                                                              String accountsLinkId, String accountId, String status,
                                                              String currency,
                                                              String accountType, String accountSubType,
                                                              OffsetDateTime fromOpeningDate,
                                                              OffsetDateTime toOpeningDate, Integer page,
                                                              String order, String xRequestId, String includeBalancesFlag, String balanceType) {
        log.trace("listProfileAccounts service called");

        // get application from db
        Application application = applicationRepoFacade.getApplicationByApplicationId(xRequestId, applicationId);
        // call Darahim backend
        ClientListAccountsResponse response = drahimProfilesResourcesClientFacade.drahimListProfileAccounts(
                application.getSponsoredTPPId(),
                xRequestId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountsLinkId,
                accountId,
                status,
                currency,
                accountType,
                accountSubType,
                fromOpeningDate,
                toOpeningDate,
                Boolean.parseBoolean(includeBalancesFlag),
                balanceType,
                order,
                psuId,
                calculatePageOffset(page),
                pageSize
        );
        BigInteger totalPages = BigInteger.valueOf((long) Math.ceil((double) response.getTotalCount() / pageSize));

        return ListProfileAccountsResponseDto.builder()
                .data(ListProfileAccountsDataDto.builder()
                        .accounts(response.getAccounts())
                        .build()
                )
                .meta(MetaDto.builder()
                        .totalPages(totalPages)
                        .pageNumber(BigInteger.valueOf(page))
                        .build())
                .build();
    }

    public ListProfileTransactionsResponseDto listProfileTransactions(String applicationId, String psuId,
                                                                      BigInteger profileId, String financialInstitutionId,
                                                                      String financialInstitutionName,
                                                                      String accountsLinkId, String accountId,
                                                                      String transactionType,
                                                                      String transactionSubType,
                                                                      String transactionFlags,
                                                                      String paymentMode, String transactionAmountType,
                                                                      String status, String transactionMutability,
                                                                      OffsetDateTime fromBookingDate,
                                                                      OffsetDateTime toBookingDate,
                                                                      BigDecimal fromAmount,
                                                                      BigDecimal toAmount,
                                                                      String currency, String merchantName,
                                                                      String cardSchemeName, String instrumentType,
                                                                      Integer page, String order, String xRequestId) {
        log.trace("listProfileTransactions service called");

        // get application from db
        Application application = applicationRepoFacade.getApplicationByApplicationId(xRequestId, applicationId);
        // call Darahim backend
        ClientListTransactionsResponse response = drahimProfilesResourcesClientFacade.drahimListProfileTransactions(
                application.getSponsoredTPPId(),
                xRequestId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountsLinkId,
                accountId,
                transactionType,
                transactionSubType,
                transactionFlags,
                paymentMode,
                transactionAmountType,
                status,
                transactionMutability,
                fromBookingDate,
                toBookingDate,
                fromAmount,
                toAmount,
                currency,
                merchantName,
                cardSchemeName,
                order,
                psuId,
                instrumentType,
                calculatePageOffset(page),
                pageSize
        );
        BigInteger totalPages = BigInteger.valueOf((long) Math.ceil((double) response.getTotalCount() / pageSize));

        return ListProfileTransactionsResponseDto.builder()
                .data(ListProfileTransactionsDataDto.builder()
                        .transactions(response.getTransactions())
                        .build()
                )
                .meta(MetaDto.builder()
                        .totalPages(totalPages)
                        .pageNumber(BigInteger.valueOf(page))
                        .build())
                .build();
    }

    public ListProfileTransactionsResponseCategorizedDto listProfileTransactionsCategorized(String applicationId, String psuId,
                                                                                 BigInteger profileId, String financialInstitutionId,
                                                                                 String financialInstitutionName,
                                                                                 String accountsLinkId, String accountId,
                                                                                 String transactionType,
                                                                                 String transactionSubType,
                                                                                 String transactionFlags,
                                                                                 String paymentMode, String transactionAmountType,
                                                                                 String status, String transactionMutability,
                                                                                 OffsetDateTime fromBookingDate,
                                                                                 OffsetDateTime toBookingDate,
                                                                                 BigDecimal fromAmount,
                                                                                 BigDecimal toAmount,
                                                                                 String currency, String merchantName,
                                                                                 String cardSchemeName, String instrumentType,
                                                                                 Integer page, String order, String xRequestId) {
        log.trace("listProfileTransactions service called");

        // get application from db
        Application application = applicationRepoFacade.getApplicationByApplicationId(xRequestId, applicationId);
        // call Darahim backend
        ClientListTransactionsCategorizedResponse response = drahimProfilesResourcesClientFacade.drahimListProfileTransactionsCategorized(
                application.getSponsoredTPPId(),
                xRequestId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountsLinkId,
                accountId,
                transactionType,
                transactionSubType,
                transactionFlags,
                paymentMode,
                transactionAmountType,
                status,
                transactionMutability,
                fromBookingDate,
                toBookingDate,
                fromAmount,
                toAmount,
                currency,
                merchantName,
                cardSchemeName,
                order,
                psuId,
                instrumentType,
                calculatePageOffset(page),
                pageSize
        );
        BigInteger totalPages = BigInteger.valueOf((long) Math.ceil((double) response.getTotalCount() / pageSize));

        return ListProfileTransactionsResponseCategorizedDto.builder()
                .data(ListProfileTransactionsDataCategorizedDto.builder()
                        .transactions(response.getTransactions())
                        .build()
                )
                .meta(MetaDto.builder()
                        .totalPages(totalPages)
                        .pageNumber(BigInteger.valueOf(page))
                        .build())
                .build();
    }

    public ListProfileBalancesResponseDto listProfileBalances(String applicationId, String psuId, BigInteger profileId,
                                                              String financialInstitutionId, String financialInstitutionName,
                                                              String accountsLinkId, String accountId, String currency, Integer page,
                                                              String balanceType, String balanceAmountType, BigDecimal fromAmount,
                                                              BigDecimal toAmount, String xRequestId) {

        log.trace("listProfileBalances service called");

        // get application from db
        Application application = applicationRepoFacade.getApplicationByApplicationId(xRequestId, applicationId);
        // call Darahim backend
        ClientListAccountsBalancesResponse response = drahimProfilesResourcesClientFacade.drahimListProfileBalances(
                application.getSponsoredTPPId(),
                xRequestId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountId,
                accountsLinkId,
                balanceType,
                currency,
                fromAmount,
                toAmount,
                psuId,
                balanceAmountType,
                pageSize,
                calculatePageOffset(page)
        );
        BigInteger totalPages = BigInteger.valueOf((long) Math.ceil((double) response.getTotalCount() / pageSize));

        return ListProfileBalancesResponseDto.builder()
                .data(ListProfileBalancesDataDto.builder()
                        .balances(response.getBalances())
                        .build()
                )
                .meta(MetaDto.builder()
                        .totalPages(totalPages)
                        .pageNumber(BigInteger.valueOf(page))
                        .build())
                .build();

    }


    public ListProfileBeneficiariesResponseDto listProfileBeneficiaries(String applicationId, String psuId, BigInteger profileId,
                                                                        String financialInstitutionId, String financialInstitutionName,
                                                                        String accountsLinkId, String accountId,
                                                                        String beneficiaryType, String beneficiaryName,
                                                                        String beneficiaryShortName, String beneficiaryBankName,
                                                                        Integer page, String xRequestId) {
        log.trace("listProfileTransactions service called");

        // get application from db
        Application application = applicationRepoFacade.getApplicationByApplicationId(xRequestId, applicationId);
        // call Darahim backend
        ClientListBeneficiariesResponse response = drahimProfilesResourcesClientFacade.drahimListProfileBeneficiaries(
                application.getSponsoredTPPId(),
                xRequestId,
                psuId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountsLinkId,
                accountId,
                beneficiaryType,
                beneficiaryName,
                beneficiaryShortName,
                beneficiaryBankName,
                calculatePageOffset(page),
                pageSize
        );
        BigInteger totalPages = BigInteger.valueOf((long) Math.ceil((double) response.getTotalCount() / pageSize));

        return ListProfileBeneficiariesResponseDto.builder()
                .data(ListProfileBeneficiariesDataDto.builder()
                        .beneficiaries(response.getBeneficiaries())
                        .build()
                )
                .meta(MetaDto.builder()
                        .totalPages(totalPages)
                        .pageNumber(BigInteger.valueOf(page))
                        .build())
                .build();
    }
}
