package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum TransactionStatusEnums {
    BOOKED("KSAOB.Booked"),
    PENDING("KSAOB.Pending"),
    REJECTED("KSAOB.Rejected");

    private final String value;

    TransactionStatusEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static TransactionStatusEnums fromValue(String text) {
        for (TransactionStatusEnums b : TransactionStatusEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
