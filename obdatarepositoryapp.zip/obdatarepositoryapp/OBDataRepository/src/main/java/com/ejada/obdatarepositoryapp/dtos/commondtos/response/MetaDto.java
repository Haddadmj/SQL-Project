package com.ejada.obdatarepositoryapp.dtos.commondtos.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigInteger;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class MetaDto {
    @JsonProperty("PageNumber")
    private BigInteger pageNumber;

    @JsonProperty("TotalPages")
    private BigInteger totalPages;
}
