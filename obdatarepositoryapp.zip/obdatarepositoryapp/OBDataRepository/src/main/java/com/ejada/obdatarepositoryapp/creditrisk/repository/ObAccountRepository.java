package com.ejada.obdatarepositoryapp.creditrisk.repository;

import com.ejada.obdatarepositoryapp.creditrisk.domain.ObAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Read-only repository for Open Banking accounts.
 */
@Repository
public interface ObAccountRepository extends JpaRepository<ObAccount, String> {

    /**
     * Find account by user ID and integrated ID (Open Banking account ID).
     */
    Optional<ObAccount> findByUserIdAndIntegratedId(String userId, String integratedId);

    /**
     * Find all accounts for a specific user.
     */
    List<ObAccount> findByUserId(String userId);

    /**
     * Find account by integrated ID (Open Banking account ID).
     */
    Optional<ObAccount> findByIntegratedId(String integratedId);

    /**
     * Find connected accounts for a user.
     */
    List<ObAccount> findByUserIdAndConnectionStatus(String userId, String connectionStatus);

    /**
     * Find account by user ID, sponsored TPP ID (consent/accountLinkId), and integrated ID.
     */
    @Query("SELECT a FROM ObAccount a WHERE a.userId = :userId AND a.sponsoredTppId = :sponsoredTppId AND a.integratedId = :integratedId")
    Optional<ObAccount> findByUserIdAndSponsoredTppIdAndIntegratedId(
            @Param("userId") String userId,
            @Param("sponsoredTppId") String sponsoredTppId,
            @Param("integratedId") String integratedId);
}
