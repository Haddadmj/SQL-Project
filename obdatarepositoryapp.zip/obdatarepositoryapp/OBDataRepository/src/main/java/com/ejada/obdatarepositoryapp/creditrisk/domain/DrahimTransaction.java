package com.ejada.obdatarepositoryapp.creditrisk.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.time.Instant;

/**
 * Read-only entity mapping to drahim_transactions table in Open Banking database.
 * Contains processed transaction data with categorization and filtering flags.
 * Use is_ignored_in_budget to filter out duplicates, failed, or same-account transfers.
 */
@Entity
@Table(name = "drahim_transactions")
@Immutable
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DrahimTransaction {

    @Id
    @Column(name = "id", nullable = false, length = 40)
    private String id;

    @Column(name = "user_id", nullable = false, length = 40)
    private String userId;

    @Column(name = "user_merchant_id", length = 40)
    private String userMerchantId;

    @Column(name = "user_display_name", length = 150)
    private String userDisplayName;

    @Column(name = "user_category_id", length = 40)
    private String userCategoryId;

    @Column(name = "sub_category_id", length = 40)
    private String subCategoryId;

    @Column(name = "is_ignored_in_report", nullable = false)
    private Boolean isIgnoredInReport;

    @Column(name = "is_ignored_in_budget", nullable = false)
    private Boolean isIgnoredInBudget;

    @Column(name = "note", length = 1000)
    private String note;

    @Column(name = "tags", columnDefinition = "jsonb")
    private String tags;

    @Column(name = "kind", length = 40)
    private String kind;

    @Column(name = "data", columnDefinition = "jsonb")
    private String data;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @Column(name = "updated_at")
    private Instant updatedAt;

    @Column(name = "account_id", nullable = false, length = 40)
    private String accountId;

    @Column(name = "merchant_id", length = 40)
    private String merchantId;

    @Column(name = "timestamp", nullable = false)
    private Instant timestamp;

    @Column(name = "effective_category_id", length = 26)
    private String effectiveCategoryId;

    @Column(name = "sponsored_tpp_id")
    private String sponsoredTppId;

    @Column(name = "encrypted_data", nullable = false)
    private byte[] encryptedData;
}
