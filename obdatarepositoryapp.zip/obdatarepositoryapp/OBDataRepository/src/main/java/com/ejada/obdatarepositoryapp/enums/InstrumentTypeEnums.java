package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum InstrumentTypeEnums {
    APPLE_PAY("KSAOB.ApplePay"),
    MADA_PAY("KSAOB.madaPay"),
    CONTACTLESS("KSAOB.Contactless"),
    MAG_STRIPE("KSAOB.MagStripe"),
    CHIP("KSAOB.Chip"),
    OTHER("KSAOB.Other");

    private final String value;

    InstrumentTypeEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static InstrumentTypeEnums fromValue(String text) {
        for (InstrumentTypeEnums b : InstrumentTypeEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
