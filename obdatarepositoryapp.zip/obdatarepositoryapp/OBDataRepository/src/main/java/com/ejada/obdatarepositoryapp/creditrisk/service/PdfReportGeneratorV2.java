package com.ejada.obdatarepositoryapp.creditrisk.service;

import com.ejada.obdatarepositoryapp.creditrisk.dto.response.*;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CreditRatingClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Service for generating PDF credit risk reports - Version 2.
 * Creates professional 8-page PDF reports with enhanced details.
 * 
 * Page 1: Executive Summary - Customer Profile, Credit Score, Key Metrics, Recommendation
 * Page 2: Credit Score Component Breakdown - Factor scores table with skipped factors
 * Page 3: Financial Health Indicators - Metrics with industry standards, strengths/weaknesses
 * Page 4: Transaction Analysis - Income breakdown, expense categories
 * Page 5: Loan Exposure & Debt Profile - Debt summary and ratios
 * Page 6: Behavior Analysis - Detected changes and patterns
 * Page 7: Monthly Breakdown - Monthly data table
 * Page 8: Final Recommendation - Credit class reference, purpose assessment, metadata
 */
@Service
@Slf4j
public class PdfReportGeneratorV2 {

    private static final float MARGIN = 40;
    private static final float PAGE_WIDTH = PDRectangle.A4.getWidth();
    private static final float PAGE_HEIGHT = PDRectangle.A4.getHeight();
    private static final float CONTENT_WIDTH = PAGE_WIDTH - 2 * MARGIN;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MMMM d, yyyy");

    // Design colors from Figma
    private static final Color ORANGE_PRIMARY = new Color(255, 102, 0);
    private static final Color GREEN_SUCCESS = new Color(76, 175, 80);
    private static final Color GRAY_TEXT = new Color(100, 100, 100);
    private static final Color GRAY_LIGHT = new Color(245, 245, 245);
    private static final Color GRAY_BORDER = new Color(224, 224, 224);
    private static final Color RED_DANGER = new Color(244, 67, 54);
    private static final Color YELLOW_WARNING = new Color(255, 193, 7);
    private static final Color DARK_BG = new Color(51, 51, 51);

    /**
     * Sanitize text for PDF rendering - removes characters not supported by standard fonts.
     * Replaces non-ASCII characters with spaces to maintain readability.
     */
    private String sanitizeText(String text) {
        if (text == null) return "N/A";
        // Replace non-ASCII characters (like Arabic) with empty string, keep basic Latin
        return text.replaceAll("[^\\x00-\\x7F]", "").trim();
    }

    /**
     * Safely get text for PDF, with fallback and length limit.
     */
    private String safeText(String text, String fallback, int maxLength) {
        String sanitized = sanitizeText(text);
        if (sanitized.isEmpty()) sanitized = fallback;
        return sanitized.length() > maxLength ? sanitized.substring(0, maxLength) + "..." : sanitized;
    }

    public byte[] generatePdf(CreditRiskReportResponse report) throws IOException {
        try (PDDocument document = new PDDocument();
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            // Page 1: Executive Summary
            drawPage1ExecutiveSummary(document, report);
            
            // Page 2: Credit Score Component Breakdown
            drawPage2ScoreBreakdown(document, report);
            
            // Page 3: Financial Health Indicators
            drawPage3FinancialHealth(document, report);
            
            // Page 4: Transaction Analysis
            drawPage4TransactionAnalysis(document, report);
            
            // Page 5: Loan Exposure & Debt Profile
            drawPage5LoanExposure(document, report);
            
            // Page 6: Behavior Analysis
            drawPage6BehaviorAnalysis(document, report);
            
            // Page 7+: Monthly Breakdown (with pagination support)
            int monthlyPages = drawPage7MonthlyBreakdown(document, report, 7);
            
            // Final Recommendation page (page number depends on monthly breakdown pages)
            drawPage8FinalRecommendation(document, report, 6 + monthlyPages + 1);

            document.save(baos);
            return baos.toByteArray();
        }
    }

    // ==================== PAGE 1: EXECUTIVE SUMMARY ====================
    
    private void drawPage1ExecutiveSummary(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            // Header with logo and date
            y = drawPageHeader(document, cs, report, y);
            
            // Section title: EXECUTIVE SUMMARY
            y = drawSectionTitle(cs, "EXECUTIVE SUMMARY", y);
            
            // Customer Profile box with Credit Score circle
            y = drawCustomerProfileSection(cs, report, y);
            
            // Four metric boxes
            y = drawMetricBoxes(cs, report, y);
            
            // Risk Level and Recommendation bar
            y = drawRecommendationBar(cs, report, y);
            
            // Weight redistribution note if applicable
            if (report.getMetadata() != null && Boolean.TRUE.equals(report.getMetadata().getWeightsRedistributed())) {
                drawWeightRedistributionNote(cs, report, y);
            }
            
            // Footer
            drawPageFooter(cs, 1);
        }
    }

    private float drawPageHeader(PDDocument document, PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        // Load and draw Neotek logo
        try {
            ClassPathResource logoResource = new ClassPathResource("neotek-logo.png");
            try (InputStream logoStream = logoResource.getInputStream()) {
                PDImageXObject logo = PDImageXObject.createFromByteArray(document, logoStream.readAllBytes(), "neotek-logo");
                float logoHeight = 30;
                float logoWidth = logoHeight * logo.getWidth() / logo.getHeight();
                cs.drawImage(logo, MARGIN, y - logoHeight + 10, logoWidth, logoHeight);
            }
        } catch (Exception e) {
            // Fallback to text if logo cannot be loaded
            log.warn("Could not load logo image, using text fallback: {}", e.getMessage());
            cs.setNonStrokingColor(ORANGE_PRIMARY);
            cs.beginText();
            cs.setFont(fontBold, 24);
            cs.newLineAtOffset(MARGIN, y);
            cs.showText("neotek");
            cs.endText();
        }
        
        // Date on right side
        String dateStr = report.getGeneratedAt().format(DATE_FORMATTER);
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(PAGE_WIDTH - MARGIN - 120, y);
        cs.showText(dateStr);
        cs.endText();
        
        // Confidential note
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(PAGE_WIDTH - MARGIN - 150, y - 15);
        cs.showText("CONFIDENTIAL - INTERNAL USE ONLY");
        cs.endText();
        
        return y - 60;
    }

    private float drawSectionTitle(PDPageContentStream cs, String title, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        
        // Orange bar
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        cs.addRect(MARGIN, y - 5, 4, 20);
        cs.fill();
        
        // Title text
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 16);
        cs.newLineAtOffset(MARGIN + 12, y);
        cs.showText(title);
        cs.endText();
        
        return y - 40;
    }

    private float drawCustomerProfileSection(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        // Customer Profile box background - white with light border and rounded corners
        float boxHeight = 180;
        float radius = 8;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // Box border - light gray with rounded corners
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // "CUSTOMER PROFILE" header
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 9);
        cs.newLineAtOffset(MARGIN + 15, y - 25);
        cs.showText("CUSTOMER PROFILE");
        cs.endText();
        
        CustomerProfile profile = report.getCustomerProfile();
        float labelY = y - 50;
        float col1X = MARGIN + 15;
        float col2X = MARGIN + 180;
        
        // Full Name
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, labelY);
        cs.showText("FULL NAME");
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col1X, labelY - 15);
        cs.showText(profile != null ? sanitizeText(profile.getFullName()) : "N/A");
        cs.endText();
        
        // National ID (UNN for corporates)
        String nationalIdLabel = report.getCustomerType() == com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType.CORPORATE 
                ? "UNN" : "NATIONAL ID";
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col2X, labelY);
        cs.showText(nationalIdLabel);
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col2X, labelY - 15);
        cs.showText(profile != null && profile.getNationalId() != null ? profile.getNationalId() : "N/A");
        cs.endText();
        
        labelY -= 45;
        
        // Age (instead of Date of Birth)
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, labelY);
        cs.showText("AGE");
        cs.endText();
        
        String ageStr = profile != null && profile.getAge() != null ? profile.getAge() + " Yrs" : "N/A";
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col1X, labelY - 15);
        cs.showText(ageStr);
        cs.endText();
        
        // Analysis Period
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col2X, labelY);
        cs.showText("ANALYSIS PERIOD");
        cs.endText();
        
        String periodStr = "N/A";
        if (profile != null && profile.getAnalysisStartDate() != null && profile.getAnalysisEndDate() != null) {
            periodStr = profile.getAnalysisStartDate() + " - " + profile.getAnalysisEndDate();
        }
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col2X, labelY - 15);
        cs.showText(periodStr);
        cs.endText();
        
        labelY -= 45;
        
        // Total Transactions
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, labelY);
        cs.showText("TOTAL TRANSACTIONS");
        cs.endText();
        
        String txnStr = profile != null && profile.getTotalTransactions() != null 
                ? profile.getTotalTransactions() + " Verified" : "N/A";
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col1X, labelY - 15);
        cs.showText(txnStr);
        cs.endText();
        
        // Credit Score Circle (right side of box) - positioned further right and vertically centered
        drawCreditScoreCircle(cs, report, MARGIN + CONTENT_WIDTH - 90, y - 90);
        
        return y - boxHeight - 20;
    }

    private void drawCreditScoreCircle(PDPageContentStream cs, CreditRiskReportResponse report, float cx, float cy) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        float radius = 55;
        Color scoreColor = getScoreColor(report.getRatingClass());
        
        // Draw circle outline (simplified - just a colored arc representation)
        cs.setStrokingColor(scoreColor);
        cs.setLineWidth(8);
        
        // Draw arc segments to represent score progress
        int segments = 60;
        double scoreRatio = (double) report.getTotalScore() / report.getMaxPossibleScore();
        int filledSegments = (int) (segments * scoreRatio);
        
        for (int i = 0; i < segments; i++) {
            double angle1 = Math.PI * 1.5 + (2 * Math.PI * i / segments);
            double angle2 = Math.PI * 1.5 + (2 * Math.PI * (i + 1) / segments);
            
            float x1 = cx + (float) (radius * Math.cos(angle1));
            float y1 = cy + (float) (radius * Math.sin(angle1));
            float x2 = cx + (float) (radius * Math.cos(angle2));
            float y2 = cy + (float) (radius * Math.sin(angle2));
            
            if (i < filledSegments) {
                cs.setStrokingColor(scoreColor);
            } else {
                cs.setStrokingColor(GRAY_BORDER);
            }
            cs.moveTo(x1, y1);
            cs.lineTo(x2, y2);
            cs.stroke();
        }
        
        cs.setLineWidth(1);
        
        // Score number in center - properly centered vertically
        cs.setNonStrokingColor(scoreColor);
        cs.beginText();
        cs.setFont(fontBold, 38);
        String scoreStr = String.valueOf(report.getTotalScore());
        float scoreWidth = fontBold.getStringWidth(scoreStr) / 1000 * 38;
        cs.newLineAtOffset(cx - scoreWidth / 2, cy + 2);
        cs.showText(scoreStr);
        cs.endText();
        
        // "CLASS XX" below score - properly positioned
        cs.setNonStrokingColor(scoreColor);
        cs.beginText();
        cs.setFont(font, 11);
        String classStr = "CLASS " + report.getRatingClass().name();
        float classWidth = font.getStringWidth(classStr) / 1000 * 11;
        cs.newLineAtOffset(cx - classWidth / 2, cy - 18);
        cs.showText(classStr);
        cs.endText();
        
        // Rating description below circle
        cs.setNonStrokingColor(scoreColor);
        cs.beginText();
        cs.setFont(fontBold, 11);
        String ratingName = report.getRatingClassName();
        float ratingWidth = fontBold.getStringWidth(ratingName) / 1000 * 11;
        cs.newLineAtOffset(cx - ratingWidth / 2, cy - radius - 20);
        cs.showText(ratingName);
        cs.endText();
    }

    private float drawMetricBoxes(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        float boxWidth = (CONTENT_WIDTH - 30) / 4;
        float boxHeight = 80;
        float startX = MARGIN;
        
        // Box 1: Median Income
        drawMetricBox(cs, startX, y - boxHeight, boxWidth, boxHeight,
                "MEDIAN INCOME (L3M)",
                formatCurrency(metrics != null ? metrics.getMedianMonthlyIncome() : null),
                "Verifiable 100%", ORANGE_PRIMARY, font, fontBold);
        
        // Box 2: Monthly Cash Flow  
        drawMetricBox(cs, startX + boxWidth + 10, y - boxHeight, boxWidth, boxHeight,
                "MONTHLY CASH FLOW",
                formatCurrency(metrics != null ? metrics.getAverageMonthlySurplus() : null),
                "Surplus " + (metrics != null && metrics.getSurplusRatio() != null ? 
                        formatPercentage(metrics.getSurplusRatio()) : "N/A"), 
                ORANGE_PRIMARY, font, fontBold);
        
        // Box 3: Debt-to-Income
        String dtiValue = metrics != null && metrics.getDebtBurdenRatio() != null ?
                formatPercentage(metrics.getDebtBurdenRatio()) : "N/A";
        drawMetricBox(cs, startX + 2 * (boxWidth + 10), y - boxHeight, boxWidth, boxHeight,
                "DEBT-TO-INCOME",
                dtiValue,
                "Excellent", ORANGE_PRIMARY, font, fontBold);
        
        // Box 4: Current Balance
        CustomerProfile profile = report.getCustomerProfile();
        drawMetricBox(cs, startX + 3 * (boxWidth + 10), y - boxHeight, boxWidth, boxHeight,
                "CURRENT BALANCE",
                formatCurrency(profile != null ? profile.getCurrentBalance() : null),
                "Healthy Level", ORANGE_PRIMARY, font, fontBold);
        
        return y - boxHeight - 30;
    }

    private void drawMetricBox(PDPageContentStream cs, float x, float y, float width, float height,
            String label, String value, String status, Color statusColor,
            PDType1Font font, PDType1Font fontBold) throws IOException {
        
        float radius = 6;
        
        // Box background with rounded corners
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, x, y, width, height, radius);
        
        // Box border with rounded corners
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, x, y, width, height, radius);
        
        // Label
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 7);
        cs.newLineAtOffset(x + 10, y + height - 20);
        cs.showText(label);
        cs.endText();
        
        // Value
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 14);
        cs.newLineAtOffset(x + 10, y + height - 40);
        cs.showText(value);
        cs.endText();
        
        // Status indicator
        cs.setNonStrokingColor(statusColor);
        cs.addRect(x + 10, y + 12, 6, 6);
        cs.fill();
        
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(x + 20, y + 12);
        cs.showText(status);
        cs.endText();
    }

    private float drawRecommendationBar(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        float barHeight = 45;
        float radius = 8;
        
        // Dark background bar with rounded corners
        cs.setNonStrokingColor(DARK_BG);
        drawRoundedRect(cs, MARGIN, y - barHeight, CONTENT_WIDTH, barHeight, radius);
        
        // Overall Risk Level label on left
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(font, 11);
        cs.newLineAtOffset(MARGIN + 25, y - 28);
        cs.showText("OVERALL RISK LEVEL");
        cs.endText();
        
        // Risk level badge on right side with rounded corners
        Color riskColor = getRiskLevelColor(report.getRatingClass());
        String riskText = getRiskLevelText(report.getRatingClass());
        float badgeWidth = 100;
        float badgeHeight = 28;
        float badgeX = MARGIN + CONTENT_WIDTH - badgeWidth - 25;
        float badgeY = y - barHeight + (barHeight - badgeHeight) / 2;
        
        cs.setNonStrokingColor(riskColor);
        drawRoundedRect(cs, badgeX, badgeY, badgeWidth, badgeHeight, 4);
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 11);
        float textWidth = fontBold.getStringWidth(riskText) / 1000 * 11;
        cs.newLineAtOffset(badgeX + (badgeWidth - textWidth) / 2, badgeY + 8);
        cs.showText(riskText);
        cs.endText();
        
        return y - barHeight - 10;
    }
    
    private void drawWeightRedistributionNote(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        int skipped = report.getMetadata().getFactorsSkipped();
        
        // Small italic note
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN, y - 5);
        cs.showText("* " + skipped + " factor(s) unavailable - weights redistributed. See Page 2 for details.");
        cs.endText();
    }
    
    private Color getRecommendationColor(CreditRatingClass ratingClass) {
        if (ratingClass == null) return ORANGE_PRIMARY;
        switch (ratingClass) {
            case AAA:
            case AA:
            case A:
                return GREEN_SUCCESS;
            case BBB:
            case BB:
                return ORANGE_PRIMARY;
            default:
                return RED_DANGER;
        }
    }
    
    private String getRecommendationText(String approval) {
        if (approval == null) return "REVIEW REQUIRED";
        switch (approval.toUpperCase()) {
            case "APPROVE":
            case "HIGH":
                return "HIGHLY RECOMMENDED";
            case "MODERATE":
                return "MODERATE";
            case "LOW":
            case "CAUTION":
                return "CAUTION";
            case "REJECT":
                return "NOT RECOMMENDED";
            default:
                return approval.toUpperCase();
        }
    }

    private void drawPageFooter(PDPageContentStream cs, int pageNumber) throws IOException {
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN, 30);
        cs.showText("Generated by Automated Credit Scoring System");
        cs.endText();
        
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(PAGE_WIDTH - MARGIN - 40, 30);
        cs.showText("Page " + pageNumber);
        cs.endText();
    }

    // ==================== PAGE 2: CREDIT SCORE COMPONENT BREAKDOWN ====================
    
    private void drawPage2ScoreBreakdown(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "CREDIT SCORE COMPONENT BREAKDOWN", y);
            y = drawFactorScoresTable(cs, report, y);
            
            // Add weight redistribution footnote if applicable
            if (report.getMetadata() != null && Boolean.TRUE.equals(report.getMetadata().getWeightsRedistributed())) {
                y = drawWeightRedistributionFootnote(cs, report, y);
            }
            
            drawPageFooter(cs, 2);
        }
    }
    
    private float drawWeightRedistributionFootnote(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font fontItalic = new PDType1Font(Standard14Fonts.FontName.HELVETICA_OBLIQUE);
        
        y -= 15;
        
        // Info box background
        float boxHeight = 60;
        cs.setNonStrokingColor(new Color(255, 248, 240)); // Light orange background
        cs.addRect(MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight);
        cs.fill();
        
        // Border
        cs.setStrokingColor(ORANGE_PRIMARY);
        cs.setLineWidth(1);
        cs.addRect(MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight);
        cs.stroke();
        
        // Icon/indicator
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(MARGIN + 10, y - 18);
        cs.showText("NOTE: Weight Redistribution Applied");
        cs.endText();
        
        // Explanation text
        int skipped = report.getMetadata().getFactorsSkipped();
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 9);
        cs.newLineAtOffset(MARGIN + 10, y - 35);
        cs.showText(skipped + " factor(s) marked N/A due to insufficient data. Scores are proportionally scaled to 1000.");
        cs.endText();
        
        // Formula
        cs.beginText();
        cs.setFont(fontItalic, 8);
        cs.newLineAtOffset(MARGIN + 10, y - 50);
        cs.showText("Formula: Final Score = Raw Score × (1000 ÷ Available Max Points)");
        cs.endText();
        
        return y - boxHeight - 10;
    }

    private float drawFactorScoresTable(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        // Table header with rounded corners
        float[] colWidths = {180, 65, 50, 40, 60, 85};
        String[] headers = {"Component", "Raw Value", "Score", "Max", "% Contrib.", "Assessment"};
        float radius = 6;
        
        cs.setNonStrokingColor(GRAY_LIGHT);
        drawRoundedRect(cs, MARGIN, y - 25, CONTENT_WIDTH, 25, radius);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        float xPos = MARGIN + 10;
        for (int i = 0; i < headers.length; i++) {
            cs.beginText();
            cs.setFont(font, 8);
            cs.newLineAtOffset(xPos, y - 17);
            cs.showText(headers[i].toUpperCase());
            cs.endText();
            xPos += colWidths[i];
        }
        y -= 30;
        
        // Factor rows - show ALL factors including unavailable ones
        List<FactorScore> factors = report.getFactorScores();
        if (factors != null) {
            for (FactorScore factor : factors) {
                y = drawFactorTableRow(cs, factor, y, colWidths, font, fontBold);
            }
        }
        
        // Total row with light orange background - matching Figma design
        y -= 10;
        float totalRowHeight = 40;
        
        // Light peach/orange background
        Color LIGHT_PEACH = new Color(255, 237, 220);
        cs.setNonStrokingColor(LIGHT_PEACH);
        drawRoundedRect(cs, MARGIN, y - totalRowHeight, CONTENT_WIDTH, totalRowHeight, radius);
        
        // Text vertically centered in the row
        float textY = y - totalRowHeight/2 - 4;
        float totalXPos = MARGIN + 10;
        
        // Column 1: TOTAL SCORE in orange
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(totalXPos, textY);
        cs.showText("TOTAL SCORE");
        cs.endText();
        totalXPos += colWidths[0];
        
        // Skip raw value column
        totalXPos += colWidths[1];
        
        // Column 3: Score value in orange (same as TOTAL SCORE)
        cs.beginText();
        cs.setFont(fontBold, 14);
        cs.newLineAtOffset(totalXPos, textY);
        cs.showText(String.valueOf(report.getTotalScore()));
        cs.endText();
        totalXPos += colWidths[2];
        
        // Column 4: Max value in orange
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(totalXPos, textY);
        cs.showText(String.valueOf(report.getMaxPossibleScore()));
        cs.endText();
        totalXPos += colWidths[3];
        
        // Column 5: Percentage in orange
        int scorePercentage = report.getMaxPossibleScore() > 0 ? 
                (report.getTotalScore() * 100) / report.getMaxPossibleScore() : 0;
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(totalXPos, textY);
        cs.showText(scorePercentage + "%");
        cs.endText();
        totalXPos += colWidths[4];
        
        // Column 6: Class badge - solid green with white text
        float badgeWidth = 75;
        float badgeHeight = 24;
        float badgeX = totalXPos + 5;
        float badgeY = y - totalRowHeight/2 - badgeHeight/2;
        
        cs.setNonStrokingColor(GREEN_SUCCESS);
        drawRoundedRect(cs, badgeX, badgeY, badgeWidth, badgeHeight, 4);
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 9);
        String classText = "CLASS " + report.getRatingClass().name();
        float classTextWidth = fontBold.getStringWidth(classText) / 1000 * 9;
        cs.newLineAtOffset(badgeX + (badgeWidth - classTextWidth)/2, badgeY + 7);
        cs.showText(classText);
        cs.endText();
        
        return y - totalRowHeight - 15;
    }

    private float drawFactorTableRow(PDPageContentStream cs, FactorScore factor, float y, 
            float[] colWidths, PDType1Font font, PDType1Font fontBold) throws IOException {
        
        float rowHeight = 35;
        boolean isAvailable = Boolean.TRUE.equals(factor.getDataAvailable());
        
        // Light gray background for unavailable factors
        if (!isAvailable) {
            cs.setNonStrokingColor(new Color(245, 245, 245));
        } else {
            cs.setNonStrokingColor(Color.WHITE);
        }
        cs.addRect(MARGIN, y - rowHeight, CONTENT_WIDTH, rowHeight);
        cs.fill();
        
        // Bottom border
        cs.setStrokingColor(GRAY_BORDER);
        cs.moveTo(MARGIN, y - rowHeight);
        cs.lineTo(MARGIN + CONTENT_WIDTH, y - rowHeight);
        cs.stroke();
        
        float xPos = MARGIN + 10;
        float textY = y - 22;
        
        // Component name with underline (use smaller font to fit long names)
        String componentName = factor.getFactorName();
        cs.setNonStrokingColor(isAvailable ? Color.BLACK : GRAY_TEXT);
        cs.beginText();
        cs.setFont(fontBold, 8);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(componentName != null ? componentName : "N/A");
        cs.endText();
        
        // Orange underline (gray for unavailable)
        cs.setStrokingColor(isAvailable ? ORANGE_PRIMARY : GRAY_TEXT);
        cs.setLineWidth(2);
        cs.moveTo(xPos, textY - 5);
        cs.lineTo(xPos + 100, textY - 5);
        cs.stroke();
        cs.setLineWidth(1);
        
        xPos += colWidths[0];
        
        // Raw Value - show "N/A" for unavailable factors
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        if (isAvailable) {
            cs.showText(factor.getFormattedValue() != null ? factor.getFormattedValue() : "N/A");
        } else {
            cs.showText("N/A");
        }
        cs.endText();
        xPos += colWidths[1];
        
        // Score - show "N/A" for unavailable factors
        cs.setNonStrokingColor(isAvailable ? Color.BLACK : GRAY_TEXT);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(xPos, textY);
        if (isAvailable) {
            cs.showText(String.valueOf(factor.getScore()));
        } else {
            cs.showText("N/A");
        }
        cs.endText();
        xPos += colWidths[2];
        
        // Max
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.valueOf(factor.getMaxScore()));
        cs.endText();
        xPos += colWidths[3];
        
        // % Contribution - show "N/A" for unavailable factors
        String pctStr;
        if (isAvailable) {
            pctStr = factor.getPercentage() != null ? String.format("%.1f%%", factor.getPercentage()) : "N/A";
        } else {
            pctStr = "N/A";
        }
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(pctStr);
        cs.endText();
        xPos += colWidths[4];
        
        // Assessment badge with color based on score - rounded corners
        String label = factor.getScoreLabel() != null ? factor.getScoreLabel() : "N/A";
        Color badgeColor = getAssessmentBadgeColor(factor.getPercentage());
        Color textColor = Color.WHITE;
        
        // Draw badge background with rounded corners
        cs.setNonStrokingColor(badgeColor);
        drawRoundedRect(cs, xPos, textY - 6, 75, 20, 4);
        
        // Badge text centered
        cs.setNonStrokingColor(textColor);
        cs.beginText();
        cs.setFont(font, 9);
        float labelWidth = font.getStringWidth(label) / 1000 * 9;
        cs.newLineAtOffset(xPos + (75 - labelWidth) / 2, textY - 1);
        cs.showText(label);
        cs.endText();
        
        return y - rowHeight;
    }
    
    private Color getAssessmentBadgeColor(Double percentage) {
        if (percentage == null) return GRAY_TEXT;
        if (percentage >= 80) return GREEN_SUCCESS;       // Excellent
        if (percentage >= 60) return new Color(139, 195, 74);  // Good - light green
        if (percentage >= 40) return ORANGE_PRIMARY;      // Average
        if (percentage >= 20) return YELLOW_WARNING;      // Below Average
        return RED_DANGER;                                // Poor
    }

    // ==================== PAGE 3: FINANCIAL HEALTH INDICATORS ====================
    
    private void drawPage3FinancialHealth(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "FINANCIAL HEALTH INDICATORS", y);
            y = drawHealthIndicatorsTable(cs, report, y);
            
            drawPageFooter(cs, 3);
        }
    }

    private float drawHealthIndicatorsTable(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        if (metrics == null) return y;
        
        boolean isCorporate = report.getCustomerType() == com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType.CORPORATE;
        
        // Table header
        cs.setNonStrokingColor(GRAY_LIGHT);
        cs.addRect(MARGIN, y - 25, CONTENT_WIDTH, 25);
        cs.fill();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 15, y - 17);
        cs.showText("METRIC");
        cs.endText();
        
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 250, y - 17);
        cs.showText("VALUE");
        cs.endText();
        
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 380, y - 17);
        cs.showText("INDUSTRY STANDARD");
        cs.endText();
        
        y -= 30;
        
        if (isCorporate) {
            // Corporate health indicators
            y = drawHealthRow(cs, "Revenue Stability", formatCoefficientOfVariation(metrics.getRevenueStabilityCoefficient()), "< 20% CoV", y, font, fontBold);
            y = drawHealthRow(cs, "Revenue Trend", formatPercentageShort(metrics.getRevenueTrendPercentage()), "> 0% (Growth)", y, font, fontBold);
            y = drawHealthRow(cs, "Operating Expense Ratio", formatPercentageShort(metrics.getOperatingExpenseRatio()), "< 80%", y, font, fontBold);
            y = drawHealthRow(cs, "Supplier Payment Score", formatScore(metrics.getSupplierPaymentConsistencyScore()), "> 80%", y, font, fontBold);
            y = drawHealthRow(cs, "Cash Buffer", formatCashBuffer(metrics.getCashBufferMonths()), "> 3 Months", y, font, fontBold);
            y = drawHealthRow(cs, "Corporate Cash Flow", formatCurrency(metrics.getCorporateCashFlow()), "Positive", y, font, fontBold);
            y = drawHealthRow(cs, "Payment Behavior Score", formatScore(metrics.getPaymentBehaviorScore()), "> 80%", y, font, fontBold);
            y = drawHealthRow(cs, "Unique Suppliers", metrics.getUniqueSupplierCount() != null ? metrics.getUniqueSupplierCount() + "" : "N/A", "Diversified", y, font, fontBold);
        } else {
            // Retail health indicators - values are decimals (0.35 = 35%), need to multiply by 100
            y = drawHealthRow(cs, "Debt-to-Income Ratio", formatPercentage(metrics.getDebtBurdenRatio()), "< 35%", y, font, fontBold);
            y = drawHealthRow(cs, "Savings Rate", formatPercentage(metrics.getSavingsRate()), "> 15%", y, font, fontBold);
            y = drawHealthRow(cs, "Surplus Ratio", formatPercentage(metrics.getSurplusRatio()), "> 20%", y, font, fontBold);
            y = drawHealthRow(cs, "Monthly Cash Flow", formatCurrency(metrics.getAverageMonthlySurplus()), "Positive", y, font, fontBold);
            y = drawHealthRow(cs, "Emergency Fund", formatEmergencyFund(metrics.getEmergencyFundMonths()), "> 3 Months", y, font, fontBold);
            y = drawHealthRow(cs, "Avg Balance (6M)", formatCurrency(metrics.getAverageBalance6M()), "Stable", y, font, fontBold);
            y = drawHealthRow(cs, "Negative Balance Days", metrics.getNegativeBalanceDays() != null ? metrics.getNegativeBalanceDays() + " Days" : "N/A", "0 Days", y, font, fontBold);
            y = drawHealthRow(cs, "Salary Regularity", formatSalaryRegularity(metrics), "> 90%", y, font, fontBold);
        }
        
        return y;
    }
    
    private String formatCoefficientOfVariation(BigDecimal cov) {
        if (cov == null) return "N/A";
        // Value is already a percentage (e.g., 44.59 means 44.59%)
        return String.format("%.1f%% CoV", cov);
    }
    
    private String formatScore(BigDecimal score) {
        if (score == null) return "N/A";
        // Value is already a percentage/score (e.g., 50.0 means 50%)
        return String.format("%.0f%%", score);
    }
    
    private String formatCashBuffer(BigDecimal months) {
        if (months == null) return "N/A";
        return String.format("%.1f Months", months);
    }

    private float drawHealthRow(PDPageContentStream cs, String metric, String value, String standard,
            float y, PDType1Font font, PDType1Font fontBold) throws IOException {
        
        float rowHeight = 40;
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.addRect(MARGIN, y - rowHeight, CONTENT_WIDTH, rowHeight);
        cs.fill();
        
        cs.setStrokingColor(GRAY_BORDER);
        cs.moveTo(MARGIN, y - rowHeight);
        cs.lineTo(MARGIN + CONTENT_WIDTH, y - rowHeight);
        cs.stroke();
        
        float textY = y - 25;
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(MARGIN + 15, textY);
        cs.showText(metric);
        cs.endText();
        
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(MARGIN + 250, textY);
        cs.showText(value);
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(MARGIN + 380, textY);
        cs.showText(standard);
        cs.endText();
        
        return y - rowHeight;
    }

    // ==================== PAGE 4: TRANSACTION ANALYSIS ====================
    
    private void drawPage4TransactionAnalysis(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "TRANSACTION ANALYSIS", y);
            y = drawIncomeBreakdown(cs, report, y);
            y = drawExpenseCategories(cs, report, y);
            
            drawPageFooter(cs, 4);
        }
    }

    private float drawIncomeBreakdown(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        
        // Box with border for Income Breakdown - rounded corners
        float boxHeight = 120;
        float radius = 8;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // Section header inside box
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(MARGIN + 15, y - 20);
        cs.showText("INCOME BREAKDOWN");
        cs.endText();
        
        // Table header row
        float tableY = y - 45;
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 15, tableY);
        cs.showText("Source");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 180, tableY);
        cs.showText("Count");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 260, tableY);
        cs.showText("Amount (SAR)");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 400, tableY);
        cs.showText("Verifiable");
        cs.endText();
        
        // Get actual salary data from metrics
        int salaryCount = metrics != null && metrics.getSalaryOccurrences() != null ? metrics.getSalaryOccurrences() : 0;
        BigDecimal salaryTotal = metrics != null && metrics.getAverageSalaryAmount() != null && salaryCount > 0 ?
                metrics.getAverageSalaryAmount().multiply(BigDecimal.valueOf(salaryCount)) : BigDecimal.ZERO;
        boolean hasSalary = salaryCount >= 3;
        
        // Get other income (total income minus salary) - use averageMonthlyIncome * months as proxy
        BigDecimal totalIncome = metrics != null && metrics.getAverageMonthlyIncome() != null ? 
                metrics.getAverageMonthlyIncome().multiply(BigDecimal.valueOf(Math.max(1, salaryCount))) : BigDecimal.ZERO;
        BigDecimal otherIncome = totalIncome.subtract(salaryTotal).max(BigDecimal.ZERO);
        // Use actual credit transaction count (income transactions) instead of total transactions
        int creditTxCount = metrics != null && metrics.getCreditTransactionCount() != null ?
                metrics.getCreditTransactionCount() : 0;
        int otherIncomeCount = Math.max(0, creditTxCount - salaryCount);
        
        float dataY = y - 65;
        
        // Salary row (only show if salary data exists)
        if (salaryCount > 0) {
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(fontBold, 10);
            cs.newLineAtOffset(MARGIN + 15, dataY);
            cs.showText("Salary Deposits");
            cs.endText();
            
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(MARGIN + 180, dataY);
            cs.showText(String.valueOf(salaryCount));
            cs.endText();
            
            cs.beginText();
            cs.newLineAtOffset(MARGIN + 260, dataY);
            cs.showText(String.format("%,.0f", salaryTotal));
            cs.endText();
            
            cs.setNonStrokingColor(hasSalary ? GREEN_SUCCESS : YELLOW_WARNING);
            cs.beginText();
            cs.setFont(fontBold, 10);
            cs.newLineAtOffset(MARGIN + 400, dataY);
            cs.showText(hasSalary ? "Yes" : "Insufficient");
            cs.endText();
            
            dataY -= 20;
        }
        
        // Other Income row
        if (otherIncome.compareTo(BigDecimal.ZERO) > 0) {
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(fontBold, 10);
            cs.newLineAtOffset(MARGIN + 15, dataY);
            cs.showText("Other Income");
            cs.endText();
            
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(MARGIN + 180, dataY);
            cs.showText(String.valueOf(otherIncomeCount));
            cs.endText();
            
            cs.beginText();
            cs.newLineAtOffset(MARGIN + 260, dataY);
            cs.showText(String.format("%,.0f", otherIncome));
            cs.endText();
            
            cs.setNonStrokingColor(ORANGE_PRIMARY);
            cs.beginText();
            cs.setFont(fontBold, 10);
            cs.newLineAtOffset(MARGIN + 400, dataY);
            cs.showText("Partial");
            cs.endText();
            
            dataY -= 20;
        }
        
        // No income data message
        if (salaryCount == 0 && otherIncome.compareTo(BigDecimal.ZERO) == 0) {
            cs.setNonStrokingColor(GRAY_TEXT);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(MARGIN + 15, dataY);
            cs.showText("No income transactions identified");
            cs.endText();
        }
        
        // Calculate verifiable income ratio - only for retail customers
        boolean isCorporate = report.getCustomerType() == com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType.CORPORATE;
        
        if (!isCorporate) {
            BigDecimal verifiableRatio = BigDecimal.ZERO;
            if (totalIncome.compareTo(BigDecimal.ZERO) > 0 && hasSalary) {
                verifiableRatio = salaryTotal.divide(totalIncome, 4, java.math.RoundingMode.HALF_UP)
                        .multiply(BigDecimal.valueOf(100));
            }
            
            // Verifiable Income Ratio banner - light orange background with rounded corners
            float bannerHeight = 40;
            float bannerY = y - boxHeight - bannerHeight - 10;
            float bannerRadius = 8;
            
            // Light orange background
            cs.setNonStrokingColor(new Color(255, 237, 213));  // Light peach/orange
            drawRoundedRect(cs, MARGIN, bannerY, CONTENT_WIDTH, bannerHeight, bannerRadius);
            
            // Orange text centered
            cs.setNonStrokingColor(ORANGE_PRIMARY);
            cs.beginText();
            cs.setFont(fontBold, 12);
            String ratioText = hasSalary ? String.format("VERIFIABLE INCOME RATIO: %.0f%%", verifiableRatio) : "VERIFIABLE INCOME RATIO: N/A";
            float textWidth = fontBold.getStringWidth(ratioText) / 1000 * 12;
            cs.newLineAtOffset(MARGIN + (CONTENT_WIDTH - textWidth) / 2, bannerY + 14);
            cs.showText(ratioText);
            cs.endText();
            
            return bannerY - 15;
        }
        
        return y - boxHeight - 15;
    }

    private float drawExpenseCategories(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        
        // Box with border for Expense Categories - rounded corners
        float boxHeight = 180;
        float radius = 8;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // Section header inside box
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(MARGIN + 15, y - 20);
        cs.showText("EXPENSE CATEGORIES");
        cs.endText();
        
        // Get expense categories from metrics (calculated from transaction types)
        List<FinancialMetrics.ExpenseCategory> expenseCategories = metrics != null ? 
                metrics.getExpenseCategories() : null;
        
        // If no expense data, show message
        if (expenseCategories == null || expenseCategories.isEmpty()) {
            cs.setNonStrokingColor(GRAY_TEXT);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(MARGIN + 15, y - 50);
            cs.showText("No expense data available");
            cs.endText();
            return y - boxHeight - 20;
        }
        
        Color[] categoryColors = {
            new Color(255, 152, 0),    // Orange
            new Color(255, 183, 77),   // Light orange
            new Color(255, 204, 128),  // Lighter orange
            new Color(255, 224, 178),  // Very light orange
            new Color(255, 245, 224)   // Cream
        };
        
        // Draw donut chart on the left side
        float chartCenterX = MARGIN + 100;
        float chartCenterY = y - 100;
        float outerRadius = 60;
        float innerRadius = 35;
        
        // Draw donut segments
        double startAngle = -90; // Start from top
        for (int i = 0; i < expenseCategories.size(); i++) {
            FinancialMetrics.ExpenseCategory cat = expenseCategories.get(i);
            double pct = cat.getPercentage() != null ? cat.getPercentage().doubleValue() / 100.0 : 0;
            double sweepAngle = pct * 360;
            
            cs.setNonStrokingColor(categoryColors[i % categoryColors.length]);
            drawDonutSegment(cs, chartCenterX, chartCenterY, outerRadius, innerRadius, startAngle, sweepAngle);
            startAngle += sweepAngle;
        }
        
        // Draw inner circle (white) to complete donut
        cs.setNonStrokingColor(Color.WHITE);
        drawFilledCircle(cs, chartCenterX, chartCenterY, innerRadius);
        
        // Category legend table on the right
        float tableX = MARGIN + 220;
        float tableY = y - 45;
        
        // Table header
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(tableX + 20, tableY);
        cs.showText("Category");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(tableX + 150, tableY);
        cs.showText("Amount");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(tableX + 220, tableY);
        cs.showText("%");
        cs.endText();
        
        tableY -= 20;
        
        for (int i = 0; i < expenseCategories.size(); i++) {
            FinancialMetrics.ExpenseCategory cat = expenseCategories.get(i);
            String name = cat.getCategory();
            BigDecimal amount = cat.getAmount() != null ? cat.getAmount() : BigDecimal.ZERO;
            BigDecimal pct = cat.getPercentage() != null ? cat.getPercentage() : BigDecimal.ZERO;
            
            // Color indicator
            cs.setNonStrokingColor(categoryColors[i % categoryColors.length]);
            cs.addRect(tableX, tableY - 3, 10, 10);
            cs.fill();
            
            // Category name
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(tableX + 20, tableY);
            cs.showText(name);
            cs.endText();
            
            // Amount
            cs.beginText();
            cs.newLineAtOffset(tableX + 150, tableY);
            cs.showText(String.format("%,.0f", amount));
            cs.endText();
            
            // Percentage
            cs.beginText();
            cs.newLineAtOffset(tableX + 220, tableY);
            cs.showText(String.format("%.0f%%", pct));
            cs.endText();
            
            tableY -= 22;
        }
        
        return y - boxHeight - 20;
    }
    
    private void drawDonutSegment(PDPageContentStream cs, float cx, float cy, float outerR, float innerR, 
            double startAngle, double sweepAngle) throws IOException {
        if (sweepAngle <= 0) return;
        
        // Draw outer arc segments
        int segments = Math.max(1, (int) (sweepAngle / 5));
        double angleStep = sweepAngle / segments;
        
        for (int i = 0; i < segments; i++) {
            double a1 = Math.toRadians(startAngle + i * angleStep);
            double a2 = Math.toRadians(startAngle + (i + 1) * angleStep);
            
            float x1 = cx + (float) (outerR * Math.cos(a1));
            float y1 = cy + (float) (outerR * Math.sin(a1));
            float x2 = cx + (float) (outerR * Math.cos(a2));
            float y2 = cy + (float) (outerR * Math.sin(a2));
            float x3 = cx + (float) (innerR * Math.cos(a2));
            float y3 = cy + (float) (innerR * Math.sin(a2));
            float x4 = cx + (float) (innerR * Math.cos(a1));
            float y4 = cy + (float) (innerR * Math.sin(a1));
            
            // Draw quad
            cs.moveTo(x1, y1);
            cs.lineTo(x2, y2);
            cs.lineTo(x3, y3);
            cs.lineTo(x4, y4);
            cs.closePath();
            cs.fill();
        }
    }
    
    private void drawFilledCircle(PDPageContentStream cs, float cx, float cy, float radius) throws IOException {
        int segments = 36;
        cs.moveTo(cx + radius, cy);
        for (int i = 1; i <= segments; i++) {
            double angle = 2 * Math.PI * i / segments;
            float x = cx + (float) (radius * Math.cos(angle));
            float y = cy + (float) (radius * Math.sin(angle));
            cs.lineTo(x, y);
        }
        cs.closePath();
        cs.fill();
    }

    // ==================== PAGE 5: LOAN EXPOSURE & DEBT PROFILE ====================
    
    private void drawPage5LoanExposure(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "LOAN EXPOSURE & DEBT PROFILE", y);
            y = drawLoanSummary(cs, report, y);
            y = drawDebtDetailsSection(cs, report, y);
            
            drawPageFooter(cs, 5);
        }
    }
    
    private float drawDebtDetailsSection(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        
        // Debt Details header
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(MARGIN, y);
        cs.showText("DEBT ANALYSIS DETAILS");
        cs.endText();
        y -= 25;
        
        // Debt metrics table
        float boxHeight = 180;
        float radius = 8;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        float rowY = y - 25;
        float labelX = MARGIN + 15;
        float valueX = MARGIN + 200;
        float statusX = MARGIN + 350;
        
        // Header row
        cs.setNonStrokingColor(GRAY_LIGHT);
        cs.addRect(MARGIN + 5, rowY - 5, CONTENT_WIDTH - 10, 20);
        cs.fill();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(labelX, rowY);
        cs.showText("METRIC");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(valueX, rowY);
        cs.showText("VALUE");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(statusX, rowY);
        cs.showText("STATUS");
        cs.endText();
        
        rowY -= 30;
        
        // Monthly Debt Payment
        BigDecimal monthlyDebt = metrics != null ? metrics.getLastMonthDebtPayment() : null;
        drawDebtMetricRow(cs, "Monthly Debt Payment", formatCurrency(monthlyDebt), 
                getDebtStatus(monthlyDebt, metrics), labelX, valueX, statusX, rowY, font, fontBold);
        rowY -= 30;
        
        // Total Debt Payments (loans + mortgages)
        BigDecimal totalDebt = metrics != null ? metrics.getTotalDebtPayments() : null;
        drawDebtMetricRow(cs, "Total Debt Payments (Period)", formatCurrency(totalDebt), 
                "Tracked", labelX, valueX, statusX, rowY, font, fontBold);
        rowY -= 30;
        
        // Debt Burden Ratio
        BigDecimal dbr = metrics != null ? metrics.getDebtBurdenRatio() : null;
        String dbrStatus = dbr != null && dbr.compareTo(new BigDecimal("0.35")) <= 0 ? "Healthy" : "High";
        drawDebtMetricRow(cs, "Debt Burden Ratio (DBR)", formatPercentage(dbr), 
                dbrStatus, labelX, valueX, statusX, rowY, font, fontBold);
        rowY -= 30;
        
        // Months of Data (proxy for loan tracking)
        Integer monthsOfData = metrics != null ? metrics.getMonthsOfData() : null;
        String dataStatus = monthsOfData != null && monthsOfData >= 3 ? "Sufficient" : "Limited";
        drawDebtMetricRow(cs, "Data Coverage", 
                monthsOfData != null ? monthsOfData + " months" : "N/A", 
                dataStatus, labelX, valueX, statusX, rowY, font, fontBold);
        
        return y - boxHeight - 20;
    }
    
    private void drawDebtMetricRow(PDPageContentStream cs, String label, String value, String status,
            float labelX, float valueX, float statusX, float y, PDType1Font font, PDType1Font fontBold) throws IOException {
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(labelX, y);
        cs.showText(label);
        cs.endText();
        
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(valueX, y);
        cs.showText(value);
        cs.endText();
        
        Color statusColor = "Healthy".equals(status) || "Regular".equals(status) || "Tracked".equals(status) 
                ? GREEN_SUCCESS : ("High".equals(status) || "Irregular".equals(status) ? RED_DANGER : ORANGE_PRIMARY);
        cs.setNonStrokingColor(statusColor);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(statusX, y);
        cs.showText(status);
        cs.endText();
    }
    
    private String getDebtStatus(BigDecimal monthlyDebt, FinancialMetrics metrics) {
        if (monthlyDebt == null || monthlyDebt.compareTo(BigDecimal.ZERO) == 0) return "No Debt";
        if (metrics != null && metrics.getAverageMonthlyIncome() != null) {
            BigDecimal ratio = monthlyDebt.divide(metrics.getAverageMonthlyIncome(), 4, java.math.RoundingMode.HALF_UP);
            if (ratio.compareTo(new BigDecimal("0.3")) <= 0) return "Manageable";
            if (ratio.compareTo(new BigDecimal("0.5")) <= 0) return "Moderate";
            return "High";
        }
        return "Unknown";
    }

    private float drawLoanSummary(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        float boxWidth = (CONTENT_WIDTH - 20) / 2;
        float boxHeight = 80;
        float radius = 8;
        
        // Loan Summary box with rounded corners
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, boxWidth, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, boxWidth, boxHeight, radius);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 15, y - 20);
        cs.showText("LOAN SUMMARY");
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 15, y - 40);
        cs.showText("TOTAL DEBT PAYMENTS");
        cs.endText();
        
        // Use totalDebtPayments which includes both loans and mortgages
        BigDecimal totalLoan = metrics != null && metrics.getTotalDebtPayments() != null ? 
                metrics.getTotalDebtPayments() : BigDecimal.ZERO;
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 20);
        cs.newLineAtOffset(MARGIN + 15, y - 65);
        cs.showText(formatCurrency(totalLoan));
        cs.endText();
        
        // Debt Ratios box with rounded corners
        float debtBoxX = MARGIN + boxWidth + 20;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, debtBoxX, y - boxHeight, boxWidth, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        strokeRoundedRect(cs, debtBoxX, y - boxHeight, boxWidth, boxHeight, radius);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(debtBoxX + 15, y - 20);
        cs.showText("DEBT RATIOS");
        cs.endText();
        
        // DBR (Debt Burden Ratio) - only show if we have debt data
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(debtBoxX + 15, y - 50);
        cs.showText("DBR");
        cs.endText();
        
        BigDecimal dtiValue = metrics != null ? metrics.getDebtBurdenRatio() : null;
        String dti = dtiValue != null ? formatPercentage(dtiValue) : "N/A";
        Color dtiColor = dtiValue != null && dtiValue.compareTo(new BigDecimal("0.35")) <= 0 ? GREEN_SUCCESS : ORANGE_PRIMARY;
        cs.setNonStrokingColor(dtiColor);
        cs.beginText();
        cs.setFont(fontBold, 14);
        cs.newLineAtOffset(debtBoxX + 150, y - 50);
        cs.showText(dti);
        cs.endText();
        
        return y - boxHeight - 20;
    }

    private float drawCreditClassReference(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        // Get user's score to highlight the matching row
        int userScore = report.getTotalScore() != null ? report.getTotalScore() : 0;
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN, y);
        cs.showText("CREDIT CLASS REFERENCE");
        cs.endText();
        y -= 20;
        
        // Header row
        cs.setNonStrokingColor(GRAY_LIGHT);
        cs.addRect(MARGIN, y - 18, CONTENT_WIDTH, 18);
        cs.fill();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 7);
        cs.newLineAtOffset(MARGIN + 10, y - 12);
        cs.showText("CLASS");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 120, y - 12);
        cs.showText("SCORE RANGE");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 280, y - 12);
        cs.showText("DESCRIPTION");
        cs.endText();
        
        y -= 22;
        
        // Credit class rows with score ranges [minScore, maxScore]
        Object[][] classes = {
            {"AAA", "900-1000", "Excellent", 900, 1000},
            {"AA", "800-899", "Very Good", 800, 899},
            {"A", "700-799", "Good", 700, 799},
            {"BBB", "600-699", "Above Average", 600, 699},
            {"BB", "500-599", "Average", 500, 599},
            {"B", "400-499", "Below Average", 400, 499},
            {"CCC", "300-399", "Poor", 300, 399},
            {"CC", "200-299", "Very Poor", 200, 299},
            {"C", "100-199", "Extremely Poor", 100, 199},
            {"D", "0-99", "Default Risk", 0, 99}
        };
        
        Color[] classColors = {
            GREEN_SUCCESS, GREEN_SUCCESS, new Color(139, 195, 74),
            YELLOW_WARNING, YELLOW_WARNING,
            new Color(255, 152, 0), RED_DANGER, RED_DANGER, RED_DANGER, RED_DANGER
        };
        
        for (int i = 0; i < classes.length; i++) {
            float rowY = y - (i * 18);
            int minScore = (Integer) classes[i][3];
            int maxScore = (Integer) classes[i][4];
            boolean isUserRow = userScore >= minScore && userScore <= maxScore;
            
            // Highlight the user's row with a light background and left border
            if (isUserRow) {
                cs.setNonStrokingColor(new Color(255, 248, 225));  // Light yellow background
                cs.addRect(MARGIN, rowY - 14, CONTENT_WIDTH, 18);
                cs.fill();
                
                // Left border indicator (orange)
                cs.setNonStrokingColor(new Color(255, 152, 0));
                cs.addRect(MARGIN, rowY - 14, 3, 18);
                cs.fill();
            }
            
            // Color indicator
            cs.setNonStrokingColor(classColors[i]);
            cs.addRect(MARGIN + 10, rowY - 10, 8, 8);
            cs.fill();
            
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(fontBold, 9);
            cs.newLineAtOffset(MARGIN + 25, rowY - 8);
            cs.showText((String) classes[i][0]);
            cs.endText();
            
            cs.setNonStrokingColor(GRAY_TEXT);
            cs.beginText();
            cs.setFont(font, 8);
            cs.newLineAtOffset(MARGIN + 120, rowY - 8);
            cs.showText((String) classes[i][1]);
            cs.endText();
            
            cs.beginText();
            cs.newLineAtOffset(MARGIN + 280, rowY - 8);
            cs.showText((String) classes[i][2]);
            cs.endText();
        }
        
        return y - (classes.length * 18) - 20;
    }

    private void drawFinalRecommendationBanner(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        // Orange outlined box with white background containing Final Score and Risk Level
        float boxHeight = 90;
        float radius = 12;
        
        // White background
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // Orange border
        cs.setStrokingColor(ORANGE_PRIMARY);
        cs.setLineWidth(2);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // Final Score section - left side
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 10);
        float finalScoreLabelWidth = font.getStringWidth("FINAL SCORE") / 1000 * 10;
        cs.newLineAtOffset(MARGIN + CONTENT_WIDTH/4 - finalScoreLabelWidth/2, y - 25);
        cs.showText("FINAL SCORE");
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 36);
        String scoreText = String.valueOf(report.getTotalScore());
        float scoreWidth = fontBold.getStringWidth(scoreText) / 1000 * 36;
        cs.newLineAtOffset(MARGIN + CONTENT_WIDTH/4 - scoreWidth/2 - 20, y - 65);
        cs.showText(scoreText);
        cs.endText();
        
        // "/ 1000" suffix
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 16);
        cs.newLineAtOffset(MARGIN + CONTENT_WIDTH/4 + scoreWidth/2 - 15, y - 60);
        cs.showText("/ " + report.getMaxPossibleScore());
        cs.endText();
        
        // Risk Level section - right side
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 10);
        float riskLevelLabelWidth = font.getStringWidth("RISK LEVEL") / 1000 * 10;
        cs.newLineAtOffset(MARGIN + 3*CONTENT_WIDTH/4 - riskLevelLabelWidth/2, y - 25);
        cs.showText("RISK LEVEL");
        cs.endText();
        
        // Risk level badge with rounded corners - centered on right side
        Color riskColor = getRiskLevelColor(report.getRatingClass());
        String riskText = getRiskLevelText(report.getRatingClass());
        float badgeWidth = 110;
        float badgeHeight = 30;
        float badgeX = MARGIN + 3*CONTENT_WIDTH/4 - badgeWidth/2;
        float badgeY = y - 70;
        
        cs.setNonStrokingColor(riskColor);
        drawRoundedRect(cs, badgeX, badgeY, badgeWidth, badgeHeight, 6);
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 12);
        float riskTextWidth = fontBold.getStringWidth(riskText) / 1000 * 12;
        cs.newLineAtOffset(badgeX + (badgeWidth - riskTextWidth) / 2, badgeY + 9);
        cs.showText(riskText);
        cs.endText();
    }

    // ==================== PAGE 6: BEHAVIOR ANALYSIS ====================
    
    private void drawPage6BehaviorAnalysis(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "BEHAVIOR ANALYSIS", y);
            y = drawBehaviorSummary(cs, report, y);
            y = drawDetectedChanges(cs, report, y);
            
            drawPageFooter(cs, 6);
        }
    }
    
    private float drawBehaviorSummary(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        
        // Summary box
        float boxHeight = 100;
        float radius = 8;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // Behavior Change Status
        Boolean changeDetected = metrics != null ? metrics.getBehaviorChangeDetected() : null;
        Color statusColor = Boolean.TRUE.equals(changeDetected) ? YELLOW_WARNING : GREEN_SUCCESS;
        String statusText = Boolean.TRUE.equals(changeDetected) ? "CHANGES DETECTED" : "STABLE BEHAVIOR";
        
        // Status badge - centered horizontally and vertically within its area
        float badgeWidth = 160;
        float badgeHeight = 28;
        float badgeX = MARGIN + 15;
        float badgeY = y - boxHeight/2 - badgeHeight/2 + 10;  // Vertically centered
        
        cs.setNonStrokingColor(statusColor);
        drawRoundedRect(cs, badgeX, badgeY, badgeWidth, badgeHeight, 4);
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 11);
        float statusTextWidth = fontBold.getStringWidth(statusText) / 1000 * 11;
        cs.newLineAtOffset(badgeX + (badgeWidth - statusTextWidth) / 2, badgeY + 8);
        cs.showText(statusText);
        cs.endText();
        
        // Volatility metrics
        float col1X = MARGIN + 200;
        float col2X = MARGIN + 350;
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, y - 20);
        cs.showText("INCOME VOLATILITY");
        cs.endText();
        
        // Volatility is already stored as percentage (1.23 = 1.23%), don't multiply by 100
        BigDecimal incomeVol = metrics != null ? metrics.getIncomeVolatility() : null;
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 14);
        cs.newLineAtOffset(col1X, y - 40);
        cs.showText(incomeVol != null ? String.format("%.1f%%", incomeVol) : "N/A");
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col2X, y - 20);
        cs.showText("EXPENSE VOLATILITY");
        cs.endText();
        
        // Volatility is already stored as percentage (1.48 = 1.48%), don't multiply by 100
        BigDecimal expenseVol = metrics != null ? metrics.getExpenseVolatility() : null;
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 14);
        cs.newLineAtOffset(col2X, y - 40);
        cs.showText(expenseVol != null ? String.format("%.1f%%", expenseVol) : "N/A");
        cs.endText();
        
        // Last month changes
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, y - 60);
        cs.showText("LAST MONTH INCOME CHANGE");
        cs.endText();
        
        BigDecimal incomeChange = metrics != null ? metrics.getLastMonthIncomeChange() : null;
        Color incomeChangeColor = getChangeColor(incomeChange);
        cs.setNonStrokingColor(incomeChangeColor);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col1X, y - 78);
        cs.showText(formatChangePercent(incomeChange));
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col2X, y - 60);
        cs.showText("LAST MONTH EXPENSE CHANGE");
        cs.endText();
        
        BigDecimal expenseChange = metrics != null ? metrics.getLastMonthExpenseChange() : null;
        Color expenseChangeColor = getChangeColor(expenseChange != null ? expenseChange.negate() : null);
        cs.setNonStrokingColor(expenseChangeColor);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col2X, y - 78);
        cs.showText(formatChangePercent(expenseChange));
        cs.endText();
        
        return y - boxHeight - 20;
    }
    
    private float drawDetectedChanges(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        List<FinancialMetrics.BehaviorChange> changes = metrics != null ? metrics.getDetectedChanges() : null;
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(MARGIN, y);
        cs.showText("DETECTED BEHAVIOR CHANGES");
        cs.endText();
        y -= 25;
        
        if (changes == null || changes.isEmpty()) {
            // No changes detected box
            float boxHeight = 60;
            float radius = 8;
            cs.setNonStrokingColor(new Color(232, 245, 233)); // Light green
            drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
            
            cs.setNonStrokingColor(GREEN_SUCCESS);
            cs.beginText();
            cs.setFont(fontBold, 12);
            cs.newLineAtOffset(MARGIN + (CONTENT_WIDTH / 2) - 100, y - 35);
            cs.showText("No significant behavior changes detected");
            cs.endText();
            
            return y - boxHeight - 20;
        }
        
        // Table header
        cs.setNonStrokingColor(GRAY_LIGHT);
        cs.addRect(MARGIN, y - 20, CONTENT_WIDTH, 20);
        cs.fill();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 10, y - 14);
        cs.showText("CHANGE TYPE");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 180, y - 14);
        cs.showText("SEVERITY");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 270, y - 14);
        cs.showText("DESCRIPTION");
        cs.endText();
        
        y -= 25;
        
        // Change rows
        for (FinancialMetrics.BehaviorChange change : changes) {
            if (y < 100) break; // Prevent overflow
            
            float rowHeight = 35;
            
            // Row background
            cs.setNonStrokingColor(Color.WHITE);
            cs.addRect(MARGIN, y - rowHeight, CONTENT_WIDTH, rowHeight);
            cs.fill();
            
            cs.setStrokingColor(GRAY_BORDER);
            cs.moveTo(MARGIN, y - rowHeight);
            cs.lineTo(MARGIN + CONTENT_WIDTH, y - rowHeight);
            cs.stroke();
            
            // Change type
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(fontBold, 9);
            cs.newLineAtOffset(MARGIN + 10, y - 15);
            String changeType = change.getChangeType() != null ? change.getChangeType().replace("_", " ") : "N/A";
            if (changeType.length() > 22) changeType = changeType.substring(0, 19) + "...";
            cs.showText(changeType);
            cs.endText();
            
            // Severity badge
            Color severityColor = getSeverityColor(change.getSeverity());
            cs.setNonStrokingColor(severityColor);
            drawRoundedRect(cs, MARGIN + 180, y - 22, 60, 18, 3);
            
            cs.setNonStrokingColor(Color.WHITE);
            cs.beginText();
            cs.setFont(font, 8);
            cs.newLineAtOffset(MARGIN + 190, y - 17);
            cs.showText(change.getSeverity() != null ? change.getSeverity() : "N/A");
            cs.endText();
            
            // Description - wrap to multiple lines if needed
            String desc = sanitizeText(change.getDescription());
            cs.setNonStrokingColor(GRAY_TEXT);
            cs.setFont(font, 9);
            
            // Split description into lines of ~45 chars each
            int maxCharsPerLine = 45;
            float descX = MARGIN + 270;
            float descY = y - 15;
            int lineCount = 0;
            
            while (desc.length() > 0 && lineCount < 3) {
                String line;
                if (desc.length() <= maxCharsPerLine) {
                    line = desc;
                    desc = "";
                } else {
                    // Find last space before maxCharsPerLine
                    int breakPoint = desc.lastIndexOf(' ', maxCharsPerLine);
                    if (breakPoint <= 0) breakPoint = maxCharsPerLine;
                    line = desc.substring(0, breakPoint).trim();
                    desc = desc.substring(breakPoint).trim();
                }
                cs.beginText();
                cs.newLineAtOffset(descX, descY - (lineCount * 10));
                cs.showText(line);
                cs.endText();
                lineCount++;
            }
            
            y -= rowHeight;
        }
        
        return y - 20;
    }
    
    private Color getSeverityColor(String severity) {
        if (severity == null) return GRAY_TEXT;
        return switch (severity.toUpperCase()) {
            case "LOW" -> new Color(139, 195, 74);  // Light green
            case "MEDIUM" -> YELLOW_WARNING;
            case "HIGH" -> ORANGE_PRIMARY;
            case "CRITICAL" -> RED_DANGER;
            default -> GRAY_TEXT;
        };
    }
    
    private Color getChangeColor(BigDecimal change) {
        if (change == null) return GRAY_TEXT;
        if (change.compareTo(BigDecimal.ZERO) > 0) return GREEN_SUCCESS;
        if (change.compareTo(new BigDecimal("-0.1")) > 0) return ORANGE_PRIMARY;
        return RED_DANGER;
    }
    
    private String formatChangePercent(BigDecimal change) {
        if (change == null) return "N/A";
        // Change values are already stored as percentages (-23 = -23%), don't multiply by 100
        String sign = change.compareTo(BigDecimal.ZERO) >= 0 ? "+" : "";
        return sign + String.format("%.1f%%", change);
    }

    // ==================== PAGE 7+: MONTHLY BREAKDOWN (with pagination) ====================
    
    private int monthlyBreakdownPageCount = 0;
    
    private int drawPage7MonthlyBreakdown(PDDocument document, CreditRiskReportResponse report, int startPageNum) throws IOException {
        FinancialMetrics metrics = report.getFinancialMetrics();
        List<FinancialMetrics.MonthlyBreakdown> breakdowns = metrics != null ? metrics.getMonthlyBreakdowns() : null;
        
        if (breakdowns == null || breakdowns.isEmpty()) {
            // Single page with no data message
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
                float y = PAGE_HEIGHT - MARGIN;
                y = drawPageHeader(document, cs, report, y);
                y = drawSectionTitle(cs, "MONTHLY BREAKDOWN", y);
                
                PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
                cs.setNonStrokingColor(GRAY_TEXT);
                cs.beginText();
                cs.setFont(font, 10);
                cs.newLineAtOffset(MARGIN + 15, y - 40);
                cs.showText("No monthly breakdown data available");
                cs.endText();
                
                drawPageFooter(cs, startPageNum);
            }
            return 1;
        }
        
        // Calculate totals first
        BigDecimal totalIncome = BigDecimal.ZERO;
        BigDecimal totalExpenses = BigDecimal.ZERO;
        BigDecimal totalLoan = BigDecimal.ZERO;
        BigDecimal totalSurplus = BigDecimal.ZERO;
        for (FinancialMetrics.MonthlyBreakdown b : breakdowns) {
            totalIncome = totalIncome.add(b.getIncome() != null ? b.getIncome() : BigDecimal.ZERO);
            totalExpenses = totalExpenses.add(b.getExpenses() != null ? b.getExpenses() : BigDecimal.ZERO);
            totalLoan = totalLoan.add(b.getLoanPayment() != null ? b.getLoanPayment() : BigDecimal.ZERO);
            totalSurplus = totalSurplus.add(b.getSurplus() != null ? b.getSurplus() : BigDecimal.ZERO);
        }
        
        int currentPage = 0;
        int rowIndex = 0;
        int totalRows = breakdowns.size();
        
        while (rowIndex < totalRows) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            
            try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
                float y = PAGE_HEIGHT - MARGIN;
                y = drawPageHeader(document, cs, report, y);
                
                if (currentPage == 0) {
                    y = drawSectionTitle(cs, "MONTHLY BREAKDOWN", y);
                } else {
                    y = drawSectionTitle(cs, "MONTHLY BREAKDOWN (continued)", y);
                }
                
                // Draw table header
                y = drawMonthlyTableHeader(cs, y);
                
                // Draw rows until page is full or no more data
                while (rowIndex < totalRows && y > 120) {
                    FinancialMetrics.MonthlyBreakdown breakdown = breakdowns.get(rowIndex);
                    y = drawMonthlyTableRow(cs, breakdown, y, rowIndex);
                    rowIndex++;
                }
                
                // If this is the last page (all rows drawn), add total row
                if (rowIndex >= totalRows) {
                    y = drawMonthlyTableTotalRow(cs, totalIncome, totalExpenses, totalLoan, totalSurplus, y);
                }
                
                drawPageFooter(cs, startPageNum + currentPage);
            }
            currentPage++;
        }
        
        monthlyBreakdownPageCount = currentPage;
        return currentPage;
    }
    
    private float drawMonthlyTableHeader(PDPageContentStream cs, float y) throws IOException {
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        float[] colWidths = {80, 90, 90, 90, 90};
        String[] headers = {"Month", "Income", "Expenses", "Loan Payment", "Surplus"};
        
        cs.setNonStrokingColor(GRAY_LIGHT);
        drawRoundedRect(cs, MARGIN, y - 25, CONTENT_WIDTH, 25, 6);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        float xPos = MARGIN + 10;
        for (int i = 0; i < headers.length; i++) {
            cs.beginText();
            cs.setFont(font, 8);
            cs.newLineAtOffset(xPos, y - 17);
            cs.showText(headers[i].toUpperCase());
            cs.endText();
            xPos += colWidths[i];
        }
        return y - 30;
    }
    
    private float drawMonthlyTableRow(PDPageContentStream cs, FinancialMetrics.MonthlyBreakdown breakdown, float y, int rowIndex) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        float[] colWidths = {80, 90, 90, 90, 90};
        float rowHeight = 30;
        
        // Alternating row background
        if (rowIndex % 2 == 1) {
            cs.setNonStrokingColor(new Color(250, 250, 250));
        } else {
            cs.setNonStrokingColor(Color.WHITE);
        }
        cs.addRect(MARGIN, y - rowHeight, CONTENT_WIDTH, rowHeight);
        cs.fill();
        
        cs.setStrokingColor(GRAY_BORDER);
        cs.moveTo(MARGIN, y - rowHeight);
        cs.lineTo(MARGIN + CONTENT_WIDTH, y - rowHeight);
        cs.stroke();
        
        float xPos = MARGIN + 10;
        float textY = y - 20;
        
        // Month
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(breakdown.getMonth() != null ? breakdown.getMonth() : "N/A");
        cs.endText();
        xPos += colWidths[0];
        
        // Income
        BigDecimal income = breakdown.getIncome() != null ? breakdown.getIncome() : BigDecimal.ZERO;
        cs.setNonStrokingColor(GREEN_SUCCESS);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.format("%,.0f", income));
        cs.endText();
        xPos += colWidths[1];
        
        // Expenses
        BigDecimal expenses = breakdown.getExpenses() != null ? breakdown.getExpenses() : BigDecimal.ZERO;
        cs.setNonStrokingColor(RED_DANGER);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.format("%,.0f", expenses));
        cs.endText();
        xPos += colWidths[2];
        
        // Loan Payment
        BigDecimal loan = breakdown.getLoanPayment() != null ? breakdown.getLoanPayment() : BigDecimal.ZERO;
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.format("%,.0f", loan));
        cs.endText();
        xPos += colWidths[3];
        
        // Surplus
        BigDecimal surplus = breakdown.getSurplus() != null ? breakdown.getSurplus() : BigDecimal.ZERO;
        Color surplusColor = surplus.compareTo(BigDecimal.ZERO) >= 0 ? GREEN_SUCCESS : RED_DANGER;
        cs.setNonStrokingColor(surplusColor);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.format("%,.0f", surplus));
        cs.endText();
        
        return y - rowHeight;
    }
    
    private float drawMonthlyTableTotalRow(PDPageContentStream cs, BigDecimal totalIncome, BigDecimal totalExpenses, 
            BigDecimal totalLoan, BigDecimal totalSurplus, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        float[] colWidths = {80, 90, 90, 90, 90};
        
        y -= 5;
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        drawRoundedRect(cs, MARGIN, y - 30, CONTENT_WIDTH, 30, 6);
        
        float xPos = MARGIN + 10;
        float textY = y - 20;
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText("TOTAL");
        cs.endText();
        xPos += colWidths[0];
        
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.format("%,.0f", totalIncome));
        cs.endText();
        xPos += colWidths[1];
        
        cs.beginText();
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.format("%,.0f", totalExpenses));
        cs.endText();
        xPos += colWidths[2];
        
        cs.beginText();
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.format("%,.0f", totalLoan));
        cs.endText();
        xPos += colWidths[3];
        
        cs.beginText();
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.format("%,.0f", totalSurplus));
        cs.endText();
        
        return y - 50;
    }

    // ==================== PAGE 8: FINAL RECOMMENDATION ====================
    
    private void drawPage8FinalRecommendation(PDDocument document, CreditRiskReportResponse report, int pageNum) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "FINAL RECOMMENDATION", y);
            y = drawCreditClassReference(cs, report, y);
            y = drawPurposeAssessment(cs, report, y);
            drawFinalRecommendationBanner(cs, report, y);
            // Draw metadata LAST so it's on top (at fixed bottom position)
            drawMetadataSection(cs, report, y);
            
            drawPageFooter(cs, pageNum);
        }
    }
    
    private float drawPurposeAssessment(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        PurposeAssessment purpose = report.getPurposeAssessment();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(MARGIN, y);
        cs.showText("PURPOSE ASSESSMENT");
        cs.endText();
        y -= 25;
        
        if (purpose == null) {
            // No purpose assessment available
            float boxHeight = 40;
            cs.setNonStrokingColor(GRAY_LIGHT);
            drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, 8);
            cs.setNonStrokingColor(GRAY_TEXT);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(MARGIN + 15, y - 25);
            cs.showText("No purpose assessment available (purpose/amount not provided in request)");
            cs.endText();
            return y - boxHeight - 20;
        }
        
        float boxHeight = 140;
        float radius = 8;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        float col1X = MARGIN + 15;
        float col2X = MARGIN + 180;
        float col3X = MARGIN + 360;
        
        // Row 1: Purpose, Requested Amount, Risk Level
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, y - 18);
        cs.showText("PURPOSE");
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(col1X, y - 35);
        cs.showText(purpose.getPurposeDisplayName() != null ? purpose.getPurposeDisplayName() : "N/A");
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col2X, y - 18);
        cs.showText("REQUESTED AMOUNT");
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(col2X, y - 35);
        cs.showText(purpose.getRequestedAmount() != null ? String.format("SAR %,.0f", purpose.getRequestedAmount()) : "N/A");
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col3X, y - 18);
        cs.showText("RISK LEVEL");
        cs.endText();
        
        String riskLevel = purpose.getRiskLevel() != null ? purpose.getRiskLevel() : "N/A";
        Color riskColor = "Low".equalsIgnoreCase(riskLevel) ? GREEN_SUCCESS : 
                         ("Medium".equalsIgnoreCase(riskLevel) ? ORANGE_PRIMARY : RED_DANGER);
        cs.setNonStrokingColor(riskColor);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(col3X, y - 35);
        cs.showText(riskLevel);
        cs.endText();
        
        // Row 2: Est. Monthly Payment, DTI After Loan, Affordable
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, y - 55);
        cs.showText("EST. MONTHLY PAYMENT");
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(col1X, y - 72);
        cs.showText(purpose.getEstimatedMonthlyPayment() != null ? String.format("SAR %,.2f", purpose.getEstimatedMonthlyPayment()) : "N/A");
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col2X, y - 55);
        cs.showText("DTI AFTER LOAN");
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(col2X, y - 72);
        cs.showText(purpose.getDebtToIncomeAfterLoan() != null ? purpose.getDebtToIncomeAfterLoan() : "N/A");
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col3X, y - 55);
        cs.showText("AFFORDABLE");
        cs.endText();
        
        Boolean affordable = purpose.getIsAffordable();
        Color affColor = Boolean.TRUE.equals(affordable) ? GREEN_SUCCESS : RED_DANGER;
        cs.setNonStrokingColor(affColor);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(col3X, y - 72);
        cs.showText(affordable != null ? (affordable ? "Yes" : "No") : "N/A");
        cs.endText();
        
        // Row 3: Affordability Assessment (full width)
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, y - 95);
        cs.showText("AFFORDABILITY ASSESSMENT");
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(col1X, y - 115);
        String assessment = purpose.getAffordabilityAssessment() != null ? purpose.getAffordabilityAssessment() : "N/A";
        if (assessment.length() > 70) assessment = assessment.substring(0, 67) + "...";
        cs.showText(assessment);
        cs.endText();
        
        return y - boxHeight - 20;
    }
    
    private float drawMetadataSection(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        // Position metadata at absolute bottom of page (above footer)
        float boxHeight = 55;
        float radius = 8;
        float bottomY = MARGIN + 50; // Position above footer with spacing
        
        cs.setNonStrokingColor(GRAY_LIGHT);
        drawRoundedRect(cs, MARGIN, bottomY, CONTENT_WIDTH, boxHeight, radius);
        
        float col1X = MARGIN + 20;
        float col2X = MARGIN + 200;
        float col3X = MARGIN + 380;
        float labelY = bottomY + boxHeight - 15;
        float valueY = bottomY + boxHeight - 38;
        
        // Report Version - Label
        cs.setNonStrokingColor(new Color(80, 80, 80));
        cs.beginText();
        cs.setFont(fontBold, 8);
        cs.newLineAtOffset(col1X, labelY);
        cs.showText("REPORT VERSION");
        cs.endText();
        
        // Report Version - Value
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col1X, valueY);
        cs.showText("V2.0");
        cs.endText();
        
        // Generated At - Label
        cs.setNonStrokingColor(new Color(80, 80, 80));
        cs.beginText();
        cs.setFont(fontBold, 8);
        cs.newLineAtOffset(col2X, labelY);
        cs.showText("GENERATED AT");
        cs.endText();
        
        // Generated At - Value
        String generatedAt = report.getGeneratedAt() != null ? 
                report.getGeneratedAt().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "N/A";
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col2X, valueY);
        cs.showText(generatedAt);
        cs.endText();
        
        // Report ID - Label
        cs.setNonStrokingColor(new Color(80, 80, 80));
        cs.beginText();
        cs.setFont(fontBold, 8);
        cs.newLineAtOffset(col3X, labelY);
        cs.showText("REPORT ID");
        cs.endText();
        
        // Report ID - Value (truncate to first 8 chars)
        String reportId = report.getReportId() != null ? report.getReportId().substring(0, 8).toUpperCase() : "N/A";
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col3X, valueY);
        cs.showText(reportId);
        cs.endText();
        
        return y - 20;
    }

    // ==================== HELPER METHODS ====================
    
    /**
     * Draw a rounded rectangle (filled)
     */
    private void drawRoundedRect(PDPageContentStream cs, float x, float y, float width, float height, float radius) throws IOException {
        // Start from bottom-left corner, going clockwise
        cs.moveTo(x + radius, y);
        cs.lineTo(x + width - radius, y);
        // Bottom-right corner
        cs.curveTo(x + width - radius + radius * 0.552f, y, x + width, y + radius - radius * 0.552f, x + width, y + radius);
        cs.lineTo(x + width, y + height - radius);
        // Top-right corner
        cs.curveTo(x + width, y + height - radius + radius * 0.552f, x + width - radius + radius * 0.552f, y + height, x + width - radius, y + height);
        cs.lineTo(x + radius, y + height);
        // Top-left corner
        cs.curveTo(x + radius - radius * 0.552f, y + height, x, y + height - radius + radius * 0.552f, x, y + height - radius);
        cs.lineTo(x, y + radius);
        // Bottom-left corner
        cs.curveTo(x, y + radius - radius * 0.552f, x + radius - radius * 0.552f, y, x + radius, y);
        cs.closePath();
        cs.fill();
    }
    
    /**
     * Draw a rounded rectangle (stroked only)
     */
    private void strokeRoundedRect(PDPageContentStream cs, float x, float y, float width, float height, float radius) throws IOException {
        cs.moveTo(x + radius, y);
        cs.lineTo(x + width - radius, y);
        cs.curveTo(x + width - radius + radius * 0.552f, y, x + width, y + radius - radius * 0.552f, x + width, y + radius);
        cs.lineTo(x + width, y + height - radius);
        cs.curveTo(x + width, y + height - radius + radius * 0.552f, x + width - radius + radius * 0.552f, y + height, x + width - radius, y + height);
        cs.lineTo(x + radius, y + height);
        cs.curveTo(x + radius - radius * 0.552f, y + height, x, y + height - radius + radius * 0.552f, x, y + height - radius);
        cs.lineTo(x, y + radius);
        cs.curveTo(x, y + radius - radius * 0.552f, x + radius - radius * 0.552f, y, x + radius, y);
        cs.closePath();
        cs.stroke();
    }

    private Color getScoreColor(CreditRatingClass rating) {
        return switch (rating) {
            case AAA, AA, A -> GREEN_SUCCESS;
            case BBB, BB -> YELLOW_WARNING;
            default -> RED_DANGER;
        };
    }

    private Color getRiskLevelColor(CreditRatingClass rating) {
        return switch (rating) {
            case AAA, AA, A -> GREEN_SUCCESS;
            case BBB, BB -> YELLOW_WARNING;
            default -> RED_DANGER;
        };
    }

    private String getRiskLevelText(CreditRatingClass rating) {
        return switch (rating) {
            case AAA, AA, A -> "LOW RISK";
            case BBB, BB -> "MEDIUM RISK";
            default -> "HIGH RISK";
        };
    }

    private String formatCurrency(BigDecimal amount) {
        if (amount == null) return "N/A";
        return String.format("SAR %,.0f", amount);
    }

    private String formatPercentage(BigDecimal ratio) {
        if (ratio == null) return "N/A";
        return String.format("%.1f%%", ratio.multiply(BigDecimal.valueOf(100)));
    }

    private String formatPercentageShort(BigDecimal ratio) {
        if (ratio == null) return "N/A";
        // Value is already a percentage (e.g., 42.67 means 42.67%)
        return String.format("%.1f%%", ratio);
    }

    private String formatEmergencyFund(BigDecimal months) {
        if (months == null || months.compareTo(BigDecimal.ZERO) == 0) return "N/A";
        return String.format("%.1f Months", months);
    }

    private String formatSalaryRegularity(FinancialMetrics metrics) {
        if (metrics.getSalaryOccurrences() == null || metrics.getSalaryOccurrences() < 3) {
            return "N/A"; // Not enough salary data
        }
        if (metrics.getSalaryRegularity() == null) return "N/A";
        // salaryRegularity is stored as decimal (0.90 = 90%), so multiply by 100 for display
        return String.format("%.0f%%", metrics.getSalaryRegularity().multiply(BigDecimal.valueOf(100)));
    }
}
