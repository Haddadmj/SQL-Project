package com.ejada.obdatarepositoryapp.errors.enums;

import lombok.Getter;


@Getter
public enum ErrorCodes {
    RESPONSE_BODY_VALIDATION("E999992", Constants.RESPONSE_BODY_VALIDATION),
    RESOURCE_FETCHER_NOT_FOUND("E100001", Constants.RESOURCE_FETCHER_NOT_FOUND),
    RESOURCE_TYPE_NOT_FOUND("E100002", Constants.RESOURCE_TYPE_NOT_FOUND),
    RESOURCE_FETCHER_DOES_NOT_EXIST("E100003", Constants.RESOURCE_FETCHER_DOES_NOT_EXIST),
    REPORT_QUEUE_IS_MANDATORY("E100004", Constants.REPORT_QUEUE_IS_MANDATORY),
    RESOURCE_FETCHER_PAGE_NOT_FOUND("E100005", Constants.RESOURCE_FETCHER_PAGE_NOT_FOUND);


    private final String code;
    private final String desc;

    ErrorCodes(String code, String desc) {
            this.code = code;
            this.desc = desc;
    }

    public static class Constants {
        public static final String RESPONSE_BODY_VALIDATION = "Response Body Validation Error";
        public static final String REQUEST_ID_IS_MANDATORY = "A valid RequestID is mandatory";
        public static final String REQUEST_ID_IS_NUMERIC = "RequestID should contain only numbers";
        public static final String RESOURCE_FETCHED_ID_IS_MANDATORY = "A valid ResourceFetchedID is mandatory";
        public static final String RESOURCE_FETCHED_ID_IS_NUMERIC = "ResourceFetchedID should contain only numbers";
        public static final String APPLICATION_ID_IS_MANDATORY = "A valid ApplicationID is mandatory";
        public static final String ACCOUNTS_LINK_ID_IS_MANDATORY = "A valid AccountsLinkID is mandatory";
        public static final String PSU_ID_IS_MANDATORY = "A valid PSUID is mandatory";
        public static final String PSU_ID_IS_NUMERIC = "PSUID should contain only numbers";
        public static final String ACCOUNT_ID_IS_MANDATORY = "A valid AccountID is mandatory";
        public static final String STAGING_QUEUE_IS_MANDATORY = "A valid StagingQueue is mandatory";
        public static final String FETCH_FROM_DATE_IS_MANDATORY = "A valid FetchFromDate is mandatory";
        public static final String FETCH_TO_DATE_IS_MANDATORY = "A valid FetchToDate is mandatory";
        public static final String PAGE_NUMBER_IS_MANDATORY = "A valid PageNumber is mandatory";
        public static final String RESOURCE_TARGET_URL_IS_MANDATORY = "A valid ResourceTargetUrl is mandatory";
        public static final String ACCOUNT_ID_HAS_WRONG_SIZE = "AccountID length is not valid";
        public static final String TRANSACTIONS_LIST_IS_MANDATORY = "A valid Transaction is mandatory";
        public static final String TRANSACTION_ID_IS_MANDATORY = "A valid TransactionID is mandatory";
        public static final String TRANSACTION_ID_HAS_WRONG_SIZE = "TransactionID length is not valid";
        public static final String TRANSACTION_DATE_TIME_IS_MANDATORY = "A valid TransactionDateTime is mandatory";
        public static final String STATEMENT_REFERENCE_HAS_WRONG_SIZE = "StatementReference length is not valid";
        public static final String TRANSACTION_REFERENCE_HAS_WRONG_SIZE = "TransactionReference length is not valid";
        public static final String TRANSACTION_TYPE_IS_MANDATORY = "A valid TransactionType is mandatory";
        public static final String TRANSACTION_TYPE_HAS_INVALID_VALUE = "TransactionType value is invalid, check possible values.";
        public static final String TRANSACTION_SUB_TYPE_IS_MANDATORY = "A valid SubTransactionType is mandatory";
        public static final String TRANSACTION_SUB_TYPE_HAS_INVALID_VALUE = "SubTransactionType value is invalid, check possible values.";
        public static final String TERMINAL_ID_HAS_INVALID_VALUE = "TerminalId value is invalid";
        public static final String FLAG_HAS_INVALID_VALUE = "Flag value is invalid, check possible values.";
        public static final String PAYMENT_MODES_IS_MANDATORY = "A valid PaymentModes is mandatory";
        public static final String PAYMENT_MODES_HAS_INVALID_VALUE = "PaymentModes value is invalid, check possible values.";
        public static final String CREDIT_DEBIT_INDICATOR_IS_MANDATORY = "A valid CreditDebitIndicator is mandatory";
        public static final String CREDIT_DEBIT_INDICATOR_HAS_INVALID_VALUE = "CreditDebitIndicator value is invalid, check possible values.";
        public static final String STATUS_IS_MANDATORY = "A valid Status is mandatory";
        public static final String STATUS_HAS_INVALID_VALUE = "Status value is invalid, check possible values.";
        public static final String TRANSACTION_MUTABILITY_HAS_INVALID_VALUE = "TransactionMutability value is invalid, check possible values.";
        public static final String BOOKING_DATE_TIME_IS_MANDATORY = "A valid BookingDateTime is mandatory";
        public static final String TRANSACTION_INFORMATION_HAS_WRONG_SIZE = "TransactionInformation length is not valid";
        public static final String AMOUNT_IS_MANDATORY = "A valid Amount is mandatory";
        public static final String AMOUNT_HAS_INVALID_VALUE = "Amount value is invalid, check possible values.";
        public static final String CURRENCY_IS_MANDATORY = "A valid Currency is mandatory";
        public static final String CURRENCY_HAS_INVALID_VALUE = "Currency value is invalid, check possible values.";
        public static final String SOURCE_CURRENCY_IS_MANDATORY = "A valid SourceCurrency is mandatory";
        public static final String SOURCE_CURRENCY_HAS_INVALID_VALUE = "SourceCurrency value is invalid";
        public static final String TARGET_CURRENCY_IS_MANDATORY = "A valid TargetCurrency is mandatory";
        public static final String TARGET_CURRENCY_HAS_INVALID_VALUE = "TargetCurrency value is invalid";
        public static final String UNIT_CURRENCY_IS_MANDATORY = "A valid UnitCurrency is mandatory";
        public static final String UNIT_CURRENCY_HAS_INVALID_VALUE = "UnitCurrency value is invalid";
        public static final String EXCHANGE_RATE_IS_MANDATORY = "A valid ExchangeRate is mandatory";
        public static final String CONTRACT_IDENTIFICATION_HAS_WRONG_SIZE = "ContractIdentification length is not valid";
        public static final String INSTRUCTED_AMOUNT_IS_MANDATORY = "A valid InstructedAmount is mandatory";
        public static final String CODE_IS_MANDATORY = "A valid Code is mandatory";
        public static final String CODE_HAS_WRONG_SIZE = "Code length is not valid";
        public static final String ISSUER_HAS_WRONG_SIZE = "Issuer length is not valid";
        public static final String TYPE_IS_MANDATORY = "A valid Type is mandatory";
        public static final String TYPE_HAS_INVALID_VALUE = "Type value is invalid";
        public static final String MERCHANT_ID_HAS_INVALID_VALUE = "MerchantId value is invalid";
        public static final String MERCHANT_NAME_HAS_WRONG_SIZE = "MerchantName length is not valid";
        public static final String MERCHANT_CATEGORY_CODE_HAS_WRONG_SIZE = "MerchantCategoryCode length is not valid";
        public static final String CREDITOR_AGENT_IDENTIFICATION_TYPE_HAS_INVALID_VALUE = "IdentificationType value is invalid, check possible values.";
        public static final String CREDITOR_AGENT_IDENTIFICATION_HAS_WRONG_SIZE = "Identification length is not valid";
        public static final String CREDITOR_AGENT_NAME_HAS_WRONG_SIZE = "Name length is not valid";
        public static final String ADDRESS_TYPE_HAS_INVALID_VALUE = "AddressType value is invalid, check possible values.";
        public static final String SHORT_ADDRESS_HAS_WRONG_SIZE = "ShortAddress length is not valid";
        public static final String BUILDING_NUMBER_HAS_WRONG_SIZE = "BuildingNumber length is not valid";
        public static final String STREET_NAME_HAS_WRONG_SIZE = "StreetName length is not valid";
        public static final String SECONDARY_NUMBER_HAS_WRONG_SIZE = "SecondaryNumber length is not valid";
        public static final String DISTRICT_HAS_WRONG_SIZE = "District length is not valid";
        public static final String POSTAL_CODE_HAS_WRONG_SIZE = "PostalCode length is not valid";
        public static final String CITY_HAS_WRONG_SIZE = "City length is not valid";
        public static final String COUNTRY_HAS_INVALID_VALUE = "Country value is invalid";
        public static final String CREDITOR_ACCOUNT_IDENTIFICATION_TYPE_HAS_INVALID_VALUE = "IdentificationType value is invalid, check possible values.";
        public static final String CREDITOR_ACCOUNT_IDENTIFICATION_HAS_WRONG_SIZE = "Identification length is not valid";
        public static final String CREDITOR_ACCOUNT_NAME_HAS_WRONG_SIZE = "Name length is not valid";
        public static final String DEBTOR_AGENT_IDENTIFICATION_TYPE_HAS_INVALID_VALUE = "IdentificationType value is invalid, check possible values.";
        public static final String DEBTOR_AGENT_IDENTIFICATION_HAS_WRONG_SIZE = "Identification length is not valid";
        public static final String DEBTOR_AGENT_NAME_HAS_WRONG_SIZE = "Name length is not valid";
        public static final String DEBTOR_ACCOUNT_IDENTIFICATION_TYPE_HAS_INVALID_VALUE = "IdentificationType value is invalid, check possible values.";
        public static final String DEBTOR_ACCOUNT_IDENTIFICATION_HAS_WRONG_SIZE = "Identification length is not valid";
        public static final String DEBTOR_ACCOUNT_NAME_HAS_WRONG_SIZE = "Name length is not valid";
        public static final String CARD_INSTRUMENT_IS_MANDATORY = "A valid CardSchemeName is mandatory";
        public static final String CARD_SCHEME_NAME_HAS_INVALID_VALUE = "CardSchemeName value is invalid, check possible values.";
        public static final String INSTRUMENT_TYPE_IS_MANDATORY = "A valid InstrumentType is mandatory";
        public static final String INSTRUMENT_TYPE_HAS_INVALID_VALUE = "InstrumentType value is invalid, check possible values.";
        public static final String CARD_INSTRUMENT_NAME_HAS_WRONG_SIZE = "Name length is not valid";
        public static final String CARD_INSTRUMENT_IDENTIFICATION_HAS_WRONG_SIZE = "Identification length is not valid";
        public static final String BILL_PAYMENT_TYPE_HAS_INVALID_VALUE = "BillPaymentType value is invalid, check possible values.";
        public static final String DATA_IS_MANDATORY = "A valid Data is mandatory";
        public static final String META_IS_MANDATORY = "A valid Meta is mandatory";
        public static final String RESOURCE_TYPE_IS_MANDATORY = "A valid ResourceType is mandatory";
        public static final String REPORT_FLAG_IS_MANDATORY = "A valid ReportFlag is mandatory";
        public static final String TOTAL_PAGES_IS_MANDATORY = "A valid TotalPages is mandatory";
        public static final String RESOURCE_FETCHER_NOT_FOUND = "ResourceFetcher does not exist";
        public static final String RESOURCE_TYPE_NOT_FOUND = "ResourceType does not exist";
        public static final String RESOURCE_FETCHER_DOES_NOT_EXIST = "Requested resource fetcher does not exist";
        public static final String REQUEST_DATA_IS_MANDATORY = "A valid RequestData is mandatory";
        public static final String DIRECT_DEBITS_LIST_IS_MANDATORY = "A valid DirectDebit is mandatory";
        public static final String DIRECT_DEBIT_ID_IS_MANDATORY = "A valid directDebitId is mandatory";
        public static final String DIRECT_DEBIT_ID_HAS_WRONG_SIZE = "DirectDebitId length is not valid";
        public static final String MANDATE_IDENTIFICATION_IS_MANDATORY = "A valid MandateIdentification is mandatory";
        public static final String MANDATE_IDENTIFICATION_HAS_WRONG_SIZE = "MandateIdentification length is not valid";
        public static final String DIRECT_DEBIT_STATUS_CODE_IS_MANDATORY = "A valid DirectDebitStatusCode is mandatory";
        public static final String DIRECT_DEBIT_STATUS_CODE_HAS_INVALID_VALUE = "DirectDebitStatusCode value is invalid, check possible values.";
        public static final String DIRECT_DEBIT_NAME_IS_MANDATORY = "A valid Name is mandatory";
        public static final String DIRECT_DEBIT_NAME_HAS_WRONG_SIZE = "Name length is not valid";
        public static final String DIRECT_DEBIT_FREQUENCY_HAS_INVALID_VALUE = "Frequency value is invalid, check possible values.";
        public static final String RESOURCE_TYPE_HAS_INVALID_VALUE = "ResourceType value is invalid, check possible values.";
        public static final String ACCOUNT_BALANCE_IS_MANDATORY = "Account balances from authorization GW is not found";
        public static final String ACCOUNT_DATA_IS_MANDATORY = "Account data from authorization GW is not found";
        public static final String ACCOUNT_BENEFICIARIES_IS_MANDATORY = "Account beneficiaries from authorization GW is not found";
        public static final String REPORT_QUEUE_IS_MANDATORY = "A valid ReportQueue is mandatory";
        public static final String INVALID_TOTAL_PAGES = "Total pages must be greater than 1";
        public static final String RESOURCE_FETCHER_PAGE_NOT_FOUND = "Requested Resource Fetcher Page not found";
        public static final String FINANCIAL_INSTITUTION_ID_IS_MANDATORY = "A valid FinancialInstitutionId is mandatory";
        public static final String EVENT_CODE_IS_MANDATORY = "Event code is mandatory";
        public static final String INVALID_EVENT_CODE = "Invalid event code";

        public static final String REMOVE_DATA_FLAG_IS_MANDATORY = "RemoveDataFlag is mandatory";
    }

}
