package com.ejada.obdatarepositoryapp.clients.darahim;

import com.ejada.commons.logs.annotations.FailureQueueDescriptor;
import com.ejada.commons.utilities.ParserUtility;
import com.ejada.obdatarepositoryapp.clients.models.ListAccounts.ClientListAccountsResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListProfileBeneficiaries.ClientListBeneficiariesResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListProfileTransactions.ClientListTransactionsCategorizedResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListProfileTransactions.ClientListTransactionsResponse;
import com.ejada.obdatarepositoryapp.clients.models.ListAccountsBalances.ClientListAccountsBalancesResponse;
import com.ejada.obdatarepositoryapp.constants.FailureQueues;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.OffsetDateTime;

@Slf4j
@Component
@RequiredArgsConstructor
@FailureQueueDescriptor(destination = FailureQueues.OB_DATA_REPOSITORY_FAILURE_QUEUE)
public class DrahimProfilesResourcesClientFacade {
    @Autowired
    private DrahimProfileResourcesClient drahimListProfileAccountsLinks;

    @Value("${app.config.integration.backend.clientId}")
    private String clientId;
    @Value("${app.config.integration.backend.clientSecret}")
    private String clientSecret;
    @Value("${app.config.integration.backend.drahimClientId}")
    private String drahimClientId;
    @Value("${app.config.integration.backend.drahimClientSecret}")
    private String drahimClientSecret;

    public ClientListAccountsBalancesResponse drahimListProfileBalances(String sponsoredTPPId,
                                                                        String requestId,
                                                                        BigInteger profileId,
                                                                        String financialInstitutionId,
                                                                        String financialInstitutionName,
                                                                        String accountId,
                                                                        String accountsLinkId,
                                                                        String balanceType,
                                                                        String currency,
                                                                        BigDecimal fromAmount,
                                                                        BigDecimal toAmount,
                                                                        String psuId,
                                                                        String balanceAmountType,
                                                                        Integer limit,
                                                                        Integer offset
    ) {
        log.debug("drahimListProfileBalances client facade called with requestId: {} and profileId: {}", requestId, profileId);
        ClientListAccountsBalancesResponse response = drahimListProfileAccountsLinks.drahimListProfileBalances(
                requestId,
                clientId,
                clientSecret,
                drahimClientId,
                drahimClientSecret,
                sponsoredTPPId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountId,
                accountsLinkId,
                balanceType,
                currency,
                fromAmount,
                toAmount,
                psuId,
                balanceAmountType,
                limit,
                offset
        );
        log.debug("drahimListProfileBalances client facade responded with requestId: {} and response: {}", requestId, ParserUtility.convertObjectToJsonString(response));
        return response;
    }


    public ClientListAccountsResponse drahimListProfileAccounts(String sponsoredTPPId,
                                                                String requestId,
//                                                             String consentId,
                                                                String profileId,
                                                                String financialInstitutionId,
                                                                String financialInstitutionName,
                                                                String accountsLinkId,
                                                                String accountId,
                                                                String status,
                                                                String currency,
                                                                String accountType,
                                                                String accountSubType,
                                                                OffsetDateTime fromOpeningDate,
                                                                OffsetDateTime toOpeningDate,
                                                                boolean includeBalanceFlag,
                                                                String balanceType,
                                                                String order,
                                                                String psuId,
                                                                Integer offset,
                                                                Integer limit) {
        log.debug("drahimListAccounts client facade called with requestId: {} and profileId: {}", requestId, profileId);
        ClientListAccountsResponse response = drahimListProfileAccountsLinks.drahimListProfileAccounts(
                requestId,
                clientId,
                clientSecret,
                drahimClientId,
                drahimClientSecret,
                sponsoredTPPId,
//                consentId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountsLinkId,
                accountId,
                status,
                currency,
                accountType,
                accountSubType,
                fromOpeningDate,
                toOpeningDate,
                includeBalanceFlag,
                balanceType,
                order,
                psuId,
                offset,
                limit
        );
        log.debug("drahimListAccounts client facade responded with requestId: {} and response: {}", requestId, ParserUtility.convertObjectToJsonString(response));
        return response;
    }

    public ClientListTransactionsResponse drahimListProfileTransactions(String sponsoredTPPId,
                                                                        String requestId,
//                                                                                 String consentId,
                                                                        BigInteger profileId,
                                                                        String financialInstitutionId,
                                                                        String financialInstitutionName,
                                                                        String accountsLinkId,
                                                                        String accountId,
                                                                        String transactionType,
                                                                        String transactionSubType,
                                                                        String transactionFlags,
                                                                        String paymentMode,
                                                                        String transactionAmountType,
                                                                        String transactionStatus,
                                                                        String transactionMutability,
                                                                        OffsetDateTime fromBookingDate,
                                                                        OffsetDateTime toBookingDate,
                                                                        BigDecimal fromAmount,
                                                                        BigDecimal toAmount,
                                                                        String currency,
                                                                        String merchantName,
                                                                        String cardSchemeName,
                                                                        String order,
                                                                        String psuId,
                                                                        String instrumentType,
                                                                        Integer offset,
                                                                        Integer limit
    ) {
        log.debug("drahimListProfileTransactions client facade called with requestId: {} and profileId: {}", requestId, profileId);
        ClientListTransactionsResponse response = drahimListProfileAccountsLinks.drahimListProfileTransactions(
                requestId,
                clientId,
                clientSecret,
                drahimClientId,
                drahimClientSecret,
                sponsoredTPPId,
//                consentId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountsLinkId,
                accountId,
                transactionType,
                transactionSubType,
                transactionFlags,
                paymentMode,
                transactionAmountType,
                transactionStatus,
                transactionMutability,
                fromBookingDate,
                toBookingDate,
                fromAmount,
                toAmount,
                currency,
                merchantName,
                cardSchemeName,
                order,
                psuId,
                instrumentType,
                offset,
                limit
        );
        log.debug("drahimListProfileTransactions client facade responded with requestId: {} and response: {}", requestId, ParserUtility.convertObjectToJsonString(response));
        return response;
    }


    public ClientListBeneficiariesResponse drahimListProfileBeneficiaries(String sponsoredTPPId, String requestId,
                                                                          String psuId, BigInteger profileId,
                                                                          String financialInstitutionId, String financialInstitutionName,
                                                                          String accountsLinkId, String accountId,
                                                                          String beneficiaryType, String beneficiaryName,
                                                                          String beneficiaryShortName, String beneficiaryBankName,
                                                                          Integer offset, Integer limit
    ) {
        log.debug("drahimListProfileBeneficiaries client facade called with requestId: {} and profileId: {}", requestId, profileId);
        ClientListBeneficiariesResponse response = drahimListProfileAccountsLinks.drahimListProfileBeneficiaries(
                requestId,
                clientId,
                clientSecret,
                drahimClientId,
                drahimClientSecret,
                sponsoredTPPId,
                psuId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountsLinkId,
                accountId,
                beneficiaryType,
                beneficiaryName,
                beneficiaryShortName,
                beneficiaryBankName,
                offset,
                limit
        );
        log.debug("drahimListProfileBeneficiaries client facade responded with requestId: {} and response: {}", requestId, ParserUtility.convertObjectToJsonString(response));
        return response;
    }

    public ClientListTransactionsCategorizedResponse drahimListProfileTransactionsCategorized(String sponsoredTPPId,
                                                                                              String requestId,
//                                                                                 String consentId,
                                                                                              BigInteger profileId,
                                                                                              String financialInstitutionId,
                                                                                              String financialInstitutionName,
                                                                                              String accountsLinkId,
                                                                                              String accountId,
                                                                                              String transactionType,
                                                                                              String transactionSubType,
                                                                                              String transactionFlags,
                                                                                              String paymentMode,
                                                                                              String transactionAmountType,
                                                                                              String transactionStatus,
                                                                                              String transactionMutability,
                                                                                              OffsetDateTime fromBookingDate,
                                                                                              OffsetDateTime toBookingDate,
                                                                                              BigDecimal fromAmount,
                                                                                              BigDecimal toAmount,
                                                                                              String currency,
                                                                                              String merchantName,
                                                                                              String cardSchemeName,
                                                                                              String order,
                                                                                              String psuId,
                                                                                              String instrumentType,
                                                                                              Integer offset,
                                                                                              Integer limit
    ) {
        log.debug("drahimListProfileTransactions client facade called with requestId: {} and profileId: {}", requestId, profileId);
        ClientListTransactionsCategorizedResponse response = drahimListProfileAccountsLinks.drahimListProfileTransactionsCategorized(
                requestId,
                clientId,
                clientSecret,
                drahimClientId,
                drahimClientSecret,
                sponsoredTPPId,
//                consentId,
                profileId,
                financialInstitutionId,
                financialInstitutionName,
                accountsLinkId,
                accountId,
                transactionType,
                transactionSubType,
                transactionFlags,
                paymentMode,
                transactionAmountType,
                transactionStatus,
                transactionMutability,
                fromBookingDate,
                toBookingDate,
                fromAmount,
                toAmount,
                currency,
                merchantName,
                cardSchemeName,
                order,
                psuId,
                instrumentType,
                offset,
                limit
        );
        log.debug("drahimListProfileTransactions client facade responded with requestId: {} and response: {}", requestId, ParserUtility.convertObjectToJsonString(response));
        return response;
    }
}
