package com.ejada.obdatarepositoryapp.creditrisk.exception;

/**
 * Custom exception for Credit Risk Engine errors.
 */
public class CreditRiskException extends RuntimeException {

    private final String errorCode;
    private final String details;

    public CreditRiskException(String message) {
        super(message);
        this.errorCode = "CREDIT_RISK_ERROR";
        this.details = null;
    }

    public CreditRiskException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
        this.details = null;
    }

    public CreditRiskException(String errorCode, String message, String details) {
        super(message);
        this.errorCode = errorCode;
        this.details = details;
    }

    public CreditRiskException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "CREDIT_RISK_ERROR";
        this.details = cause != null ? cause.getMessage() : null;
    }

    public CreditRiskException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.details = cause != null ? cause.getMessage() : null;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getDetails() {
        return details;
    }
}
