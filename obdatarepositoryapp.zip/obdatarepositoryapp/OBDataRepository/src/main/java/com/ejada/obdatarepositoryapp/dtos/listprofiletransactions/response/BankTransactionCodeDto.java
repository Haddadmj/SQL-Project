package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BankTransactionCodeDto {
    @JsonProperty("Domain")
    private String domain;

    @JsonProperty("DomainCode")
    private String domainCode;

    @JsonProperty("Family")
    private String family;

    @JsonProperty("FamilyCode")
    private String familyCode;

    @JsonProperty("SubFamily")
    private String subFamily;

    @JsonProperty("SubFamilyCode")
    private String subFamilyCode;
}
