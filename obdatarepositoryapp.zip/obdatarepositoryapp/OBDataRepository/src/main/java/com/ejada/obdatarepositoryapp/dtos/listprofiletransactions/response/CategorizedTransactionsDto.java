package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CategorizedTransactionsDto {

    @JsonProperty("id")
    private String id;

    @JsonProperty("account_id")
    private String accountId;

    @JsonProperty("description")
    private String description;

    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("logo")
    private String logo;

    @JsonProperty("verified_name_ar")
    private String verifiedNameAr;

    @JsonProperty("verified_name")
    private String verifiedName;

    @JsonProperty("timestamp")
    private LocalDateTime timestamp;

    @JsonProperty("sub_category_id")
    private String subCategoryId;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("sub_category")
    private SubCategoryDto subCategory;

    @JsonProperty("merchant")
    private MerchantDto merchant;

    @JsonProperty("kind")
    private String kind;

    @JsonProperty("effective_category_id")
    private String effectiveCategoryId;

    @JsonProperty("is_debit")
    private Boolean isDebit;

    @JsonProperty("merchant_name")
    private String merchantName;

    @JsonProperty("category")
    private CategoryDto category;
}
