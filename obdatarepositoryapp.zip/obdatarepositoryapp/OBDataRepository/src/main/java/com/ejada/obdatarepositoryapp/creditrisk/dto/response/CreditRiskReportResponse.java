package com.ejada.obdatarepositoryapp.creditrisk.dto.response;

import com.ejada.obdatarepositoryapp.creditrisk.enums.CreditRatingClass;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Complete credit risk report response.
 * Contains score breakdown, financial metrics, and recommendations.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditRiskReportResponse {
    
    private String reportId;
    private LocalDateTime generatedAt;
    
    private String psuId;
    private String accountLinkId;
    private String accountId;
    @JsonIgnore
    private String sponsoredTppId;
    private CustomerType customerType;
    
    private Integer totalScore;
    private Integer maxPossibleScore;
    private CreditRatingClass ratingClass;
    private String ratingClassName;
    private String ratingDescription;
    private String approvalRecommendation;
    
    private List<FactorScore> factorScores;
    
    private FinancialMetrics financialMetrics;
    
    private CustomerProfile customerProfile;
    
    private CreditRecommendation recommendation;
    
    private PurposeAssessment purposeAssessment;
    
    private ReportMetadata metadata;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ReportMetadata {
        private Integer factorsEvaluated;
        private Integer factorsSkipped;
        private List<String> skippedFactorReasons;
        private Boolean weightsRedistributed;
        private String dataQualityNote;
    }
}
