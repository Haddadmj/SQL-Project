package com.ejada.obdatarepositoryapp.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * Constants representing the headers names used throughout the project.
 */
@NoArgsConstructor(access = AccessLevel.NONE)
public class Headers {

    public static final String X_REQUEST_ID = "x-request-id";
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String DRAHIM_CLIENT_ID = "drahim-client-id";
    public static final String DRAHIM_CLIENT_SECRET = "drahim-client-secret";

}
