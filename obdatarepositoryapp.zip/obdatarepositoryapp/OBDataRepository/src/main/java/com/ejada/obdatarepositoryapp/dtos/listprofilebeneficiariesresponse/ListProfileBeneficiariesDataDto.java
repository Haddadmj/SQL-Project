package com.ejada.obdatarepositoryapp.dtos.listprofilebeneficiariesresponse;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListProfileBeneficiariesDataDto {
    @JsonProperty("Beneficiaries")
    private List<ListProfileBeneficiariesItemDto> beneficiaries;
}
