package com.ejada.obdatarepositoryapp.repositories;

import com.ejada.commons.errors.exceptions.ErrorCodeException;
import com.ejada.commons.logs.GeneralException;
import com.ejada.obrepositoryabstractmodel.entities.Application;
import com.ejada.obrepositoryabstractmodel.errors.ErrorCodes;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class ApplicationRepoFacade {
    private final ApplicationRepo applicationRepo;

    public Application getApplicationByApplicationId(String requestId, String applicationId) {
        log.info("getApplicationByApplicationId called");
        log.debug("Retrieving User with requestId: {} and applicationId: {}", requestId, applicationId);
        try {
            return applicationRepo.findByApplicationId(applicationId).orElseThrow(() -> new ErrorCodeException(
                    ErrorCodes.APPLICATION_DOES_NOT_EXIST.getCode(), ErrorCodes.APPLICATION_DOES_NOT_EXIST.getDesc()));
        } catch (ErrorCodeException errorCodeException) {
            throw errorCodeException;
        } catch (Exception exception) {
            log.error("Error occurred while retrieving application from DB with requestId: {}", requestId);
            throw new GeneralException(exception.getMessage());
        }
    }
}
