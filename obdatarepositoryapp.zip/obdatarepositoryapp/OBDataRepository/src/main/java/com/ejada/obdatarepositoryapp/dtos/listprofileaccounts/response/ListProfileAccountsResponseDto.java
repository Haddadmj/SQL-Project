package com.ejada.obdatarepositoryapp.dtos.listprofileaccounts.response;
import com.ejada.obdatarepositoryapp.dtos.commondtos.response.MetaDto;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class ListProfileAccountsResponseDto {
    @JsonProperty("Data")
    private ListProfileAccountsDataDto data;

    @JsonProperty("Meta")
    private MetaDto meta;
}
