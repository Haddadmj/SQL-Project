package com.ejada.obdatarepositoryapp.creditrisk.service;

import com.ejada.commons.errors.exceptions.ErrorCodeException;
import com.ejada.obdatarepositoryapp.creditrisk.domain.DecryptedDrahimTransactionProjection;
import com.ejada.obdatarepositoryapp.creditrisk.domain.DecryptedTransactionProjection;
import com.ejada.obdatarepositoryapp.creditrisk.domain.ObAccount;
import com.ejada.obdatarepositoryapp.creditrisk.domain.UserConsent;
import com.ejada.obdatarepositoryapp.creditrisk.dto.TransactionData;
import com.ejada.obdatarepositoryapp.creditrisk.repository.DrahimTransactionRepository;
import com.ejada.obdatarepositoryapp.creditrisk.repository.ObAccountRepository;
import com.ejada.obdatarepositoryapp.creditrisk.repository.ObTransactionRepository;
import com.ejada.obdatarepositoryapp.creditrisk.repository.UserConsentRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service for fetching and parsing Open Banking data.
 * Handles PGP decryption and JSON parsing of transaction/account data.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class OpenBankingDataFetcher {

    private final DrahimTransactionRepository drahimTransactionRepository;
    private final ObTransactionRepository obTransactionRepository;
    private final ObAccountRepository accountRepository;
    private final UserConsentRepository userConsentRepository;
    private final ObjectMapper objectMapper;

    @Value("${openbanking.encryption.pgp-key}")
    private String pgpEncryptionKey;

    private static final List<DateTimeFormatter> DATE_FORMATTERS = Arrays.asList(
            DateTimeFormatter.ISO_DATE_TIME,
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd")
    );

    /**
     * Get account with full validation of psuId, accountLinkId, accountId, and sponsoredTppId.
     * Ensures data isolation per client.
     */
    @Transactional(readOnly = true, transactionManager = "openBankingTransactionManager")
    public Optional<ObAccount> getAccount(String psuId, String accountLinkId, String accountId, String sponsoredTppId) {
        // First validate the consent exists for this user and sponsored TPP
        Optional<UserConsent> consentOpt = userConsentRepository.findByNeotekAccountsLinkIdAndSponsoredTppId(
                Long.parseLong(accountLinkId), sponsoredTppId);

        if (consentOpt.isEmpty()) {
            log.warn("Consent not found for psuId={}, accountLinkId={}, sponsoredTppId={}",
                    psuId, accountLinkId, sponsoredTppId);
            throw new ErrorCodeException("E100001",String.format("Consent not found for AccountLinkID: %s",accountLinkId));
        }

        if (consentOpt.get().getConnectionStatus().equalsIgnoreCase("failed") || consentOpt.get().getConnectionStatus().equalsIgnoreCase("disconnected")) {
            String status = consentOpt.get().getConnectionStatus();
            log.warn("Consent status is {} for psuId={}, accountLinkId={}, sponsoredTppId={}",status,psuId,accountLinkId,sponsoredTppId);
            throw new ErrorCodeException("E100002",String.format("Consent status is %s for AccountLinkID: %s",status,accountLinkId));
        }
        
        // Ownership check: verify the account link belongs to this PSU
        if (!consentOpt.get().getUserId().equals(psuId)) {
            log.warn("Ownership check failed: accountLinkId={} does not belong to psuId={}",
                    accountLinkId, psuId);
            throw new ErrorCodeException("E100003",String.format("Ownership check failed: %s does not belong to %s",accountLinkId,psuId));

        }
        
        // Then get the account with sponsoredTppId validation
        return accountRepository.findByUserIdAndSponsoredTppIdAndIntegratedId(psuId, sponsoredTppId, accountId);
    }

    /**
     * Get user consent for validation.
     */
    @Transactional(readOnly = true, transactionManager = "openBankingTransactionManager")
    public Optional<UserConsent> getConsent(String psuId, String accountLinkId, String sponsoredTppId) {
        Optional<UserConsent> consentOpt = userConsentRepository.findByNeotekAccountsLinkIdAndSponsoredTppId(
                Long.parseLong(accountLinkId), sponsoredTppId);
        
        // Ownership check: verify the account link belongs to this PSU
        if (consentOpt.isPresent() && !consentOpt.get().getUserId().equals(psuId)) {
            log.warn("Ownership check failed: accountLinkId={} does not belong to psuId={}",
                    accountLinkId, psuId);
            return Optional.empty();
        }
        
        return consentOpt;
    }

    /**
     * Get transactions for account using drahim_transactions table with database-level decryption.
     * Filters out ignored transactions (duplicates, failed, same-account transfers).
     * Requires full validation with psuId, accountId (internal), and sponsoredTppId.
     */
    @Transactional(readOnly = true, transactionManager = "openBankingTransactionManager")
    public List<TransactionData> getTransactionsForAccount(String psuId, String accountId, String sponsoredTppId) {
        List<DecryptedTransactionProjection> transactions = obTransactionRepository
                .findDecryptedByUserIdAndAccountId(psuId, accountId, pgpEncryptionKey);

        return transactions.stream()
                .map(this::parseDecryptedTransaction)
                .filter(Objects::nonNull)
                .filter(t -> t.getTransactionDateTime() != null)
                .sorted(Comparator.comparing(TransactionData::getTransactionDateTime).reversed())
                .collect(Collectors.toList());
    }

    /**
     * Parse decrypted DrahimTransaction projection to TransactionData DTO.
     * Data is already decrypted at database level using pgp_sym_decrypt().
     */
    private TransactionData parseDecryptedDrahimTransaction(DecryptedDrahimTransactionProjection transaction) {
        try {
            String decryptedJson = transaction.getDecryptedData();
            if (decryptedJson == null || decryptedJson.isBlank()) {
                return null;
            }

            JsonNode root = objectMapper.readTree(decryptedJson);
            
            // Get timestamp from decrypted JSON (BookingDateTime/ValueDateTime), fallback to DB timestamp
            LocalDateTime txDateTime = parseTransactionDateTime(root);
            if (txDateTime == null && transaction.getTimestamp() != null) {
                txDateTime = LocalDateTime.ofInstant(transaction.getTimestamp(), ZoneId.systemDefault());
            }
            
            return TransactionData.builder()
                    .transactionId(transaction.getId())
                    .accountId(transaction.getAccountId())
                    .transactionDateTime(txDateTime)
                    .amount(parseAmount(root))
                    .currency(getTextValue(root, "currency"))
                    .creditDebitIndicator(getTextValue(root, "creditDebitIndicator"))
                    .status("Booked") // drahim_transactions are processed/booked
                    .transactionType(transaction.getKind())
                    .category(transaction.getEffectiveCategoryId())
                    .merchantName(extractMerchantName(root, null))
                    .description(getTextValue(root, "description"))
                    .reference(getTextValue(root, "reference"))
                    .balanceAfter(parseBalanceAfter(root))
                    .build();
        } catch (Exception e) {
            log.warn("Failed to parse decrypted drahim transaction {}: {}", transaction.getId(), e.getMessage());
            return null;
        }
    }

    private TransactionData parseDecryptedTransaction(DecryptedTransactionProjection transaction) {
        try {
            String decryptedJson = transaction.getDecryptedData();
            if (decryptedJson == null || decryptedJson.isBlank()) {
                return null;
            }

            JsonNode root = objectMapper.readTree(decryptedJson);

            // Get timestamp from decrypted JSON (BookingDateTime/ValueDateTime), fallback to DB timestamp
            LocalDateTime txDateTime = parseTransactionDateTime(root);
            if (txDateTime == null && transaction.getCreatedAt() != null) {
                txDateTime = LocalDateTime.ofInstant(transaction.getCreatedAt(), ZoneId.systemDefault());
            }

            return TransactionData.builder()
                    .transactionId(transaction.getId())
                    .accountId(transaction.getAccountId())
                    .transactionDateTime(txDateTime)
                    .amount(parseAmount(root))
                    .currency(parseCurrency(root))
                    .creditDebitIndicator(getTextValue(root, "CreditDebitIndicator"))
                    .status("Booked") // raw_transactions are processed/booked
                    .transactionType(getTextValue(root, "TransactionType"))
                    .merchantName(transaction.getExtractedMerchantName())
                    .description(getTextValue(root, "TransactionInformation"))
                    .reference(getTextValue(root, "TransactionReference"))
                    .balanceAfter(parseBalanceAfter(root))
                    .build();
        } catch (Exception e) {
            log.warn("Failed to parse decrypted drahim transaction {}: {}", transaction.getId(), e.getMessage());
            return null;
        }
    }


    private LocalDateTime parseTransactionDateTime(JsonNode root) {
        String dateStr = getTextValue(root, "BookingDateTime");
        if (dateStr == null) {
            dateStr = getTextValue(root, "ValueDateTime");
        }
        if (dateStr == null) {
            return null;
        }

        for (DateTimeFormatter formatter : DATE_FORMATTERS) {
            try {
                return LocalDateTime.parse(dateStr, formatter);
            } catch (Exception ignored) {
            }
        }

        try {
            Instant instant = Instant.parse(dateStr);
            return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
        } catch (Exception e) {
            log.warn("Could not parse date: {}", dateStr);
            return null;
        }
    }

    private BigDecimal parseAmount(JsonNode root) {
        JsonNode amountNode = root.path("Amount");
        if (amountNode.isMissingNode()) {
            return BigDecimal.ZERO;
        }

        String amountStr = amountNode.path("Amount").asText(null);
        if (amountStr == null) {
            amountStr = amountNode.asText(null);
        }

        if (amountStr != null) {
            try {
                return new BigDecimal(amountStr);
            } catch (NumberFormatException e) {
                log.warn("Could not parse amount: {}", amountStr);
            }
        }
        return BigDecimal.ZERO;
    }

    private String parseCurrency(JsonNode root) {
        JsonNode amountNode = root.path("Amount");
        if (amountNode.isMissingNode()) {
            return null;
        }

        String currencyStr = amountNode.path("Currency").asText(null);
        if (currencyStr == null) {
            currencyStr = amountNode.asText(null);
        }

        if (currencyStr != null) {
            try {
                return currencyStr;
            } catch (Exception e) {
                log.warn("Could not parse Currency: {}", currencyStr);
            }
        }
        return currencyStr;
    }


    /**
     * Parse balance after transaction from SAMA OB structure.
     * JSON path: Balance.Amount.Amount
     * Also considers Balance.CreditDebitIndicator for sign.
     */
    private BigDecimal parseBalanceAfter(JsonNode root) {
        JsonNode balanceNode = root.path("Balance");
        if (balanceNode.isMissingNode()) {
            return null;
        }
        
        // Get Amount.Amount from Balance object
        JsonNode amountNode = balanceNode.path("Amount");
        if (amountNode.isMissingNode()) {
            return null;
        }
        
        String balanceStr = amountNode.path("Amount").asText(null);
        if (balanceStr == null || balanceStr.isEmpty()) {
            return null;
        }
        
        try {
            BigDecimal balance = new BigDecimal(balanceStr);
            
            // Check CreditDebitIndicator - if Debit, balance might need to be negative
            String indicator = balanceNode.path("CreditDebitIndicator").asText(null);
            if ("KSAOB.Debit".equals(indicator) && balance.compareTo(BigDecimal.ZERO) > 0) {
                balance = balance.negate();
            }
            
            return balance;
        } catch (NumberFormatException e) {
            log.warn("Could not parse balance: {}", balanceStr);
            return null;
        }
    }

    private String extractCategory(JsonNode root) {
        JsonNode bankCategory = root.path("BankTransactionCode");
        if (!bankCategory.isMissingNode()) {
            String code = bankCategory.path("Code").asText(null);
            String subCode = bankCategory.path("SubCode").asText(null);
            if (code != null) {
                return subCode != null ? code + "/" + subCode : code;
            }
        }
        return null;
    }

    private String extractMerchantName(JsonNode root, String extractedMerchant) {
        if (extractedMerchant != null && !extractedMerchant.isBlank()) {
            return extractedMerchant;
        }
        
        JsonNode merchantDetails = root.path("MerchantDetails");
        if (!merchantDetails.isMissingNode()) {
            String name = merchantDetails.path("MerchantName").asText(null);
            if (name != null) {
                return name;
            }
        }
        
        JsonNode creditorAgent = root.path("CreditorAgent");
        if (!creditorAgent.isMissingNode()) {
            return creditorAgent.path("Name").asText(null);
        }
        
        return null;
    }

    private String getTextValue(JsonNode node, String fieldName) {
        JsonNode field = node.path(fieldName);
        return field.isMissingNode() || field.isNull() ? null : field.asText();
    }

    /**
     * Parse account data to extract customer profile information.
     * Extracts account holder name, IBAN, and balance from Open Banking JSON.
     */
    public AccountInfo parseAccountInfo(ObAccount account) {
        AccountInfo.AccountInfoBuilder builder = AccountInfo.builder()
                .accountId(account.getIntegratedId())
                .bankId(account.getBankId());

        if (account.getData() == null) {
            return builder.build();
        }

        try {
            JsonNode dataNode = objectMapper.readTree(account.getData());
            
            if (dataNode.has("ob")) {
                JsonNode obNode = dataNode.get("ob");
                
                // Extract account holder name from AccountIdentifiers
                String accountHolderName = extractAccountHolderName(obNode);
                if (accountHolderName != null) {
                    builder.accountHolderName(accountHolderName);
                }
                
                // Extract IBAN
                if (obNode.has("AccountIdentifiers") && obNode.get("AccountIdentifiers").isArray()) {
                    for (JsonNode identifier : obNode.get("AccountIdentifiers")) {
                        String type = identifier.has("IdentificationType") ? 
                                identifier.get("IdentificationType").asText() : "";
                        if (type.contains("IBAN") && identifier.has("Identification")) {
                            builder.accountNumber(identifier.get("Identification").asText());
                            break;
                        }
                    }
                }
            }
            
            // Parse balance info
            if (dataNode.has("balance_api_response")) {
                JsonNode balanceResponse = dataNode.get("balance_api_response");
                if (balanceResponse.has("data") && balanceResponse.get("data").has("balance")) {
                    JsonNode balances = balanceResponse.get("data").get("balance");
                    if (balances.isArray() && balances.size() > 0) {
                        JsonNode balance = balances.get(0);
                        if (balance.has("amount")) {
                            JsonNode amount = balance.get("amount");
                            if (amount.has("amount")) {
                                String amountStr = amount.get("amount").asText();
                                try {
                                    builder.currentBalance(new BigDecimal(amountStr));
                                } catch (NumberFormatException ignored) {}
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.warn("Could not parse account info for {}: {}", account.getId(), e.getMessage());
        }

        return builder.build();
    }

    private String extractAccountHolderName(JsonNode obNode) {
        String accountHolderName = null;
        
        if (obNode.has("AccountIdentifiers") && obNode.get("AccountIdentifiers").isArray()) {
            String fallbackName = null;
            
            for (JsonNode identifier : obNode.get("AccountIdentifiers")) {
                String type = identifier.has("IdentificationType") ? 
                        identifier.get("IdentificationType").asText() : "";
                String name = (identifier.has("Name") && !identifier.get("Name").isNull()) ?
                        identifier.get("Name").asText() : null;
                
                // Extract name from IBAN identifier as fallback
                if (type.contains("IBAN") && name != null && !name.isEmpty()) {
                    fallbackName = name;
                }
                
                // Priority: IqamaNumber or NationalID
                if ((type.contains("IqamaNumber") || type.contains("NationalID")) 
                        && name != null && !name.isEmpty()) {
                    accountHolderName = name;
                }
            }
            
            if (accountHolderName == null && fallbackName != null) {
                accountHolderName = fallbackName;
            }
        }
        
        // Fallback: Extract from Account array
        if (accountHolderName == null && obNode.has("Account") && obNode.get("Account").isArray()) {
            for (JsonNode account : obNode.get("Account")) {
                if (account.has("Name") && account.get("Name") != null 
                        && !account.get("Name").isNull()) {
                    String name = account.get("Name").asText();
                    if (name != null && !name.isEmpty()) {
                        accountHolderName = name;
                        break;
                    }
                }
            }
        }
        
        // Last fallback: Use Nickname
        if (accountHolderName == null && obNode.has("Nickname") 
                && obNode.get("Nickname") != null && !obNode.get("Nickname").isNull()) {
            String nickname = obNode.get("Nickname").asText();
            if (nickname != null && !nickname.isEmpty() && !nickname.matches("^[0-9]+$")) {
                accountHolderName = nickname;
            }
        }
        
        return accountHolderName;
    }

    /**
     * Debug helper: returns the raw, database-decrypted rows from both the
     * raw_transactions table (ObTransactionRepository) and the
     * drahim_transactions table (DrahimTransactionRepository) for the given
     * identifiers.
     *
     * <p>The account is first resolved to its internal id (account.getId()),
     * which is what the production scoring flow queries against. If the account
     * or consent cannot be resolved, the queries fall back to using the
     * supplied accountId directly so the raw data can still be inspected.</p>
     */
    @Transactional(readOnly = true, transactionManager = "openBankingTransactionManager")
    public com.ejada.obdatarepositoryapp.creditrisk.dto.response.DebugTransactionsResponse debugTransactions(
            String psuId, String accountLinkId, String accountId, String sponsoredTppId) {

        String internalAccountId = accountId;
        boolean resolved = false;
        String message;

        try {
            Optional<ObAccount> accountOpt = getAccount(psuId, accountLinkId, accountId, sponsoredTppId);
            if (accountOpt.isPresent()) {
                internalAccountId = accountOpt.get().getId();
                resolved = true;
                message = "Account resolved; queries ran against internal account id.";
            } else {
                message = "Account not found for the given identifiers; queries ran against the supplied accountId.";
            }
        } catch (Exception e) {
            message = "Account resolution failed (" + e.getMessage()
                    + "); queries ran against the supplied accountId.";
        }

        List<DecryptedTransactionProjection> rawTransactions = obTransactionRepository
                .findDecryptedByUserIdAndAccountId(psuId, internalAccountId, pgpEncryptionKey);

        List<DecryptedDrahimTransactionProjection> drahimTransactions = drahimTransactionRepository
                .findDecryptedByUserAndAccount(psuId, internalAccountId, sponsoredTppId, pgpEncryptionKey);

        return com.ejada.obdatarepositoryapp.creditrisk.dto.response.DebugTransactionsResponse.builder()
                .psuId(psuId)
                .accountLinkId(accountLinkId)
                .requestedAccountId(accountId)
                .sponsoredTppId(sponsoredTppId)
                .resolvedInternalAccountId(internalAccountId)
                .accountResolved(resolved)
                .message(message)
                .rawTransactionsCount(rawTransactions.size())
                .rawTransactions(rawTransactions)
                .drahimTransactionsCount(drahimTransactions.size())
                .drahimTransactions(drahimTransactions)
                .build();
    }

    @lombok.Data
    @lombok.Builder
    @lombok.NoArgsConstructor
    @lombok.AllArgsConstructor
    public static class AccountInfo {
        private String accountId;
        private String bankId;
        private String accountHolderName;
        private String accountNumber;
        private BigDecimal currentBalance;
    }
}
