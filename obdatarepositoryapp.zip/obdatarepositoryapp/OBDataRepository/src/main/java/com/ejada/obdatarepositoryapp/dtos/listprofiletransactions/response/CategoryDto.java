package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CategoryDto {

    @JsonProperty("id")
    private String id;

    @JsonProperty("a_name")
    private String aName;

    @JsonProperty("e_name")
    private String eName;

    @JsonProperty("color")
    private String color;

    @JsonProperty("icon_name")
    private String iconName;
}