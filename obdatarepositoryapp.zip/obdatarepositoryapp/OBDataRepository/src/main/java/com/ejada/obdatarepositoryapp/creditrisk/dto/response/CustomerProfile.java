package com.ejada.obdatarepositoryapp.creditrisk.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Customer profile data for PDF report.
 * Contains customer identification and account summary information.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerProfile {
    
    private String fullName;
    private String nationalId;
    private Integer age;
    private String analysisStartDate;
    private String analysisEndDate;
    private Integer totalTransactions;
    private Integer verifiedTransactions;
    private BigDecimal currentBalance;
    private String accountNumber;
    private String bankName;
}
