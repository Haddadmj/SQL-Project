package com.ejada.obdatarepositoryapp.creditrisk.enums;

/**
 * Customer type for credit risk assessment.
 * Retail and Corporate may have different scoring logic in the future.
 */
public enum CustomerType {
    RETAIL,
    CORPORATE
}
