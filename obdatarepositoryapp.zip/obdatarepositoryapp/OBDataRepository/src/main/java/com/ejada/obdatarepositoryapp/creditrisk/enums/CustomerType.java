package com.ejada.obdatarepositoryapp.creditrisk.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Customer type for credit risk assessment.
 * Retail and Corporate may have different scoring logic in the future.
 */
public enum CustomerType {
    RETAIL,
    CORPORATE;
    
    @JsonCreator
    public static CustomerType fromString(String value) {
        if (value == null) return null;
        return CustomerType.valueOf(value.toUpperCase());
    }
}
