package com.ejada.obdatarepositoryapp.creditrisk.service;

import com.ejada.obdatarepositoryapp.creditrisk.domain.ObAccount;
import com.ejada.obdatarepositoryapp.creditrisk.dto.TransactionData;
import com.ejada.obdatarepositoryapp.creditrisk.dto.request.CreditRiskRequest;
import com.ejada.obdatarepositoryapp.creditrisk.dto.request.RangeConfig;
import com.ejada.obdatarepositoryapp.creditrisk.dto.request.RiskFactorConfig;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.*;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CreditRatingClass;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType;
import com.ejada.obdatarepositoryapp.creditrisk.enums.LoanPurpose;
import com.ejada.obdatarepositoryapp.creditrisk.enums.RiskFactorType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Core credit risk scoring service.
 * Calculates credit scores based on configurable factors and financial metrics.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class CreditRiskScoringService {

    private final OpenBankingDataFetcher dataFetcher;
    private final FinancialMetricsCalculator metricsCalculator;

    private static final Map<RiskFactorType, List<RangeConfig>> DEFAULT_RANGES = initializeDefaultRanges();

    public CreditRiskReportResponse generateReport(CreditRiskRequest request) {
        log.info("Generating credit risk report for psuId={}, accountId={}, sponsoredTppId={}", 
                request.getPsuId(), request.getAccountId(), request.getSponsoredTppId());

        // Get account with full validation (psuId, accountLinkId, accountId, sponsoredTppId)
        Optional<ObAccount> accountOpt = dataFetcher.getAccount(
                request.getPsuId(), request.getAccountLinkId(), request.getAccountId(), request.getSponsoredTppId());
        
        if (accountOpt.isEmpty()) {
            log.warn("Account not found for psuId={}, accountLinkId={}, accountId={}, sponsoredTppId={}",
                    request.getPsuId(), request.getAccountLinkId(), request.getAccountId(), request.getSponsoredTppId());
            return buildErrorReport(request, "Account not found or access denied");
        }

        ObAccount account = accountOpt.get();
        
        // Get transactions using internal account ID (account.getId()) and sponsoredTppId
        List<TransactionData> transactions = dataFetcher.getTransactionsForAccount(
                request.getPsuId(), account.getId(), request.getSponsoredTppId());

        // Build customer profile from account data and transactions
        OpenBankingDataFetcher.AccountInfo accountInfo = dataFetcher.parseAccountInfo(accountOpt.get());
        CustomerProfile customerProfile = buildCustomerProfile(request, accountInfo, transactions);

        FinancialMetrics metrics = metricsCalculator.calculate(transactions, request.getCustomerType(), request.getAge());

        Map<RiskFactorType, RiskFactorConfig> factorConfigs = buildFactorConfigs(request.getRiskFactors(), request.getCustomerType(), request.getAge());

        List<FactorScore> factorScores = calculateFactorScores(metrics, factorConfigs, request.getCustomerType());

        int totalScore = factorScores.stream()
                .filter(f -> Boolean.TRUE.equals(f.getDataAvailable()))
                .mapToInt(FactorScore::getScore)
                .sum();

        int maxPossibleScore = factorScores.stream()
                .filter(f -> Boolean.TRUE.equals(f.getDataAvailable()))
                .mapToInt(FactorScore::getMaxScore)
                .sum();

        if (maxPossibleScore > 0 && maxPossibleScore < 1000) {
            totalScore = (int) Math.round((double) totalScore * 1000 / maxPossibleScore);
            maxPossibleScore = 1000;
        }

        CreditRatingClass ratingClass = CreditRatingClass.fromScore(totalScore);

        CreditRecommendation recommendation = buildRecommendation(ratingClass, metrics, factorScores);

        PurposeAssessment purposeAssessment = null;
        if (request.getPurpose() != null && request.getRequestedAmount() != null) {
            purposeAssessment = assessPurpose(request, metrics, ratingClass);
        }

        long skippedCount = factorScores.stream()
                .filter(f -> !Boolean.TRUE.equals(f.getDataAvailable()))
                .count();

        List<String> skippedReasons = factorScores.stream()
                .filter(f -> !Boolean.TRUE.equals(f.getDataAvailable()))
                .map(f -> f.getFactorName() + ": " + f.getDataUnavailableReason())
                .collect(Collectors.toList());

        String reportId = UUID.randomUUID().toString();

        return CreditRiskReportResponse.builder()
                .reportId(reportId)
                .generatedAt(LocalDateTime.now())
                .psuId(request.getPsuId())
                .accountLinkId(request.getAccountLinkId())
                .accountId(request.getAccountId())
                .sponsoredTppId(request.getSponsoredTppId())
                .customerType(request.getCustomerType())
                .totalScore(totalScore)
                .maxPossibleScore(maxPossibleScore)
                .ratingClass(ratingClass)
                .ratingClassName(ratingClass.getClassName())
                .ratingDescription(ratingClass.getDescription())
                .approvalRecommendation(ratingClass.getApprovalRecommendation())
                .factorScores(factorScores)
                .financialMetrics(metrics)
                .customerProfile(customerProfile)
                .recommendation(recommendation)
                .purposeAssessment(purposeAssessment)
                .metadata(CreditRiskReportResponse.ReportMetadata.builder()
                        .factorsEvaluated((int) (factorScores.size() - skippedCount))
                        .factorsSkipped((int) skippedCount)
                        .skippedFactorReasons(skippedReasons)
                        .weightsRedistributed(skippedCount > 0)
                        .dataQualityNote(buildDataQualityNote(metrics))
                        .build())
                .build();
    }

    private Map<RiskFactorType, RiskFactorConfig> buildFactorConfigs(List<RiskFactorConfig> requestConfigs, CustomerType customerType, Integer age) {
        Map<RiskFactorType, RiskFactorConfig> configs = new EnumMap<>(RiskFactorType.class);

        for (RiskFactorType type : RiskFactorType.values()) {
            // Only include factors applicable to the customer type
            boolean isApplicable = type.isApplicableTo(customerType);
            // AGE and BUSINESS_AGE factors are enabled only if age is provided in request
            boolean isAgeBasedFactor = type == RiskFactorType.AGE || type == RiskFactorType.BUSINESS_AGE;
            boolean isEnabled = isApplicable && (!isAgeBasedFactor || age != null);
            
            configs.put(type, RiskFactorConfig.builder()
                    .factorType(type)
                    .weight(type.getDefaultWeight())
                    .ranges(DEFAULT_RANGES.get(type))
                    .enabled(isEnabled)
                    .build());
        }

        if (requestConfigs != null) {
            for (RiskFactorConfig config : requestConfigs) {
                if (config.getFactorType() != null) {
                    RiskFactorConfig existing = configs.get(config.getFactorType());
                    if (existing != null) {
                        if (config.getWeight() != null) {
                            existing.setWeight(config.getWeight());
                        }
                        if (config.getRanges() != null && !config.getRanges().isEmpty()) {
                            existing.setRanges(config.getRanges());
                        }
                        if (config.getEnabled() != null) {
                            existing.setEnabled(config.getEnabled());
                        }
                    }
                }
            }
        }

        return configs;
    }

    private List<FactorScore> calculateFactorScores(FinancialMetrics metrics, 
                                                     Map<RiskFactorType, RiskFactorConfig> configs,
                                                     CustomerType customerType) {
        List<FactorScore> scores = new ArrayList<>();

        for (RiskFactorType type : RiskFactorType.values()) {
            // Only include factors applicable to the customer type
            if (!type.isApplicableTo(customerType)) {
                continue;
            }
            RiskFactorConfig config = configs.get(type);
            FactorScore score = calculateSingleFactorScore(type, config, metrics);
            scores.add(score);
        }

        return scores;
    }

    private FactorScore calculateSingleFactorScore(RiskFactorType type, RiskFactorConfig config, 
                                                    FinancialMetrics metrics) {
        if (config == null || !Boolean.TRUE.equals(config.getEnabled())) {
            return FactorScore.builder()
                    .factorType(type)
                    .factorName(type.getDisplayName())
                    .dataAvailable(false)
                    .dataUnavailableReason("Factor disabled")
                    .score(0)
                    .maxScore(config != null ? config.getWeight() : type.getDefaultWeight())
                    .build();
        }

        BigDecimal rawValue = extractRawValue(type, metrics);
        boolean hasData = rawValue != null && rawValue.compareTo(BigDecimal.ZERO) != 0;

        if (!hasData && type != RiskFactorType.AGE) {
            if (type == RiskFactorType.LOAN_PAYMENT || type == RiskFactorType.DEBT_BURDEN_RATIO) {
                rawValue = BigDecimal.ZERO;
                hasData = true;
            }
        }

        if (!hasData) {
            return FactorScore.builder()
                    .factorType(type)
                    .factorName(type.getDisplayName())
                    .dataAvailable(false)
                    .dataUnavailableReason("Insufficient data for calculation")
                    .score(0)
                    .maxScore(config.getWeight())
                    .build();
        }

        int score = calculateScoreFromRanges(rawValue, config.getRanges(), config.getWeight());
        double percentage = config.getWeight() > 0 ? (double) score / config.getWeight() * 100 : 0;

        return FactorScore.builder()
                .factorType(type)
                .factorName(type.getDisplayName())
                .rawValue(rawValue)
                .formattedValue(formatValue(type, rawValue))
                .score(score)
                .maxScore(config.getWeight())
                .percentage(percentage)
                .scoreLabel(getScoreLabel(percentage))
                .industryStandard(getIndustryStandard(type))
                .industryStandardLabel(getIndustryStandardLabel(type))
                .dataAvailable(true)
                .build();
    }

    private BigDecimal extractRawValue(RiskFactorType type, FinancialMetrics metrics) {
        return switch (type) {
            // Retail factors
            case AGE -> metrics.getAge() != null ? BigDecimal.valueOf(metrics.getAge()) : null;
            case INCOME -> metrics.getMedianMonthlyIncome();
            case LOAN_PAYMENT -> metrics.getLastMonthDebtPayment();  // Includes loans + mortgages
            case SURPLUS_RATIO -> metrics.getSurplusRatio() != null 
                    ? metrics.getSurplusRatio().multiply(BigDecimal.valueOf(100)) : null;
            case SALARY_CATEGORY -> metrics.getMedianSalaryIncome();
            case CASH_FLOW -> metrics.getCashFlow();
            case DEBT_BURDEN_RATIO -> metrics.getDebtBurdenRatio() != null
                    ? metrics.getDebtBurdenRatio().multiply(BigDecimal.valueOf(100)) : null;
            // Corporate factors
            case BUSINESS_AGE -> metrics.getAge() != null ? BigDecimal.valueOf(metrics.getAge()) : null;
            case REVENUE_STABILITY -> metrics.getRevenueStabilityCoefficient();
            case REVENUE_TREND -> metrics.getRevenueTrendPercentage();
            case OPERATING_EXPENSE_RATIO -> metrics.getOperatingExpenseRatio();
            case SUPPLIER_PAYMENT_CONSISTENCY -> metrics.getSupplierPaymentConsistencyScore();
            case CASH_BUFFER -> metrics.getCashBufferMonths();
            case CORPORATE_CASH_FLOW -> metrics.getCorporateCashFlow();
            case PAYMENT_BEHAVIOR -> metrics.getPaymentBehaviorScore();
        };
    }

    private int calculateScoreFromRanges(BigDecimal value, List<RangeConfig> ranges, int maxScore) {
        if (ranges == null || ranges.isEmpty()) {
            return maxScore / 2;
        }

        for (RangeConfig range : ranges) {
            boolean minOk = range.getMinValue() == null || value.compareTo(range.getMinValue()) >= 0;
            boolean maxOk = range.getMaxValue() == null || value.compareTo(range.getMaxValue()) <= 0;
            if (minOk && maxOk) {
                return range.getPoints() != null ? range.getPoints() : 0;
            }
        }

        return 0;
    }

    private String formatValue(RiskFactorType type, BigDecimal value) {
        if (value == null) return "N/A";
        
        return switch (type) {
            case SURPLUS_RATIO, DEBT_BURDEN_RATIO -> value.setScale(1, RoundingMode.HALF_UP) + "%";
            case INCOME, LOAN_PAYMENT, CASH_FLOW, SALARY_CATEGORY -> 
                    String.format("%,.0f SAR", value.setScale(0, RoundingMode.HALF_UP));
            default -> value.toString();
        };
    }

    private String getScoreLabel(double percentage) {
        if (percentage >= 80) return "Excellent";
        if (percentage >= 60) return "Good";
        if (percentage >= 40) return "Fair";
        if (percentage >= 20) return "Poor";
        return "Very Poor";
    }

    private BigDecimal getIndustryStandard(RiskFactorType type) {
        return switch (type) {
            case SURPLUS_RATIO -> new BigDecimal("20");
            case DEBT_BURDEN_RATIO -> new BigDecimal("30");
            case INCOME -> new BigDecimal("10000");
            default -> null;
        };
    }

    private String getIndustryStandardLabel(RiskFactorType type) {
        return switch (type) {
            case SURPLUS_RATIO -> "Healthy: >20%";
            case DEBT_BURDEN_RATIO -> "Healthy: <30%";
            case INCOME -> "Median: 10,000 SAR";
            default -> null;
        };
    }

    private CreditRecommendation buildRecommendation(CreditRatingClass ratingClass, 
                                                      FinancialMetrics metrics,
                                                      List<FactorScore> factorScores) {
        List<String> strengths = new ArrayList<>();
        List<String> weaknesses = new ArrayList<>();
        List<String> recommendations = new ArrayList<>();

        for (FactorScore score : factorScores) {
            if (Boolean.TRUE.equals(score.getDataAvailable())) {
                if (score.getPercentage() != null && score.getPercentage() >= 70) {
                    strengths.add(score.getFactorName() + ": " + score.getScoreLabel());
                } else if (score.getPercentage() != null && score.getPercentage() < 40) {
                    weaknesses.add(score.getFactorName() + ": " + score.getScoreLabel());
                }
            }
        }

        if (metrics.getSurplusRatio() != null && 
            metrics.getSurplusRatio().compareTo(new BigDecimal("0.1")) < 0) {
            recommendations.add("Consider reducing monthly expenses to improve surplus ratio");
        }

        if (metrics.getDebtBurdenRatio() != null && 
            metrics.getDebtBurdenRatio().compareTo(new BigDecimal("0.4")) > 0) {
            recommendations.add("Debt-to-income ratio is high; consider debt consolidation");
        }

        BigDecimal maxAffordable = BigDecimal.ZERO;
        if (metrics.getCashFlow() != null && metrics.getCashFlow().compareTo(BigDecimal.ZERO) > 0) {
            maxAffordable = metrics.getCashFlow().multiply(new BigDecimal("0.3"))
                    .setScale(0, RoundingMode.DOWN);
        }

        return CreditRecommendation.builder()
                .decision(ratingClass.getApprovalRecommendation())
                .decisionReason(ratingClass.getDescription())
                .maxAffordablePayment(maxAffordable)
                .strengths(strengths)
                .weaknesses(weaknesses)
                .recommendations(recommendations)
                .build();
    }

    private PurposeAssessment assessPurpose(CreditRiskRequest request, FinancialMetrics metrics,
                                            CreditRatingClass ratingClass) {
        BigDecimal requestedAmount = request.getRequestedAmount();
        
        // Determine loan term: use request value or default based on purpose
        int loanTermMonths;
        if (request.getLoanTermMonths() != null && request.getLoanTermMonths() > 0) {
            loanTermMonths = request.getLoanTermMonths();
        } else {
            // Default: 20 years (240 months) for mortgage, 5 years (60 months) for others
            loanTermMonths = (request.getPurpose() == LoanPurpose.HOME_MORTGAGE) ? 240 : 60;
        }
        
        // Determine annual interest rate: use request value or default 3%
        BigDecimal annualRate = (request.getAnnualInterestRate() != null && 
                request.getAnnualInterestRate().compareTo(BigDecimal.ZERO) > 0)
                ? request.getAnnualInterestRate() 
                : new BigDecimal("3.0");
        
        // Calculate monthly payment using amortization formula: M = P * [r(1+r)^n] / [(1+r)^n - 1]
        BigDecimal estimatedMonthly = calculateMonthlyPayment(requestedAmount, annualRate, loanTermMonths);

        // Total monthly debt = last month's loans + mortgages payments
        BigDecimal currentDebt = metrics.getLastMonthDebtPayment() != null 
                ? metrics.getLastMonthDebtPayment() : BigDecimal.ZERO;
        BigDecimal newTotalDebt = currentDebt.add(estimatedMonthly);

        BigDecimal newDebtRatio = BigDecimal.ZERO;
        boolean isAffordable = false;
        String affordabilityAssessment;

        if (metrics.getMedianMonthlyIncome() != null && 
            metrics.getMedianMonthlyIncome().compareTo(BigDecimal.ZERO) > 0) {
            newDebtRatio = newTotalDebt.divide(metrics.getMedianMonthlyIncome(), 4, RoundingMode.HALF_UP);
            isAffordable = newDebtRatio.compareTo(new BigDecimal("0.4")) <= 0;
        }

        if (isAffordable && ratingClass.getMinScore() >= 600) {
            affordabilityAssessment = "Likely affordable based on current financial profile";
        } else if (isAffordable) {
            affordabilityAssessment = "Potentially affordable but credit score suggests caution";
        } else {
            affordabilityAssessment = "May strain finances; consider lower amount";
        }

        String riskLevel = newDebtRatio.compareTo(new BigDecimal("0.3")) <= 0 ? "Low" :
                newDebtRatio.compareTo(new BigDecimal("0.5")) <= 0 ? "Medium" : "High";

        return PurposeAssessment.builder()
                .purpose(request.getPurpose())
                .purposeDisplayName(request.getPurpose() != null ? request.getPurpose().getDisplayName() : null)
                .requestedAmount(requestedAmount)
                .isAffordable(isAffordable)
                .estimatedMonthlyPayment(estimatedMonthly)
                .debtToIncomeAfterLoan(String.format("%.1f%%", 
                        newDebtRatio.multiply(BigDecimal.valueOf(100)).doubleValue()))
                .affordabilityAssessment(affordabilityAssessment)
                .riskLevel(riskLevel)
                .build();
    }

    /**
     * Calculate monthly payment using standard amortization formula.
     * Formula: M = P * [r(1+r)^n] / [(1+r)^n - 1]
     * Where: P = principal, r = monthly interest rate, n = number of months
     */
    private BigDecimal calculateMonthlyPayment(BigDecimal principal, BigDecimal annualInterestRate, int termMonths) {
        if (principal == null || principal.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        if (termMonths <= 0) {
            return principal;
        }
        
        // Convert annual rate to monthly decimal rate (e.g., 3% -> 0.0025)
        BigDecimal monthlyRate = annualInterestRate
                .divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP)
                .divide(BigDecimal.valueOf(12), 10, RoundingMode.HALF_UP);
        
        // If interest rate is 0, simple division
        if (monthlyRate.compareTo(BigDecimal.ZERO) == 0) {
            return principal.divide(BigDecimal.valueOf(termMonths), 2, RoundingMode.HALF_UP);
        }
        
        // Calculate (1 + r)^n using double for precision
        double r = monthlyRate.doubleValue();
        double n = termMonths;
        double onePlusRtoN = Math.pow(1 + r, n);
        
        // M = P * [r(1+r)^n] / [(1+r)^n - 1]
        double numerator = r * onePlusRtoN;
        double denominator = onePlusRtoN - 1;
        double monthlyPayment = principal.doubleValue() * (numerator / denominator);
        
        return BigDecimal.valueOf(monthlyPayment).setScale(2, RoundingMode.HALF_UP);
    }

    private String buildDataQualityNote(FinancialMetrics metrics) {
        if (metrics.getMonthsOfData() == null || metrics.getMonthsOfData() < 3) {
            return "Limited data available (less than 3 months). Results may be less reliable.";
        }
        if (metrics.getTransactionCount() != null && metrics.getTransactionCount() < 30) {
            return "Low transaction volume. Results may be less representative.";
        }
        return "Sufficient data for reliable analysis.";
    }

    private CreditRiskReportResponse buildErrorReport(CreditRiskRequest request, String error) {
        return CreditRiskReportResponse.builder()
                .reportId(UUID.randomUUID().toString())
                .generatedAt(LocalDateTime.now())
                .psuId(request.getPsuId())
                .accountLinkId(request.getAccountLinkId())
                .accountId(request.getAccountId())
                .sponsoredTppId(request.getSponsoredTppId())
                .customerType(request.getCustomerType())
                .totalScore(0)
                .maxPossibleScore(1000)
                .ratingClass(CreditRatingClass.D)
                .ratingClassName("Error")
                .ratingDescription(error)
                .approvalRecommendation("Reject")
                .factorScores(Collections.emptyList())
                .metadata(CreditRiskReportResponse.ReportMetadata.builder()
                        .factorsEvaluated(0)
                        .factorsSkipped(7)
                        .skippedFactorReasons(List.of(error))
                        .weightsRedistributed(false)
                        .dataQualityNote("Unable to retrieve data")
                        .build())
                .build();
    }

    private static Map<RiskFactorType, List<RangeConfig>> initializeDefaultRanges() {
        Map<RiskFactorType, List<RangeConfig>> ranges = new EnumMap<>(RiskFactorType.class);

        // Factor 1: AGE RANGES - Total Weight: 150 points (15%)
        ranges.put(RiskFactorType.AGE, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("36")).maxValue(new BigDecimal("50")).points(150).label("Peak earning and stability").build(),
                RangeConfig.builder().minValue(new BigDecimal("51")).maxValue(new BigDecimal("60")).points(100).label("Near retirement, stable").build(),
                RangeConfig.builder().minValue(new BigDecimal("26")).maxValue(new BigDecimal("35")).points(80).label("Establishing financial stability").build(),
                RangeConfig.builder().minValue(new BigDecimal("18")).maxValue(new BigDecimal("25")).points(30).label("Young, limited credit history").build(),
                RangeConfig.builder().minValue(new BigDecimal("61")).maxValue(new BigDecimal("120")).points(0).label("Retired, higher risk").build()
        ));

        // Factor 2: MEDIAN INCOME (Last 3 Months, Spike Excluded) - Total Weight: 150 points (15%)
        ranges.put(RiskFactorType.INCOME, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("15001")).maxValue(null).points(150).label("High income").build(),
                RangeConfig.builder().minValue(new BigDecimal("10001")).maxValue(new BigDecimal("15000")).points(100).label("Medium income").build(),
                RangeConfig.builder().minValue(new BigDecimal("5001")).maxValue(new BigDecimal("10000")).points(50).label("Low income").build(),
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("5000")).points(0).label("Below minimum threshold").build()
        ));

        // Factor 3: LOAN PAYMENT (Sum of Last Month Loan Payment) - Total Weight: 150 points (15%)
        ranges.put(RiskFactorType.LOAN_PAYMENT, Arrays.asList(
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("1500")).points(150).label("Very low debt (0-500/month avg)").build(),
                RangeConfig.builder().minValue(new BigDecimal("1501")).maxValue(new BigDecimal("3000")).points(130).label("Low debt (501-1,000/month avg)").build(),
                RangeConfig.builder().minValue(new BigDecimal("3001")).maxValue(new BigDecimal("4500")).points(110).label("Moderate debt (1,001-1,500/month avg)").build(),
                RangeConfig.builder().minValue(new BigDecimal("4501")).maxValue(new BigDecimal("9000")).points(80).label("High debt (1,501-3,000/month avg)").build(),
                RangeConfig.builder().minValue(new BigDecimal("9001")).maxValue(new BigDecimal("15000")).points(40).label("Very high debt (3,001-5,000/month avg)").build(),
                RangeConfig.builder().minValue(new BigDecimal("15001")).maxValue(null).points(0).label("Excessive debt (>5,000/month avg)").build()
        ));

        // Factor 4: SURPLUS RATIO - Total Weight: 150 points (15%)
        // Formula: (Avg Income - Avg Expenses) / Avg Income (as percentage 0-100)
        ranges.put(RiskFactorType.SURPLUS_RATIO, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("31")).maxValue(new BigDecimal("100")).points(150).label("Excellent surplus (>30%)").build(),
                RangeConfig.builder().minValue(new BigDecimal("21")).maxValue(new BigDecimal("30")).points(130).label("Good surplus (21-30%)").build(),
                RangeConfig.builder().minValue(new BigDecimal("11")).maxValue(new BigDecimal("20")).points(100).label("Moderate surplus (11-20%)").build(),
                RangeConfig.builder().minValue(new BigDecimal("1")).maxValue(new BigDecimal("10")).points(50).label("Minimal surplus (1-10%)").build(),
                RangeConfig.builder().minValue(new BigDecimal("-100")).maxValue(new BigDecimal("0")).points(0).label("Spending more than earning").build()
        ));

        // Factor 5: SALARY CATEGORY - Total Weight: 150 points (15%)
        ranges.put(RiskFactorType.SALARY_CATEGORY, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("15001")).maxValue(null).points(150).label("Low Risk").build(),
                RangeConfig.builder().minValue(new BigDecimal("5001")).maxValue(new BigDecimal("15000")).points(90).label("Medium Risk").build(),
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("5000")).points(30).label("High Risk").build()
        ));

        // Factor 6: CASH FLOW - Total Weight: 150 points (15%)
        // Formula: Avg Income - Avg Expenses
        ranges.put(RiskFactorType.CASH_FLOW, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("3001")).maxValue(null).points(150).label("Strong positive").build(),
                RangeConfig.builder().minValue(new BigDecimal("1001")).maxValue(new BigDecimal("3000")).points(100).label("Moderate positive").build(),
                RangeConfig.builder().minValue(new BigDecimal("0")).maxValue(new BigDecimal("1000")).points(50).label("Minimal positive").build(),
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("-1")).points(0).label("Negative cash flow").build()
        ));

        // Factor 7: Debt Burden Ratio (DBR) - Total Weight: 100 points (10%)
        // Formula: Total Monthly Debt Payments / Total Monthly Income (as percentage 0-100)
        ranges.put(RiskFactorType.DEBT_BURDEN_RATIO, Arrays.asList(
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("10")).points(100).label("Excellent (0-10%)").build(),
                RangeConfig.builder().minValue(new BigDecimal("11")).maxValue(new BigDecimal("25")).points(70).label("Good (11-25%)").build(),
                RangeConfig.builder().minValue(new BigDecimal("26")).maxValue(new BigDecimal("40")).points(40).label("Moderate (26-40%)").build(),
                RangeConfig.builder().minValue(new BigDecimal("41")).maxValue(new BigDecimal("60")).points(20).label("High (41-60%)").build(),
                RangeConfig.builder().minValue(new BigDecimal("61")).maxValue(null).points(0).label("Very High (>60%)").build()
        ));

        // Corporate factors
        
        // BUSINESS_AGE - Years in operation (different from retail AGE)
        // 3 years = baseline average, tiers of 2 years increase trust
        ranges.put(RiskFactorType.BUSINESS_AGE, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("9")).maxValue(null).points(150).label("Established (9+ years)").build(),
                RangeConfig.builder().minValue(new BigDecimal("7")).maxValue(new BigDecimal("8")).points(130).label("Very Mature (7-8 years)").build(),
                RangeConfig.builder().minValue(new BigDecimal("5")).maxValue(new BigDecimal("6")).points(110).label("Mature (5-6 years)").build(),
                RangeConfig.builder().minValue(new BigDecimal("3")).maxValue(new BigDecimal("4")).points(90).label("Average (3-4 years)").build(),
                RangeConfig.builder().minValue(new BigDecimal("2")).maxValue(new BigDecimal("2")).points(60).label("Young (2 years)").build(),
                RangeConfig.builder().minValue(new BigDecimal("1")).maxValue(new BigDecimal("1")).points(40).label("New (1 year)").build(),
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("0")).points(20).label("Startup (<1 year)").build()
        ));

        ranges.put(RiskFactorType.REVENUE_STABILITY, Arrays.asList(
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("15")).points(150).label("Very Stable").build(),
                RangeConfig.builder().minValue(new BigDecimal("15.01")).maxValue(new BigDecimal("25")).points(120).label("Stable").build(),
                RangeConfig.builder().minValue(new BigDecimal("25.01")).maxValue(new BigDecimal("40")).points(90).label("Moderate").build(),
                RangeConfig.builder().minValue(new BigDecimal("40.01")).maxValue(new BigDecimal("60")).points(60).label("Volatile").build(),
                RangeConfig.builder().minValue(new BigDecimal("60.01")).maxValue(null).points(30).label("Very Volatile").build()
        ));

        ranges.put(RiskFactorType.REVENUE_TREND, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("20")).maxValue(null).points(150).label("Strong Growth").build(),
                RangeConfig.builder().minValue(new BigDecimal("10")).maxValue(new BigDecimal("19.99")).points(120).label("Good Growth").build(),
                RangeConfig.builder().minValue(new BigDecimal("0")).maxValue(new BigDecimal("9.99")).points(100).label("Stable").build(),
                RangeConfig.builder().minValue(new BigDecimal("-10")).maxValue(new BigDecimal("-0.01")).points(60).label("Declining").build(),
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("-10.01")).points(30).label("Sharp Decline").build()
        ));

        ranges.put(RiskFactorType.OPERATING_EXPENSE_RATIO, Arrays.asList(
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("60")).points(150).label("Excellent").build(),
                RangeConfig.builder().minValue(new BigDecimal("60.01")).maxValue(new BigDecimal("75")).points(120).label("Good").build(),
                RangeConfig.builder().minValue(new BigDecimal("75.01")).maxValue(new BigDecimal("90")).points(90).label("Moderate").build(),
                RangeConfig.builder().minValue(new BigDecimal("90.01")).maxValue(new BigDecimal("100")).points(50).label("High").build(),
                RangeConfig.builder().minValue(new BigDecimal("100.01")).maxValue(null).points(20).label("Loss-Making").build()
        ));

        ranges.put(RiskFactorType.SUPPLIER_PAYMENT_CONSISTENCY, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("80")).maxValue(null).points(150).label("Excellent").build(),
                RangeConfig.builder().minValue(new BigDecimal("60")).maxValue(new BigDecimal("79.99")).points(120).label("Good").build(),
                RangeConfig.builder().minValue(new BigDecimal("40")).maxValue(new BigDecimal("59.99")).points(90).label("Moderate").build(),
                RangeConfig.builder().minValue(new BigDecimal("20")).maxValue(new BigDecimal("39.99")).points(50).label("Poor").build(),
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("19.99")).points(20).label("Very Poor").build()
        ));

        ranges.put(RiskFactorType.CASH_BUFFER, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("6")).maxValue(null).points(150).label("Excellent").build(),
                RangeConfig.builder().minValue(new BigDecimal("3")).maxValue(new BigDecimal("5.99")).points(120).label("Good").build(),
                RangeConfig.builder().minValue(new BigDecimal("1.5")).maxValue(new BigDecimal("2.99")).points(90).label("Adequate").build(),
                RangeConfig.builder().minValue(new BigDecimal("0.5")).maxValue(new BigDecimal("1.49")).points(50).label("Low").build(),
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("0.49")).points(20).label("Critical").build()
        ));

        ranges.put(RiskFactorType.CORPORATE_CASH_FLOW, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("50000")).maxValue(null).points(150).label("Excellent").build(),
                RangeConfig.builder().minValue(new BigDecimal("20000")).maxValue(new BigDecimal("49999")).points(120).label("Very Good").build(),
                RangeConfig.builder().minValue(new BigDecimal("5000")).maxValue(new BigDecimal("19999")).points(100).label("Good").build(),
                RangeConfig.builder().minValue(new BigDecimal("0")).maxValue(new BigDecimal("4999")).points(60).label("Fair").build(),
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("-1")).points(20).label("Negative").build()
        ));

        ranges.put(RiskFactorType.PAYMENT_BEHAVIOR, Arrays.asList(
                RangeConfig.builder().minValue(new BigDecimal("80")).maxValue(null).points(100).label("Excellent").build(),
                RangeConfig.builder().minValue(new BigDecimal("60")).maxValue(new BigDecimal("79.99")).points(80).label("Good").build(),
                RangeConfig.builder().minValue(new BigDecimal("40")).maxValue(new BigDecimal("59.99")).points(60).label("Moderate").build(),
                RangeConfig.builder().minValue(new BigDecimal("20")).maxValue(new BigDecimal("39.99")).points(40).label("Poor").build(),
                RangeConfig.builder().minValue(null).maxValue(new BigDecimal("19.99")).points(20).label("Very Poor").build()
        ));

        return ranges;
    }

    private CustomerProfile buildCustomerProfile(CreditRiskRequest request, 
            OpenBankingDataFetcher.AccountInfo accountInfo, List<TransactionData> transactions) {
        
        String analysisStartDate = null;
        String analysisEndDate = null;
        
        if (!transactions.isEmpty()) {
            // Transactions are sorted by date descending, so last is oldest
            LocalDateTime oldest = transactions.stream()
                    .map(TransactionData::getTransactionDateTime)
                    .filter(Objects::nonNull)
                    .min(LocalDateTime::compareTo)
                    .orElse(null);
            LocalDateTime newest = transactions.stream()
                    .map(TransactionData::getTransactionDateTime)
                    .filter(Objects::nonNull)
                    .max(LocalDateTime::compareTo)
                    .orElse(null);
            
            if (oldest != null) {
                analysisStartDate = oldest.format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy"));
            }
            if (newest != null) {
                analysisEndDate = newest.format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy"));
            }
        }
        
        return CustomerProfile.builder()
                .fullName(accountInfo.getAccountHolderName())
                .nationalId(request.getPsuId())
                .age(request.getAge())
                .analysisStartDate(analysisStartDate)
                .analysisEndDate(analysisEndDate)
                .totalTransactions(transactions.size())
                .verifiedTransactions(transactions.size())
                .currentBalance(accountInfo.getCurrentBalance())
                .accountNumber(accountInfo.getAccountNumber())
                .bankName(accountInfo.getBankId())
                .build();
    }
}
