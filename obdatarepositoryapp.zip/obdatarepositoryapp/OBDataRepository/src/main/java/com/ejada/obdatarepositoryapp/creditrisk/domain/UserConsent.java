package com.ejada.obdatarepositoryapp.creditrisk.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.time.Instant;

/**
 * Read-only entity mapping to users_consents table in Open Banking database.
 * Used to cross-reference account link ID with the bank the user consented on.
 */
@Entity
@Table(name = "users_consents")
@Immutable
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserConsent {

    @Id
    @Column(name = "consent_id", nullable = false, length = 300)
    private String consentId;

    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "bank_id", length = 40)
    private String bankId;

    @Column(name = "bank_entity_id")
    private String bankEntityId;

    @Column(name = "integration_method", length = 100)
    private String integrationMethod;

    @Column(name = "expires_at")
    private Instant expiresAt;

    @Column(name = "connection_status", length = 100)
    private String connectionStatus;

    @Column(name = "access_token_expire")
    private Instant accessTokenExpire;

    @Column(name = "access_token", columnDefinition = "text")
    private String accessToken;

    @Column(name = "refresh_token_expire")
    private Instant refreshTokenExpire;

    @Column(name = "refresh_token", columnDefinition = "text")
    private String refreshToken;

    @Column(name = "created_at")
    private Instant createdAt;

    @Column(name = "updated_at")
    private Instant updatedAt;

    @Column(name = "sponsored_tpp_id")
    private String sponsoredTppId;

    @Column(name = "neotek_accounts_link_id")
    private Long neotekAccountsLinkId;

    @Column(name = "data", columnDefinition = "jsonb")
    private String data;
}
