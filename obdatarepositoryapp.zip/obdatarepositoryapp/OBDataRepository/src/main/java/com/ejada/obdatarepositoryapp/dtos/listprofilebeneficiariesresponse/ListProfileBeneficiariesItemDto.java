package com.ejada.obdatarepositoryapp.dtos.listprofilebeneficiariesresponse;

import com.ejada.obdatarepositoryapp.dtos.commondtos.response.FinancialInstitutionDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ListProfileBeneficiariesItemDto {
    @JsonProperty("ProfileId")
    private String profileId;

    @JsonProperty("AccountsLinkId")
    private String accountsLinkId;

    @JsonProperty("FinancialInstitution")
    private FinancialInstitutionDto financialInstitution;

    @JsonProperty("AccountId")
    private String accountId;

    @JsonProperty("BeneficiaryId")
    private String beneficiaryId;

    @JsonProperty("BeneficiaryType")
    private String beneficiaryType;

    @JsonProperty("AccountHolderName")
    private String accountHolderName;

    @JsonProperty("AccountHolderShortName")
    private String accountHolderShortName;

    @JsonProperty("Reference")
    private String reference;

    @JsonProperty("SupplementaryData")
    private Object supplementaryData;

    @JsonProperty("CreditorAgent")
    private CreditorAgentDto creditorAgent;

    @JsonProperty("CreditorAccount")
    @Builder.Default
    private List<CreditorAccountDto> creditorAccount = new ArrayList<>();
}
