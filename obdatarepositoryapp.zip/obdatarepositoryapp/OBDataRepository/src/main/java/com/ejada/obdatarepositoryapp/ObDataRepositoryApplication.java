package com.ejada.obdatarepositoryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(scanBasePackages = {"com.ejada.obdatarepositoryapp", "com.ejada.commons"})
@EntityScan(basePackages = "com.ejada.obrepositoryabstractmodel.entities")
@EnableAsync
@EnableScheduling
@EnableJms
@EnableFeignClients
public class ObDataRepositoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObDataRepositoryApplication.class, args);
	}

}
