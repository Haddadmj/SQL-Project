package com.ejada.obdatarepositoryapp.creditrisk.controller;

import com.ejada.commons.logs.annotations.FailureQueueDescriptor;
import com.ejada.commons.logs.annotations.ServiceDescriptor;
import com.ejada.obdatarepositoryapp.creditrisk.dto.request.CreditRiskRequest;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.CreditRiskReportResponse;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.DebugTransactionsResponse;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.PDFResponse;
import com.ejada.obdatarepositoryapp.creditrisk.exception.CreditRiskException;
import com.ejada.obdatarepositoryapp.creditrisk.service.CreditRiskScoringService;
import com.ejada.obdatarepositoryapp.creditrisk.service.OpenBankingDataFetcher;
import com.ejada.obdatarepositoryapp.creditrisk.service.PdfReportGenerator;
import com.ejada.obdatarepositoryapp.creditrisk.service.PdfReportGeneratorV2;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Base64;

/**
 * REST controller for Credit Risk scoring endpoints.
 * Provides JSON and PDF report generation.
 */
@RestController
@RequestMapping("/api/v1/credit-risk")
@RequiredArgsConstructor
@Slf4j
@FailureQueueDescriptor(destination = "JMS.DRM.CreditRisk.FAILURE")
public class CreditRiskController {

    private final CreditRiskScoringService scoringService;
    private final PdfReportGenerator pdfGenerator;
    private final PdfReportGeneratorV2 pdfGeneratorV2;
    private final OpenBankingDataFetcher dataFetcher;

    /**
     * Generate credit risk report as JSON.
     *
     * @param request Credit risk request with account identifiers and optional configurations
     * @return Credit risk report response
     */
    @PostMapping("/getCreditRiskReport")
    @ServiceDescriptor(name = "getCreditRiskReport", exception = "getCreditRiskReportException")
    public ResponseEntity<CreditRiskReportResponse> getCreditRiskReport(
            @Valid @RequestBody CreditRiskRequest request) {
        
        System.out.println(">>> CREDIT RISK: Request received for psuId=" + request.getPsuId());
        log.info("Received credit risk report request for psuId={}, accountId={}", 
                request.getPsuId(), request.getAccountId());

        System.out.println(">>> CREDIT RISK: Calling scoring service");
        CreditRiskReportResponse response = scoringService.generateReport(request);
        System.out.println(">>> CREDIT RISK: Report generated successfully");
        return ResponseEntity.ok(response);

    }

    /**
     * Generate credit risk report as PDF.
     *
     * @param request Credit risk request with account identifiers and optional configurations
     * @return PDF document bytes
     */
    @PostMapping("/getCreditRiskReport/pdf")
    @ServiceDescriptor(name = "getCreditRiskReportPdf", exception = "getCreditRiskReportPdfException")
    public ResponseEntity<PDFResponse> getCreditRiskReportPdf(
            @Valid @RequestBody CreditRiskRequest request) throws IOException  {
        
        log.info("Received credit risk PDF report request for psuId={}, accountId={}", 
                request.getPsuId(), request.getAccountId());


        CreditRiskReportResponse report = scoringService.generateReport(request);
        byte[] pdfBytes = pdfGenerator.generatePdf(report);
        String pdf_base64 = Base64.getEncoder().encodeToString(pdfBytes);
        PDFResponse pdfResponse = PDFResponse.builder().pdfFile(pdf_base64).build();



        String filename = String.format("credit-risk-report-%s-%s.pdf",
                report.getAccountId(), report.getReportId().substring(0, 8));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
//            headers.setContentDispositionFormData("attachment", filename);
//            headers.setContentLength(pdfBytes.length);

        return new ResponseEntity<>(pdfResponse, headers, HttpStatus.OK);

    }

    /**
     * Generate credit risk report as PDF (Version 2 - Enhanced 8-page report).
     *
     * @param request Credit risk request with account identifiers and optional configurations
     * @return PDF document bytes
     */
    @PostMapping("/getCreditRiskReport/v2/pdf")
    @ServiceDescriptor(name = "getCreditRiskReportPdfV2", exception = "getCreditRiskReportPdfV2Exception")
    public ResponseEntity<PDFResponse> getCreditRiskReportPdfV2(
            @Valid @RequestBody CreditRiskRequest request) throws IOException{
        
        log.info("Received credit risk PDF V2 report request for psuId={}, accountId={}", 
                request.getPsuId(), request.getAccountId());

        CreditRiskReportResponse report = scoringService.generateReport(request);
        byte[] pdfBytes = pdfGeneratorV2.generatePdf(report);
        String pdf_base64 = Base64.getEncoder().encodeToString(pdfBytes);
        PDFResponse pdfResponse = PDFResponse.builder().pdfFile(pdf_base64).build();


        String filename = String.format("credit-risk-report-v2-%s-%s.pdf",
                report.getAccountId(), report.getReportId().substring(0, 8));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
//            headers.setContentDispositionFormData("attachment", filename);
//            headers.setContentLength(pdfBytes.length);

        return new ResponseEntity<>(pdfResponse, headers, HttpStatus.OK);

    }

    /**
     * Debug endpoint: returns the raw, database-decrypted rows from both the
     * raw_transactions table (ObTransactionRepository) and the
     * drahim_transactions table (DrahimTransactionRepository) for the given
     * identifiers, so data availability and decryption can be inspected.
     *
     * <p>Example:
     * {@code GET /api/v1/credit-risk/debug/transactions?psuId=...&accountLinkId=...&accountId=...&sponsoredTppId=...}</p>
     *
     * @param psuId          PSU ID (user id)
     * @param accountId      Account ID (integrated id from the request); resolved to the internal id
     * @param sponsoredTppId Sponsored TPP ID (client identifier)
     * @param accountLinkId  Account Link ID (consent); optional, used only for account resolution
     * @return raw rows from both transaction tables with row counts
     */
    @GetMapping("/debug/transactions")
    @ServiceDescriptor(name = "debugTransactions", exception = "debugTransactionsException")
    public ResponseEntity<DebugTransactionsResponse> debugTransactions(
            @RequestParam String psuId,
            @RequestParam String accountId,
            @RequestParam String sponsoredTppId,
            @RequestParam(required = false) String accountLinkId) {

        log.info("Debug transactions request for psuId={}, accountId={}, sponsoredTppId={}",
                psuId, accountId, sponsoredTppId);

        DebugTransactionsResponse response = dataFetcher.debugTransactions(
                psuId, accountLinkId, accountId, sponsoredTppId);

        return ResponseEntity.ok(response);
    }

    /**
     * Health check endpoint for credit risk service.
     */
    @GetMapping("/health")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Credit Risk Service is running");
    }
}
