package com.ejada.obdatarepositoryapp.dtos.listprofilebeneficiariesresponse;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditorAccountDto {
    @JsonProperty("IdentificationType")
    private String identificationType;

    @JsonProperty("Identification")
    private String identification;
}
