package com.ejada.obdatarepositoryapp.creditrisk.domain;

import java.time.Instant;

/**
 * Projection interface for database-level decrypted transaction data.
 * Used with native queries that utilize pgp_sym_decrypt().
 */
public interface DecryptedTransactionProjection {
    
    String getId();
    
    String getUserId();
    
    String getAccountId();
    
    String getStatus();
    
    String getType();
    
    String getExtractedMerchantName();
    
    Instant getCreatedAt();
    
    String getDecryptedData();
}
