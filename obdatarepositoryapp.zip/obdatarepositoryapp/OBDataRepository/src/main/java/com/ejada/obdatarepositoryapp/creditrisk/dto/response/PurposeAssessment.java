package com.ejada.obdatarepositoryapp.creditrisk.dto.response;

import com.ejada.obdatarepositoryapp.creditrisk.enums.LoanPurpose;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Assessment of the requested credit purpose and amount.
 * Only populated if purpose and amount are provided in request.
 * Currency is SAR by default.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PurposeAssessment {
    
    private LoanPurpose purpose;
    private String purposeDisplayName;
    private BigDecimal requestedAmount;
    private Boolean isAffordable;
    private BigDecimal estimatedMonthlyPayment;
    private String debtToIncomeAfterLoan;
    private String affordabilityAssessment;
    private String riskLevel;
}
