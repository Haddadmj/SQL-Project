package com.ejada.obdatarepositoryapp.creditrisk.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Loan purpose types for credit risk assessment.
 */
@Getter
@RequiredArgsConstructor
public enum LoanPurpose {
    
    PERSONAL_FINANCE("Personal Finance"),
    CAR_LOAN("Car Loan"),
    HOME_MORTGAGE("Home Mortgage"),
    EDUCATION("Education"),
    MEDICAL("Medical"),
    BUSINESS("Business"),
    DEBT_CONSOLIDATION("Debt Consolidation"),
    TRAVEL("Travel"),
    WEDDING("Wedding"),
    HOME_IMPROVEMENT("Home Improvement"),
    OTHER("Other");

    private final String displayName;
}
