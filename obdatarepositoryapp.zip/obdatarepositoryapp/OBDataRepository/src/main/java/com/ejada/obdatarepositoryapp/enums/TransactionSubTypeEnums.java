package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum TransactionSubTypeEnums {
    PURCHASE("KSAOB.Purchase"),
    REVERSAL("KSAOB.Reversal"),
    REFUND("KSAOB.Refund"),
    WITHDRAWAL("KSAOB.Withdrawal"),
    WITHDRAWAL_REVERSAL("KSAOB.WithdrawalReversal"),
    DEPOSIT("KSAOB.Deposit"),
    DEPOSIT_REVERSAL("KSAOB.DepositReversal"),
    MONEY_TRANSFER("KSAOB.MoneyTransfer"),
    NOT_APPLICABLE("KSAOB.NotApplicable");

    private final String value;

    TransactionSubTypeEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static TransactionSubTypeEnums fromValue(String text) {
        for (TransactionSubTypeEnums b : TransactionSubTypeEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
