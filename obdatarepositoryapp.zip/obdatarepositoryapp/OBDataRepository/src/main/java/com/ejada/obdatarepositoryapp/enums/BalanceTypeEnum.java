package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum BalanceTypeEnum {

    KSAOB_CLOSING_AVAILABLE("KSAOB.ClosingAvailable"),
    KSAOB_CLOSING_BOOKED("KSAOB.ClosingBooked"),
    KSAOB_CLOSING_CLEARED("KSAOB.ClosingCleared"),
    KSAOB_EXPECTED("KSAOB.Expected"),
    KSAOB_FORWARD_AVAILABLE("KSAOB.ForwardAvailable"),
    KSAOB_INFORMATION("KSAOB.Information"),
    KSAOB_INTERIM_BOOKED("KSAOB.InterimBooked"),
    KSAOB_INTERIM_CLEARED("KSAOB.InterimCleared"),
    KSAOB_INTERIM_AVAILABLE("KSAOB.InterimAvailable"),
    KSAOB_OPENING_BOOKED("KSAOB.OpeningBooked"),
    KSAOB_OPENING_CLEARED("KSAOB.OpeningCleared"),
    KSAOB_OPENING_AVAILABLE("KSAOB.OpeningAvailable"),
    KSAOB_PreviouslyClosedBooked("KSAOB.PreviouslyClosedBooked"),

    ;

    private final String value;

    BalanceTypeEnum(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static BalanceTypeEnum fromValue(String text) {
        for (BalanceTypeEnum b : BalanceTypeEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
