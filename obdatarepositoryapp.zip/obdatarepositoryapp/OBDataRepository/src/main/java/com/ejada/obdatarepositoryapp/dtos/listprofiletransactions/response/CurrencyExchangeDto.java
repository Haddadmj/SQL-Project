package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_EMPTY)
public class CurrencyExchangeDto {
    @JsonProperty("SourceCurrency")
    private String sourceCurrency;

    @JsonProperty("TargetCurrency")
    private String targetCurrency;

    @JsonProperty("UnitCurrency")
    private String unitCurrency;

    @JsonProperty("ExchangeRate")
    private BigDecimal exchangeRate;

    @JsonProperty("ContractIdentification")
    private String contractIdentification;

    @JsonProperty("QuotationDate")
    private OffsetDateTime quotationDate;

    @JsonProperty("InstructedAmount")
    private AmountDto instructedAmount;
}
