package com.ejada.obdatarepositoryapp.enums;

import lombok.Getter;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

@Getter
public enum CardSchemeNameEnums {
    AMERICAN_EXPRESS("KSAOB.AmericanExpress"),
    DINERS("KSAOB.Diners"),
    DISCOVER("KSAOB.Discover"),
    GCC("KSAOB.GCC"),
    MASTER_CARD("KSAOB.MasterCard"),
    UPI("KSAOB.UPI"),
    VISA("KSAOB.VISA"),
    MADA("KSAOB.mada");


    private final String value;

    CardSchemeNameEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static CardSchemeNameEnums fromValue(String text) {
        for (CardSchemeNameEnums b : CardSchemeNameEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
