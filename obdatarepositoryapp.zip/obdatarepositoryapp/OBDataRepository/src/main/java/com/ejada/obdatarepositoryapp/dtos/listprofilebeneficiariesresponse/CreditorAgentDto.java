package com.ejada.obdatarepositoryapp.dtos.listprofilebeneficiariesresponse;

import com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response.PostalAddressDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditorAgentDto {
    @JsonProperty("IdentificationType")
    private String identificationType;

    @JsonProperty("Identification")
    private String identification;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("PostalAddress")
    private PostalAddressDto postalAddress;
}
