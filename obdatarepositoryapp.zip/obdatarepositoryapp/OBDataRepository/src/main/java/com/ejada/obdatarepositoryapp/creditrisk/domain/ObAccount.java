package com.ejada.obdatarepositoryapp.creditrisk.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.time.Instant;

/**
 * Read-only entity mapping to accounts table in Open Banking database.
 * Contains account information including balance data as JSON.
 */
@Entity
@Table(name = "accounts")
@Immutable
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ObAccount {

    @Id
    @Column(name = "id", nullable = false, length = 26)
    private String id;

    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "bank_id")
    private String bankId;

    @Column(name = "integrated_id")
    private String integratedId;

    @Column(name = "connection_status")
    private String connectionStatus;

    @Column(name = "type")
    private String type;

    @Column(name = "data", columnDefinition = "text")
    private String data;

    @Column(name = "sponsored_tpp_id")
    private String sponsoredTppId;

    @Column(name = "encrypted_data")
    private byte[] encryptedData;

    @Column(name = "created_at")
    private Instant createdAt;

    @Column(name = "updated_at")
    private Instant updatedAt;
}
