package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigInteger;


@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BillDetailsDto {
    @JsonProperty("BillerId")
    private BigInteger billerId;

    @JsonProperty("BillNumber")
    private String billNumber;

    @JsonProperty("BillPaymentType")
    private String billPaymentType;
}
