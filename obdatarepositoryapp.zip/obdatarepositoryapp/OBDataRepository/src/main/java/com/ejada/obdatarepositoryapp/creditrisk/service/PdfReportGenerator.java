package com.ejada.obdatarepositoryapp.creditrisk.service;

import com.ejada.obdatarepositoryapp.creditrisk.dto.response.*;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CreditRatingClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Service for generating PDF credit risk reports.
 * Creates professional 5-page PDF reports following the Figma design.
 * 
 * Page 1: Executive Summary - Customer Profile, Credit Score, Key Metrics, Recommendation
 * Page 2: Credit Score Component Breakdown - Factor scores table
 * Page 3: Financial Health Indicators - Metrics with industry standards
 * Page 4: Transaction Analysis - Income breakdown, expense categories
 * Page 5: Loan Exposure & Final Recommendation - Debt profile, credit class reference
 */
@Service
@Slf4j
public class PdfReportGenerator {

    private static final float MARGIN = 40;
    private static final float PAGE_WIDTH = PDRectangle.A4.getWidth();
    private static final float PAGE_HEIGHT = PDRectangle.A4.getHeight();
    private static final float CONTENT_WIDTH = PAGE_WIDTH - 2 * MARGIN;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MMMM d, yyyy");

    // Design colors from Figma
    private static final Color ORANGE_PRIMARY = new Color(255, 102, 0);
    private static final Color GREEN_SUCCESS = new Color(76, 175, 80);
    private static final Color GRAY_TEXT = new Color(100, 100, 100);
    private static final Color GRAY_LIGHT = new Color(245, 245, 245);
    private static final Color GRAY_BORDER = new Color(224, 224, 224);
    private static final Color RED_DANGER = new Color(244, 67, 54);
    private static final Color YELLOW_WARNING = new Color(255, 193, 7);
    private static final Color DARK_BG = new Color(51, 51, 51);

    public byte[] generatePdf(CreditRiskReportResponse report) throws IOException {
        try (PDDocument document = new PDDocument();
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            // Page 1: Executive Summary
            drawPage1ExecutiveSummary(document, report);
            
            // Page 2: Credit Score Component Breakdown
            drawPage2ScoreBreakdown(document, report);
            
            // Page 3: Financial Health Indicators
            drawPage3FinancialHealth(document, report);
            
            // Page 4: Transaction Analysis
            drawPage4TransactionAnalysis(document, report);
            
            // Page 5: Loan Exposure & Final Recommendation
            drawPage5LoanExposure(document, report);

            document.save(baos);
            return baos.toByteArray();
        }
    }

    // ==================== PAGE 1: EXECUTIVE SUMMARY ====================
    
    private void drawPage1ExecutiveSummary(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            // Header with logo and date
            y = drawPageHeader(document, cs, report, y);
            
            // Section title: EXECUTIVE SUMMARY
            y = drawSectionTitle(cs, "EXECUTIVE SUMMARY", y);
            
            // Customer Profile box with Credit Score circle
            y = drawCustomerProfileSection(cs, report, y);
            
            // Four metric boxes
            y = drawMetricBoxes(cs, report, y);
            
            // Risk Level and Recommendation bar
            drawRecommendationBar(cs, report, y);
            
            // Footer
            drawPageFooter(cs, 1);
        }
    }

    private float drawPageHeader(PDDocument document, PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        // Load and draw Neotek logo
        try {
            ClassPathResource logoResource = new ClassPathResource("neotek-logo.png");
            try (InputStream logoStream = logoResource.getInputStream()) {
                PDImageXObject logo = PDImageXObject.createFromByteArray(document, logoStream.readAllBytes(), "neotek-logo");
                float logoHeight = 30;
                float logoWidth = logoHeight * logo.getWidth() / logo.getHeight();
                cs.drawImage(logo, MARGIN, y - logoHeight + 10, logoWidth, logoHeight);
            }
        } catch (Exception e) {
            // Fallback to text if logo cannot be loaded
            log.warn("Could not load logo image, using text fallback: {}", e.getMessage());
            cs.setNonStrokingColor(ORANGE_PRIMARY);
            cs.beginText();
            cs.setFont(fontBold, 24);
            cs.newLineAtOffset(MARGIN, y);
            cs.showText("neotek");
            cs.endText();
        }
        
        // Date on right side
        String dateStr = report.getGeneratedAt().format(DATE_FORMATTER);
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(PAGE_WIDTH - MARGIN - 120, y);
        cs.showText(dateStr);
        cs.endText();
        
        // Confidential note
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(PAGE_WIDTH - MARGIN - 150, y - 15);
        cs.showText("CONFIDENTIAL - INTERNAL USE ONLY");
        cs.endText();
        
        return y - 60;
    }

    private float drawSectionTitle(PDPageContentStream cs, String title, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        
        // Orange bar
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        cs.addRect(MARGIN, y - 5, 4, 20);
        cs.fill();
        
        // Title text
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 16);
        cs.newLineAtOffset(MARGIN + 12, y);
        cs.showText(title);
        cs.endText();
        
        return y - 40;
    }

    private float drawCustomerProfileSection(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        // Customer Profile box background - white with light border and rounded corners
        float boxHeight = 180;
        float radius = 8;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // Box border - light gray with rounded corners
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // "CUSTOMER PROFILE" header
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 9);
        cs.newLineAtOffset(MARGIN + 15, y - 25);
        cs.showText("CUSTOMER PROFILE");
        cs.endText();
        
        CustomerProfile profile = report.getCustomerProfile();
        float labelY = y - 50;
        float col1X = MARGIN + 15;
        float col2X = MARGIN + 180;
        
        // Full Name
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, labelY);
        cs.showText("FULL NAME");
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col1X, labelY - 15);
        cs.showText(profile != null && profile.getFullName() != null ? profile.getFullName() : "N/A");
        cs.endText();
        
        // National ID (UNN for corporates)
        String nationalIdLabel = report.getCustomerType() == com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType.CORPORATE 
                ? "UNN" : "NATIONAL ID";
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col2X, labelY);
        cs.showText(nationalIdLabel);
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col2X, labelY - 15);
        cs.showText(profile != null && profile.getNationalId() != null ? profile.getNationalId() : "N/A");
        cs.endText();
        
        labelY -= 45;
        
        // Age (instead of Date of Birth)
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, labelY);
        cs.showText("AGE");
        cs.endText();
        
        String ageStr = profile != null && profile.getAge() != null ? profile.getAge() + " Yrs" : "N/A";
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col1X, labelY - 15);
        cs.showText(ageStr);
        cs.endText();
        
        // Analysis Period
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col2X, labelY);
        cs.showText("ANALYSIS PERIOD");
        cs.endText();
        
        String periodStr = "N/A";
        if (profile != null && profile.getAnalysisStartDate() != null && profile.getAnalysisEndDate() != null) {
            periodStr = profile.getAnalysisStartDate() + " - " + profile.getAnalysisEndDate();
        }
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col2X, labelY - 15);
        cs.showText(periodStr);
        cs.endText();
        
        labelY -= 45;
        
        // Total Transactions
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(col1X, labelY);
        cs.showText("TOTAL TRANSACTIONS");
        cs.endText();
        
        String txnStr = profile != null && profile.getTotalTransactions() != null 
                ? profile.getTotalTransactions() + " Verified" : "N/A";
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(col1X, labelY - 15);
        cs.showText(txnStr);
        cs.endText();
        
        // Credit Score Circle (right side of box) - positioned further right and vertically centered
        drawCreditScoreCircle(cs, report, MARGIN + CONTENT_WIDTH - 90, y - 90);
        
        return y - boxHeight - 20;
    }

    private void drawCreditScoreCircle(PDPageContentStream cs, CreditRiskReportResponse report, float cx, float cy) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        float radius = 55;
        Color scoreColor = getScoreColor(report.getRatingClass());
        
        // Draw circle outline (simplified - just a colored arc representation)
        cs.setStrokingColor(scoreColor);
        cs.setLineWidth(8);
        
        // Draw arc segments to represent score progress
        int segments = 60;
        double scoreRatio = (double) report.getTotalScore() / report.getMaxPossibleScore();
        int filledSegments = (int) (segments * scoreRatio);
        
        for (int i = 0; i < segments; i++) {
            double angle1 = Math.PI * 1.5 + (2 * Math.PI * i / segments);
            double angle2 = Math.PI * 1.5 + (2 * Math.PI * (i + 1) / segments);
            
            float x1 = cx + (float) (radius * Math.cos(angle1));
            float y1 = cy + (float) (radius * Math.sin(angle1));
            float x2 = cx + (float) (radius * Math.cos(angle2));
            float y2 = cy + (float) (radius * Math.sin(angle2));
            
            if (i < filledSegments) {
                cs.setStrokingColor(scoreColor);
            } else {
                cs.setStrokingColor(GRAY_BORDER);
            }
            cs.moveTo(x1, y1);
            cs.lineTo(x2, y2);
            cs.stroke();
        }
        
        cs.setLineWidth(1);
        
        // Score number in center
        cs.setNonStrokingColor(scoreColor);
        cs.beginText();
        cs.setFont(fontBold, 36);
        String scoreStr = String.valueOf(report.getTotalScore());
        float scoreWidth = fontBold.getStringWidth(scoreStr) / 1000 * 36;
        cs.newLineAtOffset(cx - scoreWidth / 2, cy + 5);
        cs.showText(scoreStr);
        cs.endText();
        
        // "CLASS XX" below score
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 10);
        String classStr = "CLASS " + report.getRatingClass().name();
        float classWidth = font.getStringWidth(classStr) / 1000 * 10;
        cs.newLineAtOffset(cx - classWidth / 2, cy - 15);
        cs.showText(classStr);
        cs.endText();
        
        // Rating description below circle
        cs.setNonStrokingColor(scoreColor);
        cs.beginText();
        cs.setFont(fontBold, 11);
        String ratingName = report.getRatingClassName();
        float ratingWidth = fontBold.getStringWidth(ratingName) / 1000 * 11;
        cs.newLineAtOffset(cx - ratingWidth / 2, cy - radius - 20);
        cs.showText(ratingName);
        cs.endText();
    }

    private float drawMetricBoxes(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        float boxWidth = (CONTENT_WIDTH - 30) / 4;
        float boxHeight = 80;
        float startX = MARGIN;
        
        // Box 1: Median Income
        drawMetricBox(cs, startX, y - boxHeight, boxWidth, boxHeight,
                "MEDIAN INCOME (L3M)",
                formatCurrency(metrics != null ? metrics.getMedianMonthlyIncome() : null),
                "Verifiable 100%", ORANGE_PRIMARY, font, fontBold);
        
        // Box 2: Monthly Cash Flow  
        drawMetricBox(cs, startX + boxWidth + 10, y - boxHeight, boxWidth, boxHeight,
                "MONTHLY CASH FLOW",
                formatCurrency(metrics != null ? metrics.getAverageMonthlySurplus() : null),
                "Surplus " + (metrics != null && metrics.getSurplusRatio() != null ? 
                        formatPercentageShort(metrics.getSurplusRatio()) : "N/A"), 
                ORANGE_PRIMARY, font, fontBold);
        
        // Box 3: Debt-to-Income
        String dtiValue = metrics != null && metrics.getDebtBurdenRatio() != null ?
                formatPercentageShort(metrics.getDebtBurdenRatio()) : "N/A";
        drawMetricBox(cs, startX + 2 * (boxWidth + 10), y - boxHeight, boxWidth, boxHeight,
                "DEBT-TO-INCOME",
                dtiValue,
                "Excellent", ORANGE_PRIMARY, font, fontBold);
        
        // Box 4: Current Balance
        CustomerProfile profile = report.getCustomerProfile();
        drawMetricBox(cs, startX + 3 * (boxWidth + 10), y - boxHeight, boxWidth, boxHeight,
                "CURRENT BALANCE",
                formatCurrency(profile != null ? profile.getCurrentBalance() : null),
                "Healthy Level", ORANGE_PRIMARY, font, fontBold);
        
        return y - boxHeight - 30;
    }

    private void drawMetricBox(PDPageContentStream cs, float x, float y, float width, float height,
            String label, String value, String status, Color statusColor,
            PDType1Font font, PDType1Font fontBold) throws IOException {
        
        float radius = 6;
        
        // Box background with rounded corners
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, x, y, width, height, radius);
        
        // Box border with rounded corners
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, x, y, width, height, radius);
        
        // Label
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 7);
        cs.newLineAtOffset(x + 10, y + height - 20);
        cs.showText(label);
        cs.endText();
        
        // Value
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 14);
        cs.newLineAtOffset(x + 10, y + height - 40);
        cs.showText(value);
        cs.endText();
        
        // Status indicator
        cs.setNonStrokingColor(statusColor);
        cs.addRect(x + 10, y + 12, 6, 6);
        cs.fill();
        
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(x + 20, y + 12);
        cs.showText(status);
        cs.endText();
    }

    private void drawRecommendationBar(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        float barHeight = 70;
        float radius = 8;
        
        // Dark background bar with rounded corners
        cs.setNonStrokingColor(DARK_BG);
        drawRoundedRect(cs, MARGIN, y - barHeight, CONTENT_WIDTH, barHeight, radius);
        
        // Overall Risk Level label
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 9);
        cs.newLineAtOffset(MARGIN + 25, y - 22);
        cs.showText("OVERALL RISK LEVEL");
        cs.endText();
        
        // Risk level badge with rounded corners
        Color riskColor = getRiskLevelColor(report.getRatingClass());
        String riskText = getRiskLevelText(report.getRatingClass());
        float badgeWidth = 90;
        float badgeHeight = 24;
        float badgeX = MARGIN + 25;
        float badgeY = y - 55;
        
        cs.setNonStrokingColor(riskColor);
        drawRoundedRect(cs, badgeX, badgeY, badgeWidth, badgeHeight, 4);
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 10);
        float textWidth = fontBold.getStringWidth(riskText) / 1000 * 10;
        cs.newLineAtOffset(badgeX + (badgeWidth - textWidth) / 2, badgeY + 7);
        cs.showText(riskText);
        cs.endText();
        
        // Vertical separator line
        cs.setStrokingColor(new Color(80, 80, 80));
        cs.setLineWidth(1);
        cs.moveTo(MARGIN + 160, y - 15);
        cs.lineTo(MARGIN + 160, y - barHeight + 15);
        cs.stroke();
        
        // Recommendation section
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 9);
        cs.newLineAtOffset(MARGIN + 185, y - 22);
        cs.showText("RECOMMENDATION");
        cs.endText();
        
        // Recommendation text - color based on rating
        Color recommendationColor = getRecommendationColor(report.getRatingClass());
        cs.setNonStrokingColor(recommendationColor);
        cs.beginText();
        cs.setFont(fontBold, 22);
        cs.newLineAtOffset(MARGIN + 185, y - 50);
        String recommendation = getRecommendationText(report.getApprovalRecommendation());
        cs.showText(recommendation);
        cs.endText();
    }
    
    private Color getRecommendationColor(CreditRatingClass ratingClass) {
        if (ratingClass == null) return ORANGE_PRIMARY;
        switch (ratingClass) {
            case AAA:
            case AA:
            case A:
                return GREEN_SUCCESS;
            case BBB:
            case BB:
                return ORANGE_PRIMARY;
            default:
                return RED_DANGER;
        }
    }
    
    private String getRecommendationText(String approval) {
        if (approval == null) return "REVIEW REQUIRED";
        switch (approval.toUpperCase()) {
            case "APPROVE":
            case "HIGH":
                return "HIGHLY RECOMMENDED";
            case "MODERATE":
                return "MODERATE";
            case "LOW":
            case "CAUTION":
                return "CAUTION";
            case "REJECT":
                return "NOT RECOMMENDED";
            default:
                return approval.toUpperCase();
        }
    }

    private void drawPageFooter(PDPageContentStream cs, int pageNumber) throws IOException {
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN, 30);
        cs.showText("Generated by Automated Credit Scoring System");
        cs.endText();
        
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(PAGE_WIDTH - MARGIN - 40, 30);
        cs.showText("Page " + pageNumber);
        cs.endText();
    }

    // ==================== PAGE 2: CREDIT SCORE COMPONENT BREAKDOWN ====================
    
    private void drawPage2ScoreBreakdown(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "CREDIT SCORE COMPONENT BREAKDOWN", y);
            y = drawFactorScoresTable(cs, report, y);
            
            drawPageFooter(cs, 2);
        }
    }

    private float drawFactorScoresTable(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        // Table header with rounded corners
        float[] colWidths = {180, 65, 50, 40, 60, 85};
        String[] headers = {"Component", "Raw Value", "Score", "Max", "% Contrib.", "Assessment"};
        float radius = 6;
        
        cs.setNonStrokingColor(GRAY_LIGHT);
        drawRoundedRect(cs, MARGIN, y - 25, CONTENT_WIDTH, 25, radius);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        float xPos = MARGIN + 10;
        for (int i = 0; i < headers.length; i++) {
            cs.beginText();
            cs.setFont(font, 8);
            cs.newLineAtOffset(xPos, y - 17);
            cs.showText(headers[i].toUpperCase());
            cs.endText();
            xPos += colWidths[i];
        }
        y -= 30;
        
        // Factor rows
        List<FactorScore> factors = report.getFactorScores();
        if (factors != null) {
            for (FactorScore factor : factors) {
                if (Boolean.TRUE.equals(factor.getDataAvailable())) {
                    y = drawFactorTableRow(cs, factor, y, colWidths, font, fontBold);
                }
            }
        }
        
        // Total row with rounded corners
        y -= 10;
        cs.setNonStrokingColor(ORANGE_PRIMARY);
        drawRoundedRect(cs, MARGIN, y - 25, CONTENT_WIDTH, 25, radius);
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(MARGIN + 10, y - 17);
        cs.showText("TOTAL SCORE");
        cs.endText();
        
        cs.beginText();
        cs.setFont(fontBold, 12);
        cs.newLineAtOffset(MARGIN + 220, y - 17);
        cs.showText(String.valueOf(report.getTotalScore()));
        cs.endText();
        
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(MARGIN + 280, y - 17);
        cs.showText(String.valueOf(report.getMaxPossibleScore()));
        cs.endText();
        
        // Calculate actual score percentage
        int scorePercentage = report.getMaxPossibleScore() > 0 ? 
                (report.getTotalScore() * 100) / report.getMaxPossibleScore() : 0;
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(MARGIN + 330, y - 17);
        cs.showText(scorePercentage + "%");
        cs.endText();
        
        // Class badge
        cs.setNonStrokingColor(GREEN_SUCCESS);
        cs.addRect(MARGIN + 410, y - 22, 70, 18);
        cs.fill();
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 9);
        cs.newLineAtOffset(MARGIN + 420, y - 17);
        cs.showText("CLASS " + report.getRatingClass().name());
        cs.endText();
        
        return y - 40;
    }

    private float drawFactorTableRow(PDPageContentStream cs, FactorScore factor, float y, 
            float[] colWidths, PDType1Font font, PDType1Font fontBold) throws IOException {
        
        float rowHeight = 35;
        
        // Alternating row background
        cs.setNonStrokingColor(Color.WHITE);
        cs.addRect(MARGIN, y - rowHeight, CONTENT_WIDTH, rowHeight);
        cs.fill();
        
        // Bottom border
        cs.setStrokingColor(GRAY_BORDER);
        cs.moveTo(MARGIN, y - rowHeight);
        cs.lineTo(MARGIN + CONTENT_WIDTH, y - rowHeight);
        cs.stroke();
        
        float xPos = MARGIN + 10;
        float textY = y - 22;
        
        // Component name with underline (use smaller font to fit long names)
        String componentName = factor.getFactorName();
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 8);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(componentName != null ? componentName : "N/A");
        cs.endText();
        
        // Orange underline
        cs.setStrokingColor(ORANGE_PRIMARY);
        cs.setLineWidth(2);
        cs.moveTo(xPos, textY - 5);
        cs.lineTo(xPos + 100, textY - 5);
        cs.stroke();
        cs.setLineWidth(1);
        
        xPos += colWidths[0];
        
        // Raw Value
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(factor.getFormattedValue() != null ? factor.getFormattedValue() : "N/A");
        cs.endText();
        xPos += colWidths[1];
        
        // Score
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.valueOf(factor.getScore()));
        cs.endText();
        xPos += colWidths[2];
        
        // Max
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(String.valueOf(factor.getMaxScore()));
        cs.endText();
        xPos += colWidths[3];
        
        // % Contribution
        String pctStr = factor.getPercentage() != null ? 
                String.format("%.1f%%", factor.getPercentage()) : "N/A";
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(xPos, textY);
        cs.showText(pctStr);
        cs.endText();
        xPos += colWidths[4];
        
        // Assessment badge with color based on score - rounded corners
        String label = factor.getScoreLabel() != null ? factor.getScoreLabel() : "N/A";
        Color badgeColor = getAssessmentBadgeColor(factor.getPercentage());
        Color textColor = Color.WHITE;
        
        // Draw badge background with rounded corners
        cs.setNonStrokingColor(badgeColor);
        drawRoundedRect(cs, xPos, textY - 6, 75, 20, 4);
        
        // Badge text centered
        cs.setNonStrokingColor(textColor);
        cs.beginText();
        cs.setFont(font, 9);
        float labelWidth = font.getStringWidth(label) / 1000 * 9;
        cs.newLineAtOffset(xPos + (75 - labelWidth) / 2, textY - 1);
        cs.showText(label);
        cs.endText();
        
        return y - rowHeight;
    }
    
    private Color getAssessmentBadgeColor(Double percentage) {
        if (percentage == null) return GRAY_TEXT;
        if (percentage >= 80) return GREEN_SUCCESS;       // Excellent
        if (percentage >= 60) return new Color(139, 195, 74);  // Good - light green
        if (percentage >= 40) return ORANGE_PRIMARY;      // Average
        if (percentage >= 20) return YELLOW_WARNING;      // Below Average
        return RED_DANGER;                                // Poor
    }

    // ==================== PAGE 3: FINANCIAL HEALTH INDICATORS ====================
    
    private void drawPage3FinancialHealth(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "FINANCIAL HEALTH INDICATORS", y);
            y = drawHealthIndicatorsTable(cs, report, y);
            
            drawPageFooter(cs, 3);
        }
    }

    private float drawHealthIndicatorsTable(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        if (metrics == null) return y;
        
        boolean isCorporate = report.getCustomerType() == com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType.CORPORATE;
        
        // Table header
        cs.setNonStrokingColor(GRAY_LIGHT);
        cs.addRect(MARGIN, y - 25, CONTENT_WIDTH, 25);
        cs.fill();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 15, y - 17);
        cs.showText("METRIC");
        cs.endText();
        
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 250, y - 17);
        cs.showText("VALUE");
        cs.endText();
        
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 380, y - 17);
        cs.showText("INDUSTRY STANDARD");
        cs.endText();
        
        y -= 30;
        
        if (isCorporate) {
            // Corporate health indicators
            y = drawHealthRow(cs, "Revenue Stability", formatCoefficientOfVariation(metrics.getRevenueStabilityCoefficient()), "< 20% CoV", y, font, fontBold);
            y = drawHealthRow(cs, "Revenue Trend", formatPercentageShort(metrics.getRevenueTrendPercentage()), "> 0% (Growth)", y, font, fontBold);
            y = drawHealthRow(cs, "Operating Expense Ratio", formatPercentageShort(metrics.getOperatingExpenseRatio()), "< 80%", y, font, fontBold);
            y = drawHealthRow(cs, "Supplier Payment Score", formatScore(metrics.getSupplierPaymentConsistencyScore()), "> 80%", y, font, fontBold);
            y = drawHealthRow(cs, "Cash Buffer", formatCashBuffer(metrics.getCashBufferMonths()), "> 3 Months", y, font, fontBold);
            y = drawHealthRow(cs, "Corporate Cash Flow", formatCurrency(metrics.getCorporateCashFlow()), "Positive", y, font, fontBold);
            y = drawHealthRow(cs, "Payment Behavior Score", formatScore(metrics.getPaymentBehaviorScore()), "> 80%", y, font, fontBold);
            y = drawHealthRow(cs, "Unique Suppliers", metrics.getUniqueSupplierCount() != null ? metrics.getUniqueSupplierCount() + "" : "N/A", "Diversified", y, font, fontBold);
        } else {
            // Retail health indicators
            y = drawHealthRow(cs, "Debt-to-Income Ratio", formatPercentageShort(metrics.getDebtBurdenRatio()), "< 35%", y, font, fontBold);
            y = drawHealthRow(cs, "Savings Rate", formatPercentageShort(metrics.getSavingsRate()), "> 15%", y, font, fontBold);
            y = drawHealthRow(cs, "Surplus Ratio", formatPercentageShort(metrics.getSurplusRatio()), "> 20%", y, font, fontBold);
            y = drawHealthRow(cs, "Monthly Cash Flow", formatCurrency(metrics.getAverageMonthlySurplus()), "Positive", y, font, fontBold);
            y = drawHealthRow(cs, "Emergency Fund", formatEmergencyFund(metrics.getEmergencyFundMonths()), "> 3 Months", y, font, fontBold);
            y = drawHealthRow(cs, "Avg Balance (6M)", formatCurrency(metrics.getAverageBalance6M()), "Stable", y, font, fontBold);
            y = drawHealthRow(cs, "Negative Balance Days", metrics.getNegativeBalanceDays() != null ? metrics.getNegativeBalanceDays() + " Days" : "N/A", "0 Days", y, font, fontBold);
            y = drawHealthRow(cs, "Salary Regularity", formatSalaryRegularity(metrics), "> 90%", y, font, fontBold);
        }
        
        return y;
    }
    
    private String formatCoefficientOfVariation(BigDecimal cov) {
        if (cov == null) return "N/A";
        return String.format("%.1f%% CoV", cov.multiply(BigDecimal.valueOf(100)));
    }
    
    private String formatScore(BigDecimal score) {
        if (score == null) return "N/A";
        return String.format("%.0f%%", score.multiply(BigDecimal.valueOf(100)));
    }
    
    private String formatCashBuffer(BigDecimal months) {
        if (months == null) return "N/A";
        return String.format("%.1f Months", months);
    }

    private float drawHealthRow(PDPageContentStream cs, String metric, String value, String standard,
            float y, PDType1Font font, PDType1Font fontBold) throws IOException {
        
        float rowHeight = 40;
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.addRect(MARGIN, y - rowHeight, CONTENT_WIDTH, rowHeight);
        cs.fill();
        
        cs.setStrokingColor(GRAY_BORDER);
        cs.moveTo(MARGIN, y - rowHeight);
        cs.lineTo(MARGIN + CONTENT_WIDTH, y - rowHeight);
        cs.stroke();
        
        float textY = y - 25;
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(MARGIN + 15, textY);
        cs.showText(metric);
        cs.endText();
        
        cs.beginText();
        cs.setFont(fontBold, 11);
        cs.newLineAtOffset(MARGIN + 250, textY);
        cs.showText(value);
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(MARGIN + 380, textY);
        cs.showText(standard);
        cs.endText();
        
        return y - rowHeight;
    }

    // ==================== PAGE 4: TRANSACTION ANALYSIS ====================
    
    private void drawPage4TransactionAnalysis(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "TRANSACTION ANALYSIS", y);
            y = drawIncomeBreakdown(cs, report, y);
            y = drawExpenseCategories(cs, report, y);
            
            drawPageFooter(cs, 4);
        }
    }

    private float drawIncomeBreakdown(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        
        // Box with border for Income Breakdown - rounded corners
        float boxHeight = 120;
        float radius = 8;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // Section header inside box
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(MARGIN + 15, y - 20);
        cs.showText("INCOME BREAKDOWN");
        cs.endText();
        
        // Table header row
        float tableY = y - 45;
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 15, tableY);
        cs.showText("Source");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 180, tableY);
        cs.showText("Count");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 260, tableY);
        cs.showText("Amount (SAR)");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 400, tableY);
        cs.showText("Verifiable");
        cs.endText();
        
        // Get actual salary data from metrics
        int salaryCount = metrics != null && metrics.getSalaryOccurrences() != null ? metrics.getSalaryOccurrences() : 0;
        BigDecimal salaryTotal = metrics != null && metrics.getAverageSalaryAmount() != null && salaryCount > 0 ?
                metrics.getAverageSalaryAmount().multiply(BigDecimal.valueOf(salaryCount)) : BigDecimal.ZERO;
        boolean hasSalary = salaryCount >= 3;
        
        // Get other income (total income minus salary) - use averageMonthlyIncome * months as proxy
        BigDecimal totalIncome = metrics != null && metrics.getAverageMonthlyIncome() != null ? 
                metrics.getAverageMonthlyIncome().multiply(BigDecimal.valueOf(Math.max(1, salaryCount))) : BigDecimal.ZERO;
        BigDecimal otherIncome = totalIncome.subtract(salaryTotal).max(BigDecimal.ZERO);
        int totalTxCount = report.getCustomerProfile() != null && report.getCustomerProfile().getTotalTransactions() != null ?
                report.getCustomerProfile().getTotalTransactions() : 0;
        int otherIncomeCount = Math.max(0, totalTxCount - salaryCount);
        
        float dataY = y - 65;
        
        // Salary row (only show if salary data exists)
        if (salaryCount > 0) {
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(fontBold, 10);
            cs.newLineAtOffset(MARGIN + 15, dataY);
            cs.showText("Salary Deposits");
            cs.endText();
            
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(MARGIN + 180, dataY);
            cs.showText(String.valueOf(salaryCount));
            cs.endText();
            
            cs.beginText();
            cs.newLineAtOffset(MARGIN + 260, dataY);
            cs.showText(String.format("%,.0f", salaryTotal));
            cs.endText();
            
            cs.setNonStrokingColor(hasSalary ? GREEN_SUCCESS : YELLOW_WARNING);
            cs.beginText();
            cs.setFont(fontBold, 10);
            cs.newLineAtOffset(MARGIN + 400, dataY);
            cs.showText(hasSalary ? "Yes" : "Insufficient");
            cs.endText();
            
            dataY -= 20;
        }
        
        // Other Income row
        if (otherIncome.compareTo(BigDecimal.ZERO) > 0) {
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(fontBold, 10);
            cs.newLineAtOffset(MARGIN + 15, dataY);
            cs.showText("Other Income");
            cs.endText();
            
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(MARGIN + 180, dataY);
            cs.showText(String.valueOf(otherIncomeCount));
            cs.endText();
            
            cs.beginText();
            cs.newLineAtOffset(MARGIN + 260, dataY);
            cs.showText(String.format("%,.0f", otherIncome));
            cs.endText();
            
            cs.setNonStrokingColor(ORANGE_PRIMARY);
            cs.beginText();
            cs.setFont(fontBold, 10);
            cs.newLineAtOffset(MARGIN + 400, dataY);
            cs.showText("Partial");
            cs.endText();
            
            dataY -= 20;
        }
        
        // No income data message
        if (salaryCount == 0 && otherIncome.compareTo(BigDecimal.ZERO) == 0) {
            cs.setNonStrokingColor(GRAY_TEXT);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(MARGIN + 15, dataY);
            cs.showText("No income transactions identified");
            cs.endText();
        }
        
        // Calculate verifiable income ratio - only for retail customers
        boolean isCorporate = report.getCustomerType() == com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType.CORPORATE;
        
        if (!isCorporate) {
            BigDecimal verifiableRatio = BigDecimal.ZERO;
            if (totalIncome.compareTo(BigDecimal.ZERO) > 0 && hasSalary) {
                verifiableRatio = salaryTotal.divide(totalIncome, 4, java.math.RoundingMode.HALF_UP)
                        .multiply(BigDecimal.valueOf(100));
            }
            
            // Verifiable Income Ratio banner - positioned below the income breakdown box
            // Banner is 30 tall, positioned with 10pt gap below box
            float bannerHeight = 30;
            float bannerY = y - boxHeight - bannerHeight - 10;
            cs.setStrokingColor(ORANGE_PRIMARY);
            cs.setLineWidth(2);
            cs.addRect(MARGIN, bannerY, CONTENT_WIDTH, bannerHeight);
            cs.stroke();
            
            cs.setNonStrokingColor(ORANGE_PRIMARY);
            cs.beginText();
            cs.setFont(fontBold, 11);
            String ratioText = hasSalary ? String.format("VERIFIABLE INCOME RATIO: %.0f%%", verifiableRatio) : "VERIFIABLE INCOME RATIO: N/A (Insufficient salary data)";
            float textWidth = fontBold.getStringWidth(ratioText) / 1000 * 11;
            cs.newLineAtOffset(MARGIN + (CONTENT_WIDTH - textWidth) / 2, bannerY + 10);
            cs.showText(ratioText);
            cs.endText();
            
            return bannerY - 15;
        }
        
        return y - boxHeight - 15;
    }

    private float drawExpenseCategories(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        
        // Box with border for Expense Categories - rounded corners
        float boxHeight = 180;
        float radius = 8;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, CONTENT_WIDTH, boxHeight, radius);
        
        // Section header inside box
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(fontBold, 10);
        cs.newLineAtOffset(MARGIN + 15, y - 20);
        cs.showText("EXPENSE CATEGORIES");
        cs.endText();
        
        // Calculate actual expense categories from metrics
        BigDecimal totalExpenses = metrics != null && metrics.getAverageMonthlyExpenses() != null ? 
                metrics.getAverageMonthlyExpenses() : BigDecimal.ZERO;
        BigDecimal loanPayments = metrics != null && metrics.getLastMonthDebtPayment() != null ? 
                metrics.getLastMonthDebtPayment() : BigDecimal.ZERO;
        BigDecimal otherExpenses = totalExpenses.subtract(loanPayments).max(BigDecimal.ZERO);
        
        // Build dynamic categories with percentages
        java.util.List<Object[]> categoryList = new java.util.ArrayList<>();
        
        if (loanPayments.compareTo(BigDecimal.ZERO) > 0) {
            double pct = totalExpenses.compareTo(BigDecimal.ZERO) > 0 ? 
                    loanPayments.divide(totalExpenses, 4, java.math.RoundingMode.HALF_UP).doubleValue() : 0;
            categoryList.add(new Object[]{"Loan Repayments", loanPayments, pct});
        }
        
        if (otherExpenses.compareTo(BigDecimal.ZERO) > 0) {
            double pct = totalExpenses.compareTo(BigDecimal.ZERO) > 0 ? 
                    otherExpenses.divide(totalExpenses, 4, java.math.RoundingMode.HALF_UP).doubleValue() : 0;
            categoryList.add(new Object[]{"Other Expenses", otherExpenses, pct});
        }
        
        // If no expense data, show message
        if (categoryList.isEmpty()) {
            cs.setNonStrokingColor(GRAY_TEXT);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(MARGIN + 15, y - 50);
            cs.showText("No expense data available");
            cs.endText();
            return y - boxHeight - 20;
        }
        
        Color[] categoryColors = {
            new Color(255, 152, 0),    // Orange
            new Color(255, 183, 77),   // Light orange
            new Color(255, 204, 128),  // Lighter orange
            new Color(255, 224, 178),  // Very light orange
            new Color(255, 245, 224)   // Cream
        };
        
        // Draw donut chart on the left side
        float chartCenterX = MARGIN + 100;
        float chartCenterY = y - 100;
        float outerRadius = 60;
        float innerRadius = 35;
        
        // Draw donut segments
        double startAngle = -90; // Start from top
        for (int i = 0; i < categoryList.size(); i++) {
            Object[] cat = categoryList.get(i);
            double pct = (Double) cat[2];
            double sweepAngle = pct * 360;
            
            cs.setNonStrokingColor(categoryColors[i % categoryColors.length]);
            drawDonutSegment(cs, chartCenterX, chartCenterY, outerRadius, innerRadius, startAngle, sweepAngle);
            startAngle += sweepAngle;
        }
        
        // Draw inner circle (white) to complete donut
        cs.setNonStrokingColor(Color.WHITE);
        drawFilledCircle(cs, chartCenterX, chartCenterY, innerRadius);
        
        // Category legend table on the right
        float tableX = MARGIN + 220;
        float tableY = y - 45;
        
        // Table header
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(tableX + 20, tableY);
        cs.showText("Category");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(tableX + 150, tableY);
        cs.showText("Amount");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(tableX + 220, tableY);
        cs.showText("%");
        cs.endText();
        
        tableY -= 20;
        
        for (int i = 0; i < categoryList.size(); i++) {
            Object[] cat = categoryList.get(i);
            String name = (String) cat[0];
            BigDecimal amount = (BigDecimal) cat[1];
            double pct = (Double) cat[2];
            
            // Color indicator
            cs.setNonStrokingColor(categoryColors[i % categoryColors.length]);
            cs.addRect(tableX, tableY - 3, 10, 10);
            cs.fill();
            
            // Category name
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(font, 10);
            cs.newLineAtOffset(tableX + 20, tableY);
            cs.showText(name);
            cs.endText();
            
            // Amount
            cs.beginText();
            cs.newLineAtOffset(tableX + 150, tableY);
            cs.showText(String.format("%,.0f", amount));
            cs.endText();
            
            // Percentage
            cs.beginText();
            cs.newLineAtOffset(tableX + 220, tableY);
            cs.showText(String.format("%.0f%%", pct * 100));
            cs.endText();
            
            tableY -= 22;
        }
        
        return y - boxHeight - 20;
    }
    
    private void drawDonutSegment(PDPageContentStream cs, float cx, float cy, float outerR, float innerR, 
            double startAngle, double sweepAngle) throws IOException {
        if (sweepAngle <= 0) return;
        
        // Draw outer arc segments
        int segments = Math.max(1, (int) (sweepAngle / 5));
        double angleStep = sweepAngle / segments;
        
        for (int i = 0; i < segments; i++) {
            double a1 = Math.toRadians(startAngle + i * angleStep);
            double a2 = Math.toRadians(startAngle + (i + 1) * angleStep);
            
            float x1 = cx + (float) (outerR * Math.cos(a1));
            float y1 = cy + (float) (outerR * Math.sin(a1));
            float x2 = cx + (float) (outerR * Math.cos(a2));
            float y2 = cy + (float) (outerR * Math.sin(a2));
            float x3 = cx + (float) (innerR * Math.cos(a2));
            float y3 = cy + (float) (innerR * Math.sin(a2));
            float x4 = cx + (float) (innerR * Math.cos(a1));
            float y4 = cy + (float) (innerR * Math.sin(a1));
            
            // Draw quad
            cs.moveTo(x1, y1);
            cs.lineTo(x2, y2);
            cs.lineTo(x3, y3);
            cs.lineTo(x4, y4);
            cs.closePath();
            cs.fill();
        }
    }
    
    private void drawFilledCircle(PDPageContentStream cs, float cx, float cy, float radius) throws IOException {
        int segments = 36;
        cs.moveTo(cx + radius, cy);
        for (int i = 1; i <= segments; i++) {
            double angle = 2 * Math.PI * i / segments;
            float x = cx + (float) (radius * Math.cos(angle));
            float y = cy + (float) (radius * Math.sin(angle));
            cs.lineTo(x, y);
        }
        cs.closePath();
        cs.fill();
    }

    // ==================== PAGE 5: LOAN EXPOSURE & FINAL RECOMMENDATION ====================
    
    private void drawPage5LoanExposure(PDDocument document, CreditRiskReportResponse report) throws IOException {
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);
        
        try (PDPageContentStream cs = new PDPageContentStream(document, page)) {
            float y = PAGE_HEIGHT - MARGIN;
            
            y = drawPageHeader(document, cs, report, y);
            y = drawSectionTitle(cs, "LOAN EXPOSURE & DEBT PROFILE", y);
            y = drawLoanSummary(cs, report, y);
            y = drawSectionTitle(cs, "FINAL RECOMMENDATION", y - 20);
            y = drawCreditClassReference(cs, report, y - 20);
            drawFinalRecommendationBanner(cs, report, y);
            
            drawPageFooter(cs, 5);
        }
    }

    private float drawLoanSummary(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        FinancialMetrics metrics = report.getFinancialMetrics();
        float boxWidth = (CONTENT_WIDTH - 20) / 2;
        float boxHeight = 80;
        float radius = 8;
        
        // Loan Summary box with rounded corners
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, MARGIN, y - boxHeight, boxWidth, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        cs.setLineWidth(1);
        strokeRoundedRect(cs, MARGIN, y - boxHeight, boxWidth, boxHeight, radius);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 15, y - 20);
        cs.showText("LOAN SUMMARY");
        cs.endText();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 15, y - 40);
        cs.showText("TOTAL LOAN AMOUNT");
        cs.endText();
        
        BigDecimal totalLoan = metrics != null && metrics.getTotalLoanPayments() != null ? 
                metrics.getTotalLoanPayments() : BigDecimal.ZERO;
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 20);
        cs.newLineAtOffset(MARGIN + 15, y - 65);
        cs.showText(formatCurrency(totalLoan));
        cs.endText();
        
        // Debt Ratios box with rounded corners
        float debtBoxX = MARGIN + boxWidth + 20;
        cs.setNonStrokingColor(Color.WHITE);
        drawRoundedRect(cs, debtBoxX, y - boxHeight, boxWidth, boxHeight, radius);
        cs.setStrokingColor(GRAY_BORDER);
        strokeRoundedRect(cs, debtBoxX, y - boxHeight, boxWidth, boxHeight, radius);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(debtBoxX + 15, y - 20);
        cs.showText("DEBT RATIOS");
        cs.endText();
        
        // DBR (Debt Burden Ratio) - only show if we have debt data
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(debtBoxX + 15, y - 50);
        cs.showText("DBR");
        cs.endText();
        
        BigDecimal dtiValue = metrics != null ? metrics.getDebtBurdenRatio() : null;
        String dti = dtiValue != null ? formatPercentageShort(dtiValue) : "N/A";
        Color dtiColor = dtiValue != null && dtiValue.compareTo(new BigDecimal("0.35")) <= 0 ? GREEN_SUCCESS : ORANGE_PRIMARY;
        cs.setNonStrokingColor(dtiColor);
        cs.beginText();
        cs.setFont(fontBold, 14);
        cs.newLineAtOffset(debtBoxX + 150, y - 50);
        cs.showText(dti);
        cs.endText();
        
        return y - boxHeight - 20;
    }

    private float drawCreditClassReference(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN, y);
        cs.showText("CREDIT CLASS REFERENCE");
        cs.endText();
        y -= 20;
        
        // Header row
        cs.setNonStrokingColor(GRAY_LIGHT);
        cs.addRect(MARGIN, y - 18, CONTENT_WIDTH, 18);
        cs.fill();
        
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 7);
        cs.newLineAtOffset(MARGIN + 10, y - 12);
        cs.showText("CLASS");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 80, y - 12);
        cs.showText("SCORE RANGE");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 180, y - 12);
        cs.showText("DESCRIPTION");
        cs.endText();
        
        cs.beginText();
        cs.newLineAtOffset(MARGIN + 320, y - 12);
        cs.showText("APPROVAL LEVEL");
        cs.endText();
        
        y -= 22;
        
        // Credit class rows
        String[][] classes = {
            {"AAA", "900-1000", "Excellent", "Very High"},
            {"AA", "800-899", "Very Good", "High"},
            {"A", "700-799", "Good", "High"},
            {"BBB", "600-699", "Above Average", "Moderate"},
            {"BB", "500-599", "Average", "Moderate"},
            {"B", "400-499", "Below Average", "Low"},
            {"CCC", "300-399", "Poor", "Very Low"},
            {"CC", "200-299", "Very Poor", "Unlikely"},
            {"C", "100-199", "Extremely Poor", "Declined"},
            {"D", "0-99", "Default Risk", "Declined"}
        };
        
        Color[] classColors = {
            GREEN_SUCCESS, GREEN_SUCCESS, new Color(139, 195, 74),
            YELLOW_WARNING, YELLOW_WARNING,
            new Color(255, 152, 0), RED_DANGER, RED_DANGER, RED_DANGER, RED_DANGER
        };
        
        for (int i = 0; i < classes.length; i++) {
            float rowY = y - (i * 18);
            
            // Color indicator
            cs.setNonStrokingColor(classColors[i]);
            cs.addRect(MARGIN + 10, rowY - 10, 8, 8);
            cs.fill();
            
            cs.setNonStrokingColor(Color.BLACK);
            cs.beginText();
            cs.setFont(fontBold, 9);
            cs.newLineAtOffset(MARGIN + 25, rowY - 8);
            cs.showText(classes[i][0]);
            cs.endText();
            
            cs.setNonStrokingColor(GRAY_TEXT);
            cs.beginText();
            cs.setFont(font, 8);
            cs.newLineAtOffset(MARGIN + 80, rowY - 8);
            cs.showText(classes[i][1]);
            cs.endText();
            
            cs.beginText();
            cs.newLineAtOffset(MARGIN + 180, rowY - 8);
            cs.showText(classes[i][2]);
            cs.endText();
            
            cs.beginText();
            cs.newLineAtOffset(MARGIN + 320, rowY - 8);
            cs.showText(classes[i][3]);
            cs.endText();
        }
        
        return y - (classes.length * 18) - 20;
    }

    private void drawFinalRecommendationBanner(PDPageContentStream cs, CreditRiskReportResponse report, float y) throws IOException {
        PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        
        float bannerHeight = 70;
        float radius = 8;
        
        // Banner color based on rating
        Color bannerColor = getRecommendationColor(report.getRatingClass());
        cs.setNonStrokingColor(bannerColor);
        drawRoundedRect(cs, MARGIN, y - bannerHeight, CONTENT_WIDTH, bannerHeight, radius);
        
        // Recommendation text
        String recText = getRecommendationText(report.getApprovalRecommendation());
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 26);
        float textWidth = fontBold.getStringWidth(recText) / 1000 * 26;
        cs.newLineAtOffset(MARGIN + (CONTENT_WIDTH - textWidth) / 2, y - 35);
        cs.showText(recText);
        cs.endText();
        
        cs.beginText();
        cs.setFont(font, 10);
        cs.newLineAtOffset(MARGIN + (CONTENT_WIDTH / 2) - 60, y - 55);
        cs.showText("Automated System Decision");
        cs.endText();
        
        // Score summary below banner with rounded corners
        y -= bannerHeight + 15;
        
        cs.setNonStrokingColor(GRAY_LIGHT);
        drawRoundedRect(cs, MARGIN, y - 55, CONTENT_WIDTH, 55, radius);
        
        // Final Score section
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 80, y - 18);
        cs.showText("FINAL SCORE");
        cs.endText();
        
        cs.setNonStrokingColor(Color.BLACK);
        cs.beginText();
        cs.setFont(fontBold, 24);
        cs.newLineAtOffset(MARGIN + 80, y - 45);
        cs.showText(report.getTotalScore() + " / " + report.getMaxPossibleScore());
        cs.endText();
        
        // Risk Level section
        cs.setNonStrokingColor(GRAY_TEXT);
        cs.beginText();
        cs.setFont(font, 8);
        cs.newLineAtOffset(MARGIN + 320, y - 18);
        cs.showText("RISK LEVEL");
        cs.endText();
        
        // Risk level badge with rounded corners
        Color riskColor = getRiskLevelColor(report.getRatingClass());
        String riskText = getRiskLevelText(report.getRatingClass());
        cs.setNonStrokingColor(riskColor);
        drawRoundedRect(cs, MARGIN + 320, y - 50, 100, 28, 4);
        
        cs.setNonStrokingColor(Color.WHITE);
        cs.beginText();
        cs.setFont(fontBold, 11);
        float riskTextWidth = fontBold.getStringWidth(riskText) / 1000 * 11;
        cs.newLineAtOffset(MARGIN + 320 + (100 - riskTextWidth) / 2, y - 40);
        cs.showText(riskText);
        cs.endText();
    }

    // ==================== HELPER METHODS ====================
    
    /**
     * Draw a rounded rectangle (filled)
     */
    private void drawRoundedRect(PDPageContentStream cs, float x, float y, float width, float height, float radius) throws IOException {
        // Start from bottom-left corner, going clockwise
        cs.moveTo(x + radius, y);
        cs.lineTo(x + width - radius, y);
        // Bottom-right corner
        cs.curveTo(x + width - radius + radius * 0.552f, y, x + width, y + radius - radius * 0.552f, x + width, y + radius);
        cs.lineTo(x + width, y + height - radius);
        // Top-right corner
        cs.curveTo(x + width, y + height - radius + radius * 0.552f, x + width - radius + radius * 0.552f, y + height, x + width - radius, y + height);
        cs.lineTo(x + radius, y + height);
        // Top-left corner
        cs.curveTo(x + radius - radius * 0.552f, y + height, x, y + height - radius + radius * 0.552f, x, y + height - radius);
        cs.lineTo(x, y + radius);
        // Bottom-left corner
        cs.curveTo(x, y + radius - radius * 0.552f, x + radius - radius * 0.552f, y, x + radius, y);
        cs.closePath();
        cs.fill();
    }
    
    /**
     * Draw a rounded rectangle (stroked only)
     */
    private void strokeRoundedRect(PDPageContentStream cs, float x, float y, float width, float height, float radius) throws IOException {
        cs.moveTo(x + radius, y);
        cs.lineTo(x + width - radius, y);
        cs.curveTo(x + width - radius + radius * 0.552f, y, x + width, y + radius - radius * 0.552f, x + width, y + radius);
        cs.lineTo(x + width, y + height - radius);
        cs.curveTo(x + width, y + height - radius + radius * 0.552f, x + width - radius + radius * 0.552f, y + height, x + width - radius, y + height);
        cs.lineTo(x + radius, y + height);
        cs.curveTo(x + radius - radius * 0.552f, y + height, x, y + height - radius + radius * 0.552f, x, y + height - radius);
        cs.lineTo(x, y + radius);
        cs.curveTo(x, y + radius - radius * 0.552f, x + radius - radius * 0.552f, y, x + radius, y);
        cs.closePath();
        cs.stroke();
    }

    private Color getScoreColor(CreditRatingClass rating) {
        return switch (rating) {
            case AAA, AA, A -> GREEN_SUCCESS;
            case BBB, BB -> YELLOW_WARNING;
            default -> RED_DANGER;
        };
    }

    private Color getRiskLevelColor(CreditRatingClass rating) {
        return switch (rating) {
            case AAA, AA, A -> GREEN_SUCCESS;
            case BBB, BB -> YELLOW_WARNING;
            default -> RED_DANGER;
        };
    }

    private String getRiskLevelText(CreditRatingClass rating) {
        return switch (rating) {
            case AAA, AA, A -> "LOW RISK";
            case BBB, BB -> "MEDIUM RISK";
            default -> "HIGH RISK";
        };
    }

    private String formatCurrency(BigDecimal amount) {
        if (amount == null) return "N/A";
        return String.format("SAR %,.0f", amount);
    }

    private String formatPercentage(BigDecimal ratio) {
        if (ratio == null) return "N/A";
        return String.format("%.1f%%", ratio.multiply(BigDecimal.valueOf(100)));
    }

    private String formatPercentageShort(BigDecimal ratio) {
        if (ratio == null) return "N/A";
        return String.format("%.1f%%", ratio.multiply(BigDecimal.valueOf(100)));
    }

    private String formatEmergencyFund(BigDecimal months) {
        if (months == null || months.compareTo(BigDecimal.ZERO) == 0) return "N/A";
        return String.format("%.1f Months", months);
    }

    private String formatSalaryRegularity(FinancialMetrics metrics) {
        if (metrics.getSalaryOccurrences() == null || metrics.getSalaryOccurrences() < 3) {
            return "N/A"; // Not enough salary data
        }
        if (metrics.getSalaryRegularity() == null) return "N/A";
        // salaryRegularity is stored as decimal (0.90 = 90%), so multiply by 100 for display
        return String.format("%.0f%%", metrics.getSalaryRegularity().multiply(BigDecimal.valueOf(100)));
    }
}
