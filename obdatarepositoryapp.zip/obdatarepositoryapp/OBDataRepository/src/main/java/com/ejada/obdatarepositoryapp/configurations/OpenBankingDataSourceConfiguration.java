package com.ejada.obdatarepositoryapp.configurations;

import com.zaxxer.hikari.HikariDataSource;
import jakarta.persistence.EntityManagerFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * Configuration for the Open Banking database connection.
 * Used for credit risk scoring to access transaction and account data.
 * This is a read-only connection with PGP decryption support.
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = "com.ejada.obdatarepositoryapp.creditrisk.repository",
        entityManagerFactoryRef = "openBankingEntityManagerFactory",
        transactionManagerRef = "openBankingTransactionManager"
)
@RequiredArgsConstructor
public class OpenBankingDataSourceConfiguration {

    @Value("${openbanking.schema:public}")
    private String obDbSchema;

    @Bean
    @ConfigurationProperties("openbanking.datasource")
    public DataSourceProperties openBankingDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    public DataSource openBankingDataSource() {
        HikariDataSource dataSource = openBankingDataSourceProperties()
                .initializeDataSourceBuilder()
                .type(HikariDataSource.class)
                .build();
        dataSource.setReadOnly(true);
        dataSource.setPoolName("OpenBankingHikariPool");
        return dataSource;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean openBankingEntityManagerFactory(
            EntityManagerFactoryBuilder builder,
            @Qualifier("openBankingDataSource") DataSource dataSource) {
        
        Map<String, Object> properties = new HashMap<>();
        properties.put("hibernate.hbm2ddl.auto", "none");
        properties.put("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
        properties.put("hibernate.format_sql", true);
        properties.put("hibernate.default_schema", obDbSchema);
        
        return builder
                .dataSource(dataSource)
                .packages("com.ejada.obdatarepositoryapp.creditrisk.domain")
                .persistenceUnit("openbanking")
                .properties(properties)
                .build();
    }

    @Bean
    public PlatformTransactionManager openBankingTransactionManager(
            @Qualifier("openBankingEntityManagerFactory") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }
}
