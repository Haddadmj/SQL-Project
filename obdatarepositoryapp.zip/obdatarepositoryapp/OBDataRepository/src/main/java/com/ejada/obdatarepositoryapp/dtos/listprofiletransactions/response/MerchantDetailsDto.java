package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigInteger;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MerchantDetailsDto {
    @JsonProperty("MerchantId")
    private String  merchantId;

    @JsonProperty("MerchantName")
    private String merchantName;

    @JsonProperty("MerchantCategoryCode")
    private String merchantCategoryCode;
}
