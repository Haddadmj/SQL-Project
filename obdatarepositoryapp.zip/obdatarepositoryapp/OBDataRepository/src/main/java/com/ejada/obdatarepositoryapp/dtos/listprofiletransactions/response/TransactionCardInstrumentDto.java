package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.ejada.commons.masking.Maskable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionCardInstrumentDto {
    @JsonProperty("CardSchemeName")
    private String cardSchemeName;

    @JsonProperty("InstrumentType")
    private String instrumentType;

    @JsonProperty("Name")
    private String name;

    @Maskable(type = "PARTIAL")
    @JsonProperty("Identification")
    private String identification;
}
