package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.ejada.obdatarepositoryapp.dtos.commondtos.response.MetaDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListProfileTransactionsResponseCategorizedDto {
    @JsonProperty("Data")
    private ListProfileTransactionsDataCategorizedDto data;

    @JsonProperty("Meta")
    private MetaDto meta;
}
