package com.ejada.obdatarepositoryapp.dtos.listprofilebalances.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class AmountDto {
    @JsonProperty("Amount")
    private BigDecimal amount;
    @JsonProperty("Currency")
    private String currency;
}
