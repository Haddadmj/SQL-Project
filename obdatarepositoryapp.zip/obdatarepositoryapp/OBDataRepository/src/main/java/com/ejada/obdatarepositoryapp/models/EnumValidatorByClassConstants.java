package com.ejada.obdatarepositoryapp.models;

import com.ejada.obdatarepositoryapp.utils.EnumValidatorByClassConstantsImpl;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RUNTIME)
@Documented
@Constraint(validatedBy = EnumValidatorByClassConstantsImpl.class)
public @interface EnumValidatorByClassConstants {
    Class<? extends Enum<?>> enumClass();

    String message() default "must be any of enum {enumClass}";

    String code() default "The Error Code";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}