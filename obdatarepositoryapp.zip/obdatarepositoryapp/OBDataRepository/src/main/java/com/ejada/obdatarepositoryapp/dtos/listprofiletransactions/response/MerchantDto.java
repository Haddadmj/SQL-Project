package com.ejada.obdatarepositoryapp.dtos.listprofiletransactions.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MerchantDto {

    @JsonProperty("id")
    private String id;

    @JsonProperty("merchant_name")
    private String merchantName;
}
