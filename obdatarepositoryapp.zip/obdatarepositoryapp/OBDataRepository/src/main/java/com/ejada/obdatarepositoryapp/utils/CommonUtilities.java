package com.ejada.obdatarepositoryapp.utils;

import lombok.Builder;
import lombok.extern.slf4j.Slf4j;

@Builder
@Slf4j
public class CommonUtilities {
    public static Integer calculatePageOffset(Integer page) {
        return (page - 1) * 50;
    }
}
