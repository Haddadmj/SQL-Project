package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum AccountStatusEnums {
    ACTIVE("Active"),
    NOT_ACTIVE("NotActive"),
    DORMANT("Dormant"),
    UNCLAIMED("Unclaimed"),
    DECEASED("Deceased"),
    SUSPENDED("Suspended"),
    CLOSED("Closed");


    private final String value;

    AccountStatusEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static AccountStatusEnums fromValue(String text) {
        for (AccountStatusEnums b : AccountStatusEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
