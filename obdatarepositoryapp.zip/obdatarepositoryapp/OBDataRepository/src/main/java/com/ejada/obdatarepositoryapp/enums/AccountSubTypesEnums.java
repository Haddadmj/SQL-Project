package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum AccountSubTypesEnums {
    CURRENT_ACCOUNT("CurrentAccount"),
    SAVINGS("Savings"),
    CREDIT_CARD("CreditCard"),
    PRE_PAID_CARD("PrePaidCard"),
    E_MONEY("EMoney"),
    CHARGE_CARD("ChargeCard"),
    OTHER("Other");

    private final String value;

    AccountSubTypesEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static AccountSubTypesEnums fromValue(String text) {
        for (AccountSubTypesEnums b : AccountSubTypesEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
