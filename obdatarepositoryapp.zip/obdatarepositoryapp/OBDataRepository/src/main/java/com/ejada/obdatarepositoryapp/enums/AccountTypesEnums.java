package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum AccountTypesEnums {
    RETAIL("KSAOB.Retail"),
    CORPORATE("KSAOB.Corporate");

    private final String value;

    AccountTypesEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static AccountTypesEnums fromValue(String text) {
        for (AccountTypesEnums b : AccountTypesEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
