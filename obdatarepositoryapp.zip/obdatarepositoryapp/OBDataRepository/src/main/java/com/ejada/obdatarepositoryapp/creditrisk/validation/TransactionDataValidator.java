package com.ejada.obdatarepositoryapp.creditrisk.validation;

import com.ejada.obdatarepositoryapp.creditrisk.dto.TransactionData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Validates and sanitizes transaction data before processing.
 * Filters out invalid transactions and logs issues.
 */
@Component
@Slf4j
public class TransactionDataValidator {

    /**
     * Validate and filter transactions, removing invalid entries.
     * @param transactions Raw transaction list
     * @return Validated and cleaned transaction list
     */
    public List<TransactionData> validateAndFilter(List<TransactionData> transactions) {
        if (transactions == null) {
            log.warn("Received null transaction list");
            return new ArrayList<>();
        }

        if (transactions.isEmpty()) {
            log.info("Received empty transaction list");
            return new ArrayList<>();
        }

        int originalCount = transactions.size();
        
        List<TransactionData> validTransactions = transactions.stream()
                .filter(this::isValidTransaction)
                .map(this::sanitizeTransaction)
                .collect(Collectors.toList());

        int removedCount = originalCount - validTransactions.size();
        if (removedCount > 0) {
            log.warn("Filtered out {} invalid transactions from {} total", removedCount, originalCount);
        }

        return validTransactions;
    }

    /**
     * Check if a transaction is valid for processing.
     */
    private boolean isValidTransaction(TransactionData txn) {
        if (txn == null) {
            log.debug("Skipping null transaction");
            return false;
        }

        // Must have transaction date
        if (txn.getTransactionDateTime() == null) {
            log.debug("Skipping transaction without date: {}", txn.getTransactionId());
            return false;
        }

        // Must have amount
        if (txn.getAmount() == null) {
            log.debug("Skipping transaction without amount: {}", txn.getTransactionId());
            return false;
        }

        // Amount must be positive (we handle credit/debit via indicator)
        if (txn.getAmount().compareTo(BigDecimal.ZERO) < 0) {
            log.debug("Skipping transaction with negative amount: {} = {}", 
                    txn.getTransactionId(), txn.getAmount());
            return false;
        }

        // Must have credit/debit indicator
        if (txn.getCreditDebitIndicator() == null || txn.getCreditDebitIndicator().isBlank()) {
            log.debug("Skipping transaction without credit/debit indicator: {}", txn.getTransactionId());
            return false;
        }

        return true;
    }

    /**
     * Sanitize transaction data, fixing common issues.
     */
    private TransactionData sanitizeTransaction(TransactionData txn) {
        // Ensure amount is absolute (positive)
        if (txn.getAmount() != null && txn.getAmount().compareTo(BigDecimal.ZERO) < 0) {
            txn.setAmount(txn.getAmount().abs());
        }

        // Trim string fields
        if (txn.getDescription() != null) {
            txn.setDescription(txn.getDescription().trim());
        }
        if (txn.getMerchantName() != null) {
            txn.setMerchantName(txn.getMerchantName().trim());
        }
        if (txn.getReference() != null) {
            txn.setReference(txn.getReference().trim());
        }

        return txn;
    }

    /**
     * Validate minimum data requirements for reliable scoring.
     */
    public ValidationResult validateDataRequirements(List<TransactionData> transactions, int minimumMonths) {
        if (transactions == null || transactions.isEmpty()) {
            return ValidationResult.builder()
                    .valid(false)
                    .errorCode("NO_DATA")
                    .errorMessage("No transaction data available for scoring")
                    .build();
        }

        // Check date range
        long distinctMonths = transactions.stream()
                .filter(t -> t.getTransactionDateTime() != null)
                .map(t -> t.getTransactionDateTime().toLocalDate().withDayOfMonth(1))
                .distinct()
                .count();

        if (distinctMonths < minimumMonths) {
            return ValidationResult.builder()
                    .valid(false)
                    .errorCode("INSUFFICIENT_DATA")
                    .errorMessage(String.format("Insufficient data: %d months found, minimum %d required", 
                            distinctMonths, minimumMonths))
                    .warningMessage("Score may be less reliable with limited data")
                    .build();
        }

        // Check for credit transactions (income)
        long creditCount = transactions.stream()
                .filter(TransactionData::isCredit)
                .count();

        if (creditCount == 0) {
            return ValidationResult.builder()
                    .valid(false)
                    .errorCode("NO_INCOME_DATA")
                    .errorMessage("No credit transactions found - cannot calculate income")
                    .build();
        }

        return ValidationResult.builder()
                .valid(true)
                .transactionCount((int) transactions.size())
                .monthsCovered((int) distinctMonths)
                .build();
    }

    @lombok.Data
    @lombok.Builder
    @lombok.NoArgsConstructor
    @lombok.AllArgsConstructor
    public static class ValidationResult {
        private boolean valid;
        private String errorCode;
        private String errorMessage;
        private String warningMessage;
        private Integer transactionCount;
        private Integer monthsCovered;
    }
}
