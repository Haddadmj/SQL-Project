package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum BeneficiaryTypeEnums {

    ACTIVATED("KSAOB.Activated"),
    NOTACTIVATED("KSAOB.NotActivated");

    private final String value;

    BeneficiaryTypeEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static BeneficiaryTypeEnums fromValue(String text) {
        for (BeneficiaryTypeEnums b : BeneficiaryTypeEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
