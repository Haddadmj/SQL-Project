package com.ejada.obdatarepositoryapp.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum TransactionMutabilityEnums {
    MUTABLE("KSAOB.Mutable"),
    IMMUTABLE("KSAOB.Immutable");

    private final String value;

    TransactionMutabilityEnums(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

    @JsonCreator
    public static TransactionMutabilityEnums fromValue(String text) {
        for (TransactionMutabilityEnums b : TransactionMutabilityEnums.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
