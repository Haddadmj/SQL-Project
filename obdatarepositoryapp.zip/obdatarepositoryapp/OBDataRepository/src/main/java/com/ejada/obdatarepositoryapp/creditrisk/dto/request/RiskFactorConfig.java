package com.ejada.obdatarepositoryapp.creditrisk.dto.request;

import com.ejada.obdatarepositoryapp.creditrisk.enums.RiskFactorType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Configuration for a single risk factor.
 * Allows dynamic weight and scoring ranges per factor.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RiskFactorConfig {
    
    private RiskFactorType factorType;
    private Integer weight;
    private List<RangeConfig> ranges;
    private Boolean enabled;
}
