package com.ejada.obdatarepositoryapp.creditrisk.service;

import com.ejada.obdatarepositoryapp.creditrisk.domain.ObAccount;
import com.ejada.obdatarepositoryapp.creditrisk.dto.TransactionData;
import com.ejada.obdatarepositoryapp.creditrisk.dto.request.CreditRiskRequest;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.CreditRiskReportResponse;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.FactorScore;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.FinancialMetrics;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CreditRatingClass;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType;
import com.ejada.obdatarepositoryapp.creditrisk.enums.RiskFactorType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreditRiskScoringServiceTest {

    @Mock
    private OpenBankingDataFetcher dataFetcher;

    @Mock
    private FinancialMetricsCalculator metricsCalculator;

    @InjectMocks
    private CreditRiskScoringService service;

    private ObAccount testAccount;
    private OpenBankingDataFetcher.AccountInfo testAccountInfo;

    @BeforeEach
    void setUp() {
        testAccount = ObAccount.builder()
                .id("test-account-id")
                .userId("test-psu")
                .data("{}")
                .build();

        testAccountInfo = OpenBankingDataFetcher.AccountInfo.builder()
                .accountHolderName("TASTE OF FLOUR BAKERY")
                .build();
    }

    // ── Task 1: Score scaling divisor ──────────────────────────────────────

    @Test
    void bakeryFixture_twoFactorsSkipped_scalesTotalScoreTo443() {
        // rawScore=310, 2 skipped factors (BUSINESS_AGE=150, SUPPLIER_PAYMENT_CONSISTENCY=150)
        // Bug: availableMaxPoints=850 (only one 150 subtracted from 1000) → totalScore=365, ratingClass=CCC
        // Fix: availableMaxPoints=1000-150-150=700 → totalScore=443, ratingClass=B
        mockDataFetcher();
        when(metricsCalculator.calculate(any(), eq(CustomerType.CORPORATE), eq(null)))
                .thenReturn(bakeryMetrics());

        CreditRiskReportResponse response = service.generateReport(corporateRequest(null));

        assertThat(response.getTotalScore()).isEqualTo(443);
        assertThat(response.getRatingClass()).isEqualTo(CreditRatingClass.B);
        assertThat(response.getMetadata().getFactorsSkipped()).isEqualTo(2);
    }

    @Test
    void noFactorsSkipped_doesNotScale_maxScoreIs1000() {
        // age=5 enables BUSINESS_AGE; all other metrics non-null → zero factors skipped
        mockDataFetcher();
        when(metricsCalculator.calculate(any(), eq(CustomerType.CORPORATE), eq(5)))
                .thenReturn(allFactorsAvailableMetrics());

        CreditRiskReportResponse response = service.generateReport(corporateRequest(5));

        assertThat(response.getMaxPossibleScore()).isEqualTo(1000);
        assertThat(response.getMetadata().getFactorsSkipped()).isEqualTo(0);
    }

    @Test
    void oneFactorSkipped_150pts_factorsSkippedIsOne() {
        // age=5 enables BUSINESS_AGE; SUPPLIER_PAYMENT_CONSISTENCY null → exactly 1 factor skipped
        mockDataFetcher();
        when(metricsCalculator.calculate(any(), eq(CustomerType.CORPORATE), eq(5)))
                .thenReturn(oneFactorSkippedMetrics());

        CreditRiskReportResponse response = service.generateReport(corporateRequest(5));

        assertThat(response.getMetadata().getFactorsSkipped()).isEqualTo(1);
    }

    // ── Task 2: Per-factor labels for F4 and F6 ───────────────────────────

    @Test
    void operatingExpenseRatio_above100_labelIsVeryPoor() {
        // rawValue=100.59 → bottom band → score=20, label must be "Very Poor" not "Loss-Making"
        mockDataFetcher();
        when(metricsCalculator.calculate(any(), eq(CustomerType.CORPORATE), eq(null)))
                .thenReturn(bakeryMetrics());

        CreditRiskReportResponse response = service.generateReport(corporateRequest(null));

        FactorScore oer = response.getFactorScores().stream()
                .filter(f -> f.getFactorType() == RiskFactorType.OPERATING_EXPENSE_RATIO)
                .findFirst().orElseThrow();

        assertThat(oer.getScore()).isEqualTo(20);
        assertThat(oer.getScoreLabel()).isEqualTo("Very Poor");
    }

    @Test
    void cashBuffer_below05_labelIsVeryPoor() {
        // rawValue=0.16 → bottom band → score=20, label must be "Very Poor" not "Critical"
        mockDataFetcher();
        when(metricsCalculator.calculate(any(), eq(CustomerType.CORPORATE), eq(null)))
                .thenReturn(bakeryMetrics());

        CreditRiskReportResponse response = service.generateReport(corporateRequest(null));

        FactorScore cashBuffer = response.getFactorScores().stream()
                .filter(f -> f.getFactorType() == RiskFactorType.CASH_BUFFER)
                .findFirst().orElseThrow();

        assertThat(cashBuffer.getScore()).isEqualTo(20);
        assertThat(cashBuffer.getScoreLabel()).isEqualTo("Very Poor");
    }

    // ── Task 3: Legacy retail fields absent from corporate response ────────

    @Test
    void corporateResponse_doesNotContainRetailLegacyFields() {
        // emergencyFundMonths, savingsRate, surplusRatio are retail-only — must be null in corporate
        mockDataFetcher();
        when(metricsCalculator.calculate(any(), eq(CustomerType.CORPORATE), eq(null)))
                .thenReturn(bakeryMetrics());

        CreditRiskReportResponse response = service.generateReport(corporateRequest(null));
        FinancialMetrics metrics = response.getFinancialMetrics();

        assertThat(metrics.getEmergencyFundMonths()).isNull();
        assertThat(metrics.getSavingsRate()).isNull();
        assertThat(metrics.getSurplusRatio()).isNull();
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private void mockDataFetcher() {
        when(dataFetcher.getAccount(any(), any(), any(), any()))
                .thenReturn(Optional.of(testAccount));
        when(dataFetcher.getTransactionsForAccount(any(), any(), any()))
                .thenReturn(Collections.emptyList());
        when(dataFetcher.parseAccountInfo(testAccount))
                .thenReturn(testAccountInfo);
    }

    private CreditRiskRequest corporateRequest(Integer age) {
        return CreditRiskRequest.builder()
                .psuId("test-psu")
                .accountLinkId("test-link")
                .accountId("test-account")
                .sponsoredTppId("test-tpp")
                .customerType(CustomerType.CORPORATE)
                .age(age)
                .build();
    }

    /** TASTE OF FLOUR BAKERY fixture — two factors skipped, rawScore=310 */
    private FinancialMetrics bakeryMetrics() {
        return FinancialMetrics.builder()
                .revenueStabilityCoefficient(new BigDecimal("55.41"))   // 40-59.99 → 100
                .revenueTrendPercentage(new BigDecimal("-14.01"))        // < -10    → 30
                .operatingExpenseRatio(new BigDecimal("100.59"))        // > 100    → 20
                .supplierPaymentConsistencyScore(null)                  // null     → unavailable
                .cashBufferMonths(new BigDecimal("0.16"))               // < 0.49   → 20
                .corporateCashFlow(new BigDecimal("-654.96"))           // -4999-0  → 60
                .paymentBehaviorScore(new BigDecimal("71.45"))          // 70-84.99 → 80
                // rawScore = 310, skipped: BUSINESS_AGE(150) + SUPPLIER_PAYMENT_CONSISTENCY(150)
                .build();
    }

    /** All corporate factors have data — no scaling should be applied */
    private FinancialMetrics allFactorsAvailableMetrics() {
        return FinancialMetrics.builder()
                .age(5)                                                 // enables BUSINESS_AGE
                .revenueStabilityCoefficient(new BigDecimal("55.41"))
                .revenueTrendPercentage(new BigDecimal("-14.01"))
                .operatingExpenseRatio(new BigDecimal("100.59"))
                .supplierPaymentConsistencyScore(new BigDecimal("50.00"))
                .cashBufferMonths(new BigDecimal("0.16"))
                .corporateCashFlow(new BigDecimal("-654.96"))
                .paymentBehaviorScore(new BigDecimal("71.45"))
                .build();
    }

    /** Only SUPPLIER_PAYMENT_CONSISTENCY unavailable — one factor skipped */
    private FinancialMetrics oneFactorSkippedMetrics() {
        return FinancialMetrics.builder()
                .age(5)                                                 // enables BUSINESS_AGE
                .revenueStabilityCoefficient(new BigDecimal("55.41"))
                .revenueTrendPercentage(new BigDecimal("-14.01"))
                .operatingExpenseRatio(new BigDecimal("100.59"))
                .supplierPaymentConsistencyScore(null)                  // only skip
                .cashBufferMonths(new BigDecimal("0.16"))
                .corporateCashFlow(new BigDecimal("-654.96"))
                .paymentBehaviorScore(new BigDecimal("71.45"))
                .build();
    }
}