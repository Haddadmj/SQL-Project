package com.ejada.obdatarepositoryapp.creditrisk.integration;

import com.ejada.obdatarepositoryapp.creditrisk.config.CreditRiskConfig;
import com.ejada.obdatarepositoryapp.creditrisk.domain.ObAccount;
import com.ejada.obdatarepositoryapp.creditrisk.dto.TransactionData;
import com.ejada.obdatarepositoryapp.creditrisk.dto.request.CreditRiskRequest;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.CreditRiskReportResponse;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.FactorScore;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType;
import com.ejada.obdatarepositoryapp.creditrisk.enums.RiskFactorType;
import com.ejada.obdatarepositoryapp.creditrisk.service.CreditRiskScoringService;
import com.ejada.obdatarepositoryapp.creditrisk.service.FinancialMetricsCalculator;
import com.ejada.obdatarepositoryapp.creditrisk.service.OpenBankingDataFetcher;
import com.ejada.obdatarepositoryapp.creditrisk.validation.TransactionDataValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * End-to-end validation of the credit risk API response against the bakery fixture
 * (data_transactions.json). Mocks only the data-fetch boundary; uses the REAL
 * FinancialMetricsCalculator and CreditRiskScoringService.
 *
 * NOTE: maven-surefire-plugin is configured with skip=true in pom.xml. To run this
 * test, temporarily flip to skip=false, then restore.
 */
@ExtendWith(MockitoExtension.class)
class BakeryFixtureIntegrationTest {

    private static final Path FIXTURE_PATH = Paths.get("data_transactions.json");
    private static final Path OUTPUT_PATH = Paths.get("target/bakery-credit-risk-report-old.json");

    private static final List<DateTimeFormatter> DATE_FORMATTERS = Arrays.asList(
            DateTimeFormatter.ISO_DATE_TIME,
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd")
    );

    @Mock
    private OpenBankingDataFetcher dataFetcher;

    private final CreditRiskConfig config = new CreditRiskConfig();
    private final TransactionDataValidator validator = new TransactionDataValidator();
    private final ObjectMapper objectMapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .enable(SerializationFeature.INDENT_OUTPUT)
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

    @Test
    void generateReport_forBakeryFixture_emitsValidatedResponse() throws Exception {
        // 1. Load and parse fixture
        assertThat(FIXTURE_PATH).as("fixture file must exist at repo root").exists();
        List<TransactionData> transactions = loadFixture(FIXTURE_PATH);
        assertThat(transactions).as("fixture must contain transactions").isNotEmpty();
        System.out.printf("Loaded %d transactions from %s%n", transactions.size(), FIXTURE_PATH);

        // 2. Build real services with mocked data fetcher
        FinancialMetricsCalculator metricsCalculator = new FinancialMetricsCalculator(config, validator);
        CreditRiskScoringService service = new CreditRiskScoringService(dataFetcher, metricsCalculator);

        // 3. Mock data fetcher boundary
        ObAccount account = ObAccount.builder()
                .id("test-acc-7a4f2996")
                .userId("test-psu-b864a11d")
                .integratedId("test-acc-7a4f2996")
                .sponsoredTppId("test-tpp")
                .data("{}")
                .build();

        OpenBankingDataFetcher.AccountInfo accountInfo = OpenBankingDataFetcher.AccountInfo.builder()
                .accountId("test-acc-7a4f2996")
                .accountHolderName("TASTE OF FLOUR BAKERY")
                .accountNumber("SA0000000000000000000000")
                .currentBalance(BigDecimal.ZERO)
                .build();

        when(dataFetcher.getAccount(any(), any(), any(), any())).thenReturn(Optional.of(account));
        when(dataFetcher.getTransactionsForAccount(any(), any(), any())).thenReturn(transactions);
        when(dataFetcher.parseAccountInfo(any())).thenReturn(accountInfo);

        // 4. Build request — CORPORATE, no age (matches the fix doc fixture)
        CreditRiskRequest request = CreditRiskRequest.builder()
                .psuId("test-psu-b864a11d")
                .accountLinkId("test-link")
                .accountId("test-acc-7a4f2996")
                .sponsoredTppId("test-tpp")
                .customerType(CustomerType.CORPORATE)
                .age(null)
                .build();

        // 5. Run scoring
        CreditRiskReportResponse response = service.generateReport(request);

        // 6. Serialise + persist + print
        String json = objectMapper.writeValueAsString(response);
        Files.createDirectories(OUTPUT_PATH.getParent());
        Files.writeString(OUTPUT_PATH, json);
        System.out.println("=== CREDIT RISK API RESPONSE (CORPORATE, " + transactions.size() + " transactions) ===");
        System.out.println(json);
        System.out.println("=== Response written to: " + OUTPUT_PATH.toAbsolutePath() + " ===");

        // 7. Structural assertions — invariants from the three fixes
        assertThat(response.getCustomerType()).isEqualTo(CustomerType.CORPORATE);
        assertThat(response.getMaxPossibleScore())
                .as("Task 1: divisor normalises to 1000")
                .isEqualTo(1000);

        // Task 1: factorsSkipped count and identity
        assertThat(response.getMetadata().getFactorsSkipped())
                .as("BUSINESS_AGE skipped (no age) + SUPPLIER_PAYMENT_CONSISTENCY skipped (no signal)")
                .isEqualTo(2);

        List<RiskFactorType> skippedTypes = response.getFactorScores().stream()
                .filter(f -> !Boolean.TRUE.equals(f.getDataAvailable()))
                .map(FactorScore::getFactorType)
                .toList();
        assertThat(skippedTypes).contains(RiskFactorType.BUSINESS_AGE);

        // Task 2: No V1 labels surface anywhere in factor scores
        List<String> allLabels = response.getFactorScores().stream()
                .map(FactorScore::getScoreLabel)
                .filter(java.util.Objects::nonNull)
                .toList();
        assertThat(allLabels)
                .as("Task 2: 'Loss-Making' and 'Critical' V1 labels are purged")
                .doesNotContain("Loss-Making", "Critical");

        // Task 3: retail-heritage fields absent from corporate response
        assertThat(response.getFinancialMetrics().getEmergencyFundMonths())
                .as("Task 3: emergencyFundMonths nulled for corporate").isNull();
        assertThat(response.getFinancialMetrics().getSavingsRate())
                .as("Task 3: savingsRate nulled for corporate").isNull();
        assertThat(response.getFinancialMetrics().getSurplusRatio())
                .as("Task 3: surplusRatio nulled for corporate").isNull();

        // 8. Print the headline numbers for human comparison against post_validation_fixes.md
        System.out.printf("HEADLINE: totalScore=%d, ratingClass=%s, ratingClassName=%s, approval=%s%n",
                response.getTotalScore(),
                response.getRatingClass(),
                response.getRatingClassName(),
                response.getApprovalRecommendation());
    }

    // ── Fixture loader ────────────────────────────────────────────────────

    private List<TransactionData> loadFixture(Path path) throws Exception {
        JsonNode root = objectMapper.readTree(path.toFile());
        if (!root.isArray()) {
            throw new IllegalStateException("Fixture root must be a JSON array, was " + root.getNodeType());
        }

        List<TransactionData> out = new ArrayList<>();
        for (JsonNode entry : root) {
            TransactionData tx = parseEntry(entry);
            if (tx != null && tx.getTransactionDateTime() != null) {
                out.add(tx);
            }
        }
        // Match OpenBankingDataFetcher.getTransactionsForAccount ordering (desc by date)
        out.sort(Comparator.comparing(TransactionData::getTransactionDateTime).reversed());
        return out;
    }

    private TransactionData parseEntry(JsonNode entry) {
        JsonNode data = entry.path("data");
        if (data.isMissingNode() || data.isNull()) {
            return null;
        }

        LocalDateTime txDateTime = parseTransactionDateTime(data);
        if (txDateTime == null) {
            txDateTime = parseCreatedAt(entry.path("created_at").asText(null));
        }

        return TransactionData.builder()
                .transactionId(entry.path("id").asText(null))
                .accountId(entry.path("account_id").asText(null))
                .transactionDateTime(txDateTime)
                .amount(parseAmount(data))
                .currency(parseCurrency(data))
                .creditDebitIndicator(textOrNull(data, "CreditDebitIndicator"))
                .status("Booked")
                .transactionType(textOrNull(data, "TransactionType"))
                .description(textOrNull(data, "TransactionInformation"))
                .reference(textOrNull(data, "TransactionReference"))
                .balanceAfter(parseBalanceAfter(data))
                .build();
    }

    private LocalDateTime parseTransactionDateTime(JsonNode data) {
        String dateStr = textOrNull(data, "BookingDateTime");
        if (dateStr == null) {
            dateStr = textOrNull(data, "ValueDateTime");
        }
        return parseDateTime(dateStr);
    }

    private LocalDateTime parseCreatedAt(String value) {
        return parseDateTime(value);
    }

    private LocalDateTime parseDateTime(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        for (DateTimeFormatter formatter : DATE_FORMATTERS) {
            try {
                return LocalDateTime.parse(value, formatter);
            } catch (Exception ignored) {
                // try next
            }
        }
        try {
            return LocalDateTime.ofInstant(Instant.parse(value), ZoneId.systemDefault());
        } catch (Exception e) {
            return null;
        }
    }

    private BigDecimal parseAmount(JsonNode data) {
        JsonNode amount = data.path("Amount");
        if (amount.isMissingNode()) return BigDecimal.ZERO;
        String s = amount.path("Amount").asText(null);
        if (s == null) s = amount.asText(null);
        try {
            return s != null ? new BigDecimal(s) : BigDecimal.ZERO;
        } catch (NumberFormatException e) {
            return BigDecimal.ZERO;
        }
    }

    private String parseCurrency(JsonNode data) {
        JsonNode amount = data.path("Amount");
        if (amount.isMissingNode()) return null;
        return textOrNull(amount, "Currency");
    }

    private BigDecimal parseBalanceAfter(JsonNode data) {
        JsonNode balance = data.path("Balance");
        if (balance.isMissingNode()) return null;
        JsonNode amount = balance.path("Amount");
        if (amount.isMissingNode()) return null;
        String s = amount.path("Amount").asText(null);
        if (s == null) return null;
        try {
            BigDecimal value = new BigDecimal(s);
            String indicator = balance.path("CreditDebitIndicator").asText(null);
            if ("KSAOB.Debit".equals(indicator) && value.signum() > 0) {
                value = value.negate();
            }
            return value;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String textOrNull(JsonNode node, String field) {
        JsonNode child = node.path(field);
        return child.isMissingNode() || child.isNull() ? null : child.asText(null);
    }
}
