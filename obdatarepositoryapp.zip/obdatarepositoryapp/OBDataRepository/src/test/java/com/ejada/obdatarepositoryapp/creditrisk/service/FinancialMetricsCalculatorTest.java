package com.ejada.obdatarepositoryapp.creditrisk.service;

import com.ejada.obdatarepositoryapp.creditrisk.config.CreditRiskConfig;
import com.ejada.obdatarepositoryapp.creditrisk.dto.TransactionData;
import com.ejada.obdatarepositoryapp.creditrisk.dto.response.FinancialMetrics;
import com.ejada.obdatarepositoryapp.creditrisk.enums.CustomerType;
import com.ejada.obdatarepositoryapp.creditrisk.validation.TransactionDataValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FinancialMetricsCalculatorTest {

    @Spy
    private CreditRiskConfig config = new CreditRiskConfig();

    @Mock
    private TransactionDataValidator validator;

    @InjectMocks
    private FinancialMetricsCalculator calculator;

    @BeforeEach
    void setUp() {
        // Pass transactions through without filtering
        when(validator.validateAndFilter(any())).thenAnswer(inv -> inv.getArgument(0));
    }

    // ── Task 3: retail-heritage fields absent from corporate response ──────

    @Test
    void corporate_surplusRatioIsNull() {
        // surplusRatio is set to ZERO by buildEmptyMetrics but must be nulled for corporate
        FinancialMetrics result = calculator.calculate(List.of(), CustomerType.CORPORATE, null);

        assertThat(result.getSurplusRatio()).isNull();
    }

    @Test
    void corporate_savingsRateIsNull() {
        // With real income/expense transactions, savingsRate is non-zero; must be null for corporate
        FinancialMetrics result = calculator.calculate(threeMonthsOfTransactions(), CustomerType.CORPORATE, null);

        assertThat(result.getSavingsRate()).isNull();
    }

    @Test
    void corporate_emergencyFundMonthsIsNull() {
        // With real income/expense transactions, emergencyFundMonths is non-zero; must be null for corporate
        FinancialMetrics result = calculator.calculate(threeMonthsOfTransactions(), CustomerType.CORPORATE, null);

        assertThat(result.getEmergencyFundMonths()).isNull();
    }

    @Test
    void retail_surplusRatioIsNotNull() {
        // retail path must NOT null out surplusRatio
        FinancialMetrics result = calculator.calculate(List.of(), CustomerType.RETAIL, null);

        assertThat(result.getSurplusRatio()).isNotNull();
    }

    @Test
    void retail_savingsRateIsNotNull() {
        // retail path must NOT null out savingsRate
        FinancialMetrics result = calculator.calculate(threeMonthsOfTransactions(), CustomerType.RETAIL, null);

        assertThat(result.getSavingsRate()).isNotNull();
    }

    @Test
    void retail_emergencyFundMonthsIsNotNull() {
        // retail path must NOT null out emergencyFundMonths
        FinancialMetrics result = calculator.calculate(threeMonthsOfTransactions(), CustomerType.RETAIL, null);

        assertThat(result.getEmergencyFundMonths()).isNotNull();
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    /**
     * Three months of income + expense transactions so calculateBase() produces
     * non-zero savingsRate (needs avgIncome > 0) and emergencyFundMonths (needs avgExpenses > 0).
     */
    private List<TransactionData> threeMonthsOfTransactions() {
        return List.of(
                credit(2025, 1, 10000),
                debit(2025, 1, 6000),
                credit(2025, 2, 10000),
                debit(2025, 2, 6000),
                credit(2025, 3, 10000),
                debit(2025, 3, 6000)
        );
    }

    private TransactionData credit(int year, int month, double amount) {
        return TransactionData.builder()
                .transactionId(UUID.randomUUID().toString())
                .amount(BigDecimal.valueOf(amount))
                .creditDebitIndicator("KSAOB.Credit")
                .transactionDateTime(LocalDateTime.of(year, month, 15, 12, 0))
                .status("BOOKED")
                .build();
    }

    private TransactionData debit(int year, int month, double amount) {
        return TransactionData.builder()
                .transactionId(UUID.randomUUID().toString())
                .amount(BigDecimal.valueOf(amount))
                .creditDebitIndicator("KSAOB.Debit")
                .transactionDateTime(LocalDateTime.of(year, month, 20, 12, 0))
                .status("BOOKED")
                .build();
    }
}
