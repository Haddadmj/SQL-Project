package com.ejada.obdatarepositoryapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObDataRepositoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
