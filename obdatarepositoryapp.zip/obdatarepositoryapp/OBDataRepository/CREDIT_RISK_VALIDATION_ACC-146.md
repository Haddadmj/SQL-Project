# Credit Risk Scoring — Validation Report: ACC-146

## 1. Header

| Field | Value |
|---|---|
| **Account ID** | `ACC-146` |
| **Endpoint** | `POST /api/v1/credit-risk/getCreditRiskReport` |
| **`psuId`** | `AbrarCRA2` |
| **`accountLinkId`** | `1442` |
| **`sponsoredTppId`** | `01K920FBZBT9NE8WRP8BQSHSBQ` |
| **`customerType`** | `RETAIL` |
| **`accountId`** | `ACC-146` |
| **`age`** | *not supplied* (AGE factor disabled — see global note) |
| **Date validated** | 2026-06-14 |
| **Report ID** | `754344c9-fc2c-4c67-9165-fd257cc28bff` |
| **Headline result** | **Score 659 / Rating BBB "Satisfactory" / Approval: Moderate** |

> **Global note (applies to all three accounts):** the request **omits `age`**, so the AGE factor is disabled (`dataAvailable=false`, `maxScore=150`). The engine then renormalizes: `totalScore = round(sumAvailable × 1000 / 850)`. This is CFD divergence **D6** — the code does **proportional** renormalization, whereas the DF-4018 acceptance criteria require a missing factor's weight to be **redistributed equally** to the remaining factors. The QA-workbook expectations correspond to the **raw `sumAvailable`** (flat sum, no `×1000/850` inflation), i.e. the scenario where AGE is actually evaluated. **Supplying `age` in the request would evaluate AGE (no redistribution) and bring the total back toward the QA flat-sum expectation.**

---

## 2. Executive Summary

The ACC-146 report is **internally fully consistent**: all financial metrics and all six evaluated factor scores reproduce exactly (to the cent) under independent recomputation against `RULES.md`. The headline **659 / BBB** is arithmetically correct *for the code as written*, but it **does not conform to DF-4018** on two counts: the surplus-ratio formula (**D1**) understates this account's true surplus band, and the proportional `×1000/850` renormalization (**D6**) inflates the flat-sum result of **560 (BB)** up to **659 (BBB)** — a one-class overstatement. The single most important fix is **D6**: supplying `age` in the request (or switching to spec-compliant equal redistribution) reproduces the QA-workbook expectation of **560 / BB**.

---

## 3. Input Data Profile

| Attribute | Value |
|---|---|
| Total transactions | 165 (12 credit, 153 debit) |
| Months of data (`monthsOfData`) | 12 |
| Date range | 2025-03-03 → 2026-02-28 |
| Salary pattern | 12 monthly salary credits `Salary - Riyad Bank HQ / راتب`, `salaryRegularity = 1.00`, avg salary 9,458.33 |
| Debt obligations | One `1,200` car-loan debit per month (`Al Rajhi Auto Finance`) = **14,400** total |
| Notable txns | No bonus, no mortgage, no credit card, no zero-income month |

### Expense-category breakdown

| Category | Amount (SAR) | % of categorized debits |
|---|---:|---:|
| Others | 39,278.00 | 39.44% |
| Living Expenses | 37,940.00 | 38.09% |
| Loan Repayments | 14,400.00 | 14.46% |
| Utilities | 7,982.00 | 8.01% |

---

## 4. Financial Metrics Validation

All metrics recomputed from `/tmp/parsed_ACC-146.json` per `RULES.md` and matched against the report. **All PASS.**

| Metric | Computed | Report | Result |
|---|---:|---:|---|
| `averageMonthlyIncome` | 9,458.33 | 9,458.33 | PASS |
| `medianMonthlyIncome` | 9,500.00 | 9,500.00 | PASS |
| `medianSalaryIncome` | 9,500.00 | 9,500.00 | PASS |
| `averageMonthlyExpenses` | 7,100.00 | 7,100.00 | PASS |
| `surplusRatio` | 0.1263 | 0.1263 | PASS |
| `debtBurdenRatio` | 0.1263 | 0.1263 | PASS |
| `cashFlow` | 2,358.33 | 2,358.33 | PASS |
| `savingsRate` | 0.25 | 0.25 | PASS |
| `emergencyFundMonths` | 3.99 | 3.99 | PASS |
| `incomeVolatility` | 1.95 | 1.95 | PASS |

No float-cosmetic artifacts on this account; every value matched exactly. (`averageBalance6M` reports `0.0` — see divergence **D8**.)

---

## 5. Factor Scoring Validation

| Factor | Raw value | Band matched | Score / Max | Label | Result |
|---|---:|---|---:|---|---|
| AGE | — | *skipped* | 0 / 150 | — (disabled) | PASS |
| INCOME | 9,500 | 5001–10000 | 50 / 150 | Low income | PASS |
| LOAN_PAYMENT | 1,200 | ≤1500 | 150 / 150 | Very low debt | PASS |
| SURPLUS_RATIO | 12.63 | 11–20 | 100 / 150 | Moderate surplus (11–20%) | PASS |
| SALARY_CATEGORY | 9,500 | 5001–15000 | 90 / 150 | Medium Risk | PASS |
| CASH_FLOW | 2,358.33 | 1001–3000 | 100 / 150 | Moderate positive | PASS |
| DEBT_BURDEN_RATIO | 12.63 | 11–25 | 70 / 100 | Good (11–25%) | PASS |

### Total-score arithmetic

```
sumAvailable      = 50 + 150 + 100 + 90 + 100 + 70 = 560
AGE skipped       → skippedMaxScore = 150
availableMaxPoints = 1000 − 150 = 850
totalScore        = round(560 × 1000 / 850) = round(658.82) = 659
ratingClass       = BBB (600–699) "Satisfactory"
```

`maxAffordablePayment = floor(2,358.33 × 0.3) = 707`. Strengths: Loan Payment, Debt Burden Ratio. Weakness: Income (Low income). No recommendations triggered.

---

## 6. DF-4018 Spec Conformance (Divergences D1–D8)

| # | Divergence | Per-account impact on ACC-146 |
|---|---|---|
| **D1** | **Surplus Ratio**: code = `(median − avgExp − avgDebt)/median`; spec = `(income − exp)/income` (no debt) | **MATERIAL.** Spec surplus = `(9500 − 7100)/9500 = 25.26%` → band **21–30 → 130** vs code's 100. **+30 raw if corrected.** |
| D2 | **Cash Flow**: code = `avg(salary) − avg(non-debt debits)`; QA = `(Σsalary − Σ ALL debits)/n` | Band-neutral. Salary = income; recompute stays in 1001–3000 → 100. |
| D3 | **Salary Category**: code uses L3M median salary; spec uses last-month salary | Band-neutral. Last-month salary 9,500 stays in 5001–15000 → 90. |
| D4 | **DBR denominator**: code ÷ median **salary**; spec ÷ median **income** | Band-neutral. Salary = income here (no non-salary credits). |
| D5 | **Loan Payment**: code includes mortgages; spec is loans only | Band-neutral. No mortgage present. |
| **D6** | **Redistribution**: proportional `×1000/850` vs spec "equally" | **MATERIAL.** Inflates 560 → 659, i.e. **BB → BBB (one rating class)**. Explains the 659-vs-QA gap. |
| D7 | **monthsOfData**: code counts only months with txns | No impact. All 12 calendar months in range have transactions; no gaps. |
| D8 | **Avg Balance 6M**: code `0.0` vs spec "Not Available" | Cosmetic. `averageBalance6M = 0.0`; display-only, not scored. |

> **Latent keyword quirk (classification):** the four `Utilities: MARAFIQ Utilities` debits fall into **Others**, not **Utilities**, because the engine's keyword is `"utility"` (singular) and does not substring-match `"Utilities"` (plural). The engine and the independent recompute **agree**, so this is a latent keyword gap rather than a discrepancy — but it slightly understates the Utilities category and overstates Others.

---

## 7. Comparison to QA Workbook Expectation

| | Expected (QA workbook) | Actual (live API) |
|---|---|---|
| Total | **560** | **659** |
| Rating | **BB** | **BBB** |

**Explanation.** The QA-workbook figure of `560 → BB` corresponds to the **raw flat `sumAvailable`** — the run in which AGE was actually evaluated (the QA sheet supplied `age = 17`, which scored 0 points but kept all seven factor weights live, so no redistribution occurred). The live request **omits `age`**, which disables AGE and triggers the proportional `×1000/850` renormalization (**D6**), inflating 560 to 659 and pushing the rating one class higher to BBB. **With `age` supplied, the code reproduces 560 / BB exactly.**

---

## 8. Findings & Recommendations

- **[P1 — D6, rating-class impact]** The omitted-`age` proportional renormalization moves this account from **BB to BBB**. Supply `age` in the request (recommended near-term) or change the engine to **redistribute the missing factor's weight equally** per DF-4018 acceptance criteria.
- **[P2 — D1, band impact]** Align the Surplus Ratio formula with DF-4018 (`(income − expenses)/income`, no debt term). For ACC-146 this raises the factor from 100 to 130 (band 21–30), a **+30 raw** correction that better reflects the account's genuine 25.26% surplus.
- **[P3 — classification keyword gap]** Add `"utilities"` (plural) to the utility keyword list so `MARAFIQ Utilities` debits are categorized as Utilities rather than Others. Cosmetic for scoring but improves category reporting accuracy.
- **[P4 — D8 display]** Surface `averageBalance6M` as **"Not Available"** rather than `0.0` until the external balance feed is integrated, per DF-4018 QA issue #2.
- **[Pass — no action]** All financial metrics and factor arithmetic are correct as implemented; loan/expense exclusion and emergency-fund logic match the spec (QA issues #7 and warning #3).
