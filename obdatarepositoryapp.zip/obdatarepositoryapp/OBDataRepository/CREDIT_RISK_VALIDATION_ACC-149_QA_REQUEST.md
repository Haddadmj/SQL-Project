# Credit Risk Validation — ACC-149 (QA Request, age = 17)

**Endpoint:** `POST /api/v1/credit-risk/getCreditRiskReport`
**Validated:** 2026-06-14
**Request (QA replica):**
```json
{
  "psuId": "AbrarCRA2",
  "accountLinkId": "1442",
  "accountId": "ACC-149",
  "sponsoredTppId": "01K920FBZBT9NE8WRP8BQSHSBQ",
  "customerType": "RETAIL",
  "age": 17
}
```
**Result:** `totalScore = 780` · `ratingClass = A` ("Good") · approval **High**

> **QA-replica note.** With `age = 17` supplied, AGE is evaluated (scores 0, `dataAvailable = true`), so the ×1000/850 redistribution is **off** and the total is the flat sum: 780 → A. The prior age-omitted run returned **918/AAA** — a two-rating-class overstatement caused entirely by the D6 redistribution artifact, now eliminated. **780/A matches the QA workbook to the dot.**

---

## 1. Executive Summary

- **Internally consistent:** ✅ Yes — every metric and factor score reproduces exactly.
- **Follows DF-4018 to the dot:** ⚠️ **Score matches QA, but one factor formula is wrong here.** **D5 (Loan Payment)** folds a **mortgage** into the loan-payment factor (band 110); the spec scopes that factor to *loans only*, which would score 150 (+40 → spec-correct 820/AA). The code's 780/A coincides with the QA workbook value, but the underlying loan-payment factor is mis-scored.
- **Headline win:** confirming `age` eliminates the D6 redistribution that had inflated this account to 918/AAA.

---

## 2. Input Data Profile

| Property | Value |
|---|---|
| Transactions | 295 (16 credit, 279 debit) |
| Months of data | 15 (2024-12 → 2026-02, consecutive) |
| Salary pattern | 15 monthly credits `"Salary - SABIC / راتب"`, avg 28,013.33 SAR |
| ⚠️ Bonus | 1 credit `"Annual Performance Bonus - SABIC / مكافأة أداء"` (24,200, 2025-07) — **not** classified as salary; it is a `LocalBankTransfer` → excluded from other-income, counts in gross income only |
| Debt | **All debt is mortgage** (SABB Home Finance), 4,000/mo = 60,000 total; **loan = 0** |
| Current balance | 36,776.00 SAR · IBAN SA78…1821 · SAIB |

**Expense categories** (debits, total 287,100):

| Category | Amount | % |
|---|---|---|
| Living Expenses | 125,114.00 | 43.58 % |
| Others | 85,809.00 | 29.89 % |
| Loan Repayments | 60,000.00 | 20.90 % |
| Utilities | 16,177.00 | 5.63 % |

---

## 3. Financial Metrics Validation

All metrics **PASS** (±0.01).

| Metric | Value | Metric | Value |
|---|---|---|---|
| averageMonthlyIncome | 29,626.67 (bonus-inflated) | surplusRatio | 0.3189 |
| medianMonthlyIncome | 28,100.00 | debtBurdenRatio | 0.1423 |
| medianSalaryIncome | 28,100.00 | cashFlow | 12,873.33 |
| savingsRate | 0.49 | emergencyFundMonths | 14.35 |
| incomeVolatility | **20.20 %** (bonus-driven) | expenseVolatility | 3.47 % |
| salaryRegularity | 1.0 (15 occ) | averageSalaryAmount | 28,013.33 |

**Bonus / spike behavior:** the July 2025 bonus lands at index 7, **outside** the L3M window `[28100, 27800, 28200]` (threshold 36,530, nothing dropped). It therefore does **not** touch any median and is **scoring-neutral**, but it is the sole driver of the 20.20 % income-volatility figure.

---

## 4. Factor Scoring (age = 17, flat sum)

| Factor | Raw value | Band | Score / Max | Label |
|---|---|---|---|---|
| AGE | 17 | *no band* | **0** / 150 | Very Poor |
| INCOME | 28,100 | ≥ 15,001 | **150** / 150 | High income |
| LOAN_PAYMENT | 4,000 *(mortgage)* | 3,001–4,500 | **110** / 150 | Moderate debt |
| SURPLUS_RATIO | 31.89 | 31–100 | **150** / 150 | Excellent surplus |
| SALARY_CATEGORY | 28,100 | ≥ 15,001 | **150** / 150 | Low Risk |
| CASH_FLOW | 12,873.33 | ≥ 3,001 | **150** / 150 | Strong positive |
| DEBT_BURDEN_RATIO | 14.23 | 11–25 | **70** / 100 | Good |

**Total:** `0 + 150 + 110 + 150 + 150 + 150 + 70 = 780`. `factorsSkipped = 0`, `weightsRedistributed = false` → **780 → A**. ✅

**Recommendation:** strengths = all 6 evaluated non-AGE factors (DBR included at exactly 70 % via `>= 70`); weaknesses = [Age: Very Poor]; recommendations = []; `maxAffordablePayment = floor(12,873.33 × 0.3) = 3,861`.

---

## 5. DF-4018 Conformance — Does it follow the spec to the dot?

| Div | Spec rule | Code → band → pts | Spec → band → pts | Δ pts | Class effect |
|---|---|---|---|---|---|
| **D5 Loan Payment** | **loans only** | mortgage 4,000 → 110 | loans 0 → **150** | **+40** | A → **AA** |
| D1 Surplus Ratio | `(income − exp)/income` | 31.89 % → 150 | 46.12 % → 150 | 0 | inert (both top band) |
| D2 Cash Flow | `(Σsalary − Σall debits)/n` | 12,873.33 → 150 | 8,873.33 → 150 | 0 | inert (both ≥ 3,001) |
| D3 Salary Category | last-month salary | 28,100 → 150 | 28,100 → 150 | 0 | inert |
| D4 DBR | ÷ median income | 14.23 % → 70 | 14.23 % → 70 | 0 | inert (salary = income) |
| D6 Redistribution | "equally" | inactive (age supplied) | — | — | ✅ off (this is what removed the 918/AAA inflation) |
| D7 monthsOfData | inject zero-activity months | 15 (all present) | 15 | 0 | inert (no gap) |
| D8 Avg Balance 6M | "Not Available" | **0.0** | — | — | ❌ fails |

**Material divergence: D5.** The 4,000/mo obligation is a *mortgage*, but the engine's `lastMonthDebtPayment` (loans + mortgages) feeds the LOAN_PAYMENT factor, scoring 110. The DF-4018 LOAN_PAYMENT factor is scoped to *loan payments*; correcting it gives loans = 0 → band 150 (+40), i.e. **spec-correct 820/AA**. (Note the mortgage *is* still correctly captured in `debtBurdenRatio` and `totalDebtPayments`.)

---

## 6. Comparison to QA Workbook

| | QA workbook | Code (age = 17) | Spec-correct (D5 applied) |
|---|---|---|---|
| Total | **780** | **780** ✅ | 820 |
| Class | **A** | **A** ✅ | AA |

The live code reproduces the QA expectation **780/A to the dot** — but note this match holds *with* the D5 mortgage-in-loan behavior; the strictly spec-correct figure (loans only) would be **820/AA**. The earlier **918/AAA** was a redistribution artifact and is now gone.

---

## 7. Findings & Recommendations

1. **✅ D6 confirmed as the prior inflation source** — supplying `age` removed the ×1000/850 renormalization; 918/AAA → 780/A, matching QA.
2. **⚠️ Fix D5 (Loan Payment scope)** — the factor folds mortgages into the loan-payment amount. Per DF-4018 it should be loans-only (here → 150, total 820/AA). The mortgage remains correctly counted in DBR/total debt.
3. **ℹ️ Bonus correctly handled** — the "Annual Performance Bonus" is correctly non-salary and outside the L3M medians (scoring-neutral); it only drives the 20.20 % income-volatility figure.
4. **⚠️ D8** — `averageBalance6M` 0.0 should be "Not Available".
5. **ℹ️ DBR at exactly 70 %** correctly counts as a strength via the `>= 70` threshold.
