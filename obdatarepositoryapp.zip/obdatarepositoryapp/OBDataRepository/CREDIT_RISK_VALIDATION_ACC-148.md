# Credit Risk Scoring — Validation Report: ACC-148

## 1. Header

| Field | Value |
|---|---|
| **Account ID** | `ACC-148` |
| **Endpoint** | `POST /api/v1/credit-risk/getCreditRiskReport` |
| **`psuId`** | `AbrarCRA2` |
| **`accountLinkId`** | `1442` |
| **`sponsoredTppId`** | `01K920FBZBT9NE8WRP8BQSHSBQ` |
| **`customerType`** | `RETAIL` |
| **`accountId`** | `ACC-148` |
| **`age`** | *not supplied* (AGE factor disabled — see global note) |
| **Date validated** | 2026-06-14 |
| **Report ID** | `f128f361-0f34-4a43-afd7-6ff836a415d4` |
| **Headline result** | **Score 318 / Rating CCC "Weak" / Approval: Low** |

> **Global note (applies to all three accounts):** the request **omits `age`**, so the AGE factor is disabled (`dataAvailable=false`, `maxScore=150`). The engine then renormalizes: `totalScore = round(sumAvailable × 1000 / 850)`. This is CFD divergence **D6** — the code does **proportional** renormalization, whereas DF-4018 acceptance criteria require a missing factor's weight to be **redistributed equally**. The QA-workbook expectations correspond to the **raw `sumAvailable`** (flat sum, AGE evaluated). **Supplying `age` would evaluate AGE (no redistribution) and bring the total toward the QA flat-sum expectation.**

---

## 2. Executive Summary

The ACC-148 report is **internally consistent** — all metrics and factor scores reproduce under independent recomputation, with a single harmless IEEE-754 cosmetic artifact in `surplusRatio` (band unaffected). The headline **318 / CCC "Weak"** correctly reflects a stressed retail profile: a **critical income-drop flag** (last month income 0, `−100%`) and **high income volatility** (41.21%). Interestingly, conformance to DF-4018 is a near-wash here: divergences **D1** and **D2** have **opposite-sign errors that offset**, so the spec-correct flat sum would be **320** — matching the QA workbook to within the 2-point `×1000/850`-vs-flat artifact. The one thing to fix remains **D6** (renormalization), plus the offsetting **D1/D2** sign errors that happen to cancel on this account but are not structurally sound.

---

## 3. Input Data Profile

| Attribute | Value |
|---|---|
| Total transactions | 53 (6 credit, 47 debit) |
| Months of data (`monthsOfData`) | 7 |
| Date range | 2025-09-02 → 2026-03-01 |
| Salary pattern | 6 salary credits `Salary - Retail Chain (Hourly) / راتب`, hourly/irregular |
| Debt obligations | One `1,000` loan debit per month = **6,000** total; no mortgage |
| Notable txns | **Trailing month 2026-03 is a ZERO-INCOME month** — a single `428` debit, income = 0. It is present and counted (`monthsOfData = 7`). No missing (zero-activity) calendar months, so **D7 is inert** here. |

### Expense-category breakdown

| Category | Amount (SAR) | % of categorized debits |
|---|---:|---:|
| Others | 7,918.00 | 35.07% |
| Loan Repayments | 6,000.00 | 26.58% |
| Living Expenses | 5,218.00 | 23.11% |
| Utilities | 3,441.00 | 15.24% |

---

## 4. Financial Metrics Validation

All metrics recomputed and matched. **All PASS** (one cosmetic float noted).

| Metric | Computed | Report | Result |
|---|---:|---:|---|
| `averageMonthlyIncome` | 2,585.71 | 2,585.71 | PASS |
| `medianMonthlyIncome` | 2,900.00 | 2,900.00 | PASS |
| `medianSalaryIncome` | 2,900.00 | 2,900.00 | PASS |
| `averageMonthlyExpenses` | 2,368.14 | 2,368.14 | PASS |
| `surplusRatio` | −0.1122 | −0.1122 | PASS* |
| `debtBurdenRatio` | 0.2956 | 0.2956 | PASS |
| `cashFlow` | 217.57 | 217.57 | PASS |
| `lastMonthIncome` | 0.00 | 0.00 | PASS |
| `lastMonthIncomeChange` | −100.00 | −100.00 | PASS (CRITICAL flag) |
| `incomeVolatility` | 41.21 | 41.21 | PASS (HIGH flag) |

> *\*Float-cosmetic artifact:* the SURPLUS_RATIO factor `rawValue` recomputes to `−11.21999…` vs the reported `−11.22` — IEEE-754 rounding noise only. The band match (`−100…0 → 0`) is **unaffected**.

`medianSalaryIncome = 2,900`: L3M window `[2026-03, 2026-02, 2026-01]` incomes `[0, 2900, 3200]`; spike threshold `2900 × 1.3 = 3,770`; nothing dropped; median = 2,900. `averageBalance6M = 0.0` (divergence **D8**).

---

## 5. Factor Scoring Validation

| Factor | Raw value | Band matched | Score / Max | Label | Result |
|---|---:|---|---:|---|---|
| AGE | — | *skipped* | 0 / 150 | — (disabled) | PASS |
| INCOME | 2,900 | ≤5000 | 0 / 150 | Below minimum threshold | PASS |
| LOAN_PAYMENT | 0 | ≤1500 | 150 / 150 | Very low debt | PASS |
| SURPLUS_RATIO | −11.22 | −100…0 | 0 / 150 | Spending more than earning | PASS |
| SALARY_CATEGORY | 2,900 | ≤5000 | 30 / 150 | High Risk | PASS |
| CASH_FLOW | 217.57 | 0–1000 | 50 / 150 | Minimal positive | PASS |
| DEBT_BURDEN_RATIO | 29.56 | 26–40 | 40 / 100 | Moderate (26–40%) | PASS |

> Note on LOAN_PAYMENT raw = 0: `lastMonthDebtPayment` is 0 because the trailing month (2026-03) carries no loan debit; the factor falls back to raw = 0 with `dataAvailable = true`, mapping to the ≤1500 → 150 band. This is correct per `RULES.md`.

### Total-score arithmetic

```
sumAvailable      = 0 + 150 + 0 + 30 + 50 + 40 = 270
AGE skipped       → skippedMaxScore = 150
availableMaxPoints = 1000 − 150 = 850
totalScore        = round(270 × 1000 / 850) = round(317.65) = 318
ratingClass       = CCC (300–399) "Weak"
```

`maxAffordablePayment = floor(217.57 × 0.3) = 65`. Strengths: Loan Payment (1). Weaknesses: Income, Surplus Ratio, Salary Category, Cash Flow (4). Recommendation triggered: *"Consider reducing monthly expenses to improve surplus ratio"* (because `surplusRatio < 0.1`).

---

## 6. DF-4018 Spec Conformance (Divergences D1–D8)

| # | Divergence | Per-account impact on ACC-148 |
|---|---|---|
| **D1** | **Surplus Ratio**: code subtracts debt & uses median; spec = `(median − exp)/median` (no debt) | **MATERIAL (offsetting).** Spec surplus = `(2900 − 2368.14)/2900 = 18.34%` → band **11–20 → 100** vs code's 0. **+100 raw**; alone would lift CCC → B. |
| **D2** | **Cash Flow**: code = `avg(salary) − avg(non-debt debits)`; QA = `(Σsalary − Σ ALL debits)/n` | **MATERIAL (offsetting).** Spec cashflow = `−639.57` → band **<0 → 0** vs code's 50. **−50 raw**; alone would drop CCC → CC. |
| D3 | **Salary Category**: code L3M median salary; spec last-month salary | Band-neutral. Last-month salary = 0 (March is debit-only) → still ≤5000 band → 30. |
| D4 | **DBR denominator**: code ÷ median salary; spec ÷ median income | Inert. Median income = median salary = 2,900. |
| D5 | **Loan Payment**: code includes mortgages; spec loans only | Inert. No mortgage present. |
| **D6** | **Redistribution**: proportional `×1000/850` vs spec "equally" | **MATERIAL.** Inflates the flat sum to the `×1000/850` value; accounts for the 2-pt gap (318 vs QA 320). |
| D7 | **monthsOfData**: code counts only months with txns | **Inert.** The trailing zero-income month is debit-bearing and already counted; no zero-activity calendar months exist in `[start, end]`. |
| D8 | **Avg Balance 6M**: code `0.0` vs spec "Not Available" | Cosmetic. `averageBalance6M = 0.0`; display-only. |

> **Key conformance finding:** D1 (**+100**) and D2 (**−50**) are opposite-sign errors. Combined, the spec-correct flat `sumAvailable` = `270 + 100 − 50 = 320` — **exactly the QA-workbook expectation (320 / CCC)**. Code's live 318 is 2 points under QA purely from the **D6** `×1000/850` artifact; the underlying band errors cancel.

---

## 7. Comparison to QA Workbook Expectation

| | Expected (QA workbook) | Actual (live API) |
|---|---|---|
| Total | **320** | **318** |
| Rating | **CCC** | **CCC** |

**Explanation.** The rating class **matches**. The 2-point gap (320 vs 318) is the `×1000/850` proportional-renormalization artifact (**D6**, triggered by the omitted `age`): the spec-correct flat sum is `320`, and `round(270 × 1000 / 850) = 318`. Critically, the QA total of `320` is reproduced by the offsetting **D1** (+100) and **D2** (−50) corrections layered onto the live `sumAvailable` of `270` — the two band errors cancel on this account.

---

## 8. Findings & Recommendations

- **[P1 — D6, score artifact]** The omitted-`age` proportional renormalization yields 318 instead of the spec flat-sum 320. Supply `age` or switch to **equal redistribution**; rating class is unchanged (CCC) but the score becomes spec-exact.
- **[P2 — D1 / D2, structural]** Although they offset to the QA-correct total **on this account**, the Surplus Ratio (debt term + median) and Cash Flow (salary-only + averaging method) formulas both diverge from DF-4018. Fix both to align with spec; do **not** rely on the cancellation, which is coincidental and account-specific.
- **[P3 — risk signals confirmed]** The **CRITICAL income-drop** (`lastMonthIncome = 0`, `−100%`) and **41.21% income volatility** are correctly detected and surfaced. These should remain the primary decisioning signals for this account regardless of the scoring divergences.
- **[P4 — float cosmetic]** The `surplusRatio` raw `−11.21999…` vs reported `−11.22` is IEEE-754 noise with no band effect; optionally normalize rounding for display consistency.
- **[P5 — D8 display]** Surface `averageBalance6M` as **"Not Available"** rather than `0.0` (DF-4018 QA issue #2).
