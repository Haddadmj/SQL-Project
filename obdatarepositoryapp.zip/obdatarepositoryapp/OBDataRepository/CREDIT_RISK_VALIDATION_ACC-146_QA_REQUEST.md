# Credit Risk Validation — ACC-146 (QA Request, age = 17)

**Endpoint:** `POST /api/v1/credit-risk/getCreditRiskReport`
**Validated:** 2026-06-14
**Request (QA replica — same inputs as prior run, `age` now supplied):**
```json
{
  "psuId": "AbrarCRA2",
  "accountLinkId": "1442",
  "accountId": "ACC-146",
  "sponsoredTppId": "01K920FBZBT9NE8WRP8BQSHSBQ",
  "customerType": "RETAIL",
  "age": 17
}
```
**Result:** `totalScore = 560` · `ratingClass = BB` ("Fair") · approval **Moderate**

> **QA-replica note.** The prior run omitted `age`, which *disabled* the AGE factor and triggered a proportional ×1000/850 renormalization (→ 659/BBB). Supplying `age = 17` makes AGE an *evaluated* factor (it scores 0 — 17 is below the 18–25 band — but `dataAvailable = true`), so there is **no redistribution** and the total is the flat sum. This reproduces the QA workbook expectation of **560/BB exactly**.

---

## 1. Executive Summary

- **Internally consistent:** ✅ Yes — 100%. Every metric, classification and factor score is reproducible to the cent from the raw transactions.
- **Follows DF-4018 to the dot:** ⚠️ **Almost.** The score and rating class are spec-faithful for this account, but one factor formula diverges: **D1 (Surplus Ratio)** understates surplus (12.63 % vs the spec's 25.26 %), costing 30 raw points. It is **band-neutral here** — the spec-correct total is `590`, still **BB** — so it does not change the rating.
- **One thing to note:** D1 should be reconciled (it bites harder on other accounts), and the `"Utility"`/`"Utilities"` keyword quirk silently routes MARAFIQ utility bills into *Others*.

---

## 2. Input Data Profile

| Property | Value |
|---|---|
| Transactions | 165 (12 credit, 153 debit) |
| Months of data | 12 (2025-03 → 2026-02, consecutive) |
| Salary pattern | 12 monthly credits `"Salary - Riyad Bank HQ / راتب"`, avg 9,458.33 SAR |
| Debt | 1,200/mo car loan (Al Rajhi Auto Finance) = 14,400 total; **no mortgage, no credit card** |
| Current balance | 42,815.00 SAR · IBAN SA74…2432 · SAIB |

**Expense categories** (debits, total 99,600):

| Category | Amount | % |
|---|---|---|
| Others | 39,278.00 | 39.44 % |
| Living Expenses | 37,940.00 | 38.09 % |
| Loan Repayments | 14,400.00 | 14.46 % |
| Utilities | 7,982.00 | 8.01 % |

---

## 3. Financial Metrics Validation

All metrics **PASS** (independent Python recompute vs report, ±0.01). Metrics are unaffected by `age`, so these are identical to the age-omitted run.

| Metric | Value | Metric | Value |
|---|---|---|---|
| averageMonthlyIncome | 9,458.33 | surplusRatio | 0.1263 |
| medianMonthlyIncome | 9,500.00 | debtBurdenRatio | 0.1263 |
| medianSalaryIncome | 9,500.00 | cashFlow | 2,358.33 |
| averageMonthlyExpenses | 7,100.00 | savingsRate | 0.25 |
| averageMonthlySurplus | 2,358.33 | emergencyFundMonths | 3.99 |
| incomeVolatility | 1.95 | salaryRegularity | 1.0 (12 occ) |

---

## 4. Factor Scoring (age = 17, flat sum)

| Factor | Raw value | Band | Score / Max | Label |
|---|---|---|---|---|
| AGE | 17 | *no band (< 18 floor)* | **0** / 150 | Very Poor |
| INCOME | 9,500 | 5,001–10,000 | **50** / 150 | Low income |
| LOAN_PAYMENT | 1,200 | ≤ 1,500 | **150** / 150 | Very low debt |
| SURPLUS_RATIO | 12.63 | 11–20 | **100** / 150 | Moderate surplus |
| SALARY_CATEGORY | 9,500 | 5,001–15,000 | **90** / 150 | Medium Risk |
| CASH_FLOW | 2,358.33 | 1,001–3,000 | **100** / 150 | Moderate positive |
| DEBT_BURDEN_RATIO | 12.63 | 11–25 | **70** / 100 | Good |

**Total:** `0 + 50 + 150 + 100 + 90 + 100 + 70 = 560`. `factorsSkipped = 0`, `weightsRedistributed = false`, `availableMaxPoints = 1000` → **no renormalization** → **560 → BB**. ✅

**Recommendation:** strengths = [Loan Payment, Debt Burden Ratio]; weaknesses = [**Age: Very Poor**, Income: Low income]; `maxAffordablePayment = floor(2,358.33 × 0.3) = 707`; recommendations = [].

> Note: supplying age 17 adds **"Age: Very Poor"** as a weakness (percentage 0 < 40), which was absent in the age-omitted run.

---

## 5. DF-4018 Conformance — Does it follow the spec to the dot?

| Div | Spec rule | Code behavior | Impact on ACC-146 |
|---|---|---|---|
| **D1 Surplus Ratio** | `(Income − Expenses) / Income` | subtracts debt **and** uses median: 12.63 % → **100** | **Band-neutral.** Spec value 25.26 % → 130 (+30 raw); total 590, still **BB**. Formula still wrong. |
| D2 Cash Flow | `(Σsalary − Σ all debits)/n` | excludes debt: 2,358.33 → 150-band¹ | Inert (CFD 1,158.33 → same 1,001–3,000 band → 100) |
| D3 Salary Category | last-month salary | L3M median salary | Inert (last = median = 9,500) |
| D4 DBR denominator | ÷ median **income** | ÷ median **salary** | Inert (salary = income) |
| D5 Loan Payment | loans only | includes mortgages | Inert (no mortgage) |
| D6 Redistribution | redistribute missing weight "equally" | proportional ×1000/850 | **Inactive** (AGE evaluated, nothing skipped) ✅ |
| D7 monthsOfData | inject zero-activity calendar months | only months with txns | Inert (12 consecutive, no gaps) |
| D8 Avg Balance 6M | show "Not Available" if no feed | returns **0.0** | ❌ shows 0.0 (no balance feed); fails "hide if insufficient" |

¹ CASH_FLOW raw is reported as 2,358.33 — note the code's cash-flow uses salary − non-debt debits.

**Classification quirk:** 4 `"Utilities: MARAFIQ Utilities"` debits land in **Others**, not Utilities — the keyword is `"Utility"` (singular) and does not substring-match `"Utilities"` (plural). Engine and recompute agree; latent keyword gap.

---

## 6. Comparison to QA Workbook

| | QA workbook | Code (age = 17) | Spec-correct (D1–D5 applied) |
|---|---|---|---|
| Total | **560** | **560** ✅ | 590 |
| Class | **BB** | **BB** ✅ | BB |

The live code reproduces the QA expectation of **560/BB to the dot**. The spec-correct surplus formula would raise the total to 590 but keeps the class at BB.

---

## 7. Findings & Recommendations

1. **✅ Score is spec-faithful for this account** — 560/BB matches QA, and the lone formula divergence (D1) is band-neutral here.
2. **⚠️ Fix D1 (Surplus Ratio)** — the engine subtracts debt and uses median income; the spec is `(income − expenses)/income`. Band-neutral here (+30, still BB) but class-changing on ACC-148.
3. **⚠️ D8 — `averageBalance6M` returns 0.0** instead of "Not Available"; violates the CFD "hide metric if data insufficient" acceptance criterion.
4. **ℹ️ Keyword gap** — add `"utilities"` (and `"marafiq"`) to the utilities dictionary so MARAFIQ bills leave *Others*.
5. **ℹ️ AGE eligibility** — age 17 silently scores 0 (below the 18–25 floor). Consider validating/rejecting ineligible ages rather than scoring 0.
