# Credit Risk Fix Plan

## Test Failures Summary (Tests.txt)

| TC | Metric | Got | Expected | Status |
|---|---|---|---|---|
| TC09 | LOAN_PAYMENT | 0 | 16000 | FAIL |
| TC09 | SURPLUS_RATIO | -130.89 | 8 | FAIL |
| TC09 | CASH_FLOW | -3171.56 | 384 | FAIL |
| TC09 | DEBT_BURDEN_RATIO | 0 | 74.07 | FAIL |
| TC10 | LOAN_PAYMENT | 1500 | 18000 | FAIL |
| TC10 | DEBT_BURDEN_RATIO | 35.71 | 79.37 | FAIL |
| TC11 | LOAN_PAYMENT | 0 | 20000 | FAIL |
| TC11 | SURPLUS_RATIO | -223.05 | -4 | FAIL |
| TC11 | CASH_FLOW | -4723.33 | -140 | FAIL |
| TC11 | DEBT_BURDEN_RATIO | 0 | 130.95 | FAIL |

## Reference Formulas (Correct Values.txt)

| Factor | Formula |
|---|---|
| Loan Payment | Sum of loan debits in last month only (raw, not recurring-filtered) |
| Surplus Ratio | (Avg Salary − Avg Expenses excl. loans) ÷ Avg Salary |
| Cash Flow | Avg Salary − Avg Expenses (excl. loans) — no debt subtraction |
| DBR | Avg Monthly Loan ÷ L3M Spike-Adjusted Median Salary |
| Salary Category | Last Month Salary only (most recent month) |

---

## Agent Investigation Areas

| Agent | Focus | Status |
|---|---|---|
| Agent 1 | LOAN_PAYMENT detection — why TC09/TC11=0, TC10 partial | ✅ COMPLETE |
| Agent 2 | CASH_FLOW + SURPLUS_RATIO formula analysis | ✅ COMPLETE |
| Agent 3 | DEBT_BURDEN_RATIO — numerator/denominator mismatch | ✅ COMPLETE |

---

## Findings

### Agent 1 — LOAN_PAYMENT Detection

**Root Cause (Primary):** SAMA OB loan/finance transactions use the description format `"Finance: <BankName>"` (e.g. `"Finance: Al Rajhi Bank"`, `"Finance: SNB"`). None of the 31 entries in `LOAN_KEYWORDS` match this pattern. The bare word `"Finance:"` is not in the array — only compound forms (`"Finance Payment"`, `"Finance Deduction"`) are, and they require extra words not present in the description.

`merchantName` is null for all loan transactions (extraction fails). `reference` is a transaction ID with no semantic content. The `category` field is never populated in the active data pipeline (`parseDecryptedTransaction` never sets it). So only `description` is searchable.

**Root Cause (Secondary):** `lastMonthLoanPayment` is assigned `recurringLoanPayment` (line 157), which requires the same amount to appear in at least 3 of the last 6 months. A valid loan with < 3 months history would still return 0 even after fixing keywords. Spec says: "sum of all mcc=6012 debits in the last month only" — use raw last-month sum.

**Why TC10 gets 1500 (not 18000):** The 1500 credit card payment is correctly detected via `isCreditCardPayment()` and clears the 3-of-6 recurrence threshold. The 18000 finance installment description matches nothing in LOAN_KEYWORDS.

**Mortgage safe:** `"Finance:"` does NOT appear in mortgage descriptions (`"SNB Home Finance"`, `"Al Rajhi Home Finance"`, `"Housing Finance"`). Adding `"Finance:"` to LOAN_KEYWORDS will not collide with mortgage detection.

**Fix 1 — TransactionData.java LOAN_KEYWORDS:** Add `"Finance:"` to the English section.

**Fix 2 — FinancialMetricsCalculator.java line 157:** Change `recurringLoanPayment` assignment to raw last-month sum:
```java
// BEFORE:
BigDecimal lastMonthLoanPayment = recurringLoanPayment;
// AFTER:
BigDecimal lastMonthLoanPayment = monthlyLoanPayments.isEmpty() ? BigDecimal.ZERO : monthlyLoanPayments.get(0);
```
Apply same change to `lastMonthMortgagePayment` at line 162.

**Fix 3 — TransactionData.java buildSearchText():** Include `category` field (future-proofing for drahim path).

---

### Agent 2 — CASH_FLOW and SURPLUS_RATIO

**CASH_FLOW (lines 189):** Formula is structurally correct. `calculateMonthlyExpenses` already excludes debt via `!isDebtPayment()`. The TC09/TC11 failures cascade entirely from loan detection failure — undetected loans pass the `!isDebtPayment()` filter and inflate expenses. No formula change needed for cash flow beyond fixing loan detection.

**Optional improvement (line 189):** Use `calculateAverage(monthlySalaryIncomes)` instead of `calculateAverage(monthlyIncomes)` to match reference formula "Avg Salary". Makes no difference for TC09-TC11 (all income is salary) but is more accurate for future mixed-income cases.

**SURPLUS_RATIO — Two independent formula bugs (lines 175–179):**

Bug A — Double-subtraction of debt (line 178):
- `avgExpenses` already excludes loan payments (via `!isDebtPayment()` filter in `calculateMonthlyExpenses`)
- Line 178 then subtracts `avgDebtPayment` a second time → numerator becomes too small
- The reference formula has NO explicit debt subtraction: `(Avg Salary − Avg Expenses)`
- Fix: remove `.subtract(avgDebtPayment)` from line 178

Bug B — Wrong income base (lines 176, 178, 179):
- Current code uses `medianIncome` = spike-adjusted median of all credits (last 3 months)
- Reference formula specifies "Avg Salary" = average of salary-only credits (all months)
- Fix: replace `medianIncome` with `calculateAverage(monthlySalaryIncomes)` (a new local variable `avgSalary`)

**Exact changes for SURPLUS_RATIO:**
```java
// ADD before line 175:
BigDecimal avgSalary = calculateAverage(monthlySalaryIncomes);

// REPLACE lines 175-179:
BigDecimal surplusRatio = BigDecimal.ZERO;
if (avgSalary.compareTo(BigDecimal.ZERO) > 0) {
    BigDecimal avgSurplusForRatio = avgSalary.subtract(avgExpenses);
    surplusRatio = avgSurplusForRatio.divide(avgSalary, 4, RoundingMode.HALF_UP);
}
```

---

### Agent 3 — DEBT_BURDEN_RATIO

**Root Cause:** Line 186 uses `lastMonthDebtPayment` as the DBR numerator. `lastMonthDebtPayment` = `recurringLoanPayment + recurringMortgagePayment` — a recurrence-gated value. For TC09/TC11 where loans are undetected, this is 0. For TC10, it's 1500 (only the recurring credit card amount), giving 1500/4200 = 35.71% instead of expected 79.37%.

**Reference formula:** "Avg Monthly Loan ÷ L3M Spike-Adjusted Median Salary". Numerator = average across all observed months, not last month's recurring amount.

**Correct variable already exists:** `avgDebtPayment` at line 171 = `calculateAverage(monthlyLoanPayments).add(calculateAverage(monthlyMortgagePayments))`. This is the correct numerator.

**Denominator:** `medianIncome` = L3M spike-adjusted median salary. This is correct — no change needed.

**Fix — FinancialMetricsCalculator.java line 186:**
```java
// BEFORE:
debtBurdenRatio = lastMonthDebtPayment.divide(medianIncome, 4, RoundingMode.HALF_UP);
// AFTER:
debtBurdenRatio = avgDebtPayment.divide(medianIncome, 4, RoundingMode.HALF_UP);
```

**Dependency:** This fix depends on Agent 1's loan detection fix. If loans are not detected, `monthlyLoanPayments` lists are all zeros, `avgDebtPayment` = 0, DBR = 0. Both fixes must be applied together.

---

## Consolidated Fix Plan

### File 1: TransactionData.java

| # | Change | Location |
|---|---|---|
| 1a | Add `"Finance:"` to LOAN_KEYWORDS array | Line ~49 (English section) |
| 1b | Add `category` field to `buildSearchText()` | Lines 271-277 |

### File 2: FinancialMetricsCalculator.java

| # | Change | Location |
|---|---|---|
| 2a | `lastMonthLoanPayment` = raw last-month sum, not recurring | Line 157 |
| 2b | `lastMonthMortgagePayment` = raw last-month sum, not recurring | Line 162 |
| 2c | Add `avgSalary` variable before surplus ratio block | Before line 175 |
| 2d | Fix SURPLUS_RATIO: remove avgDebtPayment, use avgSalary | Lines 175-179 |
| 2e | Fix DBR: use `avgDebtPayment` not `lastMonthDebtPayment` | Line 186 |
| 2f | Fix cashFlow: use `monthlySalaryIncomes` | Line 189 |

---

## Estimated Success Rate

| Test | Metrics Fixed | Confidence |
|---|---|---|
| TC09 LOAN_PAYMENT | Fix 1a + 2a → detects Finance:, uses raw last-month | HIGH |
| TC09 CASH_FLOW | Cascades from 1a+2a; formula correct once detection works | HIGH |
| TC09 SURPLUS_RATIO | Fix 1a+2a+2c+2d | HIGH |
| TC09 DEBT_BURDEN_RATIO | Fix 1a+2a+2e | HIGH |
| TC10 LOAN_PAYMENT | Fix 1a+2a (Finance: keyword + raw last-month) | HIGH |
| TC10 DEBT_BURDEN_RATIO | Fix 2e (avgDebtPayment) + 1a for loan averages | HIGH |
| TC11 LOAN_PAYMENT | Fix 1a+2a | HIGH |
| TC11 CASH_FLOW | Cascades from 1a+2a | HIGH |
| TC11 SURPLUS_RATIO | Fix 1a+2a+2c+2d | HIGH |
| TC11 DEBT_BURDEN_RATIO | Fix 1a+2a+2e | HIGH |

**Overall estimated success rate: 90–95%** — all failures have clear, confirmed root causes with targeted fixes. Remaining 5–10% uncertainty is from transaction data variations not visible in the JSON sample (e.g., exact loan amounts per month affecting averages).
