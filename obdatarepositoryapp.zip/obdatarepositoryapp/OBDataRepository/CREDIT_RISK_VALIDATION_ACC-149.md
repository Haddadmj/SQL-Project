# Credit Risk Scoring — Validation Report: ACC-149

## 1. Header

| Field | Value |
|---|---|
| **Account ID** | `ACC-149` |
| **Endpoint** | `POST /api/v1/credit-risk/getCreditRiskReport` |
| **`psuId`** | `AbrarCRA2` |
| **`accountLinkId`** | `1442` |
| **`sponsoredTppId`** | `01K920FBZBT9NE8WRP8BQSHSBQ` |
| **`customerType`** | `RETAIL` |
| **`accountId`** | `ACC-149` |
| **`age`** | *not supplied* (AGE factor disabled — see global note) |
| **Date validated** | 2026-06-14 |
| **Report ID** | `df772158-6178-43ff-8f81-4e04b8e6f05f` |
| **Headline result** | **Score 918 / Rating AAA "Excellent" / Approval: Very High** |

> **Global note (applies to all three accounts):** the request **omits `age`**, so the AGE factor is disabled (`dataAvailable=false`, `maxScore=150`). The engine renormalizes: `totalScore = round(sumAvailable × 1000 / 850)`. This is CFD divergence **D6** — the code does **proportional** renormalization, while DF-4018 acceptance criteria require a missing factor's weight to be **redistributed equally**. QA-workbook expectations correspond to the **raw `sumAvailable`** (flat sum, AGE evaluated). **Supplying `age` would evaluate AGE (no redistribution) and bring the total toward the QA flat-sum expectation.**

---

## 2. Executive Summary

The ACC-149 report is **internally fully consistent** — all metrics and all six factor scores reproduce exactly under independent recomputation. However, this account exhibits the **largest DF-4018 conformance gap** of the three: the live **918 / AAA** overstates the QA-workbook expectation of **780 / A** by **+138 points and two rating classes**. The overstatement is driven almost entirely by **D6** (proportional `×1000/850` renormalization from the omitted `age`), compounded by **D5** (a `4,000`/month **mortgage** miscounted as a loan payment, which actually *understates* the live score by 40 raw). The single most important fix is **D6** — restoring it brings the result back to the spec-correct A class.

---

## 3. Input Data Profile

| Attribute | Value |
|---|---|
| Total transactions | 295 (16 credit, 279 debit) |
| Months of data (`monthsOfData`) | 15 |
| Date range | 2024-12-02 → 2026-02-28 |
| Salary pattern | 15 salary credits `Salary - SABIC / راتب`, `salaryRegularity = 1.00`, `salaryOccurrences = 15`, avg salary 28,013.33 |
| Debt obligations | **All 15 debt debits are MORTGAGE** (`SABB Home Finance`), `4,000`/month = **60,000** total; `totalLoanPayments = 0` |
| Notable txns | One `Annual Performance Bonus - SABIC / مكافأة أداء` of **24,200** (2025-07). July income = **52,000** = 27,800 salary + 24,200 bonus |

> **Bonus classification.** The bonus is **not** salary (no salary keyword matches "bonus"/"performance"/`مكافأة`); it is a `KSAOB.LocalBankTransfer` → `isTransfer` → **excluded from "other income"**. It counts in **gross `monthlyIncome` only**. Because July sits **outside the L3M window** (index 7), the bonus **does not affect any median**. It is the sole driver of the `20.20%` income-volatility figure but is **scoring-irrelevant** (medians use L3M only).

### Expense-category breakdown

| Category | Amount (SAR) | % of categorized debits |
|---|---:|---:|
| Living Expenses | 125,114.00 | 43.58% |
| Others | 85,809.00 | 29.89% |
| Loan Repayments | 60,000.00 | 20.90% |
| Utilities | 16,177.00 | 5.63% |

---

## 4. Financial Metrics Validation

All metrics recomputed and matched. **All PASS.**

| Metric | Computed | Report | Result |
|---|---:|---:|---|
| `averageMonthlyIncome` | 29,626.67 | 29,626.67 | PASS (bonus-inflated) |
| `medianMonthlyIncome` | 28,100.00 | 28,100.00 | PASS |
| `medianSalaryIncome` | 28,100.00 | 28,100.00 | PASS |
| `surplusRatio` | 0.3189 | 0.3189 | PASS |
| `debtBurdenRatio` | 0.1423 | 0.1423 | PASS |
| `cashFlow` | 12,873.33 | 12,873.33 | PASS |
| `savingsRate` | 0.49 | 0.49 | PASS |
| `emergencyFundMonths` | 14.35 | 14.35 | PASS |
| `incomeVolatility` | 20.20 | 20.20 | PASS (driven by July bonus) |
| `expenseVolatility` | 3.47 | 3.47 | PASS |
| `salaryRegularity` | 1.00 | 1.00 | PASS |
| `averageSalaryAmount` | 28,013.33 | 28,013.33 | PASS |

`medianSalaryIncome = 28,100`: L3M salary `[28100, 27800, 28200]`; spike threshold `≈ 36,530`; nothing dropped. No float-cosmetic artifacts. `averageBalance6M = 0.0` (divergence **D8**).

---

## 5. Factor Scoring Validation

| Factor | Raw value | Band matched | Score / Max | Label | Result |
|---|---:|---|---:|---|---|
| AGE | — | *skipped* | 0 / 150 | — (disabled) | PASS |
| INCOME | 28,100 | ≥15001 | 150 / 150 | High income | PASS |
| LOAN_PAYMENT | 4,000 | 3001–4500 | 110 / 150 | Moderate debt | PASS |
| SURPLUS_RATIO | 31.89 | 31–100 | 150 / 150 | Excellent surplus (>30%) | PASS |
| SALARY_CATEGORY | 28,100 | ≥15001 | 150 / 150 | Low Risk | PASS |
| CASH_FLOW | 12,873.33 | ≥3001 | 150 / 150 | Strong positive | PASS |
| DEBT_BURDEN_RATIO | 14.23 | 11–25 | 70 / 100 | Good (11–25%) | PASS |

### Total-score arithmetic

```
sumAvailable      = 150 + 110 + 150 + 150 + 150 + 70 = 780
AGE skipped       → skippedMaxScore = 150
availableMaxPoints = 1000 − 150 = 850
totalScore        = round(780 × 1000 / 850) = round(917.65) = 918
ratingClass       = AAA (900–1000) "Excellent"
```

`maxAffordablePayment = floor(12,873.33 × 0.3) = 3,861`. **All six** evaluated factors are strengths (DBR at exactly 70.0% is included via the `>=70` rule); no weaknesses; no recommendations.

---

## 6. DF-4018 Spec Conformance (Divergences D1–D8)

| # | Divergence | Per-account impact on ACC-149 |
|---|---|---|
| D1 | **Surplus Ratio**: code subtracts debt & uses median; spec = `(income − exp)/income` | Band-neutral. Spec surplus = `46.12%` → still 31–100 → 150. |
| D2 | **Cash Flow**: code = `avg(salary) − avg(non-debt debits)`; QA = `(Σsalary − Σ ALL debits)/n` | Band-neutral. Spec cashflow = `8,873.33` → still ≥3001 → 150. |
| D3 | **Salary Category**: code L3M median salary; spec last-month salary | Band-neutral. |
| D4 | **DBR denominator**: code ÷ median salary; spec ÷ median income | Band-neutral. |
| **D5** | **Loan Payment**: code includes mortgages; spec is loans only | **MATERIAL.** The `4,000`/month is a **mortgage** folded into LOAN_PAYMENT → band 3001–4500 → 110. DF-4018 scopes LOAN_PAYMENT to loans only → loan = 0 → band ≤1500 → **150 (+40 raw)**. Correcting alone → `sumAvailable 820` → `round(820×1000/850) = 965` (still AAA). |
| **D6** | **Redistribution**: proportional `×1000/850` vs spec "equally" | **MATERIAL.** Inflates raw `780 → 918`, i.e. **A → AAA, a two-class jump** vs the QA expectation. Dominant cause of the overstatement. |
| D7 | **monthsOfData**: code counts only months with txns | Band-neutral. No zero-activity calendar months. |
| D8 | **Avg Balance 6M**: code `0.0` vs spec "Not Available" | Cosmetic. `averageBalance6M = 0.0`; display-only. |

> **Bonus note:** the July `24,200` bonus spike is **CFD-irrelevant for scoring** (medians use the L3M window only, and July is outside it) but is the entire source of the reported `20.20%` income-volatility figure.

---

## 7. Comparison to QA Workbook Expectation

| | Expected (QA workbook) | Actual (live API) |
|---|---|---|
| Total | **780** | **918** |
| Rating | **A** | **AAA** |
| Delta | — | **+138 pts, A → AAA (two-class overstatement)** |

**Explanation.** The QA figure `780 → A` is precisely the code's **raw flat `sumAvailable`**. The live `918 / AAA` results entirely from the **D6** proportional renormalization (`round(780 × 1000 / 850) = 918`), triggered by the omitted `age`. This is the single largest divergence-driven overstatement across the three test accounts: a **two-rating-class** inflation. Note that **D5** (mortgage-as-loan) works in the *opposite* direction here — correcting it would *raise* the raw sum to 820 — so D6 alone accounts for, and more than accounts for, the A → AAA jump.

---

## 8. Findings & Recommendations

- **[P1 — D6, two-class impact]** The omitted-`age` proportional renormalization inflates **780 (A)** to **918 (AAA)** — the most severe overstatement of the three accounts. Supply `age` (near-term) or implement **equal redistribution** per DF-4018; either restores the spec-correct A class.
- **[P2 — D5, factor scope]** The `4,000`/month obligation is a **mortgage**, yet it is scored under LOAN_PAYMENT (band 110). DF-4018 scopes LOAN_PAYMENT to loans only; correcting it sets the factor to 150. This *raises* the raw sum (780 → 820), so it does not mitigate the D6 overstatement — but the factor scope is wrong and should be fixed for correctness.
- **[P3 — bonus / volatility transparency]** The single July bonus drives the entire `20.20%` income-volatility reading despite being scoring-neutral. Consider annotating bonus-driven volatility in the output so reviewers do not misread it as unstable income.
- **[P4 — D8 display]** Surface `averageBalance6M` as **"Not Available"** rather than `0.0` (DF-4018 QA issue #2).
- **[Pass — no action]** Bonus classification, L3M median exclusion of the July spike, mortgage-vs-loan categorization in expense buckets, and all metric arithmetic are correct as implemented.
