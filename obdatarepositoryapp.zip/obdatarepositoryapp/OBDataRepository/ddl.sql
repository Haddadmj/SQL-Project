-- darahim.account_open_banking_sync_logs definition

-- Drop table

-- DROP TABLE darahim.account_open_banking_sync_logs;

CREATE TABLE darahim.account_open_banking_sync_logs (
	id varchar NOT NULL,
	account_id varchar NOT NULL,
	consent_id varchar NOT NULL,
	user_id varchar NOT NULL,
	sponsored_tpp_id varchar NOT NULL,
	"trigger" varchar NOT NULL,
	status varchar NOT NULL,
	"data" jsonb NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT account_open_banking_sync_logs_pkey PRIMARY KEY (id)
);
CREATE INDEX ix_account_open_banking_sync_logs_account_id ON darahim.account_open_banking_sync_logs USING btree (account_id);
CREATE INDEX ix_account_open_banking_sync_logs_consent_id ON darahim.account_open_banking_sync_logs USING btree (consent_id);
CREATE INDEX ix_account_open_banking_sync_logs_status ON darahim.account_open_banking_sync_logs USING btree (status);
CREATE INDEX ix_account_open_banking_sync_logs_trigger ON darahim.account_open_banking_sync_logs USING btree (trigger);
CREATE INDEX ix_account_open_banking_sync_logs_user_id ON darahim.account_open_banking_sync_logs USING btree (user_id);


-- darahim.alembic_version definition

-- Drop table

-- DROP TABLE darahim.alembic_version;

CREATE TABLE darahim.alembic_version (
	version_num varchar(32) NOT NULL,
	CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);


-- darahim.app_setting definition

-- Drop table

-- DROP TABLE darahim.app_setting;

CREATE TABLE darahim.app_setting (
	id varchar NOT NULL,
	"name" varchar NOT NULL,
	value jsonb NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT app_setting_pkey PRIMARY KEY (id),
	CONSTRAINT unique_app_setting_name UNIQUE (name)
);
CREATE UNIQUE INDEX ix_app_setting_name ON darahim.app_setting USING btree (name);


-- darahim.client_request_log definition

-- Drop table

-- DROP TABLE darahim.client_request_log;

CREATE TABLE darahim.client_request_log (
	id varchar NOT NULL,
	user_id varchar(40) NULL,
	request_url varchar NOT NULL,
	request_method varchar NOT NULL,
	request_params jsonb NOT NULL,
	request_body jsonb NOT NULL,
	response_body varchar NOT NULL,
	response_status varchar NOT NULL,
	headers jsonb NOT NULL,
	request_time float8 NOT NULL,
	"timestamp" timestamp NOT NULL,
	CONSTRAINT client_request_log_pkey PRIMARY KEY (id)
);
CREATE INDEX ix_client_request_log_response_status ON darahim.client_request_log USING btree (response_status);
CREATE INDEX ix_client_request_log_timestamp ON darahim.client_request_log USING btree ("timestamp");
CREATE INDEX ix_client_request_log_user_id ON darahim.client_request_log USING btree (user_id);


-- darahim.currencies definition

-- Drop table

-- DROP TABLE darahim.currencies;

CREATE TABLE darahim.currencies (
	base varchar NOT NULL,
	rates jsonb NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT currencies_pkey PRIMARY KEY (base)
);


-- darahim.data_science_logs definition

-- Drop table

-- DROP TABLE darahim.data_science_logs;

CREATE TABLE darahim.data_science_logs (
	id varchar(40) NOT NULL,
	"action" varchar NOT NULL,
	"data" jsonb NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT data_science_logs_pkey PRIMARY KEY (id)
);


-- darahim.extraction_model_logs definition

-- Drop table

-- DROP TABLE darahim.extraction_model_logs;

CREATE TABLE darahim.extraction_model_logs (
	id varchar(40) NOT NULL,
	sms_text varchar(600) NOT NULL,
	processed_context varchar(600) NOT NULL,
	question varchar(600) NOT NULL,
	context_text varchar(600) NOT NULL,
	model_1 varchar(600) NOT NULL,
	model_2 varchar(600) NOT NULL,
	currency varchar(20) NOT NULL,
	CONSTRAINT extraction_model_logs_pkey PRIMARY KEY (id)
);


-- darahim.monitoring_events definition

-- Drop table

-- DROP TABLE darahim.monitoring_events;

CREATE TABLE darahim.monitoring_events (
	id varchar NOT NULL,
	event_type varchar NOT NULL,
	"timestamp" timestamp NOT NULL,
	"data" jsonb NOT NULL,
	CONSTRAINT monitoring_events_pkey PRIMARY KEY (id)
);
CREATE INDEX ix_monitoring_events_event_type ON darahim.monitoring_events USING btree (event_type);
CREATE INDEX ix_monitoring_events_timestamp ON darahim.monitoring_events USING btree ("timestamp");


-- darahim.neotek_account_link definition

-- Drop table

-- DROP TABLE darahim.neotek_account_link;

CREATE TABLE darahim.neotek_account_link (
	id bigserial NOT NULL,
	bank_consent_id varchar NOT NULL,
	CONSTRAINT neotek_account_link_pkey PRIMARY KEY (id)
);
CREATE INDEX ix_neotek_account_link_bank_consent_id ON darahim.neotek_account_link USING btree (bank_consent_id);


-- darahim.sama_reports definition

-- Drop table

-- DROP TABLE darahim.sama_reports;

CREATE TABLE darahim.sama_reports (
	id varchar NOT NULL,
	report_name varchar NOT NULL,
	"date" date NOT NULL,
	"data" json NOT NULL,
	created_at timestamp NOT NULL,
	CONSTRAINT sama_reports_pkey PRIMARY KEY (id)
);
CREATE INDEX ix_sama_reports_date ON darahim.sama_reports USING btree (date);
CREATE INDEX ix_sama_reports_report_name ON darahim.sama_reports USING btree (report_name);


-- darahim.services_logs definition

-- Drop table

-- DROP TABLE darahim.services_logs;

CREATE TABLE darahim.services_logs (
	id varchar(40) NOT NULL,
	service varchar(100) NOT NULL,
	request_url varchar(600) NOT NULL,
	request_method varchar(100) NOT NULL,
	request_params json NOT NULL,
	request_body json NOT NULL,
	response_body varchar(2000) NOT NULL,
	response_status varchar(100) NOT NULL,
	headers json NULL,
	is_retry bool NOT NULL,
	request_time float8 NULL,
	created_at timestamp NOT NULL,
	CONSTRAINT services_logs_pkey PRIMARY KEY (id)
);
CREATE INDEX ix_services_logs_created_at ON darahim.services_logs USING btree (created_at);
CREATE INDEX ix_services_logs_is_retry ON darahim.services_logs USING btree (is_retry);
CREATE INDEX ix_services_logs_response_status ON darahim.services_logs USING btree (response_status);
CREATE INDEX ix_services_logs_service ON darahim.services_logs USING btree (service);


-- darahim.sponsored_tpp definition

-- Drop table

-- DROP TABLE darahim.sponsored_tpp;

CREATE TABLE darahim.sponsored_tpp (
	id varchar NOT NULL,
	trading_name varchar NOT NULL,
	legal_name varchar NOT NULL,
	identifier varchar NOT NULL,
	identifier_type varchar NOT NULL,
	logo varchar NOT NULL,
	status varchar NOT NULL,
	"data" jsonb NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	redirection_url varchar NOT NULL,
	CONSTRAINT sponsored_tpp_identifier_idx UNIQUE (identifier, identifier_type),
	CONSTRAINT sponsored_tpp_pkey PRIMARY KEY (id)
);
CREATE INDEX ix_sponsored_tpp_status ON darahim.sponsored_tpp USING btree (status);


-- darahim.sub_categories definition

-- Drop table

-- DROP TABLE darahim.sub_categories;

CREATE TABLE darahim.sub_categories (
	id varchar(40) NOT NULL,
	user_id varchar(40) NOT NULL,
	"name" varchar NOT NULL,
	icon varchar NOT NULL,
	color varchar NULL,
	category_id varchar(40) NOT NULL,
	global_id varchar NULL,
	created_at timestamp NOT NULL,
	CONSTRAINT sub_categories_pkey PRIMARY KEY (id),
	CONSTRAINT unique_sub_category_name_per_user UNIQUE (user_id, name, category_id)
);
CREATE INDEX ix_sub_categories_global_id ON darahim.sub_categories USING btree (global_id);


-- darahim.uploads definition

-- Drop table

-- DROP TABLE darahim.uploads;

CREATE TABLE darahim.uploads (
	id varchar(40) NOT NULL,
	user_id varchar NULL,
	file_type varchar NOT NULL,
	bucket_name varchar NOT NULL,
	asset_key varchar NOT NULL,
	original_name varchar NOT NULL,
	status varchar NOT NULL,
	expire_at timestamp NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT uploads_pkey PRIMARY KEY (id)
);


-- darahim.users definition

-- Drop table

-- DROP TABLE darahim.users;

CREATE TABLE darahim.users (
	id varchar(40) NOT NULL,
	phone varchar NULL,
	"name" varchar NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	is_verified_via_absher bool NULL,
	identifiers json NULL,
	preferences jsonb NOT NULL,
	package varchar NULL,
	CONSTRAINT users_pkey PRIMARY KEY (id)
);
CREATE INDEX ix_users_package ON darahim.users USING btree (package);
CREATE UNIQUE INDEX ix_users_phone ON darahim.users USING btree (phone);


-- darahim.consent_history definition

-- Drop table

-- DROP TABLE darahim.consent_history;

CREATE TABLE darahim.consent_history (
	id varchar(40) NOT NULL,
	consent_id varchar(300) NULL,
	user_id varchar NOT NULL,
	bank_id varchar(40) NOT NULL,
	bank_entity_id varchar NOT NULL,
	integration_method varchar(100) NOT NULL,
	"action" varchar(300) NULL,
	args jsonb NULL,
	created_at timestamp NOT NULL,
	sponsored_tpp_id varchar NOT NULL,
	neotek_accounts_link_id int8 NULL,
	"type" varchar NULL,
	CONSTRAINT consent_history_pkey PRIMARY KEY (id),
	CONSTRAINT consent_history_neotek_account_link_idx FOREIGN KEY (neotek_accounts_link_id) REFERENCES darahim.neotek_account_link(id),
	CONSTRAINT consent_history_sponsored_tpp_id_fkey FOREIGN KEY (sponsored_tpp_id) REFERENCES darahim.sponsored_tpp(id)
);
CREATE INDEX ix_consent_history_consent_id ON darahim.consent_history USING btree (consent_id);
CREATE UNIQUE INDEX ix_consent_history_neotek_accounts_link_id ON darahim.consent_history USING btree (neotek_accounts_link_id);
CREATE INDEX ix_consent_history_sponsored_tpp_id ON darahim.consent_history USING btree (sponsored_tpp_id);
CREATE INDEX ix_consent_history_user_id ON darahim.consent_history USING btree (user_id);


-- darahim.e_statement_request definition

-- Drop table

-- DROP TABLE darahim.e_statement_request;

CREATE TABLE darahim.e_statement_request (
	id varchar NOT NULL,
	user_id varchar NOT NULL,
	sponsored_tpp_id varchar NOT NULL,
	"data" jsonb NOT NULL,
	"timestamp" timestamp NOT NULL,
	CONSTRAINT e_statement_request_pkey PRIMARY KEY (id),
	CONSTRAINT e_statement_request_sponsored_tpp_id_fkey FOREIGN KEY (sponsored_tpp_id) REFERENCES darahim.sponsored_tpp(id)
);
CREATE INDEX ix_e_statement_request_timestamp ON darahim.e_statement_request USING btree ("timestamp");
CREATE INDEX ix_e_statement_request_user_id ON darahim.e_statement_request USING btree (user_id);


-- darahim.users_consents definition

-- Drop table

-- DROP TABLE darahim.users_consents;

CREATE TABLE darahim.users_consents (
	consent_id varchar(300) NOT NULL,
	user_id varchar NOT NULL,
	bank_id varchar(40) NOT NULL,
	bank_entity_id varchar NOT NULL,
	integration_method varchar(100) NOT NULL,
	expires_at timestamp NULL,
	connection_status varchar(100) NOT NULL,
	access_token_expire timestamp NULL,
	access_token text NULL,
	refresh_token_expire timestamp NULL,
	refresh_token text NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	sponsored_tpp_id varchar NOT NULL,
	neotek_accounts_link_id int8 NULL,
	"data" jsonb NULL,
	"type" varchar NULL,
	CONSTRAINT users_consents_pkey PRIMARY KEY (consent_id),
	CONSTRAINT users_consents_neotek_account_link_idx FOREIGN KEY (neotek_accounts_link_id) REFERENCES darahim.neotek_account_link(id),
	CONSTRAINT users_consents_sponsored_tpp_id_fkey FOREIGN KEY (sponsored_tpp_id) REFERENCES darahim.sponsored_tpp(id)
);
CREATE INDEX ix_users_consents_connection_status ON darahim.users_consents USING btree (connection_status);
CREATE INDEX ix_users_consents_consent_id ON darahim.users_consents USING btree (consent_id);
CREATE UNIQUE INDEX ix_users_consents_neotek_accounts_link_id ON darahim.users_consents USING btree (neotek_accounts_link_id);
CREATE INDEX ix_users_consents_sponsored_tpp_id ON darahim.users_consents USING btree (sponsored_tpp_id);
CREATE INDEX ix_users_consents_user_id ON darahim.users_consents USING btree (user_id);


-- darahim.user_activity_log definition

-- Drop table

-- DROP TABLE darahim.user_activity_log;

CREATE TABLE darahim.user_activity_log (
	id varchar(40) NOT NULL,
	user_id varchar(40) NOT NULL,
	"action" varchar(40) NOT NULL,
	"data" json NOT NULL,
	created_at timestamp NOT NULL,
	sponsored_tpp_id varchar NOT NULL,
	CONSTRAINT user_activity_log_pkey PRIMARY KEY (id),
	CONSTRAINT user_activity_log_sponsored_tpp_id_fkey FOREIGN KEY (sponsored_tpp_id) REFERENCES darahim.sponsored_tpp(id)
);
CREATE INDEX ix_user_activity_log_action ON darahim.user_activity_log USING btree (action);
CREATE INDEX ix_user_activity_log_created_at ON darahim.user_activity_log USING btree (created_at);
CREATE INDEX ix_user_activity_log_sponsored_tpp_id ON darahim.user_activity_log USING btree (sponsored_tpp_id);
CREATE INDEX ix_user_activity_log_user_id ON darahim.user_activity_log USING btree (user_id);


-- darahim.verified_merchants definition

-- Drop table

-- DROP TABLE darahim.verified_merchants;

CREATE TABLE darahim.verified_merchants (
	id varchar(40) NOT NULL,
	verified_by varchar(40) NULL,
	instagram_handle varchar NULL,
	description varchar NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	"data" jsonb NULL,
	"name" varchar(150) NOT NULL,
	logo varchar(1000) NOT NULL,
	category_id varchar(40) NOT NULL,
	sub_category_global_id varchar(100) NULL,
	name_ar varchar(150) NULL,
	CONSTRAINT verified_merchants_name_category_id_uq UNIQUE (name, category_id),
	CONSTRAINT verified_merchants_name_key UNIQUE (name),
	CONSTRAINT verified_merchants_pkey PRIMARY KEY (id),
	CONSTRAINT verified_merchants_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES darahim.users(id)
);
CREATE INDEX ix_verified_merchants_verified_by ON darahim.verified_merchants USING btree (verified_by);


-- darahim.white_listed_users definition

-- Drop table

-- DROP TABLE darahim.white_listed_users;

CREATE TABLE darahim.white_listed_users (
	phone varchar(40) NOT NULL,
	service varchar(40) NOT NULL,
	is_enabled bool NOT NULL,
	added_by_id varchar(40) NULL,
	white_listing_method varchar NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT white_listed_users_pkey PRIMARY KEY (phone, service),
	CONSTRAINT white_listed_users_added_by_id_fkey FOREIGN KEY (added_by_id) REFERENCES darahim.users(id)
);
CREATE INDEX ix_white_listed_users_added_by_id ON darahim.white_listed_users USING btree (added_by_id);
CREATE INDEX ix_white_listed_users_white_listing_method ON darahim.white_listed_users USING btree (white_listing_method);


-- darahim.zakat_money_movements definition

-- Drop table

-- DROP TABLE darahim.zakat_money_movements;

CREATE TABLE darahim.zakat_money_movements (
	id varchar(40) NOT NULL,
	user_id varchar(40) NOT NULL,
	direction varchar(40) NOT NULL,
	"location" varchar(60) NOT NULL,
	"data" jsonb NOT NULL,
	amount float8 NOT NULL,
	user_cost_amount float8 NOT NULL,
	is_completed bool NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT zakat_money_movements_pkey PRIMARY KEY (id),
	CONSTRAINT zakat_money_movements_user_id_fkey FOREIGN KEY (user_id) REFERENCES darahim.users(id)
);
CREATE INDEX ix_zakat_money_movements_is_completed ON darahim.zakat_money_movements USING btree (is_completed);
CREATE INDEX ix_zakat_money_movements_user_id ON darahim.zakat_money_movements USING btree (user_id);


-- darahim.zakat_money_movement_logs definition

-- Drop table

-- DROP TABLE darahim.zakat_money_movement_logs;

CREATE TABLE darahim.zakat_money_movement_logs (
	id varchar(40) NOT NULL,
	movement_id varchar(40) NOT NULL,
	old_location varchar NULL,
	new_location varchar NULL,
	"data" jsonb NOT NULL,
	"timestamp" timestamp NOT NULL,
	CONSTRAINT zakat_money_movement_logs_pkey PRIMARY KEY (id),
	CONSTRAINT zakat_money_movement_logs_movement_id_fkey FOREIGN KEY (movement_id) REFERENCES darahim.zakat_money_movements(id)
);
CREATE INDEX ix_zakat_money_movement_logs_movement_id ON darahim.zakat_money_movement_logs USING btree (movement_id);
CREATE INDEX ix_zakat_money_movement_logs_timestamp ON darahim.zakat_money_movement_logs USING btree ("timestamp");


-- darahim.accounts definition

-- Drop table

-- DROP TABLE darahim.accounts;

CREATE TABLE darahim.accounts (
	id varchar(40) NOT NULL,
	consent_id varchar(300) NULL,
	bank_id varchar(40) NOT NULL,
	"type" varchar(100) NOT NULL,
	integrated_id varchar(100) NULL,
	integrated_entity_id varchar NULL,
	connection_status varchar(100) NULL,
	user_id varchar(40) NOT NULL,
	integration_method varchar(100) NOT NULL,
	last_transaction_added_at timestamp NULL,
	last_sync_at timestamp NULL,
	last_sync_triggered_at timestamp NULL,
	last_historical_sync_triggered_at timestamp NULL,
	historical_sync_completed_at timestamp NULL,
	"data" jsonb NULL,
	classification varchar NOT NULL,
	is_ignored_in_report bool NULL,
	is_ignored_in_budget bool NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	fast_sync bool NOT NULL,
	is_archived bool NOT NULL,
	sponsored_tpp_id varchar NOT NULL,
	encrypted_data bytea NOT NULL,
	CONSTRAINT accounts_pkey PRIMARY KEY (id),
	CONSTRAINT accounts_consent_id_fkey FOREIGN KEY (consent_id) REFERENCES darahim.users_consents(consent_id),
	CONSTRAINT accounts_sponsored_tpp_id_fkey FOREIGN KEY (sponsored_tpp_id) REFERENCES darahim.sponsored_tpp(id)
);
CREATE INDEX ix_accounts_bank_id ON darahim.accounts USING btree (bank_id);
CREATE INDEX ix_accounts_connection_status ON darahim.accounts USING btree (connection_status);
CREATE INDEX ix_accounts_consent_id ON darahim.accounts USING btree (consent_id);
CREATE INDEX ix_accounts_fast_sync ON darahim.accounts USING btree (fast_sync);
CREATE INDEX ix_accounts_id ON darahim.accounts USING btree (id);
CREATE INDEX ix_accounts_integrated_entity_id ON darahim.accounts USING btree (integrated_entity_id);
CREATE INDEX ix_accounts_integrated_id ON darahim.accounts USING btree (integrated_id);
CREATE INDEX ix_accounts_is_ignored_in_budget ON darahim.accounts USING btree (is_ignored_in_budget);
CREATE INDEX ix_accounts_is_ignored_in_report ON darahim.accounts USING btree (is_ignored_in_report);
CREATE INDEX ix_accounts_last_historical_sync_triggered_at ON darahim.accounts USING btree (last_historical_sync_triggered_at);
CREATE INDEX ix_accounts_last_sync_triggered_at ON darahim.accounts USING btree (last_sync_triggered_at);
CREATE INDEX ix_accounts_sponsored_tpp_id ON darahim.accounts USING btree (sponsored_tpp_id);
CREATE INDEX ix_accounts_user_id ON darahim.accounts USING btree (user_id);


-- darahim.account_snapshot definition

-- Drop table

-- DROP TABLE darahim.account_snapshot;

CREATE TABLE darahim.account_snapshot (
	id varchar NOT NULL,
	account_id varchar(40) NOT NULL,
	sponsored_tpp_id varchar NOT NULL,
	"timestamp" timestamp NOT NULL,
	user_id varchar NOT NULL,
	balance float8 NOT NULL,
	"data" jsonb NOT NULL,
	currency varchar NOT NULL,
	CONSTRAINT account_snapshot_pkey PRIMARY KEY (id),
	CONSTRAINT account_snapshot_account_id_fkey FOREIGN KEY (account_id) REFERENCES darahim.accounts(id),
	CONSTRAINT account_snapshot_sponsored_tpp_id_fkey FOREIGN KEY (sponsored_tpp_id) REFERENCES darahim.sponsored_tpp(id)
);


-- darahim.account_sync_log definition

-- Drop table

-- DROP TABLE darahim.account_sync_log;

CREATE TABLE darahim.account_sync_log (
	id varchar NOT NULL,
	account_id varchar(40) NULL,
	user_id varchar(40) NOT NULL,
	status varchar NOT NULL,
	"data" jsonb NOT NULL,
	CONSTRAINT account_sync_log_pkey PRIMARY KEY (id),
	CONSTRAINT account_sync_log_account_id_fkey FOREIGN KEY (account_id) REFERENCES darahim.accounts(id)
);
CREATE INDEX ix_account_sync_log_account_id ON darahim.account_sync_log USING btree (account_id);
CREATE INDEX ix_account_sync_log_status ON darahim.account_sync_log USING btree (status);
CREATE INDEX ix_account_sync_log_user_id ON darahim.account_sync_log USING btree (user_id);


-- darahim.e_statement definition

-- Drop table

-- DROP TABLE darahim.e_statement;

CREATE TABLE darahim.e_statement (
	id varchar NOT NULL,
	e_statement_request_id varchar NOT NULL,
	account_id varchar(40) NOT NULL,
	user_id varchar NOT NULL,
	sponsored_tpp_id varchar NOT NULL,
	status varchar NOT NULL,
	"data" jsonb NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	upload_id varchar(40) NULL,
	encrypted_data bytea NULL,
	CONSTRAINT e_statement_pkey PRIMARY KEY (id),
	CONSTRAINT e_statement_account_id_fkey FOREIGN KEY (account_id) REFERENCES darahim.accounts(id),
	CONSTRAINT e_statement_e_statement_request_id_fkey FOREIGN KEY (e_statement_request_id) REFERENCES darahim.e_statement_request(id),
	CONSTRAINT e_statement_sponsored_tpp_id_fkey FOREIGN KEY (sponsored_tpp_id) REFERENCES darahim.sponsored_tpp(id),
	CONSTRAINT upload_id_fk FOREIGN KEY (upload_id) REFERENCES darahim.uploads(id)
);
CREATE INDEX ix_e_statement_account_id ON darahim.e_statement USING btree (account_id);
CREATE INDEX ix_e_statement_e_statement_request_id ON darahim.e_statement USING btree (e_statement_request_id);
CREATE INDEX ix_e_statement_status ON darahim.e_statement USING btree (status);
CREATE INDEX ix_e_statement_user_id ON darahim.e_statement USING btree (user_id);


-- darahim.known_merchants definition

-- Drop table

-- DROP TABLE darahim.known_merchants;

CREATE TABLE darahim.known_merchants (
	"data" jsonb NOT NULL,
	merchant_name varchar(150) NOT NULL,
	id varchar(40) NOT NULL,
	category_id varchar(40) NOT NULL,
	categorized_by varchar(150) NOT NULL,
	verified_merchant_id varchar(40) NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT known_merchants_name_category_id_uq UNIQUE (merchant_name, category_id),
	CONSTRAINT known_merchants_pkey PRIMARY KEY (id),
	CONSTRAINT known_merchants_verified_merchant_id_fkey FOREIGN KEY (verified_merchant_id) REFERENCES darahim.verified_merchants(id)
);
CREATE INDEX ix_known_merchants_categorized_by ON darahim.known_merchants USING btree (categorized_by);
CREATE INDEX ix_known_merchants_category_id ON darahim.known_merchants USING btree (category_id);
CREATE INDEX ix_known_merchants_verified_merchant_id ON darahim.known_merchants USING btree (verified_merchant_id);
CREATE INDEX merchant_name_trgm_idx ON darahim.known_merchants USING gin (merchant_name darahim.gin_trgm_ops);


-- darahim.raw_transactions definition

-- Drop table

-- DROP TABLE darahim.raw_transactions;

CREATE TABLE darahim.raw_transactions (
	id varchar(40) NOT NULL,
	user_id varchar(40) NOT NULL,
	"data" jsonb NOT NULL,
	processed_data jsonb NOT NULL,
	status varchar(40) NOT NULL,
	purpose varchar NOT NULL,
	release_sha varchar(40) NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	sponsored_tpp_id varchar NOT NULL,
	external_id varchar(100) NULL,
	account_id varchar(40) NULL,
	"type" varchar(40) NOT NULL,
	extracted_merchant_name varchar(100) NULL,
	encrypted_data bytea NOT NULL,
	CONSTRAINT raw_transactions_pkey PRIMARY KEY (id),
	CONSTRAINT raw_transactions_account_id_fkey FOREIGN KEY (account_id) REFERENCES darahim.accounts(id),
	CONSTRAINT raw_transactions_sponsored_tpp_id_fkey FOREIGN KEY (sponsored_tpp_id) REFERENCES darahim.sponsored_tpp(id)
);
CREATE INDEX ix_raw_transactions_account_id ON darahim.raw_transactions USING btree (account_id);
CREATE INDEX ix_raw_transactions_created_at ON darahim.raw_transactions USING btree (created_at);
CREATE UNIQUE INDEX ix_raw_transactions_external_id ON darahim.raw_transactions USING btree (external_id);
CREATE INDEX ix_raw_transactions_purpose ON darahim.raw_transactions USING btree (purpose);
CREATE INDEX ix_raw_transactions_sponsored_tpp_id ON darahim.raw_transactions USING btree (sponsored_tpp_id);
CREATE INDEX ix_raw_transactions_status ON darahim.raw_transactions USING btree (status);
CREATE INDEX ix_raw_transactions_type ON darahim.raw_transactions USING btree (type);
CREATE INDEX ix_raw_transactions_user_id ON darahim.raw_transactions USING btree (user_id);


-- darahim.user_merchant_votes definition

-- Drop table

-- DROP TABLE darahim.user_merchant_votes;

CREATE TABLE darahim.user_merchant_votes (
	id varchar(40) NOT NULL,
	user_id varchar(40) NOT NULL,
	merchant_id varchar(40) NOT NULL,
	user_merchant_id varchar(40) NULL,
	category_id varchar(40) NOT NULL,
	sub_category_id varchar(40) NULL,
	vote_level varchar(40) NOT NULL,
	created_at timestamp NULL,
	updated_at timestamp NULL,
	CONSTRAINT one_vote_per_user_per_merchant UNIQUE (user_id, merchant_id),
	CONSTRAINT user_merchant_votes_pkey PRIMARY KEY (id),
	CONSTRAINT user_merchant_votes_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES darahim.known_merchants(id),
	CONSTRAINT user_merchant_votes_sub_category_id_fkey FOREIGN KEY (sub_category_id) REFERENCES darahim.sub_categories(id),
	CONSTRAINT user_merchant_votes_user_id_fkey FOREIGN KEY (user_id) REFERENCES darahim.users(id),
	CONSTRAINT user_merchant_votes_user_merchant_id_fkey FOREIGN KEY (user_merchant_id) REFERENCES darahim.known_merchants(id)
);
CREATE INDEX ix_user_merchant_votes_category_id ON darahim.user_merchant_votes USING btree (category_id);
CREATE INDEX ix_user_merchant_votes_merchant_id ON darahim.user_merchant_votes USING btree (merchant_id);
CREATE INDEX ix_user_merchant_votes_sub_category_id ON darahim.user_merchant_votes USING btree (sub_category_id);
CREATE INDEX ix_user_merchant_votes_user_merchant_id ON darahim.user_merchant_votes USING btree (user_merchant_id);


-- darahim.commitment definition

-- Drop table

-- DROP TABLE darahim.commitment;

CREATE TABLE darahim.commitment (
	id varchar(40) NOT NULL,
	user_id varchar(40) NOT NULL,
	amount float8 NOT NULL,
	"type" varchar NOT NULL,
	frequency varchar NOT NULL,
	sub_category_id varchar(40) NULL,
	category_id varchar(40) NOT NULL,
	merchant_id varchar(40) NULL,
	commitment_label varchar(200) NULL,
	each_day_of_month int4 NULL,
	each_day_of_week int4 NULL,
	end_date timestamp NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT commitment_pkey PRIMARY KEY (id),
	CONSTRAINT commitment_unique_constraint UNIQUE (user_id, commitment_label, amount, frequency),
	CONSTRAINT commitment_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES darahim.known_merchants(id),
	CONSTRAINT commitment_sub_category_id_fkey FOREIGN KEY (sub_category_id) REFERENCES darahim.sub_categories(id),
	CONSTRAINT commitment_user_id_fkey FOREIGN KEY (user_id) REFERENCES darahim.users(id)
);
CREATE INDEX ix_commitment_id ON darahim.commitment USING btree (id);


-- darahim.drahim_transactions definition

-- Drop table

-- DROP TABLE darahim.drahim_transactions;

CREATE TABLE darahim.drahim_transactions (
	id varchar(40) NOT NULL,
	user_id varchar(40) NOT NULL,
	user_merchant_id varchar(40) NULL,
	user_display_name varchar(150) NULL,
	user_category_id varchar(40) NULL,
	sub_category_id varchar(40) NULL,
	is_ignored_in_report bool NOT NULL,
	is_ignored_in_budget bool NOT NULL,
	note varchar(1000) NULL,
	tags jsonb NOT NULL,
	kind varchar(40) NOT NULL,
	"data" jsonb NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	raw_transaction_id varchar(40) NOT NULL,
	account_id varchar(40) NOT NULL,
	merchant_id varchar(40) NULL,
	"timestamp" timestamp NOT NULL,
	effective_category_id varchar(26) NOT NULL,
	sponsored_tpp_id varchar NULL,
	encrypted_data bytea NOT NULL,
	CONSTRAINT drahim_transactions_pkey PRIMARY KEY (id),
	CONSTRAINT drahim_transactions_account_id_fkey FOREIGN KEY (account_id) REFERENCES darahim.accounts(id),
	CONSTRAINT drahim_transactions_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES darahim.known_merchants(id),
	CONSTRAINT drahim_transactions_raw_transaction_id_fkey FOREIGN KEY (raw_transaction_id) REFERENCES darahim.raw_transactions(id),
	CONSTRAINT drahim_transactions_sub_category_id_fkey FOREIGN KEY (sub_category_id) REFERENCES darahim.sub_categories(id),
	CONSTRAINT drahim_transactions_user_merchant_id_fkey FOREIGN KEY (user_merchant_id) REFERENCES darahim.known_merchants(id),
	CONSTRAINT fk_drahim_transactions_sponsored_tpp_id FOREIGN KEY (sponsored_tpp_id) REFERENCES darahim.sponsored_tpp(id)
);
CREATE INDEX ix_drahim_transactions_account_id ON darahim.drahim_transactions USING btree (account_id);
CREATE INDEX ix_drahim_transactions_effective_category_id ON darahim.drahim_transactions USING btree (effective_category_id);
CREATE INDEX ix_drahim_transactions_is_ignored_in_budget ON darahim.drahim_transactions USING btree (is_ignored_in_budget);
CREATE INDEX ix_drahim_transactions_is_ignored_in_report ON darahim.drahim_transactions USING btree (is_ignored_in_report);
CREATE INDEX ix_drahim_transactions_kind ON darahim.drahim_transactions USING btree (kind);
CREATE INDEX ix_drahim_transactions_merchant_id ON darahim.drahim_transactions USING btree (merchant_id);
CREATE INDEX ix_drahim_transactions_raw_transaction_id ON darahim.drahim_transactions USING btree (raw_transaction_id);
CREATE INDEX ix_drahim_transactions_sponsored_tpp_id ON darahim.drahim_transactions USING btree (sponsored_tpp_id);
CREATE INDEX ix_drahim_transactions_sub_category_id ON darahim.drahim_transactions USING btree (sub_category_id);
CREATE INDEX ix_drahim_transactions_timestamp ON darahim.drahim_transactions USING btree ("timestamp");
CREATE INDEX ix_drahim_transactions_user_id ON darahim.drahim_transactions USING btree (user_id);
CREATE INDEX ix_drahim_transactions_user_merchant_id ON darahim.drahim_transactions USING btree (user_merchant_id);
CREATE INDEX ix_user_id_timestamp ON darahim.drahim_transactions USING btree (user_id, "timestamp");
CREATE INDEX user_id_account_id_index ON darahim.drahim_transactions USING btree (user_id, account_id);


-- darahim.drahim_transaction_links definition

-- Drop table

-- DROP TABLE darahim.drahim_transaction_links;

CREATE TABLE darahim.drahim_transaction_links (
	id varchar(40) NOT NULL,
	child_transaction_id varchar NOT NULL,
	child_account_id varchar NOT NULL,
	parent_transaction_id varchar NOT NULL,
	parent_account_id varchar NOT NULL,
	"type" varchar NOT NULL,
	user_id varchar NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT drahim_transaction_links_pkey PRIMARY KEY (id),
	CONSTRAINT drahim_transaction_links_child_account_id_fkey FOREIGN KEY (child_account_id) REFERENCES darahim.accounts(id),
	CONSTRAINT drahim_transaction_links_child_transaction_id_fkey FOREIGN KEY (child_transaction_id) REFERENCES darahim.drahim_transactions(id),
	CONSTRAINT drahim_transaction_links_parent_account_id_fkey FOREIGN KEY (parent_account_id) REFERENCES darahim.accounts(id),
	CONSTRAINT drahim_transaction_links_parent_transaction_id_fkey FOREIGN KEY (parent_transaction_id) REFERENCES darahim.drahim_transactions(id),
	CONSTRAINT drahim_transaction_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES darahim.users(id)
);


-- darahim.verified_merchants_suggestions definition

-- Drop table

-- DROP TABLE darahim.verified_merchants_suggestions;

CREATE TABLE darahim.verified_merchants_suggestions (
	id varchar(40) NOT NULL,
	transaction_id varchar(40) NULL,
	user_id varchar(40) NOT NULL,
	merchant_id varchar(40) NOT NULL,
	suggested_name varchar(150) NOT NULL,
	merchant_url varchar(2048) NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NOT NULL,
	CONSTRAINT verified_merchants_suggestions_pkey PRIMARY KEY (id),
	CONSTRAINT verified_merchants_suggestions_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES darahim.known_merchants(id),
	CONSTRAINT verified_merchants_suggestions_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES darahim.drahim_transactions(id),
	CONSTRAINT verified_merchants_suggestions_user_id_fkey FOREIGN KEY (user_id) REFERENCES darahim.users(id)
);