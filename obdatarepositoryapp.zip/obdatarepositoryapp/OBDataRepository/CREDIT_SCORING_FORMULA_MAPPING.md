# Credit Scoring — Excel Formulas vs. Code Mapping

This document summarizes the formulas defined in the two retail credit-scoring
spreadsheets and maps each one to the Java code that implements it.

- **Spec workbook:** `Credit Scoring For Retail.xlsx` — the authoritative formula/config spec.
- **QA workbook:** `Credit Profiling Retail Testing Results (Final).xlsx` — manual re-derivation of every metric vs. the live API for 3 test accounts (ACC-146/148/149).
- **Code:**
  - `src/main/java/com/ejada/obdatarepositoryapp/creditrisk/service/FinancialMetricsCalculator.java` (FMC)
  - `src/main/java/com/ejada/obdatarepositoryapp/creditrisk/service/CreditRiskScoringService.java` (CRSS)
  - `src/main/java/com/ejada/obdatarepositoryapp/creditrisk/config/CreditRiskConfig.java` (CFG)
  - enums `RiskFactorType`, `CreditRatingClass`

> Extraction helper: `extract_xlsx.py` (openpyxl) was used to dump the sheets. Safe to delete after review.

---

## Model at a glance

- **Score scale:** 0–1000 points, mapped to a **10-tier rating** (AAA → D).
- **Total = sum of 7 retail factor point-scores** (no weighting beyond the per-factor point caps).
- **Max points:** six factors cap at 150, ACCOUNT DPR caps at 100 → 1000 total.
- **Each factor = a banded lookup** (input range → fixed points), first matching band wins, bounds inclusive.

---

## File 1 — `Credit Scoring For Retail.xlsx` (spec)

### Sheets
| Sheet | Role |
|---|---|
| `Formulas` | Prose/structured definition of every factor + the 10-tier class table (authoritative). |
| `Configuration` | The band lookup tables (range → points) for all 7 factors + industry-standard reference block. |
| `CreditScoreCalc` | The live calculation engine — `IFS` formulas over 20 sample employees. |
| `TestSample` | Raw input fixture (20 employees × 6 months). Only formulas are literal `=amount*count` for the Loan Payment column. |

### The 7 scored factors (from `Formulas` + `Configuration` + `CreditScoreCalc`)

| # | Factor | Excel formula (CreditScoreCalc, rep. cell) | Bands (input → points) | Max |
|---|---|---|---|---|
| 1 | **Age** | `=IFS(C<=25,30, C<=35,80, C<=50,150, C<=60,100, C<=120,0)` | 18–25→30, 26–35→80, 36–50→**150**, 51–60→100, 61–120→0 | 150 |
| 2 | **Median Income (L3M, spike-excl.)** | `=IFS(E<=5000,0, E<=10000,50, E<=15000,100, E>15000,150)` | ≤5k→0, ≤10k→50, ≤15k→100, >15k→150 | 150 |
| 3 | **Loan Payment (last month sum)** *(inverse)* | `=IFS(G<=1500,150, G<=3000,130, G<=4500,110, G<=9000,80, G<=15000,40, G>15000,0)` | ≤1.5k→150 … >15k→0 | 150 |
| 4 | **Surplus Ratio** = (Income−Expenses)/Income | `=IFS(J<=0,0, J<=0.1,50, J<=0.2,100, J<=0.3,130, J<=1,150)` | ≤0→0, ≤.1→50, ≤.2→100, ≤.3→130, ≤1→150 | 150 |
| 5 | **Salary Category** | `=IFS(L<=5000,30, L<=15000,90, L>15000,150)` | ≤5k→30, ≤15k→90, >15k→150 | 150 |
| 6 | **Cash Flow** = Avg Income − Avg Expenses | `=IFS(N<0,0, N<=1000,50, N<=3000,100, N>3000,150)` | neg→0, ≤1k→50, ≤3k→100, >3k→150 | 150 |
| 7 | **Account DPR** = Avg Loan Payment / Median Income *(inverse)* | `=IFS(P<=0.1,100, P<=0.25,70, P<=0.4,40, P<=0.6,20, P<=1,0)` | ≤.1→100 … ≤1→0 | 100 |

**Total Score** (`CreditScoreCalc` R): `=D+F+I+K+M+O+Q` — flat unweighted sum.
**Class Name** (T): `IFS` 100-pt bands ≥900 Excellent … <100 Default Risk.
**Approval** (U): `IFS` ≥900 Very High … else Declined.
Note: the `Credit Class` *code* column (S) is a hardcoded literal in the sheet, not a formula.

### Class bands (`Formulas` rows 31–40)
AAA 900–1000 · AA 800–899 · A 700–799 · BBB 600–699 · BB 500–599 · B 400–499 · CCC 300–399 · CC 200–299 · C 100–199 · D 0–99.

### Industry-standard reference block (NOT scored — display only)
DTI `Debt/Income` (<35%) · Savings Rate `Savings/Income` (>15%) · Surplus Ratio `(Income−Expenses)/Income` (>20%) · Monthly Cash Flow `Income−Expenses` (positive) · Emergency Fund `Savings Balance / Avg Expenses` (>3mo) · Avg Balance 6M `Σ daily balances / days` (stable) · Negative Balance Days `count(balance<0)` (0) · Salary Regularity `(months on-time / months observed)×100` (>90%).

---

## File 2 — `Credit Profiling Retail Testing Results (Final)` (QA validation)

A manual-vs-API harness. Most "formulas" are spreadsheet descriptions of backend logic plus aggregate checks. Key sheets:

- **`Scoring Configuration` (hidden):** identical 7-factor band tables (uses `VLOOKUP(value, B:D, 3, TRUE)` on Min Value), `=SUM(D6:D12)`=1000 max, and the AAA→D class thresholds.
- **`Scoring results`:** factor scores for the 3 test accounts.
- **`QA Result`:** 21 manual re-computations diffed against the API (11 PASS / 5 WARN / 5 FAIL).
- **`*-Trans`:** raw transactions with footer aggregates `=SUM(...)`, `=SUMIF(...,"Credit"/"Debit",...)`, `=COUNTA(...)`; no running-balance formula (balance is static data).

### Validated formula clarifications (the load-bearing rules this workbook pins down)
- **Months of data (n):** count of DISTINCT year-months with ≥1 txn (must include trailing zero-activity months — the ACC-148 root-cause bug).
- **Avg Monthly Income:** `Σ credits / n`.
- **L3M Median Income:** exclude values > median×1.3, then `MEDIAN`; fallback to raw median.
- **L3M Avg Expenses:** **excludes** loan/mortgage repayments (living expenses only).
- **Surplus Ratio:** `(L3M_median − L3M_avg_living_expenses) / L3M_median`.
- **Avg Monthly Surplus (headline):** `avgMonthlyIncome − L3M_avg_TOTAL_debits` (**includes** loans) — distinct from Cash Flow.
- **Cash Flow:** `(Σ salary credits − Σ all debits) / n`.
- **DBR:** `(totalDebtPayments / n) / L3M_median` — numerator is loan/direct-debit payments only.
- **Emergency Fund:** `avgSurplus × n / full-period avg expenses`; N/A if surplus < 0.
- **Negative Balance Days:** `COUNTIF(Balance < 0)`.

### Test-account results
| | ACC-146 | ACC-148 | ACC-149 |
|---|---|---|---|
| Total | 560 → **BB** | 320 → **CCC** | 780 → **A** |

(Note: the F1 Age band shows 0 pts for all because the **request age was 17** — a data-input issue, not a scoring bug. Per spec, age 32 should map to 80.)

---

## File ↔ Code mapping

Legend: ✅ matches spec · ⚠️ divergence worth review.

### Scored factors → code

| Factor | Excel formula | Code: raw value source | Code: band table | Status |
|---|---|---|---|---|
| **Age** | age bands, peak 36–50 | `metrics.age` — CRSS:247 | `initializeDefaultRanges` AGE — CRSS:512–518 | ✅ bands identical |
| **Median Income L3M** | spike >30% excl., median of last 3 mo | `medianMonthlyIncome` — CRSS:248; computed `calculateMedianExcludingSpikes(last3MonthsIncomes)` FMC:142, spike=1.3×median FMC:631–654 | INCOME — CRSS:521–526 | ✅ |
| **Loan Payment** | sum of last month loan payments | `lastMonthDebtPayment` (loans **+ mortgages**) — CRSS:249 / FMC:168 | LOAN_PAYMENT — CRSS:529–536 | ⚠️ code includes mortgages; spec says "loan payment" |
| **Surplus Ratio** | `(Income−Expenses)/Income` | `surplusRatio × 100` — CRSS:250; computed `(medianIncome − avgExpenses − avgDebtPayment)/medianIncome` FMC:178–183 | SURPLUS_RATIO — CRSS:540–546 | ⚠️ code subtracts **debt** too, and uses **median** income vs spec's avg |
| **Salary Category** | salary amount bracket | `medianSalaryIncome` (L3M spike-excl. median of salary credits) — CRSS:252 | SALARY_CATEGORY — CRSS:549–553 | ⚠️ code uses L3M median salary; spec/QA use *last month* salary |
| **Cash Flow** | `Avg Income − Avg Expenses` | `cashFlow` = `avg(salaryIncome) − avg(expenses)` — CRSS:253 / FMC:191 | CASH_FLOW — CRSS:557–562 | ⚠️ code uses **salary** income, not total income |
| **Account DPR / DBR** | `Avg Loan Payment / Median Income`, weight **100** | `debtBurdenRatio × 100` = `avgDebtPayment / medianSalaryIncome` — CRSS:254 / FMC:187 | DEBT_BURDEN_RATIO — CRSS:566–572 | ⚠️ code divides by **median salary**, spec says median **income** |

### Aggregation & class → code
| Concept | Excel | Code | Status |
|---|---|---|---|
| Total score | `=Σ 7 factor scores` (flat) | `Σ score where dataAvailable` then renormalize to /1000 if factors skipped — CRSS:67–82 | ⚠️ code adds **score redistribution** for skipped factors (not in Excel) |
| Max points | 1000 (6×150 + 100) | `RiskFactorType` weights sum 1000 | ✅ |
| Rating class | AAA 900 … D 0–99 | `CreditRatingClass.fromScore` (min≤score≤max) | ✅ identical bands |
| Band match | `IFS`/`VLOOKUP(...,TRUE)` first-match | `calculateScoreFromRanges` first inclusive match — CRSS:278–293 | ✅ equivalent |

### Industry-standard metrics → code (display/reference, not scored)
| Metric | Excel formula | Code | Status |
|---|---|---|---|
| Savings Rate | `Savings / Income` (>15%) | `max(avgSurplus,0)/avgIncome` — FMC:209–213 | ✅ |
| Emergency Fund | `Savings Balance / Avg Expenses` (>3mo) | `max(avgSurplus,0)×months / avgExpenses` — FMC:216–222 | ✅ (savings balance estimated) |
| Avg Balance 6M | `Σ daily balances / days` | mean of daily `balanceAfter` — FMC:723–758 | ✅ |
| Negative Balance Days | `count(balance < 0)` | count daily `balanceAfter < 0` — FMC:765–796 | ✅ |
| Salary Regularity | `(on-time months / months)×100` (>90%) | `onTimeCount/occurrences`, tolerance ±5 days, min 3 occ — FMC:803–855 | ✅ (decimal, not ×100) |
| Income/Expense Volatility | CV (QA sheet) | `stdDev/mean×100` — FMC:661–686 | ✅ |

---

## Key divergences to review (code vs. spec)

1. **Salary Category** — code scores the **L3M median salary** (`medianSalaryIncome`); spec & QA use the **last-month** salary amount.
2. **Cash Flow** — code uses **salary income** (`avg salary − avg expenses`); spec is **total** avg income − avg expenses.
3. **Surplus Ratio** — code = `(medianIncome − avgExpenses − avgDebtPayment)/medianIncome` (subtracts debt, uses median); spec = `(avgIncome − avgExpenses)/avgIncome`.
4. **Account DPR / Debt Burden Ratio** — code divides debt by **median salary**; spec divides by **median income**.
5. **Loan Payment factor** — code's `lastMonthDebtPayment` includes **mortgages**; spec scopes to loan payments.
6. **Score redistribution** — code renormalizes the total to a /1000 base when factors are skipped (CRSS:79–81); Excel has no such step (flat sum).
7. **QA root cause (ACC-148)** — engine must include trailing **zero-activity months** in `monthsOfData`; the QA sheet's failures hinge on this.

### Config constants (CFG) backing the metric formulas
spike `1.3` (CFG:19) · min months for median `3` (CFG:22) · recurring `≥3 of 6` months (CFG:23–24) · salary min occurrences `3`, day tolerance `5` (CFG:27–28) · supplier consistency CV `≤30` · behavior thresholds income/expense `30%`, txn-freq `40%`, high-volatility `25%` (CFG:34–37).
