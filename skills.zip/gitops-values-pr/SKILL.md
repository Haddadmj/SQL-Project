---
name: gitops-values-pr
description: Update values.yaml in one or more Neotek Bitbucket gitops repos in the OB (open-banking) project (UAT, or Prod+DR) and open a pull request per repo. Use when the user asks to bump an image tag, change a config/env value, or update values.yaml for an OB-project service on bitbucket.neotek.sa. OB project ONLY - hard-refuse the APIGW repo `api-gw-apic` (its prod/dr are bot-managed via `promotion/values.yaml`); for that repo use `deploy-apic` instead.
---

# GitOps values.yaml update + PR (bitbucket.neotek.sa)

Updates `values.yaml` for one or more services in Bitbucket Data Center at
`https://bitbucket.neotek.sa`, branching off `gitops` and opening a PR back into `gitops`.

## Inputs — ask the user if missing

1. **Repo(s)**: repo slug(s), e.g. `open-banking-api`. **Project key is always `OB`** for this skill. **Hard-refuse `api-gw-apic` (project `APIGW`)**: it is not an OB repo and its `prod/`+`dr/` values are bot-managed from `promotion/values.yaml`, so editing them directly here would corrupt the promotion flow. If asked to bump that repo, stop and tell the user to use `deploy-apic`.
2. **Environment**: `uat` or `prod`. **`prod` means updating BOTH `prod/values.yaml` AND `dr/values.yaml` with the same change** — never prod alone. (`sit` exists too if explicitly requested.)
3. **The change**: which key(s) and new value(s), e.g. `image.tag: 1.260707.124926`, or a configmap entry.
4. Optional: reason / ticket reference for the PR description.

## Constants and gotchas

- **Auth**: Bearer token in user env var `BITBUCKET_NEOTEK_TOKEN`. If empty, stop and ask the user for a token (created at Bitbucket → Manage account → HTTP access tokens).
- **HTTPS only**: SSH (ports 22/7999) is firewall-blocked from this machine. Always clone/push over HTTPS using a bearer header — never embed the token in the remote URL:
  `git -c http.extraHeader="Authorization: Bearer $TOKEN" <clone|push|fetch> ...`
- **These repos have NO default branch.** A plain clone comes back empty. Always `--branch gitops`.
- REST API base: `https://bitbucket.neotek.sa/rest/api/1.0`
- Repo layout: `<env>/values.yaml` for env in `sit|uat|prod|dr`.
- Work in the session scratchpad directory, never in the user's project dirs.

## Steps (repeat per repo)

1. **Clone** shallow into scratchpad:
   ```bash
   export BB_TOKEN="$BITBUCKET_NEOTEK_TOKEN"
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" \
     clone --depth 1 --branch gitops \
     https://bitbucket.neotek.sa/scm/ob/<repo>.git
   ```
2. **Branch**: `alhaddadmc/<env>-<short-change>-<yyyymmddHHmm>`, e.g. `alhaddadmc/uat-image-tag-202607091530`.
3. **Edit** `<env>/values.yaml` with the Edit tool (for `prod`, apply the identical change to `dr/values.yaml` too). Preserve existing YAML formatting/indentation exactly; change only the requested value(s). Show the user the old → new diff before pushing if the change is ambiguous.
4. **Commit and push**:
   ```bash
   git commit -am "<env>: <what changed>"   # e.g. "uat: bump image tag to 1.260707.124926"
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" push -u origin <branch>
   ```
5. **Create the PR**:
   ```bash
   curl -sS -X POST -H "Authorization: Bearer $BB_TOKEN" -H "Content-Type: application/json" \
     "https://bitbucket.neotek.sa/rest/api/1.0/projects/OB/repos/<repo>/pull-requests" \
     -d @pr.json
   ```
   with `pr.json`:
   ```json
   {
     "title": "<ENV>: <summary>",
     "description": "<markdown body>",
     "fromRef": { "id": "refs/heads/<branch>", "repository": { "slug": "<repo>", "project": { "key": "OB" } } },
     "toRef":   { "id": "refs/heads/gitops",   "repository": { "slug": "<repo>", "project": { "key": "OB" } } }
   }
   ```
6. **Report** the PR link: `https://bitbucket.neotek.sa/projects/OB/repos/<repo>/pull-requests/<id>` (the `id` field of the JSON response).

Notes:
- Do NOT set `reviewers` — the server auto-adds the team's default reviewers (and the DevSensei code-owners bot) on creation.
- Any later PR mutation (decline, update) needs the PR's **current** `version` — fetch the PR first; auto-added reviewers bump it immediately after creation, so the version from the create response is already stale.

## PR conventions

- **Title**: `<ENV>: <what changed> (<repo>)` — e.g. `UAT: bump image tag to 1.260707.124926 (open-banking-api)`.
- **Description** (markdown):
  - One line stating environment(s) and reason (if given).
  - A table per changed file: `| file | key | old | new |`.
- For prod PRs, note explicitly in the description that both `prod/` and `dr/` were updated.

## Failure handling

- 401 from API → token expired/revoked: ask the user for a new token and update the `BITBUCKET_NEOTEK_TOKEN` user env var.
- Push rejected → re-fetch `gitops` and rebase; these repos move fast with concurrent tag bumps.
- If the requested key does not exist in the target values.yaml, stop and ask instead of guessing where to add it.
