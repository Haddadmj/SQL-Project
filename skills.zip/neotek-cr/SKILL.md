---
name: neotek-cr
description: Drafts Change Request paperwork for Neotek UAT/PROD deployments: CR description, CAB notification email (always), Change Impact Assessment and Implementation & Rollback Plan xlsx (PROD only). Use when preparing deployment paperwork at Neotek - trigger phrases include 'I need a CR', 'draft a CR', 'deploying to UAT', 'deploying to PROD', 'fill out the deployment forms', 'change request for [service]', 'deployment paperwork', or any mention of preparing CR/SR/deployment paperwork for a Neotek service.
---

# Neotek Deployment CR Drafter

## Quick start

1. Tell the agent the environment (UAT or PROD) and a brief description of what changed.
2. Answer phase questions in batches — the agent derives what it can from git history and conversation.
3. The agent writes `./cr/<cr-number>/` with the filled `.docx` (always) and `.xlsx` (PROD only).

Example trigger: _"I need to deploy the payments hotfix to UAT, draft the CR."_

## What gets produced

| Output | When |
|---|---|
| `cr_email.docx` — CR description + CAB notification email | Always |
| `Change_Impact_Assessment.xlsx` | PROD only |
| `Implementation_and_Rollback_Plan.xlsx` | PROD only |

Output directory: `./cr/<cr-number>/`

## Core rules

- **Derive, don't ask**: infer summary, risks, components, impact rows from recent commits / changelog / branch diff. Drafting and letting the user correct beats asking 8 questions.
- **Ask only for**: data the repo can't supply (named approvers, scheduled times, externally-assigned CR numbers, links).
- **Read back before output**: summarise any non-trivial inference for confirmation before producing files.
- **Never fabricate**: leave `UPPER_SNAKE_CASE` placeholders for genuinely unknown values. List them all in Phase 6.
- **"You do all"**: if the user says to proceed and they'll correct, honor it — produce outputs with placeholders, don't keep asking.

## Standing approvers

Default these instead of asking. Confirm rather than re-ask, and let the user override per CR.

| Role | Name |
|---|---|
| Cyber Security | Naif M. Alkaltham |
| Tech Manager | Majid AlHasan |
| Infra Manager | Mahmoud M. Moawad |
| Product Owner | varies per CR, ask |

All four are columns in the `cr_email.docx` approval matrix. Product Owner is the only one to ask about per CR.

## Workflow

See [WORKFLOW.md](./WORKFLOW.md) for the full phase-by-phase question script (Phases 1-6).

## Output style

See [OUTPUT-RULES.md](./OUTPUT-RULES.md) for style constraints: no jargon, no em-dashes, terse xlsx fills, UAT/PROD scope rule.

## Running generate.py

```bash
mkdir -p ./cr/<cr-number>
python3 ~/.claude/skills/neotek-cr/generate.py ./cr/<cr-number>/input.json ./cr/<cr-number> --env <UAT|PROD>
```

See [JSON-SCHEMA.md](./JSON-SCHEMA.md) for the full `input.json` field reference.
