# Output Rules

## UAT vs PROD scope

For **UAT** deployments, only produce `cr_email.docx`. Skip Phase 2 (Change Impact Assessment) and Phase 3 (Implementation & Rollback Plan) entirely — don't gather their data, don't render them.

Exception: if the user explicitly asks for them ("draft the impact assessment too", "I need the impl plan even though it's UAT"), produce all three. Default is skip.

For **PROD** deployments, produce all three outputs.

---

## Style rules

**No technical jargon.** CR / impact / impl / email are read by CAB reviewers and auditors, not engineers. Say what happens, not how it's coded. If an identifier matters (e.g., `add k8s secret IBAN_TINK_KEYSET`), keep the identifier but drop the surrounding implementation explanation. Test: would a non-engineer reviewer understand the line?

**Keep xlsx fills terse.** One-line answers, short bullets, no padding. The xlsx is regulatory, not operational. The CR description can be slightly more substantive (it's what reviewers actually read).

**Don't surface negative answers as content.** If something is "no" / "none", don't write a line about it. E.g., no manual infra steps means the CR's Deployment Steps section is just `Deployment steps are fully handled by CI/CD.` — one line, no list, no "None, fully automated" bullet.

**Never use em-dashes (—) in any output.** Use hyphens (`-`), commas, colons, or "or" instead. Applies to the email subject, CR description, xlsx fills, and every other generated string. Em-dashes that appear in SKILL.md or WORKFLOW.md are documentation only — do not copy them into rendered output.

---

## Confirmation before output

Any non-trivial inference (Yes/No on the 7 impact rows, risk wording) must be summarised for confirmation before producing outputs. Don't silently assume.

When the user says things like "low impact, internal only", turn that into a focused confirmation ("then I'll mark Direct=No, Indirect=No, …, ok?"), not a silent set of assumptions.
