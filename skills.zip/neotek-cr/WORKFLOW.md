# Neotek CR Workflow

Run these phases in order. Don't gather everything in one mega-question — batched, contextual rounds produce better answers and let the user think clearly about each section.

---

## Phase 1 — Core CR info

Ask the user, in one batched message:

1. Environment: **UAT** or **PROD**?
2. Deployment type — one of: new app / hotfix / new feature / config change / infra change / other (specify)
3. Components touched — services or infra affected (e.g., backend service, frontend, SSO, payments, subscriptions, DNS, secrets, K8s/OKE infra). Capture the user's wording verbatim.
4. Brief summary of the fix/feature being shipped (1-3 sentences)
5. Any deployment steps the **infra team** must perform manually (e.g., add a new secret, create a DNS record, open firewall rule)? List them, or say "none — CI/CD only"

---

## Phase 2 — Change Impact Assessment *(skip for UAT unless explicitly requested)*

Ask, in one batch:

1. **Service Name** (e.g., "Qaema Payments")
2. **Module / Sub Service** (e.g., "Al Rajhi gateway integration")
3. **Pre-Prod deployment completed?** Yes / No — if Yes, also the **Pre-Prod CR Number**
4. **Business benefit** in one short line (the template default "New API Deployment" is rarely accurate — get the real one)
5. **Financial impact?** Yes / No — if Yes, ask for a one-line description
6. **Key risks** — 1-4 short bullets, just the headline of each risk
7. For each impact row below, ask: Yes/No, level (High/Medium/Low if Yes), and a one-line remark:
   - Direct related Services
   - Indirect related Services
   - No of Customer/User Impacted
   - Utilization
   - Service Availability
   - Service Continuity
   - Information Security
8. **Summary of impact** — one sentence

Accept terse answers like "Direct: yes/L/none, Indirect: no, Customers: yes/L/all paying merchants, …" but read every Yes/No back for confirmation before producing the final output. These rows are audited.

---

## Phase 3 — Implementation & Rollback Plan *(skip for UAT unless explicitly requested)*

Ask, in one batch:

1. **Change Number** — the CR number from the system (or `CR_NUMBER` placeholder if not assigned yet)
2. **Technical KT performed?** Yes / No
3. **Implementation Complexity**: Low / Medium / High
4. **Implementor Teams — Escalation Point**: name(s) and team
5. **Outage time** for the deployment (or "0" / "none"). Start/end dates and Doer/Checker are intentionally **not** captured here — the template leaves those blank for the implementer to fill at execution time.
6. **Pre-implementation tasks** beyond the standard "obtain approvals from stakeholders" — list each as `{task, duration}` (e.g., `"Generate keyset" / "10m"`).
7. **Implementation tasks** — list each as `{task, duration}`. Default for a CI/CD-driven deploy: "trigger pipeline / 5m, monitor logs / 5m, smoke-test / 10m". Manual infra steps from Phase 1 Q5 will be prepended automatically.
8. **Verification steps** — `{task, duration}` per item (smoke tests, health endpoints, key flows to retest).
9. **Post-implementation tasks** — `{task, duration}` per item (notify business, close Jira, monitor for X hours).
10. **Rollback steps** — concrete actions to revert, each `{task, duration}`. The template default "revert to old Image" is a placeholder, not an answer; get the actual commands/actions (e.g., redeploy previous image tag, run down-migration, restore secret).
11. **Business health check steps** — or "None"

If the user doesn't know a duration, leave it as `""` (the cell stays blank) — don't invent one.

---

## Phase 4 — Deployment notification email

Ask, in one batch — only for fields not already gathered:

1. **Scope** — the business unit / product (e.g., Qaema, Open Banking, Premium Services)
2. **Product Owner** — name
3. **CR Link** — paste the URL, or say "later" to keep the `CR_LINK` placeholder
4. **CAB Teams Meeting Link** — paste the URL, or "later" for the `CAB_MEETING_LINK` placeholder

Cyber Security, Tech Manager, and Infra Manager default to the standing approvers in SKILL.md — confirm them rather than asking, and accept an override.

These fields are derived automatically from earlier phases — do **not** re-ask:

- **Subject's CR Number** - from Phase 3 Q1 (or Phase 1 if no CR number yet)
- **Environment** - Phase 1 Q1
- **Type** - Phase 1 deployment type, normalized: strip leading "new ", title-case ("new feature" → "Feature")
- **Service** - Phase 2 Q2 (Module / Sub Service, NOT Service Name). The email's Service field expects the specific module ("Qaema Business Backend"), not the broader service.
- **Description** in Service Approval Matrix - short version of Phase 1 Q4 summary, one line max
- **Release Status** - default to "Pending Review" (user can override)

---

## Phase 5 — Produce the outputs

Write `./cr/<cr-number>/input.json` then invoke:

```bash
python3 ~/.claude/skills/neotek-cr/generate.py ./cr/<cr-number>/input.json ./cr/<cr-number> --env <UAT|PROD>
```

Directory layout (PROD):

```
./cr/<cr-number>/
├── input.json
├── cr_email.docx                           (always; combined CR description + email)
├── Change_Impact_Assessment.xlsx           (PROD only)
└── Implementation_and_Rollback_Plan.xlsx   (PROD only)
```

For UAT: only `cr_email.docx` and `input.json`.

Also echo the rendered CR description content in chat for a sanity-check — the chat text is NOT persisted to a file.

Surface any warnings the script printed.

---

## Phase 6 — Final reminders

Do **not** skip this — manual additions are the most common cause of CR rejection.

**For PROD:**

```
=== Files to upload through the CR system ===
[ ] ./cr/<cr-number>/Implementation_and_Rollback_Plan.xlsx
[ ] ./cr/<cr-number>/Change_Impact_Assessment.xlsx
[ ] SonarQube screenshot                              ATTACH_SCREENSHOT

Unfilled placeholders that still need values:
- <list every UPPER_SNAKE_CASE placeholder remaining, by section and field>
- (or: "None - all fields filled.")
```

**For UAT:**

```
Generated files (in ./cr/<cr-number>/):
- cr_email.docx

Unfilled placeholders that still need values:
- <list every UPPER_SNAKE_CASE placeholder remaining in cr_email.docx, by section and field>
- (or: "None - all fields filled.")
```

---

## Style of questions

Group related fields into numbered batches; accept terse answers ("1) UAT, 2) hotfix, 3) payments backend"). If an answer is ambiguous, ask one focused follow-up rather than guessing. Don't lecture about the process — assume the user knows it.
