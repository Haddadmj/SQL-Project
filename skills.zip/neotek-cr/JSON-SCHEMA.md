# JSON Schema for generate.py

Write this as `./cr/<cr-number>/input.json`, then invoke:

```bash
mkdir -p ./cr/<cr-number>
python3 ~/.claude/skills/neotek-cr/generate.py ./cr/<cr-number>/input.json ./cr/<cr-number> --env <UAT|PROD>
```

The `--env UAT` flag skips the two xlsx outputs; `--env PROD` (or no flag, defaulting to the JSON's `environment` value) writes all three.

---

## Full field reference

```json
{
  "cr_number": "...", "date_created": "YYYY-MM-DD",
  "environment": "UAT|PROD", "deployment_type": "new feature|hotfix|...",
  "scope": "...",
  "service_name": "...",            // xlsx Service Name (broader)
  "module_sub_service": "...",      // xlsx Module + email Service field (specific)
  "preprod_completed": "Yes|No", "preprod_cr_number": "...",

  // CR description section of cr_email.docx
  "version": "0.7.13",              // optional; omit = title collapses to "{scope} {environment} Deployment"
  "components": ["component 1", "component 2"],
  "summary_of_changes": "1 to 3 sentence summary",
  "deployment_steps": "Deployment steps are fully handled by CI/CD.",
  "pr_links": "https://...", "jira_links": "https://...",
  "sonarqube_link": "https://...", "changelog_link": "https://...",

  "business_benefit": "...", "financial_impact": "Yes|No",
  "key_risks": ["...", "..."],
  "impacts": {
    "direct":       {"yesno": "Yes", "detail": "...", "level": "H|M|L", "remarks": "..."},
    "indirect":     {"yesno": "No"},
    "customer":     {"yesno": "...", "detail": "...", "level": "...", "remarks": "..."},
    "utilization":  {"yesno": "...", "detail": "...", "level": "...", "remarks": "..."},
    "availability": {"yesno": "...", "detail": "...", "level": "...", "remarks": "..."},
    "continuity":   {"yesno": "...", "detail": "...", "level": "...", "remarks": "..."},
    "infosec":      {"yesno": "...", "detail": "...", "level": "...", "remarks": "..."}
  },
  "summary_of_impact": "...",

  "change_number": "...", "technical_kt": "Yes|No",
  "implementation_complexity": "Low|Medium|High",
  "implementor_team": "...",

  "deployment_tasks": [
    {"task": "...", "duration": "...", "outage": "...", "notes": "..."}
  ],
  "coordination_with_business": [{"task": "...", "duration": ""}],
  "pre_implementation":         [{"task": "Obtain approvals from stakeholders", "duration": "1d"}],
  "implementation_tasks":       [{"task": "...", "duration": "..."}],
  "verification_steps":         [{"task": "...", "duration": "..."}],
  "post_implementation":        [{"task": "...", "duration": "..."}],
  "rollback_steps":             [{"task": "...", "duration": "..."}],
  "business_health_check":      [{"task": "None", "duration": ""}],

  "cr_link": "...", "cab_meeting_link": "...",
  "product_owner": "...", "cyber_security": "...", "tech_manager": "...",
  "infra_manager": "...",
  "approval_description": "ONE_LINE_SUMMARY_FOR_THE_SERVICE_APPROVAL_MATRIX"
}
```

---

## Field notes

- **"No" impact rows**: write only `{"yesno": "No"}` — omit detail/level/remarks.
- **Manual infra steps** from Phase 1 Q5 go at the **top** of `implementation_tasks`, before operational steps.
- **Email "Service"** field is filled from `module_sub_service` (specific module), not `service_name`.
- **Email "Type"** is derived from `deployment_type`: leading `"new "` stripped, title-cased (`"new feature"` → `"Feature"`).
- **Multiple services** in the Service Approval Matrix: supply `"approval_matrix": [{...}, {...}]` instead of single-service defaults; `generate.py` appends rows as needed.
- `generate.py` keeps the impl template's first deployment-plan row (the "Example") intact and inserts real tasks below it. Variable-length list sections auto-extend when the input has more items than the template — no truncation.
- Rollback steps: template has 2 merged 4-row groups. More than 2 rollback steps triggers a warning and truncation — combine steps or extend the template manually.

---

## Outputs to report to the user

- `./cr/<cr-number>/cr_email.docx` (always)
- `./cr/<cr-number>/Change_Impact_Assessment.xlsx` (PROD only)
- `./cr/<cr-number>/Implementation_and_Rollback_Plan.xlsx` (PROD only)
