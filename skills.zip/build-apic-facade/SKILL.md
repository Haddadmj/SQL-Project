---
name: build-apic-facade
description: Builds a two-tier IBM API Connect (APIC / DataPower API Gateway) façade — a public inbound API plus a backend-facing outbound API, both products, the optional field-mapping doc, and the client-facing design deliverables (integration guide + sanitized OpenAPI) — following the fixed Neotek spine (FRAMEWORK logging, NTSP error envelope, catch-all error blocks, per-catalog env props). User-invoked.
disable-model-invocation: true
---

# Build an APIC façade

Builds a new **two-tier façade** on DataPower API Gateway, the way this project already does it: a public **inbound** API that validates and shields the caller, calling a backend-facing **outbound** API that handles upstream auth and the raw call. Everything the caller sees is a clean REST contract; all the mess (auth, error normalization, optional transform) lives in the assembly.

**Two flavours of façade** — decide up front which this API is:
- **Pass-through** — the inbound validates, forwards, and returns the backend response as-is (only status/header normalization). No mapping doc, no transform. This is the default; prefer it unless the caller contract genuinely differs from the backend shape.
- **Transforming** — the inbound reshapes the backend response into a different target contract. Needs a field-mapping doc (step 2) and a transformer (step 4). Only do this when the shapes actually differ.

If transforming, the build is **mapping-driven**: you cannot write the transform until the field mapping exists. Do the steps in order.

## Locations

**This skill only builds — it never touches the git repo.** All authoring happens in the staging tree; a separate deploy step (step 8) copies the result into the repo and hands off to `deploy-apic`.

- **Staging / build directory (non-git):** `D:\Neotek\Neotek API GW`. Author every file here. All relative paths below are relative to this tree. Confirm you are in it before generating anything.
- **Deployables** live at the staging top level (no `GW/` prefix): `inbound/apis`, `inbound/products`, `outbound/apis`, `outbound/products`.
- **Non-deployables** — the field-mapping doc (step 2) and the client deliverables (step 6) — go to `_deliverables/<name>/` in staging. They are **never** copied to the repo, so they cannot clutter it.
- **`apic` CLI:** use the copy **bundled in the staging folder**, `D:\Neotek\Neotek API GW\apic.exe`. Run validation with the staging dir as the working directory and invoke it as `.\apic.exe validate …` — do not rely on PATH or hardcode another path.
- **Git repo (deploy target — do NOT author here):** `D:\Neotek\api-gw-apic`. Only step 8 writes to it (a selective copy), then `deploy-apic` takes over.

## The two tiers

| Tier | File | Job |
|---|---|---|
| **Inbound** | `inbound/apis/<name>_1.0.0.yaml` | Public façade. Validate → build backend request → invoke outbound (optional cache) → process response → transform to target contract. Owns the caller-facing contract + all catch blocks. |
| **Outbound** | `outbound/apis/<name>_1.0.0.yaml` | Backend orchestrator. Acquire upstream auth → invoke real upstream → return raw response. |
| **Products** | `{inbound,outbound}/products/<name>_1.0.0.yaml` | Wrap each API with a plan, rate-limit, visibility. |

**Client deliverables** (step 6) derive from the inbound only: `_deliverables/<name>/<name>-integration-guide.md` + a sanitized `_deliverables/<name>/<name>-client_1.0.0.yaml`. They are what you hand a client — keep all outbound/backend internals out of them. They stay in staging and are never copied to the repo.

## The fixed spine (never redesign — copy verbatim from templates)

These are identical across every API in this project. They live in the templates already; fill only the marked holes.

- **FRAMEWORK logging** — `Log REQ / IREQ / IRPLY / RPLY / Error` gatewayscript steps calling `FRAMEWORK_FUNCTIONS.js`.
- **NTSP error envelope** — every error returns `{ Errors: [{ Code: 'NTSP.ERROR.<status>.<n>', Message, Url }] }`.
- **Catch-all blocks** — one `catch` per APIC error type: `ConnectionError`, `CoreError`, `ValidationError`, `JavaScriptError`, `ParseError`, and `default`. Never drop one.
- **Security** — OAuth2 (`clientCredentials`) on inbound; apiKey `client_id`/`client_secret` on outbound.
- **Catalogs** — `neotek-dev / neotek-sit / neotek-sandbox / neotek` (inbound) and `neotek-core-*` (outbound) property overrides. Only URLs/creds change per API.

See [reference/conventions.md](reference/conventions.md) for the full spine, directory layout, and naming rules.

## Build steps

### 1. Gather the two contracts
Establish (a) the **target** public contract — what callers get — and (b) the **backend** request/response shape — what the upstream speaks. Sources vary: a target OpenAPI spec, a backend OpenAPI or sample response, or a prose description you turn into both. Ask only for what you cannot derive.
**Done when:** you have a concrete public contract (paths, params, response schemas) AND a concrete backend request body + response shape.

### 2. Write the field-mapping doc — *transforming façades only; skip for pass-through*
Produce `_deliverables/<name>/<source>-vs-<backend>-mapping.md`: per target endpoint, map every target field to its backend path, and flag type/required diffs (⚠️), gaps with no backend source (❌), and backend-only extras (➕). This doc is the spec for the step-4 transform.
**Done when:** every target field is either mapped to a backend path or explicitly flagged ❌, and every structural difference (envelope wrapping, root-vs-nested arrays) is noted. See the structure in [reference/transform-toolkit.md](reference/transform-toolkit.md).

### 3. Generate the outbound API
Copy `templates/outbound-api.yaml`. Fill: name/title, the backend path (e.g. `/report`), the **auth-acquisition** steps, the upstream invoke target, and properties/catalogs. Pick the auth variant from [reference/outbound-auth.md](reference/outbound-auth.md) — **Basic→JWT→Bearer** or **client_id/client_secret** (do not assume Basic).
**Done when:** the outbound validates and its only per-catalog variables are the upstream URL(s) + credentials.

### 4. Generate the inbound API
Copy `templates/inbound-api.yaml`. Merge the target spec's paths/schemas/parameters/responses into the head, then fill the four assembly holes:
- **Validate Request** — collect *every* invalid field, then `context.reject('ValidationError', …)`. Never build an error body in the main flow.
- **Build backend request** — transform the validated inputs into the backend request body; set the outbound credentials headers; if caching, set the **cache-key** here.
- **Invoke Outbound** — target `$(outbound-url)`. **Caching is an opt-in toggle**: when on, add `cache-response: time-to-live`, `cache-putpost-response: true`, `cache-ttl`, `cache-key: $(cacheKey)`. See the caching rules in [reference/conventions.md](reference/conventions.md).
- **Transform to target** — *transforming façades only.* Build one transformer per operation from the step-2 mapping, using the helper toolkit in [reference/transform-toolkit.md](reference/transform-toolkit.md). Omit ❌ fields; handle ⚠️ type/trim/unwrap cases explicitly. **Pass-through façades skip this hole entirely** — leave the backend response untouched and only normalize status/headers.
**Done when:** every operation has a validate rule set; transforming façades also have a transformer per operation; the fixed spine is untouched.

### 5. Generate the products
Copy `templates/inbound-product.yaml` and `templates/outbound-product.yaml`; set title/name, the `$ref` to the api file, plan rate-limit, and visibility.
**Done when:** each product `$ref`s its api by the correct relative path and version.

### 6. Generate the client design deliverables
Produce two files clients receive. Both derive **only from the inbound public contract** — never expose outbound/backend details, upstream URLs, assembly internals, the field mapping, or the `client_id`/`client_secret` property values.
- **Integration guide** `_deliverables/<name>/<name>-integration-guide.md` — copy `templates/client-integration-guide.md` and fill from the inbound spec: overview, environments/base URLs, OAuth2 token flow, per-endpoint request + sample success response (reuse the spec examples), the error-code catalog, rate limits, and the common headers.
- **Sanitized OpenAPI** `_deliverables/<name>/<name>-client_1.0.0.yaml` — copy the inbound api and **strip everything IBM/internal**: delete the entire `x-ibm-configuration` block (assembly, properties, catalogs, credentials in one cut) and any other `x-ibm-*` / `x-*` gateway keys; keep `info`, `servers`, `paths`, `components` (schemas/parameters/responses/securitySchemes), and `security`. Replace the relative `servers.url` with the public gateway base URL per environment (placeholder if unknown).
**Done when:** the guide covers every public operation with a request + response example and the full error catalog; the sanitized spec contains **no** `x-ibm-configuration`/`x-ibm-*` key and no credential value (grep to confirm), and passes `apic validate --no-extensions`.

### 7. Validate
Run the staging folder's bundled `apic.exe` on every generated file, from the staging directory as working dir:
```powershell
# working directory: D:\Neotek\Neotek API GW  (where apic.exe lives)
.\apic.exe validate inbound\apis\<name>_1.0.0.yaml         # gateway apis + products (with IBM extensions)
.\apic.exe validate inbound\products\<name>_1.0.0.yaml
.\apic.exe validate outbound\apis\<name>_1.0.0.yaml
.\apic.exe validate outbound\products\<name>_1.0.0.yaml
.\apic.exe validate --no-extensions _deliverables\<name>\<name>-client_1.0.0.yaml   # sanitized spec has no x-ibm-configuration
```
**Done when:** every file passes `apic validate` with no errors, and you have read the output back (do not report success on unseen output).

### 8. Deploy handoff (copy to the repo, then `deploy-apic`)
Building ends in staging. **Deploying is a selective copy into the git repo, then the `deploy-apic` skill** — never edit the git repo by hand beyond this copy, and never run `deploy-apic` against the staging folder.
1. Copy **only this API's deployable YAMLs** from staging `D:\Neotek\Neotek API GW` into the git repo `D:\Neotek\api-gw-apic`, preserving the same relative paths:
   - `inbound/apis/<name>_1.0.0.yaml`
   - `inbound/products/<name>_1.0.0.yaml`
   - `outbound/apis/<name>_1.0.0.yaml`
   - `outbound/products/<name>_1.0.0.yaml`
   Plus any shared policy files you actually changed (e.g. under `global-policies/`). **Never** copy `apic.exe`, `_deliverables/`, or the whole tree — only the files this build touched.
2. In the git repo, on a feature branch, commit the copied files.
3. Hand off to **`deploy-apic`** (run from inside `D:\Neotek\api-gw-apic`) to ship the env (dev/sit/uat/prod). `deploy-apic` owns branch/PR/CI mechanics from here.
**Done when:** the deployable YAMLs (and only those) exist in the git repo on a feature branch, committed and ready for `deploy-apic`.
