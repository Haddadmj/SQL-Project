<!--
CLIENT INTEGRATION GUIDE TEMPLATE. Fill every __PLACEHOLDER__ from the INBOUND
spec only. This file is shared with external clients — it must contain NOTHING
about the outbound API, upstream backend, assembly, or credential values.
-->
# __TITLE__ — Integration Guide

**Version:** 1.0.0
**Audience:** API consumers (client integrators)

## 1. Overview

__ONE_PARAGRAPH: what the API does, from the caller's point of view.__

Base path: `/__BASE_PATH__` (e.g. `/wathq/v1`). All requests and responses are `application/json`.

## 2. Environments

| Environment | Base URL |
|---|---|
| Development | `https://__DEV_GATEWAY_HOST__/__BASE_PATH__` |
| SIT | `https://__SIT_GATEWAY_HOST__/__BASE_PATH__` |
| Sandbox | `https://__SANDBOX_GATEWAY_HOST__/__BASE_PATH__` |
| Production | `https://__PROD_GATEWAY_HOST__/__BASE_PATH__` |

> Do not list internal/outbound endpoints here.

## 3. Authentication

OAuth2 **client-credentials**. Exchange your client credentials for a bearer token, then send it on every call.

1. `POST {baseURL}/oauth2security/oauth2/token` with `grant_type=client_credentials`, your `client_id`/`client_secret`, and `scope=__SCOPE__`.
2. Send `Authorization: Bearer <access_token>` on each API request.

Token limits: __e.g. at most 5 tokens/hour, 1-hour lifetime.__

## 4. Common headers

| Header | Direction | Purpose |
|---|---|---|
| `Authorization: Bearer <token>` | request | required auth |
| `x-request-id` | request → echoed | client correlation id (passed through) |
| `sub-client` | request | __identifier of the end client, if used__ |
| `THIQAH-API-ApiMsgRef` | response | unique guid per request |
| `THIQAH-API-ClientMsgRef` | response | echoes the client reference |

## 5. Endpoints

<!-- Repeat this block per operation. Reuse the request params + the success
     example straight from the inbound spec's components/responses examples. -->

### `__METHOD__ /__PATH__`

__SUMMARY__

**Path / query parameters**

| Name | In | Required | Description |
|---|---|---|---|
| __id__ | path | yes | __description__ |
| __language__ | query | no | __ar / en__ |

**Sample request**

```http
__METHOD__ https://__PROD_GATEWAY_HOST__/__BASE_PATH__/__PATH__
Authorization: Bearer <token>
```

**Sample response — 200**

```json
__PASTE_SUCCESS_EXAMPLE_FROM_SPEC__
```

## 6. Error responses

Errors return the standard envelope:

```json
{ "Errors": [ { "Code": "NTSP.ERROR.<status>.<n>", "Message": "…", "Url": "https://portal-www.neo-tek.com" } ] }
```

| HTTP | Code | Meaning |
|---|---|---|
| 400 | `400.1.1` | Input data is required |
| 400 | `400.1.x` | __other documented business validation errors__ |
| 401 | `401.1.1` | Invalid ApiKey / token |
| 403 | `403.1.1` | Insufficient privileges |
| 404 | `404.2.1` | No Results Found |
| 429 | `429.1.1` | Rate limit / quota exceeded |
| 500 | `500.x` | Internal error |

<!-- Fill 400.1.x from the inbound spec's ErrorResponse400 description list. -->

## 7. Rate limits

__From the product plan, e.g. 1000 requests / day, hard limit.__
