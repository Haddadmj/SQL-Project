# Fixed spine & conventions

Everything here is identical across every API in this project. Copy it verbatim from the templates; change only the marked holes. Do not redesign it per API.

## Directory layout & naming

Build in the staging directory `D:\Neotek\Neotek API GW` (non-git). Everything below is relative to it. The git repo (deploy target) is `D:\Neotek\api-gw-apic`; step 8 copies the deployables there.

```
D:\Neotek\Neotek API GW\        # staging (non-git) - author everything here, no GW/ prefix
  apic.exe                      # the validator to use (.\apic.exe)
  inbound/
    apis/<name>_1.0.0.yaml
    products/<name>-product_1.0.0.yaml
  outbound/
    apis/<name>_1.0.0.yaml
    products/<name>-product_1.0.0.yaml
  _deliverables/<name>/         # non-deployables - stay in staging, never copied to the repo
    <name>-integration-guide.md
    <name>-client_1.0.0.yaml
    <source>-vs-<backend>-mapping.md
```

- Deployables (`inbound/`, `outbound/`) live at the staging top level; there is **no `GW/` wrapper**. Only these get copied into the git repo at deploy (step 8). Client deliverables + the field-mapping doc go under `_deliverables/<name>/` and never leave staging.
- File suffix is always `_1.0.0.yaml` (the version).
- `info.x-ibm-name` = the api name, kebab-case, no version (e.g. `wathq-commercial-registration-api`).
- Product `apis.<key>.$ref` uses a **relative** path (`..\apis\<name>_1.0.0.yaml`).
- Outbound api names typically drop the `-api` suffix and describe the backend call (e.g. `wathq-commercial-registration`).

## FRAMEWORK logging (verbatim)

Every assembly opens and closes with framework logging, and every backend call is bracketed by IREQ/IRPLY. Never remove a log step.

```js
const Framework = require('local:/FRAMEWORK/FUNCTIONS/FRAMEWORK_FUNCTIONS.js');
Framework.FWLogReq([], [], [], []);                       // first step of main flow
Framework.FWLogIReq(`Outbound-${operationId}`, true, queryParams, []); // before an invoke
Framework.FWLogIReply(`Outbound-${operationId}`);         // after an invoke
Framework.FWLogReply();                                    // last step of main flow AND last step of every catch
Framework.FWLogError(<httpStatus>);                        // in every catch, before FWLogReply
```
`operationId = context.get('api.operation.id')`, `queryParams = context.get('request.search')`.
Label the IREQ/IRPLY with a prefix describing the call: `Outbound-`, `Token-`, `Wathq-`, etc.

## NTSP error envelope (verbatim)

Every error path returns this shape — never the raw upstream error, never an error built in the main flow:

```js
{ Errors: [ { Code: 'NTSP.ERROR.<status>.<n>', Message: <string>, Url: 'https://portal-www.neo-tek.com' } ] }
```

Codes seen in this project: `400.1.1`…`400.1.5` (validation), `500.001` (general/JS), `500.002` (connection), `502.003` (parse), `<coreStatus>.001` (core error). Validation errors also carry a `Path` (e.g. `request.id`).

## Catch-all blocks (verbatim — one per APIC error type)

The inbound `catch:` array must contain a block for **each** of these, in this spirit. Never omit one; the `default` is the safety net, not a replacement.

| Error class | HTTP | Code | Meaning |
|---|---|---|---|
| `ConnectionError` | 500 | `NTSP.ERROR.500.002` | couldn't reach the outbound/upstream |
| `CoreError` | `$(coreErrorCode)` | `NTSP.ERROR.<status>.001` | upstream returned a non-200 (rejected in *Process Response*) |
| `ValidationError` | 400 | per-field `NTSP.ERROR.400.x` | input failed validation (rejected in *Validate Request*) |
| `JavaScriptError` | 500 | `NTSP.ERROR.500.001` | a gatewayscript step threw |
| `ParseError` | 502 | `NTSP.ERROR.502.003` | a `parse` policy hit a malformed payload |
| `default` | 500 | `NTSP.ERROR.500.001` | anything else |

Each catch block: build the NTSP body → `FWLogError(status)` → `FWLogReply()`.

The main flow **rejects** into these with `context.reject('<ErrorClass>', '<message>')` and stashes context (`validationErrors`, `coreErrorCode`) for the catch to read. Build no error body outside a catch.

## Security schemes (verbatim)

**Inbound** — OAuth2 client-credentials:
```yaml
securitySchemes:
  NativeOAuth2Security:
    type: oauth2
    x-ibm-oauth-provider: oauth2security
    flows:
      clientCredentials:
        tokenUrl: "{baseURL}/oauth2security/oauth2/token"
        scopes: { <scope>: <desc> }
security:
  - NativeOAuth2Security: [ <scope> ]
```

**Outbound** — apiKey pair the inbound sends:
```yaml
securitySchemes:
  clientSecret: { type: apiKey, x-key-type: client_secret, name: client_secret, in: header }
  clientId:     { type: apiKey, x-key-type: client_id,     name: client_id,     in: header }
security:
  - clientId: []
    clientSecret: []
```

The inbound sends these to the outbound in *Build backend request*:
```js
context.set('message.headers.client_id', context.get('clientId'));
context.set('message.headers.client_secret', context.get('clientSecret'));
```

## THIQAH headers & request-id

Error responses declare `THIQAH-API-ApiMsgRef` and `THIQAH-API-ClientMsgRef` (uuid) headers. The main flow's *Build Response Headers* forces `content-type: application/json` and passes through `x-request-id`:
```js
var reqId = context.get('request.headers.x-request-id');
context.set('message.headers.content-type', 'application/json');
if (reqId) { context.set('message.headers.x-request-id', reqId); }
```

## Caching (opt-in, inbound only)

Caching is **off by default**. Enable it on the *Invoke Outbound* step only when the backend response is a pure function of identifying inputs.

```yaml
- invoke:
    ...
    target-url: $(outbound-url)
    cache-response: time-to-live      # add these 4 lines only when caching is enabled
    cache-putpost-response: true      # REQUIRED: POST responses are not cached otherwise
    cache-ttl: 3600
    cache-key: $(cacheKey)
```

**The cache key must be custom** because the backend call is a POST — the identifying values live in the request *body*, not the URL, so protocol/URL caching cannot see them and would collide or never hit. Build the key from exactly the inputs the response depends on, set in *Build backend request*:

```js
// Response depends only on id + language, so one cached entry per id:language
// serves every operation that reads the same backend report.
context.set('cacheKey', id + ':' + language);
```

Rules:
- Include every input that changes the backend response; exclude anything that doesn't (e.g. the operation name, when all ops read the same backend payload and only the transform differs).
- Never include secrets or the raw token in the key.
- Default TTL 3600s; match it to how fresh the data must be.

## Per-catalog properties

Declare each env-specific value once under `properties`, then override per catalog. Inbound catalogs: `neotek-dev`, `neotek-sit`, `neotek-sandbox`, `neotek`. Outbound catalogs: `neotek-core-dev`, `neotek-core-sit`, `neotek-core-sandbox`, `neotek-core`.

```yaml
properties:
  outbound-url: { value: <default>, description: ..., encoded: false }
  clientId:     { value: <default>, ... }
  clientSecret: { value: <default>, ... }
catalogs:
  neotek-dev:  { properties: { outbound-url: <dev-url>,  clientId: ..., clientSecret: ... } }
  neotek-sit:  { properties: { outbound-url: <sit-url>,  ... } }
  ...
activity-log: { enabled: true, success-content: activity, error-content: payload }
```
Reference a property in the assembly as `$(name)` (invoke target-url) or `context.get('name')` (gatewayscript).
