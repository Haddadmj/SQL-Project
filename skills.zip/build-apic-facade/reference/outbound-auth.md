# Outbound auth variants

The outbound API acquires upstream credentials, then calls the real backend. The acquisition steps differ per backend — **do not assume Basic→JWT**. Pick the variant that matches the upstream, fill it into the `# >>> FILL: AUTH ACQUISITION` hole in `templates/outbound-api.yaml`, and store secrets as per-catalog properties.

## Variant A — Basic → JWT → Bearer (two calls)

Upstream issues a short-lived JWT from a Basic-auth token endpoint; you then call the real endpoint with `Authorization: Bearer <jwt>`. This is the Bayan pattern.

```yaml
- gatewayscript:
    title: Set Basic Auth
    source: |
      context.clear('message.headers');
      context.set('message.headers.Authorization', 'Basic ' + context.get('bayan-basic-auth'));
- gatewayscript: { title: Log Token IREQ, source: <FWLogIReq `Token-${operationId}`> }
- invoke:
    title: Get JWT
    verb: GET
    target-url: $(bayan-token-url)
    cache-response: protocol      # cache the token by protocol headers
    cache-ttl: 3600
    stop-on-error: [ ConnectionError ]
    output: tokenResponse
- parse: { title: parse, input: tokenResponse, output: tokenResponseParsed,
           parse-settings-reference: { default: apic-default-parsesettings } }
- gatewayscript: { title: Log Token IRPLY, source: <FWLogIReply `Token-${operationId}`> }
- gatewayscript:
    title: Set Bearer Token
    source: |
      var tokenBody = context.get('tokenResponseParsed.body');
      var jwt = (tokenBody && tokenBody.jwt) || '';
      context.clear('message.headers');
      context.set('message.headers.authorization', 'Bearer ' + jwt);
      context.set('message.headers.content-type', 'application/json');
      context.set('message.headers.accept', 'application/json');
```
Properties: `bayan-basic-auth` (base64 of `user:pass`), `bayan-token-url`, `bayan-report-url`.

## Variant B — client_id / client_secret headers (no token call)

Upstream authenticates on the real call itself via an apiKey pair — no separate token round-trip. Just set the headers before the invoke.

```yaml
- gatewayscript:
    title: Set Client Credentials
    source: |
      context.clear('message.headers');
      context.set('message.headers.client_id', context.get('upstream-client-id'));
      context.set('message.headers.client_secret', context.get('upstream-client-secret'));
      context.set('message.headers.content-type', 'application/json');
      context.set('message.headers.accept', 'application/json');
```
Properties: `upstream-client-id`, `upstream-client-secret`, `upstream-url`. No `parse`/token steps.

## Variant C — OAuth2 client-credentials (token call, then Bearer)

Upstream is a standard OAuth2 CC provider: POST `client_id`/`client_secret` (form or JSON) to a token URL, read `access_token`, call with `Bearer`.

```yaml
- gatewayscript:
    title: Build Token Request
    source: |
      context.clear('message.headers');
      context.set('message.headers.content-type', 'application/x-www-form-urlencoded');
      context.message.body.write(
        'grant_type=client_credentials&client_id=' + context.get('upstream-client-id') +
        '&client_secret=' + context.get('upstream-client-secret'));
- invoke: { title: Get Token, verb: POST, target-url: $(upstream-token-url),
            cache-response: protocol, cache-ttl: 3600, stop-on-error: [ ConnectionError ], output: tokenResponse }
- parse: { input: tokenResponse, output: tokenResponseParsed,
           parse-settings-reference: { default: apic-default-parsesettings } }
- gatewayscript:
    title: Set Bearer Token
    source: |
      var t = context.get('tokenResponseParsed.body');
      context.clear('message.headers');
      context.set('message.headers.authorization', 'Bearer ' + ((t && t.access_token) || ''));
      context.set('message.headers.content-type', 'application/json');
```
Properties: `upstream-client-id`, `upstream-client-secret`, `upstream-token-url`, `upstream-url`.

## Shared rules

- Every token/upstream `invoke` uses `stop-on-error: [ ConnectionError ]` so a dead backend routes to the ConnectionError catch.
- Cache tokens (`cache-response: protocol`, `cache-ttl` ≈ token lifetime) so you don't re-auth every call.
- Bracket both the token call and the upstream call with `FWLogIReq`/`FWLogIReply` (labels `Token-…`, `Upstream-…`).
- Secrets live only in per-catalog properties — never inline in the assembly.
