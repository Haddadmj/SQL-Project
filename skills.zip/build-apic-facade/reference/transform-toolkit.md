# Transform toolkit — *transforming façades only*

Skip this entire file for a **pass-through** façade (no reshaping — the inbound returns the backend response as-is). Use it only when the target contract genuinely differs from the backend shape.

How to turn the field-mapping doc into the inbound *Transform to target* gatewayscript. The mapping doc is the spec; this toolkit is the mechanics.

## Field-mapping doc structure

`<source>-vs-<backend>-mapping.md`, one section per target endpoint, each a table:

| Target field / path | Backend path | Match | Notes |
|---|---|---|---|

Match legend — this drives the transform:
- **✅ Direct** — same name, same shape → `pick`/`idName` straight across.
- **⚠️ Type/required/structure diff** — needs explicit handling: numeric cast, trim a sub-object down (e.g. dated `status` → `{id,name}`), or **unwrap** a nested array up to the root (root `managers[]` ← backend `management.managers[]`).
- **❌ Missing in backend** — no source. **Omit** from output; note it as a genuine data gap.
- **➕ Backend-only extra** — ignore for this direction.

Also record, above the tables: the full **envelope path** from the backend response root down to the object that mirrors the target (e.g. `CB_Compact_ProductResponse → ProductResponse[0] → CB_Compact_ProductOutput → entityInfo → latestInfo`).

## Helper toolkit (copy verbatim)

Every transformer is built from these. They drop null/undefined keys so the output stays clean and matches "field absent" semantics.

```js
var clean = function (obj) {
  var out = {};
  Object.keys(obj).forEach(function (k) { if (obj[k] != null) { out[k] = obj[k]; } });
  return out;
};
var pick = function (src, keys) {          // pull a fixed key list, dropping nulls
  if (!src) { return undefined; }
  var o = {};
  keys.forEach(function (k) { o[k] = src[k]; });
  return clean(o);
};
var list = function (arr, fn) { return Array.isArray(arr) ? arr.map(fn) : undefined; };

// tiny reusable object mappers
var idName   = function (s) { return pick(s, ['id', 'name']); };
var date     = function (s) { return pick(s, ['gregorian', 'hijri']); };
var identity = function (s) { return pick(s, ['id', 'typeId', 'typeName']); };
```

## Navigation + dispatch pattern

1. **Navigate the envelope** to the mirror object with a null-safe getter:
```js
var getLatestInfo = function (res) {
  return res && res.CB_Compact_ProductResponse
      && res.CB_Compact_ProductResponse.ProductResponse
      && res.CB_Compact_ProductResponse.ProductResponse[0]
      && res.CB_Compact_ProductResponse.ProductResponse[0].CB_Compact_ProductOutput
      && res.CB_Compact_ProductResponse.ProductResponse[0].CB_Compact_ProductOutput.entityInfo
      && res.CB_Compact_ProductResponse.ProductResponse[0].CB_Compact_ProductOutput.entityInfo.latestInfo;
};
```
2. **One transformer per operation**, composed from the helpers. Compose small mappers (`entityType`, `capital`, `party`, `manager`…) for nested objects; keep a top-level key list per shape (`FULL_KEYS`, `INFO_KEYS`).
3. **Dispatch** on the resolved operation, then set status + body:
```js
var op = context.get('op');
var bayan = context.get('message.body');
if (typeof bayan === 'string') { try { bayan = JSON.parse(bayan); } catch (e) { bayan = null; } }

var result;
if (op === 'managers') { result = transformManagers(bayan); }   // array ops → [] when empty
else if (op === 'owners') { result = transformOwners(bayan); }
else if (op === 'info')   { result = transformInfo(bayan); }
else                      { result = transformFullInfo(bayan); }

context.clear('message.headers');
context.set('message.headers.content-type', 'application/json');
if (result === undefined) {                                     // object ops → 404 when no data
  context.set('message.status.code', 404);
  context.message.body.write({ code: '404.2.1', message: 'No Results Found' });
} else {
  context.set('message.status.code', 200);
  context.message.body.write(result);
}
```

## Rules that keep transforms deterministic

- **Array ops return `[]`, never 404** (managers/owners); **object ops return 404** when the mirror object is absent (fullinfo/info).
- **Trim, don't invent**: for a ⚠️ "flat vs dated" field, `pick` only the kept keys (`idName(s.status)`), never fabricate absent sub-objects.
- **Unwrap** ⚠️ root-vs-nested by reading the nested path and returning it at the root (`list(s.management && s.management.managers, manager)`).
- **Omit ❌ gaps** — do not emit a null placeholder for fields with no backend source.
- Guard every navigation with `&&` so normal "missing" data yields `undefined` (→ 404), while a genuine runtime fault still surfaces as a `JavaScriptError` catch. Don't swallow errors.
