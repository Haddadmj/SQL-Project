---
name: deploy-apic
description: "Use this skill when the user wants to deploy or promote IBM API Connect products/APIs from the api-gw-apic mono-repo (bitbucket.neotek.sa, project APIGW) to a Neotek environment. Trigger on slash form `/deploy-apic <env>` or natural-language phrases like 'deploy the gateway to dev', 'ship the apic product to SIT', 'cut an apic release', 'promote the gateway to UAT', 'release api-gw to prod', 'bump the sit tag for api-gw-apic'. Each env has different mechanics: DEV merges feature into `dev` (jenkins-bot auto-bumps dev/values.yaml), SIT cuts `release/<name>` from the feature's merge-base on main and bumps `sit/values.yaml` after CI tags, UAT bumps `uat/values.yaml`, PROD bumps `promotion/values.yaml` (jenkins-bot fans out to prod + dr). Do NOT use this skill for: the Java/service repos (that's `deploy`), drafting CR paperwork (that's `neotek-cr`), authoring new APIC apis/products (that's `build-apic-facade`), rollbacks, or manual `apic products:publish` to a catalog. This skill is APIGW-only (repo `api-gw-apic`, project `APIGW`); for value-bumps in OB-project gitops repos use `gitops-values-pr` instead."
---

# /deploy-apic - api-gw-apic (IBM APIC gateway) deployment skill

Single command. Run **from inside the api-gw-apic repo** (`https://bitbucket.neotek.sa/scm/apigw/api-gw-apic.git`). The repo is a mono-repo of APIC products/apis; deployment is GitOps-driven: CI (Jenkins `apigw_apicCiPipeline`) validates + tags, CD (`apigw_apicCdAdapter` on the `gitops` branch) publishes whatever tag each env's `values.yaml` points at.

```
/deploy-apic dev    # PR feature -> dev; auto-merge. jenkins-bot bumps dev/values.yaml itself.
/deploy-apic sit    # cut release/<name> from the feature's merge-base on main; wait for CI tag; bump sit/values.yaml; auto-merge gitops PR
/deploy-apic uat    # bump uat/values.yaml; PR to gitops; print URL (user merges manually)
/deploy-apic prod   # bump promotion/values.yaml ONLY; PR to gitops; print URL (user merges manually; fans out to PROD + DR)
```

## How this repo differs from the service repos (`/deploy`)

- **No app version / pom.xml.** Releases are identified by a free-form RELEASE_NAME (`release/<name>` branch), not semver. The deployable artifact is the git tag CI creates: `release-<name>-<short-sha>` (dev builds: `dev-<short-sha>`).
- **gitops is a branch of the SAME repo**, not a separate repo. Use a sibling worktree.
- **dev/values.yaml is bumped by jenkins-bot automatically** after CI on `dev` - never bump it by hand.
- **prod/ and dr/ are bumped by jenkins-bot** from `promotion/values.yaml` - never touch prod/ or dr/ directly.
- Each `values.yaml` is a single line: `tag: <image-tag>`.
- Env → catalogs: dev → `neotek-dev`/`neotek-core-dev`/`public-gw-dev`; sit → `neotek-sit`/`neotek-core-sit`/`public-gw-sit`; **uat → `neotek-sandbox`/`neotek-core-sandbox`/`public-gw-sandbox`** (naming quirk); prod → `neotek`/`neotek-core`/`public-gw`.

## Prerequisites

- Bitbucket bearer token in the user env var `BITBUCKET_NEOTEK_TOKEN` (see "Credentials" below). If empty, stop and ask the user for one (Bitbucket -> Manage account -> HTTP access tokens).
- Caller's CWD is the api-gw-apic source repo (main-line checkout, not the gitops worktree). On this machine that is `D:\Neotek\api-gw-apic`. New/changed APIC files are authored in the staging tree `D:\Neotek\Neotek API GW` via `build-apic-facade` and copied onto the feature branch here before this skill runs; `deploy-apic` never reads the staging tree.
- Sibling gitops worktree exists at `<source-dir>-gitops` with the `gitops` branch checked out. If missing, offer to create it:
  ```
  git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$SOURCE_DIR" fetch origin gitops
  git -C "$SOURCE_DIR" worktree add "${SOURCE_DIR}-gitops" gitops   # local; no remote call
  ```

## Globals (set once at start)

```
BB_HOST=bitbucket.neotek.sa
BB_USER=alhaddadmc          # PR-author display only; auth is the bearer token, so login casing is irrelevant - see "Credentials"
BRANCH_PREFIX=alhaddadmc    # matches existing branch convention (alhaddadmc/values.yaml-*)
SOURCE_DIR=$(git rev-parse --show-toplevel)
GITOPS_DIR="${SOURCE_DIR}-gitops"   # only required for SIT/UAT/PROD
PROJECT=APIGW
SLUG=api-gw-apic
BB_TOKEN="$BITBUCKET_NEOTEK_TOKEN"  # bearer for BOTH curl and git; if empty, stop and ask (see Credentials)
```

### Repo fence (run first - APIGW only)

This skill only operates on `api-gw-apic`. Before anything else, confirm the source repo's origin is that repo; if not, stop and hand off:

```
git -C "$SOURCE_DIR" remote get-url origin | grep -qi 'apigw/api-gw-apic' \
  || { echo "deploy-apic is APIGW-only (repo api-gw-apic). This repo is not it - for OB-project value bumps use gitops-values-pr; for the Java/service repos use /deploy."; exit 1; }
```

### Gitops dir check (SIT, UAT, PROD only - DEV skips this)

The sibling may be a worktree (`.git` is a file, not a directory), so test with:

```
git -C "$GITOPS_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "Expected gitops worktree at $GITOPS_DIR (cwd is $SOURCE_DIR). Offer to create it with: git worktree add \"$GITOPS_DIR\" gitops"; }
```

Confirm the worktree has `gitops` checked out (`git -C "$GITOPS_DIR" rev-parse --abbrev-ref HEAD`); if not, stop and tell the user.

## Credentials

Both the REST calls and the git operations authenticate with the **same bearer token** in the user env var `BITBUCKET_NEOTEK_TOKEN` (captured as `BB_TOKEN` in Globals). This mirrors `gitops-values-pr` so the two skills share one auth story.

- **If `BB_TOKEN` is empty, stop and ask the user for a token** (Bitbucket -> Manage account -> HTTP access tokens). Do not fall back to `~/.netrc`, `git credential fill`, or the OS credential store.
- **git over HTTPS**: never embed the token in the remote URL. Pass it as a header on every git command that reaches the remote (`fetch`, `push`, `ls-remote`, `worktree add` from a remote ref, `clone`):
  ```
  git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$DIR" <fetch|push|ls-remote|...> ...
  ```
  Purely local git (checkout, merge, commit, rev-parse, show, log) needs no header.
- **Never print the token.**

## Curl helper

Use `curl -sS -H "Authorization: Bearer $BB_TOKEN" --fail-with-body -H 'Content-Type: application/json'` for every Bitbucket call. Don't pass credentials any other way. `--fail-with-body` needs curl >= 7.76; if unavailable, add `-w '\n%{http_code}'` and check the trailing status yourself. On any non-2xx response, print the body verbatim prefixed `Bitbucket API error:` and exit. **Never silently fall back.**

### Connection errors (VPN)

`bitbucket.neotek.sa` is on Neotek's internal network. On connection-level errors (curl exit 6/7/28/35, or git failures with "Could not resolve host" / "Connection refused" / "Connection timed out"), stop immediately:

```
Can't reach bitbucket.neotek.sa - check that you're connected to the Neotek VPN, then rerun.
```

Don't retry connection errors. Distinguish from HTTP 4xx/5xx (request reached the server; print body verbatim).

## Always-asked input

At the start of every run, before touching any branch:

1. **Which feature branch?** Default to the current branch in `$SOURCE_DIR`. User confirms or types another.
2. **(SIT only) Release name?** Suggest `<yyyy-mm-dd>-<feature-short>` (existing convention, e.g. `2026-07-01-gosi-ncgr-30-days-ttl`). This becomes `release/$RELEASE_NAME` and the image tag `release-$RELEASE_NAME-<short-sha>`. A release name that was already pushed cannot be reused - check `git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" ls-remote --heads origin "release/$RELEASE_NAME"` and ask for a new name if it exists.

### Optional pre-flight validation (recommended, all envs)

If an `apic` CLI is available locally, validate the product files the feature touches before pushing (CI will do it anyway, but this catches failures without a round-trip):

```
git -C "$SOURCE_DIR" diff --name-only origin/main..."$FEATURE" -- '*/products/*.yaml' '*/apis/*.yaml'
apic validate <each changed product yaml>    # products validate their referenced apis too
```

Also check the repo rules CI enforces: every referenced API has all four `x-ibm-configuration.catalogs` entries, and no product `.info.name` equals a referenced API's `.info.x-ibm-name`.

## Auto-merge helper (DEV and SIT only)

DEV and SIT merge their PR automatically. UAT and PROD never do (print the URL and stop).

The `devsensei-service-user` code-owners bot adds a reviewer and bumps the PR **version** within a second of creation, so the `version` captured from the create response is usually already stale. A merge with a stale version returns **HTTP 409 `PullRequestOutOfDateException`** whose body carries the new `currentVersion`. That 409 is a benign race, not a block. Handle it:

1. Before merging, first check `GET .../pull-requests/$ID/merge` -> if `vetoes` is non-empty or `canMerge` is false, this is a real block (approval / build check / CODEOWNERS). **Stop, print the vetoes verbatim, tell the user to merge in the UI.** Do NOT retry.
2. Merge: `POST .../pull-requests/$ID/merge?version=$VERSION` with body `{}`.
3. On **409 with `PullRequestOutOfDateException`**: read `currentVersion` from the error body (or re-GET the PR's `version`) and retry the merge once with that version. Allow up to 3 attempts total (the bot may bump again); between attempts re-read the version.
4. On any **other non-2xx**, or if still 409 after 3 tries: print the body verbatim prefixed `Bitbucket API error:` and exit; the PR stays open for manual merge.
5. Success is the response `"state":"MERGED"` (HTTP 200).

---

## DEV flow

1. Push feature: `git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$SOURCE_DIR" push origin "$FEATURE"` (no-op if up to date). Pushing a `feat/`/`fix/` branch triggers validation-only CI.
2. Create PR (`POST /rest/api/1.0/projects/$PROJECT/repos/$SLUG/pull-requests`) with body:
   ```json
   {
     "title": "Merge <FEATURE> to dev",
     "description": "",
     "fromRef": {"id": "refs/heads/<FEATURE>", "repository": {"slug": "api-gw-apic", "project": {"key": "APIGW"}}},
     "toRef":   {"id": "refs/heads/dev",        "repository": {"slug": "api-gw-apic", "project": {"key": "APIGW"}}}
   }
   ```
3. From the response capture `id`, `version`, and the self link from `links.self[0].href`.
4. Merge via the **Auto-merge helper** above (handles the 409 version-race retry). On a real block or repeated failure it exits with the PR left open.
5. **Do not touch gitops.** Print PR URL and:
   ```
   CI will validate, tag dev-<short-sha>, and jenkins-bot bumps dev/values.yaml automatically. CD then publishes to the dev catalogs (neotek-dev, neotek-core-dev, public-gw-dev).
   ```
6. Optional: poll `GET /rest/build-status/1.0/commits/<merge-commit-sha>` (same loop as SIT step 5) and report the CI result, but the deploy itself needs no further action.

---

## SIT flow

1. Use `RELEASE_NAME` from "Always-asked input". If `release/$RELEASE_NAME` already exists on remote, that name was already cut; go back and pick a new one.
2. In the source repo, cut the release from the **commit where the feature branched off main** (the merge-base of `main` and the feature), NOT from main's current tip, NOT from the feature branch, NOT from dev. Cutting from the merge-base keeps the release limited to the feature's own changes and excludes unrelated work that landed on main after the feature diverged. CI later merges the release tag back into `main` itself (`Merge tag ... into main [ci skip]`), so main stays current:
   ```
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$SOURCE_DIR" fetch origin
   # Base = the commit the feature started from on main (main's starting commit for this feature), not main's tip.
   BASE_SHA=$(git -C "$SOURCE_DIR" merge-base origin/main "origin/$FEATURE")
   git -C "$SOURCE_DIR" checkout -b "release/$RELEASE_NAME" "$BASE_SHA"
   git -C "$SOURCE_DIR" merge --no-ff "origin/$FEATURE" -m "Merge $FEATURE into release/$RELEASE_NAME"
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$SOURCE_DIR" push -u origin "release/$RELEASE_NAME"
   ```
   If the merge conflicts, stop and show the user; do not force or auto-resolve.
3. Capture commit refs:
   ```
   FULL_SHA=$(git -C "$SOURCE_DIR" rev-parse HEAD)
   SHORT_SHA=$(git -C "$SOURCE_DIR" rev-parse --short=7 HEAD)
   IMAGE_TAG="release-$RELEASE_NAME-$SHORT_SHA"
   ```
4. Print: `Polling CI for $FULL_SHA. Up to 10 minutes (60s intervals).`
5. Poll loop, max 10 iterations, 60s between:
   - `GET /rest/build-status/1.0/commits/$FULL_SHA` - inspect `values[*].state`.
     - Any `SUCCESSFUL` -> proceed.
     - Any `FAILED` -> print and exit.
     - Else (`INPROGRESS` or empty) -> sleep 60 and retry.
   - On timeout: print last state seen and exit (`CI still not SUCCESSFUL after 10 min. Rerun /deploy-apic sit once green.`).
   - **Implementation note**: prefer `ScheduleWakeup(delaySeconds=60)` if available; otherwise plain `sleep 60`.
6. Confirm the tag landed: `GET /rest/api/1.0/projects/$PROJECT/repos/$SLUG/tags?filterText=$IMAGE_TAG`. Zero values -> warn but continue (build was green).
7. Update gitops (in the worktree):
   ```
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$GITOPS_DIR" fetch origin
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$GITOPS_DIR" pull --ff-only origin gitops
   git -C "$GITOPS_DIR" checkout -b "$BRANCH_PREFIX/values-$RELEASE_NAME-sit"
   ```
   Use the Edit tool on `$GITOPS_DIR/sit/values.yaml`: the file is a single line; set it to `tag: $IMAGE_TAG`.
   ```
   git -C "$GITOPS_DIR" add sit/values.yaml
   git -C "$GITOPS_DIR" commit -m "Bump SIT to $IMAGE_TAG"
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$GITOPS_DIR" push -u origin "$BRANCH_PREFIX/values-$RELEASE_NAME-sit"
   ```
8. Create gitops PR (same repo):
   ```
   fromRef: refs/heads/$BRANCH_PREFIX/values-$RELEASE_NAME-sit
   toRef:   refs/heads/gitops
   title:   "Deploy $RELEASE_NAME to SIT"
   ```
9. Merge via the **Auto-merge helper** above. It pre-checks vetoes (the gitops branch has CODEOWNERS; a required approval or build check is a real block -> stop and tell the user) and absorbs the 409 version-race the code-owners bot triggers right after PR creation.
10. Print PR URL + `CD will publish $IMAGE_TAG to the SIT catalogs (neotek-sit, neotek-core-sit, public-gw-sit).`

---

## UAT flow

1. Ask the user for `RELEASE_NAME` (used only for branch/PR naming; the tag drives the deploy).
2. Determine default tag:
   ```
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$GITOPS_DIR" fetch origin
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$GITOPS_DIR" pull --ff-only origin gitops
   ```
   Read the tag from `$GITOPS_DIR/sit/values.yaml`. Confirm: "Promote SIT's `<TAG>` to UAT?" Allow override (any existing `release-*` tag).
3. `git -C "$GITOPS_DIR" checkout -b "$BRANCH_PREFIX/values-$RELEASE_NAME-uat"`.
4. Edit `$GITOPS_DIR/uat/values.yaml`: single line, `tag: $IMAGE_TAG`.
5. Commit and push:
   ```
   git -C "$GITOPS_DIR" add uat/values.yaml
   git -C "$GITOPS_DIR" commit -m "Bump UAT to $IMAGE_TAG"
   git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$GITOPS_DIR" push -u origin "$BRANCH_PREFIX/values-$RELEASE_NAME-uat"
   ```
6. Create PR `Deploy $RELEASE_NAME to UAT` from that branch to `gitops`.
7. **Do not merge.** Print PR URL + `Waiting on approvals. Merge in Bitbucket UI when ready. UAT publishes to the sandbox catalogs (neotek-sandbox, neotek-core-sandbox, public-gw-sandbox).` Exit.

---

## PROD flow

Identical to UAT except:

- Default `IMAGE_TAG` source: `$GITOPS_DIR/uat/values.yaml` (the tag UAT is running). Confirm with user.
- Branch: `$BRANCH_PREFIX/values-$RELEASE_NAME-prod`.
- File touched: **`$GITOPS_DIR/promotion/values.yaml` only.** Do NOT touch `prod/values.yaml` or `dr/values.yaml` - jenkins-bot syncs both from `promotion/values.yaml` (commits appear as `Bump 'prod,dr' image tag ...`).
- Commit message: `Promote $IMAGE_TAG to PROD + DR`.
- PR title: `Deploy $RELEASE_NAME to PROD`.
- Don't merge. Print PR URL. Exit.

---

## First-time products

If the release contains a **new product** (not yet published in the target catalog), remind the user after the deploy lands: consumer applications need a **manual subscription** to the new product in that catalog (one-time, per the repo README). Detect this cheaply: the product file is new in the diff (`git diff --name-only --diff-filter=A origin/main..."$FEATURE" -- '*/products/*'`).

## Progress tracking and resume (deploy interrupted or failed)

A run can stop partway - CI fails, a usage limit hits, VPN drops, an approval blocks a merge. Branches are **never deleted** to recover (remote `release/*` is permission-protected, and a normal user cannot remove it). Instead the skill is resumable: it reconstructs where it stopped from what already exists on the remote, and moves forward.

**On every run, before cutting anything, detect prior progress** and report it as a short checklist (done / not done), then continue only from the first incomplete step:

```
git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" -C "$SOURCE_DIR" fetch origin --prune
git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" ls-remote --heads origin "feat/$FEATURE"              # feature pushed?
git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" ls-remote --heads origin "release/$RELEASE_NAME"      # release cut?
# CI/tag for the release HEAD:
GET /rest/build-status/1.0/commits/$FULL_SHA              # build SUCCESSFUL / FAILED / INPROGRESS?
GET /rest/api/1.0/projects/$PROJECT/repos/$SLUG/tags?filterText=$IMAGE_TAG   # tag landed?
git -C "$GITOPS_DIR" show origin/gitops:sit/values.yaml   # local read; already bumped to $IMAGE_TAG?
git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" ls-remote --heads origin "$BRANCH_PREFIX/values-$RELEASE_NAME-sit"       # gitops PR branch exists?
```

Map results to the SIT flow steps:

- release branch exists + CI SUCCESSFUL + tag present -> skip straight to the gitops bump (step 7).
- gitops `sit/values.yaml` already equals `$IMAGE_TAG` on `origin/gitops` -> the bump is merged; deploy is complete, report and stop.
- gitops values-branch exists but not merged -> find its open PR (`GET .../pull-requests?at=refs/heads/<branch>&direction=OUTGOING`) and continue from the merge step, do not re-push.

**If the problem is a bad build (wrong files / bad tag), do NOT try to delete the release.** Fix forward:

1. Commit the fix onto the **same** `release/$RELEASE_NAME` branch (or merge an updated feature into it). CI re-runs and produces a **new** `release-$RELEASE_NAME-<new-short-sha>` tag.
2. Bump `sit/values.yaml` to that new tag via a fresh gitops PR (a `-sit-2` suffixed branch if the first values-branch is still open).
3. To roll SIT back to the last good image instead, cut a gitops PR setting `sit/values.yaml` to the previous tag (recover it from `git -C "$GITOPS_DIR" log --oneline -p sit/values.yaml`). Never edit `gitops` directly.

Only a **brand-new** RELEASE_NAME (never a reused one) justifies re-cutting from `main`; the old release branch is simply left behind, superseded.

## Output style

- No em-dashes anywhere (PR titles, descriptions, commit messages, chat output). Use hyphens, commas, or "or".
- Print compact status lines as you go (`Pushed release/2026-07-12-pre-eligibility`, `CI SUCCESSFUL`, `PR #412 created`, etc.).
- Errors: print the Bitbucket response body verbatim, prefixed `Bitbucket API error:`. Don't paraphrase.

## Safety rules

- Never push to `main`, `dev`, or `gitops` directly. Always via PR.
- Never bump `dev/values.yaml`, `prod/values.yaml`, or `dr/values.yaml` by hand - those are jenkins-bot's.
- Never delete branches. Remote `release/*` branches are permission-protected anyway (a normal user cannot delete them); a scrapped release is superseded by cutting a new RELEASE_NAME, never by deletion.
- Before pushing a new branch, verify it doesn't already exist on remote (`git -c http.extraHeader="Authorization: Bearer $BB_TOKEN" ls-remote --heads origin "$NAME"`). If it does, ask the user before reusing or suffixing.
- Don't rerun a step that already succeeded. On a rerun after partial success, detect the existing `release/$RELEASE_NAME` and gitops branch and ask whether to continue from where it stopped.
- If `git push` fails because the remote ref exists with different content, **stop and show the user.** Don't `--force`.
- The gitops worktree shares the repo with `$SOURCE_DIR`: never check out `gitops` in the source dir or a source branch in the worktree.

## Out of scope

- Polling UAT/PROD PRs for approvals.
- Rollback flow (editing values.yaml back to an older tag is manual).
- Manual `apic products:publish` / `products:delete` against catalogs (CI/CD owns publishing; the apic CLI is for local validation only).
- The service repos (qaemabanking etc.) - use `/deploy`.
